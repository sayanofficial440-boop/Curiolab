<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Learning content sync (quizzes, Active Recall, games, exams)

Lesson pages under `public/pages/<subject>/` are the **single source of truth**.
Each carries `data-card-deck` (flashcards), `data-slide-deck` and `data-quiz-data` (quiz) JSON blocks.

After adding or editing **any** lesson, run:

```sh
npm run sync:learning        # or: npm run sync:learning:watch while authoring
```

This keeps everything downstream current, so never hand-edit the generated files:

| Output | Consumer |
| --- | --- |
| `data-quiz-data` in lessons with fewer than 20 hand-written questions is topped up with flashcard-derived questions tagged `"auto": true` (rebuilt every run) | lesson Quiz tab |
| `public/js/bank/bank-recall.js` | `pages/active-recall.html`, `js/active-recall.js` |
| `public/js/bank/bank-games.js` | all 10 games on `pages/play.html` |
| `public/js/bank/bank-exams.js` | `pages/exams.html` (Exam Center: all papers draw from it) |
| `public/data/learning-index.json` | per-lesson counts (manifest) |

`npm run dev` and `npm run build` run the sync automatically; `npm run sync:learning:check` exits 1 if anything is stale (use it in CI).
A new subject folder is picked up automatically. Hand-write at least 10 flashcards per lesson; the sync warns when a lesson cannot reach the quiz target.
