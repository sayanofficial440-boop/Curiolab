#!/usr/bin/env python3
"""Generates the Curio Lab cheat-sheet PDFs + public/notes/notes.json.
Run: python3 tools/make_notes.py   (needs reportlab and the DejaVu Sans fonts)"""
import json, os
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle, KeepTogether
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

FD = "/usr/share/fonts/truetype/dejavu/"
for n, f in [("DV", "DejaVuSans.ttf"), ("DV-B", "DejaVuSans-Bold.ttf"), ("DV-I", "DejaVuSans-Oblique.ttf"), ("DV-BI", "DejaVuSans-BoldOblique.ttf"), ("DVM", "DejaVuSansMono.ttf")]:
    pdfmetrics.registerFont(TTFont(n, FD + f))
pdfmetrics.registerFontFamily("DV", normal="DV", bold="DV-B", italic="DV-I", boldItalic="DV-BI")

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "public", "pages", "notes")
os.makedirs(OUT + "/pdf", exist_ok=True)
SUBJ = {"Physics": "#5b4bdb", "Chemistry": "#d0541c", "Biology": "#12805c", "Mathematics": "#0f7fb5"}

body = ParagraphStyle("b", fontName="DV", fontSize=9, leading=12.5, textColor=colors.HexColor("#1b2033"))
small = ParagraphStyle("s", parent=body, fontSize=8, leading=10.5, textColor=colors.HexColor("#5d6580"))
lab = ParagraphStyle("l", parent=body, fontName="DV-B", fontSize=8.8)
frm = ParagraphStyle("f", parent=body, fontName="DV", fontSize=9.4, leading=13)
th = ParagraphStyle("th", parent=body, fontName="DV-B", fontSize=8.6, textColor=colors.white)
td = ParagraphStyle("td", parent=body, fontSize=8.6, leading=11.5)

def make(sheet):
    c = colors.HexColor(SUBJ[sheet["subject"]])
    path = f'{OUT}/pdf/{sheet["id"]}.pdf'
    def deco(cv, doc):
        cv.saveState()
        cv.setFillColor(c); cv.rect(0, A4[1] - 26 * mm, A4[0], 26 * mm, stroke=0, fill=1)
        cv.setFillColor(colors.white); cv.setFont("DV-B", 17); cv.drawString(15 * mm, A4[1] - 14 * mm, sheet["title"])
        cv.setFont("DV", 9); cv.drawString(15 * mm, A4[1] - 20.5 * mm, f'{sheet["subject"]} · Cheat sheet · {sheet["level"]}')
        cv.setFillColor(colors.HexColor("#5d6580")); cv.setFont("DV", 7.5)
        cv.drawString(15 * mm, 9 * mm, "Curio Lab · Free to print and share for study · Check values against your syllabus")
        cv.drawRightString(A4[0] - 15 * mm, 9 * mm, f"Page {doc.page}")
        cv.restoreState()
    doc = BaseDocTemplate(path, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=32 * mm, bottomMargin=16 * mm,
                          title=sheet["title"] + " – Curio Lab cheat sheet", author="Curio Lab")
    fr = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="f", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    doc.addPageTemplates([PageTemplate(id="p", frames=[fr], onPage=deco)])
    st = []
    hd = ParagraphStyle("h", parent=body, fontName="DV-B", fontSize=11, textColor=c, spaceBefore=8, spaceAfter=3)
    for sec in sheet["sections"]:
        blk = [Paragraph(sec["h"], hd)]
        rows = []
        for it in sec["rows"]:
            k = it[0]
            if k == "f":  # label, formula
                rows.append([Paragraph(it[1], lab), Paragraph(it[2], frm)])
            elif k == "b":
                if rows:
                    blk.append(ftable(rows, c)); rows = []
                blk.append(Paragraph("• " + it[1], ParagraphStyle("bl", parent=body, leftIndent=10, firstLineIndent=-8, spaceAfter=1.5)))
            elif k == "t":
                if rows:
                    blk.append(ftable(rows, c)); rows = []
                blk.append(Spacer(1, 2)); blk.append(ttable(it[1], it[2], c, it[3] if len(it) > 3 else None)); blk.append(Spacer(1, 3))
            elif k == "n":
                if rows:
                    blk.append(ftable(rows, c)); rows = []
                blk.append(Paragraph(it[1], small))
        if rows: blk.append(ftable(rows, c))
        st.append(KeepTogether(blk) if len(blk) < 9 else blk[0]);
        if len(blk) >= 9: st.extend(blk[1:])
    doc.build(st)
    return os.path.getsize(path)

def ftable(rows, c):
    t = Table(rows, colWidths=[52 * mm, None])
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("ROWBACKGROUNDS", (0, 0), (-1, -1), [colors.HexColor("#f4f5fb"), colors.white]),
                           ("LINEBELOW", (0, 0), (-1, -1), 0.25, colors.HexColor("#d9dcea")), ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3), ("LEFTPADDING", (0, 0), (-1, -1), 5)]))
    return t

def ttable(head, rows, c, widths=None):
    data = [[Paragraph(h, th) for h in head]] + [[Paragraph(x, td) for x in r] for r in rows]
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), c), ("VALIGN", (0, 0), (-1, -1), "TOP"), ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#c9cde0")),
                           ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f4f5fb")]), ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    return t

exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "notes_content.py"), encoding="utf-8").read())

meta = []
for s in SHEETS:
    size = make(s)
    meta.append({"id": s["id"], "subject": s["subject"], "title": s["title"], "level": s["level"], "desc": s["desc"], "topics": s["topics"], "kb": round(size / 1024)})
    print("made", s["id"], round(size / 1024), "KB")
json.dump(meta, open(OUT + "/notes.json", "w"), indent=1, ensure_ascii=False)
