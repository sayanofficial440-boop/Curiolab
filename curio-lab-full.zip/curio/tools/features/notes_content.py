# -*- coding: utf-8 -*-
# Content for the cheat sheets. Allowed inline markup: <b> <i> <sub> <super>. Escape & as &amp; and < as &lt;
SHEETS = []
def S(id, subject, title, level, desc, topics, sections):
    SHEETS.append(dict(id=id, subject=subject, title=title, level=level, desc=desc, topics=topics, sections=sections))

# ------------------------------------------------------------------ PHYSICS
S("physics-motion-forces", "Physics", "Motion, Forces & Energy", "Grades 9–12",
  "Equations of motion, Newton's laws, momentum, work, energy and power on one page.",
  ["kinematics", "newton", "momentum", "energy", "gravitation"], [
 {"h": "Kinematics (constant acceleration)", "rows": [
  ("f", "Definition of a", "a = (v − u) ÷ t"),
  ("f", "SUVAT 1", "v = u + at"),
  ("f", "SUVAT 2", "s = ut + ½at²"),
  ("f", "SUVAT 3", "v² = u² + 2as"),
  ("f", "SUVAT 4", "s = ½(u + v)t"),
  ("f", "Average speed", "total distance ÷ total time"),
  ("n", "u = initial velocity, v = final velocity, a = acceleration, s = displacement, t = time. Free fall near Earth: a = g ≈ 9.8 m/s² downward."),
 ]},
 {"h": "Newton's laws", "rows": [
  ("b", "<b>1st law</b>: an object stays at rest or moves at constant velocity unless a resultant force acts (inertia)."),
  ("b", "<b>2nd law</b>: resultant force F = ma (N = kg·m/s²)."),
  ("b", "<b>3rd law</b>: forces come in equal and opposite pairs acting on <i>different</i> bodies."),
  ("f", "Weight", "W = mg"),
  ("f", "Friction (max)", "f ≤ μN, where N is the normal reaction"),
  ("f", "Incline", "component along slope = mg sinθ; perpendicular = mg cosθ"),
  ("f", "Terminal velocity", "reached when air resistance = weight (resultant force = 0)"),
 ]},
 {"h": "Momentum and impulse", "rows": [
  ("f", "Momentum", "p = mv (kg·m/s)"),
  ("f", "Impulse", "Ft = Δp = mv − mu"),
  ("f", "Conservation", "total p before = total p after (no external force)"),
  ("f", "Elastic collision", "momentum <b>and</b> kinetic energy conserved"),
 ]},
 {"h": "Work, energy, power", "rows": [
  ("f", "Work done", "W = Fs cosθ (joules)"),
  ("f", "Kinetic energy", "KE = ½mv²"),
  ("f", "Gravitational PE", "GPE = mgh"),
  ("f", "Elastic PE (spring)", "E = ½kx², and F = kx (Hooke's law)"),
  ("f", "Power", "P = W ÷ t = Fv (watts)"),
  ("f", "Efficiency", "useful energy out ÷ total energy in × 100%"),
  ("f", "Conservation", "energy is never created or destroyed, only transferred"),
 ]},
 {"h": "Circular motion and gravity", "rows": [
  ("f", "Centripetal acceleration", "a = v² ÷ r = ω²r"),
  ("f", "Centripetal force", "F = mv² ÷ r"),
  ("f", "Angular speed", "ω = 2π ÷ T = 2πf"),
  ("f", "Newton's gravitation", "F = Gm₁m₂ ÷ r², G = 6.67 × 10⁻¹¹ N·m²/kg²"),
  ("f", "Orbital speed", "v = √(GM ÷ r)"),
 ]},
])

S("physics-electricity", "Physics", "Electricity & Magnetism", "Grades 9–12",
  "Ohm's law, series and parallel circuits, power, internal resistance, magnetism and transformers.",
  ["circuits", "ohm", "power", "magnetism", "transformers"], [
 {"h": "Core quantities", "rows": [
  ("f", "Current", "I = Q ÷ t (ampere = coulomb per second)"),
  ("f", "Potential difference", "V = W ÷ Q (volt = joule per coulomb)"),
  ("f", "Ohm's law", "V = IR (for ohmic conductors at constant temperature)"),
  ("f", "Resistivity", "R = ρL ÷ A"),
  ("f", "Electrical power", "P = VI = I²R = V² ÷ R"),
  ("f", "Energy", "E = Pt = VIt (1 kWh = 3.6 × 10⁶ J)"),
 ]},
 {"h": "Combining resistors", "rows": [
  ("t", ["", "Series", "Parallel"], [
     ["Current", "same everywhere", "splits: I = I₁ + I₂ + …"],
     ["Voltage", "shares: V = V₁ + V₂ + …", "same across each branch"],
     ["Total resistance", "R = R₁ + R₂ + …", "1/R = 1/R₁ + 1/R₂ + …"],
     ["Two resistors", "R₁ + R₂", "R₁R₂ ÷ (R₁ + R₂)"],
     ["If one fails", "whole circuit stops", "other branches keep working"]], None),
 ]},
 {"h": "Cells and Kirchhoff's laws", "rows": [
  ("f", "EMF", "ε = I(R + r) = V + Ir"),
  ("f", "Terminal pd", "V = ε − Ir (drops as current rises)"),
  ("f", "Kirchhoff 1", "sum of currents into a junction = sum out (charge conserved)"),
  ("f", "Kirchhoff 2", "sum of EMFs = sum of pd's around a loop (energy conserved)"),
  ("f", "Potential divider", "V<sub>out</sub> = V<sub>in</sub> × R₂ ÷ (R₁ + R₂)"),
  ("f", "Capacitor", "C = Q ÷ V,   E = ½CV²"),
 ]},
 {"h": "Magnetism and induction", "rows": [
  ("f", "Force on a wire", "F = BIL sinθ"),
  ("f", "Force on a charge", "F = Bqv sinθ"),
  ("f", "Faraday's law", "ε = −N ΔΦ ÷ Δt (Lenz: the induced current opposes the change)"),
  ("f", "Transformer", "V<sub>s</sub> ÷ V<sub>p</sub> = N<sub>s</sub> ÷ N<sub>p</sub>; ideal: V<sub>p</sub>I<sub>p</sub> = V<sub>s</sub>I<sub>s</sub>"),
  ("b", "Right-hand grip rule: thumb along current, fingers curl in field direction."),
  ("b", "Fleming's left-hand rule (motor): First finger = Field, seCond = Current, thuMb = Motion."),
  ("b", "Step-up transformer: more turns on the secondary. It increases voltage and reduces current."),
 ]},
 {"h": "Circuit safety and AC", "rows": [
  ("b", "Fuse goes in the <b>live</b> wire; earth wire connects metal cases to ground."),
  ("b", "Peak and RMS: V<sub>rms</sub> = V<sub>peak</sub> ÷ √2 (mains in India: 230 V, 50 Hz)."),
 ]},
])

S("physics-waves-heat", "Physics", "Waves, Light & Heat", "Grades 9–12",
  "Wave equation, reflection and refraction, lenses and mirrors, EM spectrum, heat and gas laws.",
  ["waves", "optics", "lenses", "heat", "gas laws"], [
 {"h": "Waves", "rows": [
  ("f", "Wave equation", "v = fλ"),
  ("f", "Period", "T = 1 ÷ f"),
  ("f", "Speed of sound (air, 20 °C)", "≈ 343 m/s"),
  ("f", "Speed of light", "c = 3.0 × 10⁸ m/s (vacuum)"),
  ("b", "Transverse: vibration ⟂ travel (light, water). Longitudinal: vibration ∥ travel (sound)."),
  ("b", "Pitch ↔ frequency, loudness ↔ amplitude. Human hearing ≈ 20 Hz–20 kHz."),
 ]},
 {"h": "Reflection and refraction", "rows": [
  ("f", "Law of reflection", "angle of incidence = angle of reflection"),
  ("f", "Refractive index", "n = c ÷ v = sin i ÷ sin r"),
  ("f", "Snell's law", "n₁ sinθ₁ = n₂ sinθ₂"),
  ("f", "Critical angle", "sin C = 1 ÷ n (total internal reflection when θ &gt; C, going dense → less dense)"),
  ("b", "Entering a denser medium: light slows, bends <b>towards</b> the normal; frequency unchanged."),
 ]},
 {"h": "Lenses and mirrors", "rows": [
  ("f", "Lens formula", "1/v − 1/u = 1/f (real-is-positive: 1/f = 1/u + 1/v)"),
  ("f", "Mirror formula", "1/v + 1/u = 1/f"),
  ("f", "Magnification", "m = v ÷ u = image height ÷ object height"),
  ("f", "Power of a lens", "P = 1 ÷ f (f in metres → dioptres)"),
  ("b", "Convex lens converges rays; concave lens diverges. Use one sign convention consistently."),
 ]},
 {"h": "Electromagnetic spectrum (low → high frequency)", "rows": [
  ("t", ["Wave", "Typical use"], [
     ["Radio", "broadcasting, communication"], ["Microwave", "cooking, mobile and satellite signals"], ["Infrared", "remote controls, thermal cameras"],
     ["Visible", "vision (red → violet)"], ["Ultraviolet", "sterilising, vitamin D, causes sunburn"], ["X-ray", "medical imaging"], ["Gamma", "cancer treatment, sterilisation"]]),
  ("n", "All travel at c in a vacuum; energy increases as frequency increases."),
 ]},
 {"h": "Heat and gases", "rows": [
  ("f", "Heat capacity", "Q = mcΔT (water: c ≈ 4200 J/kg·°C)"),
  ("f", "Change of state", "Q = mL (latent heat; temperature stays constant)"),
  ("f", "Kelvin", "T(K) = T(°C) + 273"),
  ("f", "Boyle", "P₁V₁ = P₂V₂ (constant T)"),
  ("f", "Charles", "V₁/T₁ = V₂/T₂ (constant P, T in K)"),
  ("f", "Ideal gas", "PV = nRT, R = 8.31 J/mol·K"),
  ("b", "Heat transfer: conduction (solids, particles vibrate), convection (fluids, density currents), radiation (EM, no medium needed)."),
 ]},
])

# ------------------------------------------------------------------ CHEMISTRY
S("chem-mole-stoichiometry", "Chemistry", "Moles & Stoichiometry", "Grades 9–12",
  "Mole relationships, gas volumes, concentration, empirical formulae and limiting reagents.",
  ["moles", "stoichiometry", "concentration", "gases", "yield"], [
 {"h": "Key relationships", "rows": [
  ("f", "Moles from mass", "n = m ÷ M (M = molar mass, g/mol)"),
  ("f", "Moles from particles", "n = N ÷ N<sub>A</sub>, N<sub>A</sub> = 6.022 × 10²³ mol⁻¹"),
  ("f", "Moles of gas", "n = V ÷ 22.4 dm³ at STP (0 °C, 1 atm); V ÷ 24 dm³ at room temperature &amp; pressure"),
  ("f", "Concentration", "c = n ÷ V (mol/dm³ = M)"),
  ("f", "Dilution", "c₁V₁ = c₂V₂"),
  ("f", "Ideal gas", "PV = nRT"),
  ("f", "Mass concentration", "g/dm³ = mol/dm³ × M"),
 ]},
 {"h": "Solving a stoichiometry problem", "rows": [
  ("b", "<b>1.</b> Write and balance the equation, e.g. 2H₂ + O₂ → 2H₂O."),
  ("b", "<b>2.</b> Convert the given quantity to moles."),
  ("b", "<b>3.</b> Use the mole ratio from the balanced coefficients."),
  ("b", "<b>4.</b> Convert moles back to mass, volume or concentration."),
  ("n", "Example: 4 g H₂ (M = 2) = 2 mol → needs 1 mol O₂ → makes 2 mol H₂O = 36 g."),
 ]},
 {"h": "Formulae and yield", "rows": [
  ("f", "% composition", "(mass of element ÷ M of compound) × 100"),
  ("f", "Empirical formula", "divide % (or mass) by A<sub>r</sub> → divide by smallest → whole-number ratio"),
  ("f", "Molecular formula", "multiplier = M ÷ empirical formula mass"),
  ("f", "% yield", "(actual yield ÷ theoretical yield) × 100"),
  ("f", "Atom economy", "(M of desired product ÷ total M of reactants) × 100"),
  ("b", "<b>Limiting reagent</b>: the reactant that runs out first. Divide moles by its coefficient; the smallest value is limiting."),
 ]},
 {"h": "Useful reference", "rows": [
  ("t", ["Item", "Value"], [
     ["Relative atomic masses", "H 1, C 12, N 14, O 16, Na 23, Mg 24, Al 27, S 32, Cl 35.5, K 39, Ca 40, Fe 56, Cu 63.5, Zn 65"],
     ["Molar masses", "H₂O 18, CO₂ 44, NaCl 58.5, H₂SO₄ 98, HCl 36.5, NaOH 40, CaCO₃ 100"],
     ["Avogadro's law", "equal volumes of gases at the same T and P contain equal numbers of molecules"]], [40 * 2.83, None]),
 ]},
])

S("chem-acids-bases-titration", "Chemistry", "Acids, Bases, pH & Titration", "Grades 10–12",
  "pH calculations, strong vs weak, buffers, indicators and titration working. Pairs with the Titration virtual lab.",
  ["acids", "bases", "pH", "buffers", "titration"], [
 {"h": "pH essentials", "rows": [
  ("f", "pH", "pH = −log₁₀[H⁺]"),
  ("f", "pOH", "pOH = −log₁₀[OH⁻]"),
  ("f", "At 25 °C", "pH + pOH = 14; K<sub>w</sub> = [H⁺][OH⁻] = 1.0 × 10⁻¹⁴"),
  ("f", "Neutral", "pH = 7 at 25 °C ([H⁺] = [OH⁻] = 10⁻⁷ M)"),
  ("f", "Weak acid", "K<sub>a</sub> = [H⁺][A⁻] ÷ [HA];   [H⁺] ≈ √(K<sub>a</sub>c)"),
  ("f", "pK<sub>a</sub>", "pK<sub>a</sub> = −log K<sub>a</sub>; smaller pK<sub>a</sub> = stronger acid"),
  ("n", "A change of 1 pH unit = 10× change in [H⁺]."),
 ]},
 {"h": "Strong vs weak", "rows": [
  ("t", ["Type", "Examples"], [
     ["Strong acids (fully ionise)", "HCl, HBr, HI, HNO₃, H₂SO₄, HClO₄"],
     ["Weak acids (partly ionise)", "CH₃COOH, H₂CO₃, HF, H₃PO₄"],
     ["Strong bases", "NaOH, KOH, Ba(OH)₂ (Ca(OH)₂ sparingly soluble)"],
     ["Weak bases", "NH₃, amines"]], [55 * 2.83, None]),
  ("b", "Strong ≠ concentrated. Strength = degree of ionisation; concentration = amount per dm³."),
 ]},
 {"h": "Buffers", "rows": [
  ("f", "Henderson–Hasselbalch", "pH = pK<sub>a</sub> + log₁₀([A⁻] ÷ [HA])"),
  ("b", "A buffer resists pH change: a weak acid with its conjugate base (e.g. CH₃COOH / CH₃COO⁻)."),
  ("b", "Added acid is consumed by the conjugate base; added base is consumed by the weak acid."),
 ]},
 {"h": "Titration", "rows": [
  ("f", "Neutralisation", "acid + base → salt + water"),
  ("f", "Working rule", "c<sub>a</sub>V<sub>a</sub> ÷ n<sub>a</sub> = c<sub>b</sub>V<sub>b</sub> ÷ n<sub>b</sub> (n = coefficients in the balanced equation)"),
  ("f", "1:1 case (HCl + NaOH)", "c<sub>a</sub>V<sub>a</sub> = c<sub>b</sub>V<sub>b</sub>"),
  ("f", "Equivalence pH", "strong acid + strong base = 7;  weak acid + strong base &gt; 7;  strong acid + weak base &lt; 7"),
  ("b", "Pipette the fixed volume into the conical flask; titrant in the burette; add dropwise near the end-point; swirl; read the burette at the bottom of the meniscus at eye level."),
  ("b", "Do a rough titration first, then repeat until <b>concordant</b> results (within 0.10 cm³)."),
 ]},
 {"h": "Indicators", "rows": [
  ("t", ["Indicator", "pH range", "Colour change (acid → base)", "Best for"], [
     ["Methyl orange", "3.1 – 4.4", "red → yellow", "strong acid + weak base"],
     ["Bromothymol blue", "6.0 – 7.6", "yellow → blue", "strong acid + strong base"],
     ["Phenolphthalein", "8.2 – 10.0", "colourless → pink", "weak acid + strong base, strong + strong"],
     ["Litmus", "5 – 8", "red → blue", "rough test only"]]),
  ("n", "Choose an indicator whose range falls on the steep part of the titration curve around the equivalence point."),
 ]},
])

S("chem-periodic-bonding", "Chemistry", "Periodic Table & Bonding", "Grades 9–12",
  "Periodic trends, electron configurations, bond types, molecular shapes and intermolecular forces.",
  ["periodic table", "bonding", "VSEPR", "electron configuration"], [
 {"h": "First 20 elements", "rows": [
  ("t", ["Z = 1–10", "Z = 11–20"], [
     ["H, He, Li, Be, B, C, N, O, F, Ne", "Na, Mg, Al, Si, P, S, Cl, Ar, K, Ca"]]),
  ("b", "Electron filling order: 1s 2s 2p 3s 3p 4s 3d 4p. Max electrons: s = 2, p = 6, d = 10."),
  ("b", "Shell capacity 2n²: 2, 8, 18. Example: Na = 2,8,1; Cl = 2,8,7."),
 ]},
 {"h": "Trends", "rows": [
  ("t", ["Property", "Across a period →", "Down a group ↓"], [
     ["Atomic radius", "decreases", "increases"],
     ["Ionisation energy", "increases", "decreases"],
     ["Electronegativity", "increases", "decreases"],
     ["Metallic character", "decreases", "increases"],
     ["Reactivity", "metals: decreases; non-metals: increases", "metals (G1): increases; halogens (G17): decreases"]]),
  ("b", "Group 1 alkali metals, Group 2 alkaline earth, Group 17 halogens, Group 18 noble gases (full outer shell, unreactive)."),
 ]},
 {"h": "Types of bonding", "rows": [
  ("t", ["Bond", "Between", "Properties"], [
     ["Ionic", "metal + non-metal (electron transfer)", "high melting point; conducts when molten or dissolved; brittle"],
     ["Covalent (simple)", "non-metals (shared pairs)", "low melting point; poor conductor"],
     ["Giant covalent", "e.g. diamond, SiO₂, graphite", "very high melting point; graphite conducts"],
     ["Metallic", "cations in a sea of delocalised electrons", "conducts; malleable; ductile"]]),
 ]},
 {"h": "Shapes of molecules (VSEPR)", "rows": [
  ("t", ["Electron pairs", "Shape", "Bond angle", "Example"], [
     ["2 bonding", "linear", "180°", "CO₂, BeCl₂"],
     ["3 bonding", "trigonal planar", "120°", "BF₃"],
     ["4 bonding", "tetrahedral", "109.5°", "CH₄"],
     ["3 bonding + 1 lone", "trigonal pyramidal", "≈107°", "NH₃"],
     ["2 bonding + 2 lone", "bent (V-shaped)", "≈104.5°", "H₂O"],
     ["6 bonding", "octahedral", "90°", "SF₆"]]),
  ("n", "Lone pairs repel more strongly than bonding pairs, so they squeeze the bond angle."),
 ]},
 {"h": "Intermolecular forces (weakest → strongest)", "rows": [
  ("b", "<b>London dispersion</b>: all molecules; increases with size."),
  ("b", "<b>Dipole–dipole</b>: polar molecules (e.g. HCl)."),
  ("b", "<b>Hydrogen bonding</b>: H bonded to N, O or F (e.g. H₂O, NH₃); explains water's high boiling point."),
 ]},
])

# ------------------------------------------------------------------ BIOLOGY
S("bio-cell-biology", "Biology", "Cell Biology & Microscopy", "Grades 9–12",
  "Organelles, plant vs animal cells, transport, cell division and microscope calculations. Pairs with the Microscope lab.",
  ["cell", "organelles", "transport", "mitosis", "microscope"], [
 {"h": "Organelles", "rows": [
  ("t", ["Structure", "Function", "In"], [
     ["Nucleus", "contains DNA; controls the cell", "all eukaryotes"],
     ["Cell membrane", "selectively permeable barrier", "all cells"],
     ["Cytoplasm", "site of many reactions (glycolysis)", "all cells"],
     ["Mitochondria", "aerobic respiration → ATP", "most eukaryotes"],
     ["Ribosomes", "protein synthesis (translation)", "all cells"],
     ["Rough ER / Smooth ER", "protein processing / lipid synthesis", "eukaryotes"],
     ["Golgi apparatus", "modifies, packages and sorts proteins", "eukaryotes"],
     ["Lysosomes", "digestive enzymes", "mainly animal"],
     ["Cell wall (cellulose)", "support and shape", "plants (fungi: chitin)"],
     ["Chloroplasts", "photosynthesis", "plants and algae"],
     ["Large permanent vacuole", "stores sap, keeps cell turgid", "plants"]]),
 ]},
 {"h": "Comparing cells", "rows": [
  ("t", ["", "Prokaryote", "Animal", "Plant"], [
     ["Nucleus", "no (nucleoid, free DNA)", "yes", "yes"],
     ["Cell wall", "yes (peptidoglycan)", "no", "yes (cellulose)"],
     ["Chloroplasts", "no", "no", "yes"],
     ["Size", "1–10 µm", "10–30 µm", "10–100 µm"],
     ["Ribosomes", "smaller (70S)", "80S", "80S"]]),
 ]},
 {"h": "Transport across membranes", "rows": [
  ("f", "Diffusion", "net movement high → low concentration; passive"),
  ("f", "Osmosis", "diffusion of water through a partially permeable membrane, from high to low water potential"),
  ("f", "Active transport", "low → high concentration; needs ATP and carrier proteins"),
  ("f", "Facilitated diffusion", "passive, through channel or carrier proteins"),
  ("b", "Plant cell in pure water: turgid. In strong solution: plasmolysed. Animal cell: bursts (lysis) or shrinks (crenation)."),
 ]},
 {"h": "Cell cycle and division", "rows": [
  ("b", "<b>Interphase</b> (G1, S = DNA replication, G2) then <b>mitosis</b>: Prophase → Metaphase → Anaphase → Telophase (<b>PMAT</b>), then cytokinesis."),
  ("t", ["", "Mitosis", "Meiosis"], [
     ["Result", "2 identical diploid cells", "4 different haploid cells"],
     ["Divisions", "1", "2"],
     ["Purpose", "growth, repair, asexual reproduction", "gametes; genetic variation"]]),
 ]},
 {"h": "Microscope maths", "rows": [
  ("f", "Total magnification", "eyepiece × objective (10 × 40 = 400×)"),
  ("f", "Magnification", "image size ÷ actual size"),
  ("f", "Actual size", "image size ÷ magnification"),
  ("f", "Unit conversions", "1 mm = 1000 µm;  1 µm = 1000 nm"),
  ("b", "Start on the lowest power, centre the specimen, then increase power and refocus using the <b>fine</b> focus only."),
 ]},
])

S("bio-energy-enzymes", "Biology", "Photosynthesis, Respiration & Enzymes", "Grades 9–12",
  "Equations, stages and limiting factors for photosynthesis and respiration, plus enzyme behaviour.",
  ["photosynthesis", "respiration", "enzymes", "ATP"], [
 {"h": "Photosynthesis", "rows": [
  ("f", "Equation", "6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂ (light energy, chlorophyll)"),
  ("f", "Light-dependent stage", "thylakoid membranes: water split (photolysis), O₂ released, ATP and NADPH made"),
  ("f", "Calvin cycle", "stroma: CO₂ fixed by RuBisCO; uses ATP + NADPH to make glucose"),
  ("b", "<b>Limiting factors</b>: light intensity, CO₂ concentration, temperature (enzymes). The factor in shortest supply limits the rate."),
  ("b", "Chlorophyll absorbs mostly red and blue light and reflects green."),
 ]},
 {"h": "Respiration", "rows": [
  ("f", "Aerobic", "C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + energy (about 30–32 ATP)"),
  ("f", "Anaerobic (animals)", "glucose → lactic acid + a little energy (2 ATP)"),
  ("f", "Anaerobic (yeast)", "glucose → ethanol + CO₂ + a little energy (fermentation)"),
  ("t", ["Stage", "Where", "Main output"], [
     ["Glycolysis", "cytoplasm", "2 pyruvate, net 2 ATP, 2 NADH"],
     ["Link reaction", "mitochondrial matrix", "acetyl-CoA, CO₂, NADH"],
     ["Krebs cycle", "mitochondrial matrix", "CO₂, NADH, FADH₂, 2 ATP"],
     ["Electron transport chain", "inner mitochondrial membrane", "about 26–28 ATP, water (O₂ is the final acceptor)"]]),
  ("n", "Photosynthesis and respiration are roughly opposite processes: one stores energy in glucose, the other releases it as ATP."),
 ]},
 {"h": "Enzymes", "rows": [
  ("b", "Biological catalysts (proteins) that lower activation energy; specific to their substrate (lock-and-key / induced fit)."),
  ("b", "<b>Temperature</b>: rate rises to the optimum (≈37 °C in humans) then falls sharply as the enzyme <b>denatures</b>."),
  ("b", "<b>pH</b>: each enzyme has an optimum (pepsin ≈ 2, amylase ≈ 7, trypsin ≈ 8). Extremes change the active site shape."),
  ("b", "<b>Substrate concentration</b>: rate rises then plateaus when all active sites are occupied."),
  ("f", "Q₁₀", "rate at (T + 10 °C) ÷ rate at T ≈ 2 for many reactions below the optimum"),
  ("f", "Common examples", "amylase (starch → maltose), protease (protein → amino acids), lipase (fats → fatty acids + glycerol)"),
 ]},
 {"h": "ATP", "rows": [
  ("b", "ATP → ADP + P<sub>i</sub> releases energy for muscle contraction, active transport and synthesis. It is the cell's immediate energy currency."),
 ]},
])

S("bio-genetics-evolution", "Biology", "Genetics & Evolution", "Grades 10–12",
  "DNA, protein synthesis, Mendelian crosses, ratios, Hardy–Weinberg and natural selection.",
  ["DNA", "inheritance", "punnett", "Hardy-Weinberg", "evolution"], [
 {"h": "DNA and protein synthesis", "rows": [
  ("b", "DNA is a double helix; bases pair <b>A–T</b> and <b>G–C</b> (in RNA, U replaces T). Sugar: deoxyribose; backbone: sugar–phosphate."),
  ("f", "Central dogma", "DNA → (transcription, nucleus) → mRNA → (translation, ribosome) → protein"),
  ("f", "Codon", "3 bases code for 1 amino acid; AUG = start; UAA, UAG, UGA = stop"),
  ("f", "Replication", "semi-conservative: each new DNA has one old and one new strand"),
  ("b", "Mutation: change in the base sequence (substitution, insertion, deletion); may be silent, harmful or beneficial."),
 ]},
 {"h": "Mendelian genetics", "rows": [
  ("f", "Allele", "alternative form of a gene (dominant T, recessive t)"),
  ("f", "Genotype / phenotype", "alleles carried / observable trait; homozygous (TT, tt), heterozygous (Tt)"),
  ("f", "Monohybrid Tt × Tt", "genotypes 1 TT : 2 Tt : 1 tt; phenotypes 3 dominant : 1 recessive"),
  ("f", "Dihybrid TtRr × TtRr", "phenotypes 9 : 3 : 3 : 1"),
  ("f", "Test cross", "unknown × homozygous recessive. Any recessive offspring means the parent is heterozygous."),
  ("b", "<b>Segregation</b>: the two alleles of a gene separate into different gametes. <b>Independent assortment</b>: genes on different chromosomes sort independently."),
  ("b", "Incomplete dominance (red × white → pink); codominance (AB blood group: Iᴬ and Iᴮ both expressed; i recessive)."),
  ("b", "Sex-linked traits (e.g. colour blindness, haemophilia) are on the X chromosome: more common in males (XY)."),
 ]},
 {"h": "Hardy–Weinberg", "rows": [
  ("f", "Allele frequencies", "p + q = 1"),
  ("f", "Genotype frequencies", "p² + 2pq + q² = 1"),
  ("n", "p = frequency of dominant allele, q = recessive. If 4% show the recessive trait: q² = 0.04 → q = 0.2, p = 0.8, carriers 2pq = 0.32. Assumes no selection, migration, mutation, and random mating in a large population."),
 ]},
 {"h": "Evolution by natural selection", "rows": [
  ("b", "<b>1. Variation</b> exists in a population (mutation, sexual reproduction)."),
  ("b", "<b>2. Overproduction</b>: more offspring are born than can survive."),
  ("b", "<b>3. Struggle</b> for limited resources; individuals with advantageous traits survive and reproduce more."),
  ("b", "<b>4. Inheritance</b>: those alleles become more frequent over generations."),
  ("b", "Evidence: fossils, homologous structures, DNA similarity, antibiotic resistance in bacteria."),
  ("b", "Speciation: populations become reproductively isolated and diverge (often through geographic isolation)."),
 ]},
])

# ------------------------------------------------------------------ MATHEMATICS
S("math-algebra-coordinate", "Mathematics", "Algebra, Quadratics & Coordinate Geometry", "Grades 9–12",
  "Indices, logs, quadratics, sequences and series, straight lines and circles. Use with the Graphing Calculator.",
  ["algebra", "quadratics", "sequences", "logarithms", "coordinate geometry"], [
 {"h": "Indices and logarithms", "rows": [
  ("f", "Index laws", "aᵐ × aⁿ = aᵐ⁺ⁿ;  aᵐ ÷ aⁿ = aᵐ⁻ⁿ;  (aᵐ)ⁿ = aᵐⁿ;  a⁰ = 1;  a⁻ⁿ = 1 ÷ aⁿ;  a<super>1/n</super> = ⁿ√a"),
  ("f", "Log definition", "log<sub>a</sub> x = y ⇔ aʸ = x"),
  ("f", "Log laws", "log(xy) = log x + log y;  log(x/y) = log x − log y;  log xᵏ = k log x"),
  ("f", "Change of base", "log<sub>a</sub> x = log x ÷ log a"),
  ("f", "Special products", "(a ± b)² = a² ± 2ab + b²;  a² − b² = (a − b)(a + b)"),
 ]},
 {"h": "Quadratics: ax² + bx + c = 0", "rows": [
  ("f", "Quadratic formula", "x = (−b ± √(b² − 4ac)) ÷ 2a"),
  ("f", "Discriminant Δ", "Δ = b² − 4ac:  Δ &gt; 0 two real roots; Δ = 0 one repeated root; Δ &lt; 0 no real roots"),
  ("f", "Sum / product of roots", "α + β = −b ÷ a;   αβ = c ÷ a"),
  ("f", "Completing the square", "a(x + b/2a)² + (c − b²/4a); vertex at (−b/2a, c − b²/4a)"),
  ("f", "Axis of symmetry", "x = −b ÷ 2a"),
 ]},
 {"h": "Sequences and series", "rows": [
  ("f", "Arithmetic (AP)", "aₙ = a + (n − 1)d;   Sₙ = n/2 · [2a + (n − 1)d] = n/2 · (a + l)"),
  ("f", "Geometric (GP)", "aₙ = a rⁿ⁻¹;   Sₙ = a(1 − rⁿ) ÷ (1 − r)"),
  ("f", "Infinite GP", "S∞ = a ÷ (1 − r), for |r| &lt; 1"),
  ("f", "Binomial", "(a + b)ⁿ = Σ ⁿC<sub>r</sub> aⁿ⁻ʳ bʳ;  ⁿC<sub>r</sub> = n! ÷ (r!(n − r)!)"),
  ("f", "Sum formulas", "Σk = n(n + 1)/2;   Σk² = n(n + 1)(2n + 1)/6"),
 ]},
 {"h": "Coordinate geometry", "rows": [
  ("f", "Gradient", "m = (y₂ − y₁) ÷ (x₂ − x₁)"),
  ("f", "Line", "y = mx + c;  y − y₁ = m(x − x₁);  ax + by + c = 0"),
  ("f", "Distance", "d = √((x₂ − x₁)² + (y₂ − y₁)²)"),
  ("f", "Midpoint", "((x₁ + x₂)/2, (y₁ + y₂)/2)"),
  ("f", "Parallel / perpendicular", "m₁ = m₂;   m₁m₂ = −1"),
  ("f", "Circle", "(x − h)² + (y − k)² = r²  (centre (h, k), radius r)"),
  ("f", "Point to line distance", "|ax₁ + by₁ + c| ÷ √(a² + b²)"),
 ]},
])

S("math-trig-geometry", "Mathematics", "Trigonometry & Geometry", "Grades 9–12",
  "Trig ratios, exact values, sine and cosine rules, identities, radians and mensuration formulas.",
  ["trigonometry", "identities", "radians", "mensuration"], [
 {"h": "Right-angled triangles", "rows": [
  ("f", "SOH CAH TOA", "sinθ = opp ÷ hyp;  cosθ = adj ÷ hyp;  tanθ = opp ÷ adj"),
  ("f", "Pythagoras", "a² + b² = c² (c = hypotenuse)"),
  ("t", ["θ", "0°", "30°", "45°", "60°", "90°"], [
     ["sin θ", "0", "½", "√2/2", "√3/2", "1"],
     ["cos θ", "1", "√3/2", "√2/2", "½", "0"],
     ["tan θ", "0", "√3/3", "1", "√3", "undefined"]]),
 ]},
 {"h": "Any triangle (sides a, b, c opposite angles A, B, C)", "rows": [
  ("f", "Sine rule", "a ÷ sin A = b ÷ sin B = c ÷ sin C = 2R"),
  ("f", "Cosine rule", "a² = b² + c² − 2bc cos A"),
  ("f", "Area", "½ab sin C;  or  √(s(s − a)(s − b)(s − c)), s = (a + b + c)/2"),
 ]},
 {"h": "Identities", "rows": [
  ("f", "Pythagorean", "sin²θ + cos²θ = 1;  1 + tan²θ = sec²θ;  1 + cot²θ = cosec²θ"),
  ("f", "Quotient", "tanθ = sinθ ÷ cosθ"),
  ("f", "Compound angle", "sin(A ± B) = sinA cosB ± cosA sinB;  cos(A ± B) = cosA cosB ∓ sinA sinB"),
  ("f", "tan(A ± B)", "(tanA ± tanB) ÷ (1 ∓ tanA tanB)"),
  ("f", "Double angle", "sin2A = 2 sinA cosA;  cos2A = cos²A − sin²A = 2cos²A − 1 = 1 − 2sin²A"),
  ("f", "ASTC (quadrants)", "I: all positive; II: sin; III: tan; IV: cos"),
 ]},
 {"h": "Radians", "rows": [
  ("f", "Conversion", "π rad = 180°;  1 rad ≈ 57.3°"),
  ("f", "Arc length", "s = rθ (θ in radians)"),
  ("f", "Sector area", "A = ½r²θ"),
 ]},
 {"h": "Areas and volumes", "rows": [
  ("t", ["Shape", "Area / surface area", "Volume"], [
     ["Rectangle / triangle", "lw / ½bh", "–"],
     ["Circle", "πr²; circumference 2πr", "–"],
     ["Cylinder", "2πr(r + h)", "πr²h"],
     ["Cone", "πr(r + l), l = slant height", "⅓πr²h"],
     ["Sphere", "4πr²", "⁴⁄₃πr³"],
     ["Prism / pyramid", "–", "base area × h / ⅓ base area × h"]]),
 ]},
])

S("math-calculus-stats", "Mathematics", "Calculus, Probability & Statistics", "Grades 11–12",
  "Differentiation and integration rules, stationary points, probability, combinatorics and the normal distribution.",
  ["differentiation", "integration", "probability", "statistics"], [
 {"h": "Differentiation", "rows": [
  ("t", ["f(x)", "f′(x)", "f(x)", "f′(x)"], [
     ["xⁿ", "n xⁿ⁻¹", "sin x", "cos x"],
     ["eˣ", "eˣ", "cos x", "−sin x"],
     ["ln x", "1 ÷ x", "tan x", "sec²x"],
     ["aˣ", "aˣ ln a", "constant", "0"]]),
  ("f", "Sum / constant", "(kf)′ = kf′;  (f + g)′ = f′ + g′"),
  ("f", "Product rule", "(uv)′ = u′v + uv′"),
  ("f", "Quotient rule", "(u/v)′ = (u′v − uv′) ÷ v²"),
  ("f", "Chain rule", "dy/dx = dy/du × du/dx"),
 ]},
 {"h": "Applications", "rows": [
  ("f", "Tangent at x = a", "y − f(a) = f′(a)(x − a)"),
  ("f", "Stationary points", "f′(x) = 0;  f″ &gt; 0 minimum;  f″ &lt; 0 maximum;  f″ = 0 test further"),
  ("f", "Rates of change", "velocity v = ds/dt, acceleration a = dv/dt"),
 ]},
 {"h": "Integration", "rows": [
  ("t", ["f(x)", "∫ f(x) dx", "f(x)", "∫ f(x) dx"], [
     ["xⁿ (n ≠ −1)", "xⁿ⁺¹ ÷ (n+1) + C", "sin x", "−cos x + C"],
     ["1 ÷ x", "ln|x| + C", "cos x", "sin x + C"],
     ["eˣ", "eˣ + C", "sec²x", "tan x + C"]]),
  ("f", "Definite integral", "∫ₐᵇ f(x) dx = F(b) − F(a) = area under curve (above the axis)"),
  ("f", "Area between curves", "∫ₐᵇ (f(x) − g(x)) dx, with f on top"),
  ("f", "Volume of revolution", "V = π ∫ₐᵇ y² dx (about the x-axis)"),
 ]},
 {"h": "Probability and combinatorics", "rows": [
  ("f", "Basic", "P(A) = favourable ÷ total;  P(A′) = 1 − P(A)"),
  ("f", "Addition", "P(A ∪ B) = P(A) + P(B) − P(A ∩ B)"),
  ("f", "Conditional", "P(A | B) = P(A ∩ B) ÷ P(B);  independent: P(A ∩ B) = P(A)P(B)"),
  ("f", "Permutations", "ⁿP<sub>r</sub> = n! ÷ (n − r)!"),
  ("f", "Combinations", "ⁿC<sub>r</sub> = n! ÷ (r!(n − r)!)"),
 ]},
 {"h": "Statistics", "rows": [
  ("f", "Mean", "x̄ = Σx ÷ n;  median = middle value; mode = most frequent"),
  ("f", "Standard deviation", "σ = √(Σ(x − μ)² ÷ n) (sample: divide by n − 1)"),
  ("f", "Normal distribution", "≈68% within 1σ, 95% within 2σ, 99.7% within 3σ"),
  ("f", "z-score", "z = (x − μ) ÷ σ"),
  ("f", "Binomial", "P(X = r) = ⁿC<sub>r</sub> pʳ (1 − p)ⁿ⁻ʳ;  mean np, variance np(1 − p)"),
 ]},
])
