# Labs, Math tools & Notes

Pages live in `public/pages/labs/`, `public/pages/math-tools/` and `public/pages/notes/` (PDFs in `public/pages/notes/pdf/`).
They use the site's own header, footer, themes and scripts, copied from `public/pages/practice.html` at build time.

- Edit page content in `tools/features/src/*.frag` (first line: `Title|section|outpath`), then run `python3 tools/features/build.py`.
- Notes PDFs: `python3 tools/features/make_notes.py`.
- Shared styles: `public/features/features.css` (scoped to `.cl-wrap`, colours follow the site theme).
