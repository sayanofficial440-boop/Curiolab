# Builds Labs / Math tools / Notes pages (src/*.frag, first line "Title|section|outpath")
# using the site's own header, footer, assets and themes, taken from public/pages/practice.html.
import glob,os,re,json
root=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
tpl=open(root+'/public/pages/practice.html',encoding='utf-8').read()

def between(s,a,b):
    i=s.index(a); j=s.index(b,i)+len(b); return s[i:j]

# ---- head assets (strip page-specific SEO/practice bits, go one level deeper)
h=between(tpl,'<link rel="preconnect"','</head>')[:-len('</head>')]
h=re.sub(r'<link rel="stylesheet" href="\.\./css/practice\.css" />\n','',h)
h=h.replace('href="../','href="../../').replace('src="../','src="../../')
ICON=re.search(r'<link rel="icon"[^>]*>',tpl).group(0)

# ---- header / footer from the real site, links re-based for pages/<section>/x.html
def rebase(s):
    s=s.replace('href="../dashboard.html"','href="../../dashboard.html"')
    return re.sub(r'href="([a-z][a-z0-9-]*\.html)"',r'href="../\1"',s)
header=rebase(between(tpl,'<header class="site-header">','</header>'))
footer=rebase(between(tpl,'<footer class="site-footer-rich">','</footer>'))
footer=footer.replace('<li><a href="../play.html">','<li><a href="../labs/index.html">Virtual Labs</a></li>\n          <li><a href="../math-tools/index.html">Graphing &amp; Solver</a></li>\n          <li><a href="../notes/index.html">Revision Notes</a></li>\n          <li><a href="../play.html">',1)
tail='<script src="../../js/modern-academic.js" defer></script>\n<script src="../../js/i18n.js" defer></script>\n'

ACCENT={'labs':'var(--color-teal)','math':'var(--color-coral)','notes':'var(--color-amber)'}
EYEBROW={'labs':'Virtual labs','math':'Math tools','notes':'Revision notes'}
def page(title,cur,body):
    def a(k,href,label): return f'<a class="cl-pill" href="{href}"'+(' aria-current="page"' if cur==k else '')+f'>{label}</a>'
    m=re.match(r'\s*(<p><a href="index.html">.*?</a></p>\s*)?<h1>(.*?)</h1>\s*<p class="cl-sub">(.*?)</p>(.*)',body,re.S)
    back,h1,sub,rest=(m.group(1) or ''),m.group(2),m.group(3),m.group(4)
    pills=a('labs','../labs/index.html','🧪 Labs')+a('math','../math-tools/index.html','📈 Math tools')+a('notes','../notes/index.html','📄 Notes')
    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
{ICON}
<meta name="theme-color" content="#12213B" />
<title>{title} — Curio Lab</title>
<meta name="description" content="{re.sub('<[^>]+>','',sub)}" />
{h}<link rel="stylesheet" href="../../features/features.css" />
<script src="../../features/curio-activity.js"></script>
</head>
<body style="--accent: {ACCENT[cur]};">

{header}

<main>
  <section class="page-hero tool-hero">
    <div class="wrap">
      <p class="eyebrow">{EYEBROW[cur]}</p>
      <h1>{h1}</h1>
      <p>{sub}</p>
      <div class="cl-pills" aria-label="Learning tools">{pills}</div>
    </div>
  </section>
  <div class="wrap cl-wrap">
{back}{rest}
  </div>
</main>

{footer}

{tail}</body>
</html>
'''
np=root+'/public/pages/notes/notes.json'
NJ=json.dumps(json.load(open(np,encoding='utf-8')),ensure_ascii=False) if os.path.exists(np) else '[]'
for f in sorted(glob.glob(root+'/tools/features/src/*.frag')):
    first,body=open(f,encoding='utf-8').read().split('\n',1)
    title,cur,out=first.split('|')
    os.makedirs(os.path.dirname(os.path.join(root,'public',out)),exist_ok=True)
    open(os.path.join(root,'public',out),'w',encoding='utf-8').write(page(title,cur,body.replace('/*NOTES_JSON*/',NJ)))
    print('built',out)
