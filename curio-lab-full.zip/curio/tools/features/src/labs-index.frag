Virtual Labs|labs|pages/labs/index.html
<h1>Virtual Labs</h1>
<p class="cl-sub">Hands-on experiments you can run on any device. No equipment, no spills.</p>
<div class="cl-grid">
<a class="cl-card cl-tile" href="titration.html"><div class="em">🧪</div><h3>Acid–Base Titration</h3><p>Add NaOH from the burette, watch the indicator change, plot the pH curve and find an unknown concentration.</p><span class="cl-tag">Chemistry</span></a>
<a class="cl-card cl-tile" href="circuits.html"><div class="em">💡</div><h3>Circuit Builder</h3><p>Series, parallel and mixed circuits with live current, voltage, power and an Ohm's-law graph.</p><span class="cl-tag">Physics</span></a>
<a class="cl-card cl-tile" href="microscope.html"><div class="em">🔬</div><h3>Virtual Microscope</h3><p>Focus, switch objectives and move the stage to study onion cells, cheek cells, paramecium and blood.</p><span class="cl-tag">Biology</span></a>
</div>
<div class="cl-card" style="margin-top:18px"><h2>Your lab activity</h2><div id="act" class="cl-note">Nothing yet – run an experiment to get started.</div></div>
<script>
(function(){var a=CurioActivity.all().filter(function(x){return x.type==="lab"}).reverse().slice(0,8);
if(!a.length)return;var h="<table class='cl-t'><tr><th>Lab</th><th>Result</th><th>When</th></tr>";
a.forEach(function(x){h+="<tr><td>"+x.label+"</td><td>"+x.detail+"</td><td>"+new Date(x.ts).toLocaleString()+"</td></tr>"});
document.getElementById("act").innerHTML=h+"</table>"})();
</script>
