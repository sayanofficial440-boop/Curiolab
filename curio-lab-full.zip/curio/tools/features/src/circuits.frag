Circuit Builder|labs|pages/labs/circuits.html
<p><a href="index.html">← All labs</a></p>
<h1>Circuit Builder</h1>
<p class="cl-sub">Change the battery and resistors, flip the switch, and watch current, voltage and power respond. Moving dots show conventional current; faster means more amps.</p>
<div class="cl-lab">
  <div>
    <div class="cl-stage"><svg id="ckt" viewBox="0 0 520 320" role="img" aria-label="Circuit diagram with battery, switch, resistors and a bulb"></svg></div>
    <div class="cl-card" style="margin-top:12px"><h2>Readings</h2>
      <div class="cl-readout" id="ro"></div>
      <table class="cl-t" style="margin-top:10px" id="rt"><thead><tr><th>Part</th><th>R (Ω)</th><th>V (V)</th><th>I (A)</th><th>P (W)</th></tr></thead><tbody></tbody></table>
    </div>
  </div>
  <div>
    <div class="cl-card"><h2>Build</h2>
      <label class="cl-f" for="topo">Circuit type</label>
      <select id="topo"><option value="series">Series: R1 → R2 → R3</option><option value="parallel">Parallel: R1 ∥ R2 ∥ R3</option><option value="mixed">Mixed: R1 in series with (R2 ∥ R3)</option></select>
      <label class="cl-f" for="V">Battery: <span class="cl-val" id="Vv"></span> V</label><input id="V" type="range" min="1" max="24" step="0.5" value="9">
      <label class="cl-f" for="R1">R1: <span class="cl-val" id="R1v"></span> Ω</label><input id="R1" type="range" min="1" max="200" step="1" value="40">
      <label class="cl-f" for="R2">R2: <span class="cl-val" id="R2v"></span> Ω</label><input id="R2" type="range" min="1" max="200" step="1" value="60">
      <label class="cl-f" for="R3">R3 (bulb): <span class="cl-val" id="R3v"></span> Ω</label><input id="R3" type="range" min="1" max="200" step="1" value="30">
      <div class="cl-row"><button id="sw" class="primary" aria-pressed="true">Switch: ON</button><button id="log">📝 Record reading</button></div>
    </div>
    <div class="cl-card" style="margin-top:12px"><h2>Ohm's law graph</h2>
      <p class="cl-note">Press <b>Record reading</b> after changing the battery voltage. Points of V against I for the whole circuit should form a straight line through the origin; the gradient is the total resistance.</p>
      <div class="cl-stage" style="border:0;padding:0"><canvas id="og" width="520" height="260" role="img" aria-label="Graph of voltage against current"></canvas></div>
      <div class="cl-row"><button id="clr">Clear graph</button><span class="cl-note" id="grad"></span></div>
    </div>
    <div class="cl-card" style="margin-top:12px"><h2>Challenge</h2>
      <p class="cl-note" id="chq"></p>
      <input id="cha" type="number" step="0.01" inputmode="decimal" placeholder="Your answer">
      <div class="cl-row"><button class="primary" id="chb">Check</button><button id="chn">New question</button></div><div id="chr" role="status"></div></div>
  </div>
</div>
<script>
(function(){
var $=function(i){return document.getElementById(i)};
var on=true,pts=[],NS="http://www.w3.org/2000/svg",dots=[],last=0;
function par(a,b){return a*b/(a+b)}
function solve(){
  var V=+$("V").value,r=[+$("R1").value,+$("R2").value,+$("R3").value],t=$("topo").value,o={V:V,r:r,t:t};
  if(t==="series"){o.R=r[0]+r[1]+r[2];o.I=V/o.R;o.parts=[[ "R1",r[0],o.I*r[0],o.I],["R2",r[1],o.I*r[1],o.I],["R3 (bulb)",r[2],o.I*r[2],o.I]]}
  else if(t==="parallel"){o.R=1/(1/r[0]+1/r[1]+1/r[2]);o.I=V/o.R;o.parts=r.map(function(x,i){return [["R1","R2","R3 (bulb)"][i],x,V,V/x]})}
  else{var rp=par(r[1],r[2]);o.R=r[0]+rp;o.I=V/o.R;var vp=o.I*rp;o.parts=[["R1",r[0],o.I*r[0],o.I],["R2",r[1],vp,vp/r[1]],["R3 (bulb)",r[2],vp,vp/r[2]]]}
  if(!on){o.I=0;o.parts=o.parts.map(function(p){return [p[0],p[1],0,0]})}
  return o;
}
function el(n,a,p){var e=document.createElementNS(NS,n);for(var k in a)e.setAttribute(k,a[k]);if(p)p.appendChild(e);return e}
function resistor(g,x,y,vert,label,val){ // zigzag block
  var w=vert?18:56,h=vert?56:18;var rect=el("rect",{x:x-(vert?9:28),y:y-(vert?28:9),width:w,height:h,rx:3,fill:"var(--cl-surface2)",stroke:"var(--cl-text)","stroke-width":2},g);
  var t=el("text",{x:x+(vert?16:0),y:y+(vert?4:-14),"text-anchor":vert?"start":"middle","font-size":12,fill:"var(--cl-text)"},g);t.textContent=label+" "+val+"Ω";return rect;
}
var paths=[],speed=[];
function build(){
  var s=$("ckt");s.innerHTML="";dots=[];paths=[];var o=solve(),t=o.t;
  var g=el("g",{},s),W="var(--cl-text)",st={fill:"none",stroke:W,"stroke-width":2.5,"stroke-linecap":"round","stroke-linejoin":"round"};
  function wire(d){var p=el("path",Object.assign({d:d},st),g);return p}
  function loopDots(d,I,n){paths.push({d:d,I:I,n:n})}
  // battery on left
  var bat=el("g",{},g);el("line",{x1:30,x2:60,y1:150,y2:150,stroke:W,"stroke-width":3},bat);el("line",{x1:40,x2:50,y1:162,y2:162,stroke:W,"stroke-width":5},bat);
  el("text",{x:68,y:146,"font-size":13,fill:"var(--cl-text)"},bat).textContent="+";el("text",{x:68,y:176,"font-size":13,fill:"var(--cl-text)"},bat).textContent="−";
  el("text",{x:8,y:220,"font-size":12,fill:"var(--cl-text)"},bat).textContent=o.V+" V";
  var I=o.I;
  var bulbX=0,bulbY=0,bulbP=0;
  if(t==="series"){
    var d="M45 150 V40 H100";wire(d); // battery + up, switch near top-left
    // switch
    el("circle",{cx:100,cy:40,r:4,fill:W},g);el("circle",{cx:140,cy:40,r:4,fill:W},g);el("text",{x:104,y:66,"font-size":12,fill:"var(--cl-text)"},g).textContent="switch";
    var sw=el("line",{x1:100,y1:40,x2:on?140:132,y2:on?40:22,stroke:"var(--cl-accent)","stroke-width":4,"stroke-linecap":"round"},g);
    wire("M140 40 H200");resistor(g,228,40,false,"R1",o.r[0]);wire("M256 40 H320");resistor(g,348,40,false,"R2",o.r[1]);wire("M376 40 H480 V150");
    // bulb R3 right side
    bulbX=480;bulbY=185;wire("M480 150 V163");wire("M480 207 V280 H45 V162");
    loopDots("M45 150 V40 H480 V280 H45 V150",I,14);
    bulbP=o.parts[2][2]*o.parts[2][3];
  } else if(t==="parallel"){
    wire("M45 150 V40 H100");el("circle",{cx:100,cy:40,r:4,fill:W},g);el("circle",{cx:140,cy:40,r:4,fill:W},g);el("text",{x:104,y:66,"font-size":12,fill:"var(--cl-text)"},g).textContent="switch";
    el("line",{x1:100,y1:40,x2:on?140:132,y2:on?40:22,stroke:"var(--cl-accent)","stroke-width":4,"stroke-linecap":"round"},g);
    wire("M140 40 H460");wire("M45 162 V290 H460");
    var xs=[200,310,420];
    for(var i=0;i<3;i++){wire("M"+xs[i]+" 40 V"+(i===2?85:118));wire("M"+xs[i]+" "+(i===2?215:182)+" V290");
      if(i<2)resistor(g,xs[i],150,true,"R"+(i+1),o.r[i]);}
    bulbX=420;bulbY=150;wire("M420 40 V128");wire("M420 172 V290");
    var I1=o.parts[0][3],I2=o.parts[1][3],I3=o.parts[2][3];
    [["M45 150 V40 H200",o.I],["M200 290 H45 V150",o.I],["M200 40 V290",I1],["M200 40 H310",I2+I3],["M310 40 V290",I2],["M310 40 H420",I3],["M420 40 V290",I3],["M420 290 H310",I3],["M310 290 H200",I2+I3]].forEach(function(a){paths.push({d:a[0],I:a[1],n:1})});
    bulbP=o.parts[2][2]*o.parts[2][3];
  } else {
    wire("M45 150 V40 H100");el("circle",{cx:100,cy:40,r:4,fill:W},g);el("circle",{cx:140,cy:40,r:4,fill:W},g);el("text",{x:104,y:66,"font-size":12,fill:"var(--cl-text)"},g).textContent="switch";
    el("line",{x1:100,y1:40,x2:on?140:132,y2:on?40:22,stroke:"var(--cl-accent)","stroke-width":4,"stroke-linecap":"round"},g);
    wire("M140 40 H170");resistor(g,198,40,false,"R1",o.r[0]);wire("M226 40 H330 M330 40 H440");
    wire("M330 40 V118");resistor(g,330,150,true,"R2",o.r[1]);wire("M330 182 V280");
    wire("M440 40 V128");wire("M440 172 V280");bulbX=440;bulbY=150;
    wire("M45 162 V280 H440");
    [["M45 150 V40 H330",o.I],["M330 280 H45 V150",o.I],["M330 40 V280",o.parts[1][3]],["M330 40 H440 V280 H330",o.parts[2][3]]].forEach(function(a){paths.push({d:a[0],I:a[1],n:1})});
    bulbP=o.parts[2][2]*o.parts[2][3];
  }
  // bulb
  var br=Math.min(1,bulbP/3);
  var bg=el("g",{},g);
  el("circle",{cx:bulbX,cy:bulbY,r:30*br+14,fill:"rgba(255,214,64,"+(0.55*br).toFixed(2)+")"},bg);
  el("circle",{cx:bulbX,cy:bulbY,r:17,fill:"rgba(255,235,120,"+(0.15+0.85*br).toFixed(2)+")",stroke:W,"stroke-width":2.5},bg);
  el("path",{d:"M"+(bulbX-8)+" "+(bulbY+6)+" l4 -10 l4 10 l4 -10 l4 10",fill:"none",stroke:W,"stroke-width":1.8},bg);
  el("text",{x:bulbX+24,y:bulbY-18,"font-size":12,fill:"var(--cl-text)"},bg).textContent="R3 "+o.r[2]+"Ω";
  // dots
  paths.forEach(function(p){
    if(!p.n)return;var pe=el("path",{d:p.d,fill:"none",stroke:"none"},g);p.len=pe.getTotalLength();p.el=pe;p.dots=[];p.n=Math.max(1,Math.round(p.len/38));
    for(var i=0;i<p.n;i++){p.dots.push(el("circle",{r:4.2,fill:"var(--cl-c2)"},g))}
    p.phase=0;
  });
  readout(o);
}
function readout(o){
  var P=o.V*o.I;
  $("ro").innerHTML=[["Total R",o.R.toFixed(1)+" Ω"],["Total current",o.I.toFixed(3)+" A"],["Battery",o.V+" V"],["Power",P.toFixed(2)+" W"]].map(function(x){return "<div><small>"+x[0]+"</small><strong>"+x[1]+"</strong></div>"}).join("");
  $("rt").tBodies[0].innerHTML=o.parts.map(function(p){return "<tr><td>"+p[0]+"</td><td>"+p[1]+"</td><td>"+p[2].toFixed(2)+"</td><td>"+p[3].toFixed(3)+"</td><td>"+(p[2]*p[3]).toFixed(2)+"</td></tr>"}).join("");
  ["V","R1","R2","R3"].forEach(function(k){$(k+"v").textContent=$(k).value});
}
function frame(ts){
  var dt=Math.min(0.05,(ts-last)/1000||0);last=ts;
  paths.forEach(function(p){if(!p.el||!p.dots)return;
    var v=Math.min(1,p.I/0.6)*160+ (p.I>0?15:0); // px/s grows with current
    p.phase=(p.phase+v*dt)%p.len;
    p.dots.forEach(function(c,i){c.setAttribute("opacity",p.I>0?1:0);var pt=p.el.getPointAtLength((p.phase+i*p.len/p.n)%p.len);c.setAttribute("cx",pt.x);c.setAttribute("cy",pt.y)})});
  requestAnimationFrame(frame);
}
function drawGraph(){
  var c=$("og"),x=c.getContext("2d"),W=c.width,H=c.height,L=44,B=30,T=10,R=14,cs=getComputedStyle(document.documentElement);
  var mut=cs.getPropertyValue("--cl-muted"),brd=cs.getPropertyValue("--cl-border"),acc=cs.getPropertyValue("--cl-accent");
  x.clearRect(0,0,W,H);x.font="12px system-ui";x.fillStyle=mut;x.strokeStyle=brd;
  var imax=Math.max(0.5,Math.max.apply(null,pts.map(function(p){return p.I}).concat([0]))*1.15),vmax=24;
  function X(i){return L+i/imax*(W-L-R)}function Y(v){return T+(1-v/vmax)*(H-T-B)}
  for(var v=0;v<=24;v+=6){x.beginPath();x.moveTo(L,Y(v));x.lineTo(W-R,Y(v));x.stroke();x.fillText(v,L-24,Y(v)+4)}
  for(var k=0;k<=4;k++){var i=imax*k/4;x.fillText(i.toFixed(2),X(i)-12,H-12)}
  x.fillText("Current (A)",W/2-30,H-0);x.save();x.translate(10,H/2+12);x.rotate(-Math.PI/2);x.fillText("Voltage (V)",0,0);x.restore();
  x.fillStyle=acc;pts.forEach(function(p){x.beginPath();x.arc(X(p.I),Y(p.V),5,0,7);x.fill()});
  if(pts.length>=2){var sx=0,sy=0,sxx=0,sxy=0,n=pts.length;pts.forEach(function(p){sx+=p.I;sy+=p.V;sxx+=p.I*p.I;sxy+=p.I*p.V});
    var m=(sxy)/(sxx||1); // through origin
    x.strokeStyle=acc;x.lineWidth=2;x.beginPath();x.moveTo(X(0),Y(0));x.lineTo(X(imax),Y(m*imax));x.stroke();x.lineWidth=1;
    $("grad").textContent="Gradient ≈ "+m.toFixed(1)+" Ω (= total resistance)"}
  else $("grad").textContent="";
}
$("sw").onclick=function(){on=!on;this.textContent="Switch: "+(on?"ON":"OFF");this.setAttribute("aria-pressed",on);build()};
["topo","V","R1","R2","R3"].forEach(function(i){$(i).oninput=function(){build();}});
$("log").onclick=function(){var o=solve();if(!on||o.I===0)return;pts.push({V:o.V,I:o.I});drawGraph();CurioActivity.log("lab","circuits","Circuit builder","Recorded "+o.V+" V, "+o.I.toFixed(3)+" A ("+o.t+")")};
$("clr").onclick=function(){pts=[];drawGraph()};
// challenge
var ch;function newCh(){var t=Math.random()<.5,a=[10,20,30,40,60,100,120][Math.floor(Math.random()*7)],b=[10,20,30,40,60,100][Math.floor(Math.random()*6)],V=[6,9,12,24][Math.floor(Math.random()*4)];
  if(t){ch={a:V/(a+b),q:"A "+V+" V battery is connected to a "+a+" Ω and a "+b+" Ω resistor in SERIES. What current flows (A)?"}}
  else{ch={a:V/par(a,b),q:"A "+V+" V battery is connected to a "+a+" Ω and a "+b+" Ω resistor in PARALLEL. What is the total current (A)?"}}
  $("chq").textContent=ch.q;$("cha").value="";$("chr").textContent=""}
$("chb").onclick=function(){var v=parseFloat($("cha").value);if(isNaN(v))return;var ok=Math.abs(v-ch.a)/ch.a<0.02;
  $("chr").innerHTML=ok?'<span class="cl-ok">✔ Correct ('+ch.a.toFixed(3)+' A)</span>':'<span class="cl-err">✘ Try again. Series: add resistances. Parallel: add 1/R.</span>';
  CurioActivity.log("lab","circuits-challenge","Circuit challenge",ok?"Solved":"Missed")};
$("chn").onclick=newCh;
window.addEventListener("curio:theme",drawGraph);
newCh();build();drawGraph();requestAnimationFrame(frame);
window.__ckt={solve:solve};
})();
</script>
