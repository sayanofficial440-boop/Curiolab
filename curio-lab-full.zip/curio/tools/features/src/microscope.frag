Virtual Microscope|labs|pages/labs/microscope.html
<p><a href="index.html">← All labs</a></p>
<h1>Virtual Microscope</h1>
<p class="cl-sub">Pick a slide, start on the lowest power, centre what you want to see, then focus and step up the objective, just like a real microscope.</p>
<div class="cl-lab">
  <div>
    <div class="cl-stage" style="background:#111;border-color:#333"><canvas id="eye" width="560" height="560" tabindex="0" role="img" aria-label="Microscope field of view. Drag to move the slide; arrow keys also move it."></canvas></div>
    <div class="cl-readout" style="margin-top:10px"><div><small>Total magnification</small><strong id="mag"></strong></div><div><small>Field of view</small><strong id="fov"></strong></div><div><small>Focus</small><strong id="foc">blurry</strong></div></div>
  </div>
  <div>
    <div class="cl-card"><h2>Slide</h2>
      <select id="slide" aria-label="Slide"><option value="onion">Onion epidermis (plant)</option><option value="cheek">Human cheek cells</option><option value="para">Paramecium (pond water)</option><option value="blood">Human blood smear</option></select>
      <h2 style="margin-top:14px">Objective lens (eyepiece ×10)</h2>
      <div class="cl-row" id="objs" role="group" aria-label="Objective lens"></div>
      <label class="cl-f" for="coarse">Coarse focus</label><input id="coarse" type="range" min="0" max="100" step="1" value="12">
      <label class="cl-f" for="fine">Fine focus</label><input id="fine" type="range" min="0" max="100" step="0.5" value="50">
      <label class="cl-f" for="light">Light / diaphragm</label><input id="light" type="range" min="20" max="100" step="1" value="75">
      <div class="cl-row"><label><input type="checkbox" id="lab"> Show labels (when in focus)</label></div>
      <div class="cl-row"><button id="ctr">Centre slide</button><button id="newsp">New area</button></div>
      <p class="cl-note">Drag the view (or use arrow keys) to move the stage. The picture is upside-down and reversed in real microscopes. Here, drag moves the slide as you'd expect.</p>
    </div>
    <div class="cl-card" style="margin-top:12px"><h2>Observe &amp; answer</h2>
      <p id="q" class="cl-note"></p>
      <div class="cl-row" id="opts"></div><div id="qr" role="status"></div>
    </div>
  </div>
</div>
<script>
(function(){
var $=function(i){return document.getElementById(i)};
var cv=$("eye"),mctx=cv.getContext("2d"),SZ=560,off=document.createElement("canvas"),ctx;off.width=off.height=SZ;ctx=off.getContext("2d");
var OBJ=[{x:4,fov:4500,t:"4×"},{x:10,fov:1800,t:"10×"},{x:40,fov:450,t:"40×"},{x:100,fov:180,t:"100×"}];
var st={sp:"onion",obj:0,cx:0,cy:0,seed:1,shapes:[],half:1500,best:50,coarseBest:0};
function rng(s){return function(){s=(s*1664525+1013904223)>>>0;return s/4294967296}}
function gen(){
  var R=rng(st.seed*7919+(st.sp.charCodeAt(0)*131)),sh=[],half;
  if(st.sp==="onion"){half=1500;for(var gy=-half;gy<half;gy+=85){var off=0;for(var gx=-half;gx<half;gx+=260){var w=230+R()*50,h=70+R()*20;sh.push({k:"onion",x:gx+off+R()*10,y:gy+R()*6,w:w,h:h,nx:(R()-.5)*w*.4,ny:(R()-.5)*h*.2})}}}
  else if(st.sp==="cheek"){half=1500;for(var i=0;i<130;i++){var r=28+R()*14;sh.push({k:"cheek",x:(R()*2-1)*half,y:(R()*2-1)*half,r:r,rot:R()*6,nr:r*.28})}
    for(var j=0;j<220;j++)sh.push({k:"bac",x:(R()*2-1)*half,y:(R()*2-1)*half,l:2+R()*1.5,rot:R()*6})}
  else if(st.sp==="para"){half=1500;for(var i=0;i<40;i++)sh.push({k:"para",x:(R()*2-1)*half,y:(R()*2-1)*half,L:180+R()*50,rot:R()*6.28,seed:R()*99});
    for(var j=0;j<300;j++)sh.push({k:"debris",x:(R()*2-1)*half,y:(R()*2-1)*half,r:2+R()*8})}
  else{half=450;for(var i=0;i<4200;i++){sh.push({k:"rbc",x:(R()*2-1)*half,y:(R()*2-1)*half,r:3.3+R()*.5})}
    for(var j=0;j<45;j++)sh.push({k:"wbc",x:(R()*2-1)*half,y:(R()*2-1)*half,r:6+R()*1.5,lobes:2+Math.floor(R()*3),rot:R()*6})}
  st.shapes=sh;st.half=half;
}
function focusBlur(){
  var o=OBJ[st.obj],c=+$("coarse").value,f=+$("fine").value;
  var best=st.coarseBest; // coarse position that is "roughly right"
  var pos=c+(f-50)*0.12; // fine adds ±6
  var d=Math.abs(pos-best); // distance from perfect focus in units
  var depth=[9,5,2.2,1.0][st.obj]; // narrower depth of field at high power
  return Math.max(0,(d-depth*0.25))/depth*[1.4,2.2,3.2,4.2][st.obj];
}
function setBest(){st.coarseBest=40+((st.seed*37)%20)+st.obj*4}
function px(){return SZ/OBJ[st.obj].fov}
function draw(){
  var s=px(),b=focusBlur();
  ctx.setTransform(1,0,0,1,0,0);ctx.save();ctx.clearRect(0,0,SZ,SZ);
  var light=+$("light").value/100;
  ctx.fillStyle="rgb("+Math.round(250*light)+","+Math.round(246*light)+","+Math.round(238*light)+")";ctx.fillRect(0,0,SZ,SZ);
  ctx.translate(SZ/2-st.cx*s,SZ/2-st.cy*s);ctx.scale(s,s);
  var vis=SZ/2/s*1.5,X0=st.cx-vis,X1=st.cx+vis,Y0=st.cy-vis,Y1=st.cy+vis,labels=$("lab").checked&&b<0.8&&st.obj>=1;
  var lw=1/s;ctx.lineWidth=lw;
  var shapes=st.shapes,sharp=b<0.8;
  for(var i=0;i<shapes.length;i++){var o=shapes[i];if(o.x<X0-300||o.x>X1+300||o.y<Y0-300||o.y>Y1+300)continue;
    if(o.k==="onion"){ctx.strokeStyle="rgba(150,80,110,.8)";ctx.lineWidth=Math.max(lw*1.4,2.5);ctx.fillStyle="rgba(225,190,210,.35)";ctx.beginPath();ctx.rect(o.x,o.y,o.w,o.h);ctx.fill();ctx.stroke();
      ctx.fillStyle="rgba(120,60,130,.75)";ctx.beginPath();ctx.ellipse(o.x+o.w/2+o.nx,o.y+o.h/2+o.ny,9,7,0,0,7);ctx.fill();
      if(labels&&st.obj>=2&&Math.abs(o.x+o.w/2-st.cx)<130&&Math.abs(o.y+o.h/2-st.cy)<80)lbl(o.x+o.w/2+o.nx,o.y+o.h/2+o.ny,"nucleus",o.x+o.w,o.y,"cell wall",s)}
    else if(o.k==="cheek"){ctx.save();ctx.translate(o.x,o.y);ctx.rotate(o.rot);ctx.fillStyle="rgba(200,180,210,.35)";ctx.strokeStyle="rgba(120,90,150,.7)";ctx.lineWidth=Math.max(lw*1.2,1.5);
      ctx.beginPath();ctx.ellipse(0,0,o.r*1.1,o.r*.9,0,0,7);ctx.fill();ctx.stroke();ctx.fillStyle="rgba(90,50,140,.75)";ctx.beginPath();ctx.arc(0,0,o.nr,0,7);ctx.fill();ctx.restore();
      if(labels&&st.obj>=2&&Math.hypot(o.x-st.cx,o.y-st.cy)<110)lbl(o.x,o.y,"nucleus",o.x+o.r,o.y-o.r*.7,"cell membrane",s)}
    else if(o.k==="bac"){ctx.save();ctx.translate(o.x,o.y);ctx.rotate(o.rot);ctx.fillStyle="rgba(60,60,60,.6)";ctx.fillRect(-o.l/2,-.4,o.l,.8);ctx.restore()}
    else if(o.k==="para"){para(o,s,labels)}
    else if(o.k==="debris"){ctx.fillStyle="rgba(100,110,80,.35)";ctx.beginPath();ctx.arc(o.x,o.y,o.r,0,7);ctx.fill()}
    else if(o.k==="rbc"){ctx.fillStyle="rgba(210,70,80,.65)";ctx.beginPath();ctx.arc(o.x,o.y,o.r,0,7);ctx.fill();ctx.fillStyle="rgba(240,150,150,.7)";ctx.beginPath();ctx.arc(o.x,o.y,o.r*.45,0,7);ctx.fill()}
    else if(o.k==="wbc"){ctx.save();ctx.translate(o.x,o.y);ctx.rotate(o.rot);ctx.fillStyle="rgba(210,215,235,.5)";ctx.beginPath();ctx.arc(0,0,o.r,0,7);ctx.fill();ctx.fillStyle="rgba(70,50,150,.85)";
      for(var l=0;l<o.lobes;l++){var a=l/o.lobes*6.28;ctx.beginPath();ctx.arc(Math.cos(a)*o.r*.4,Math.sin(a)*o.r*.4,o.r*.32,0,7);ctx.fill()}ctx.restore();
      if(labels&&st.obj>=2&&Math.hypot(o.x-st.cx,o.y-st.cy)<80)lbl(o.x,o.y,"white blood cell",o.x,o.y,"",s)}}
  ctx.restore();
  // composite: one blur for the whole scene (per-shape blur would be far too slow)
  mctx.clearRect(0,0,SZ,SZ);mctx.save();mctx.beginPath();mctx.arc(SZ/2,SZ/2,SZ/2-2,0,7);mctx.clip();
  mctx.filter=b>0.15?"blur("+Math.min(14,b).toFixed(1)+"px)":"none";mctx.drawImage(off,0,0);mctx.filter="none";
  var g=mctx.createRadialGradient(SZ/2,SZ/2,SZ*.35,SZ/2,SZ/2,SZ/2);g.addColorStop(0,"rgba(0,0,0,0)");g.addColorStop(1,"rgba(0,0,0,"+(0.45*(1-light*.4)).toFixed(2)+")");mctx.fillStyle=g;mctx.fillRect(0,0,SZ,SZ);mctx.restore();
  var bar={0:1000,1:500,2:100,3:50}[st.obj];mctx.fillStyle="rgba(255,255,255,.9)";mctx.fillRect(24,SZ-44,bar*s,5);mctx.font="bold 14px system-ui";mctx.fillText(bar+" µm",24,SZ-52);
  var fine=b<0.4;
  $("mag").textContent=OBJ[st.obj].x*10+"×";$("fov").textContent=OBJ[st.obj].fov>=1000?(OBJ[st.obj].fov/1000).toFixed(1)+" mm":OBJ[st.obj].fov+" µm";
  $("foc").textContent=b<0.4?"sharp ✔":b<1.5?"almost":"blurry";
}
function lbl(x,y,t1,x2,y2,t2,s){ // labels drawn in world units scaled back to screen size
  var f=14/ctx.getTransform().a;ctx.save();ctx.lineJoin="round";ctx.font="bold "+f+"px system-ui";ctx.fillStyle="#fff";ctx.strokeStyle="#000";ctx.lineWidth=f*.25;
  ctx.strokeText(t1,x+f,y-f*.5);ctx.fillText(t1,x+f,y-f*.5);if(t2){ctx.strokeText(t2,x2,y2-f*.3);ctx.fillText(t2,x2,y2-f*.3)}ctx.restore()}
function para(o,s,labels){
  ctx.save();ctx.translate(o.x,o.y);ctx.rotate(o.rot);var L=o.L,W=L*.28;
  ctx.fillStyle="rgba(190,205,170,.45)";ctx.strokeStyle="rgba(90,110,70,.8)";ctx.lineWidth=Math.max(1/s*1.3,1.5);
  ctx.beginPath();ctx.moveTo(-L/2,0);ctx.bezierCurveTo(-L/2,-W*1.2,L/2-30,-W*1.1,L/2,-W*.2);ctx.bezierCurveTo(L/2+4,W*.4,L/2-40,W*1.1,-L/2,W*.9);ctx.bezierCurveTo(-L/2-14,W*.6,-L/2-8,W*.1,-L/2,0);ctx.fill();ctx.stroke();
  if(s>0.4){ctx.strokeStyle="rgba(90,110,70,.55)";ctx.lineWidth=1/s;for(var a=0;a<60;a++){var t=a/60*6.28,ex=Math.cos(t)*L*.52,ey=Math.sin(t)*W*.95;ctx.beginPath();ctx.moveTo(ex,ey);ctx.lineTo(ex*1.07,ey*1.15);ctx.stroke()}}
  ctx.fillStyle="rgba(100,70,120,.6)";ctx.beginPath();ctx.ellipse(0,0,L*.09,W*.22,0,0,7);ctx.fill();
  ctx.fillStyle="rgba(255,255,255,.7)";ctx.beginPath();ctx.arc(-L*.25,W*.2,W*.16,0,7);ctx.fill();ctx.beginPath();ctx.arc(L*.28,-W*.2,W*.14,0,7);ctx.fill();ctx.restore();
  if(labels&&Math.hypot(o.x-st.cx,o.y-st.cy)<OBJ[st.obj].fov*.5)lbl(o.x,o.y,"macronucleus",o.x-o.L*.2,o.y+o.L*.2,"contractile vacuole",s)}
// interaction
var drag=null;
cv.addEventListener("pointerdown",function(e){drag={x:e.clientX,y:e.clientY};cv.setPointerCapture(e.pointerId)});
cv.addEventListener("pointermove",function(e){if(!drag)return;var r=cv.getBoundingClientRect(),k=SZ/r.width/px();st.cx-=(e.clientX-drag.x)*k;st.cy-=(e.clientY-drag.y)*k;clamp();drag={x:e.clientX,y:e.clientY};draw()});
cv.addEventListener("pointerup",function(){drag=null});
cv.addEventListener("keydown",function(e){var m={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key];if(!m)return;e.preventDefault();var step=OBJ[st.obj].fov*0.06;st.cx+=m[0]*step;st.cy+=m[1]*step;clamp();draw()});
function clamp(){st.cx=Math.max(-st.half,Math.min(st.half,st.cx));st.cy=Math.max(-st.half,Math.min(st.half,st.cy))}
// objectives
var ob=$("objs");OBJ.forEach(function(o,i){var b=document.createElement("button");b.textContent=o.t;b.setAttribute("aria-pressed",i===0);b.onclick=function(){
  if(i>st.obj+1){$("qr").innerHTML='<span class="cl-err">Step up one lens at a time: re-focus after each change.</span>';}
  st.obj=i;setBest();[].forEach.call(ob.children,function(c,j){c.setAttribute("aria-pressed",j===i);c.className=j===i?"primary":""});
  CurioActivity.log("lab","microscope-"+st.sp,"Virtual microscope","Used "+o.t+" objective on "+$("slide").selectedOptions[0].text);draw()};
  if(i===0)b.className="primary";ob.appendChild(b)});
["coarse","fine","light"].forEach(function(i){$(i).oninput=draw});$("lab").onchange=draw;
$("slide").onchange=function(){st.sp=this.value;st.cx=st.cy=0;gen();setBest();q();draw()};
$("ctr").onclick=function(){st.cx=st.cy=0;draw()};
$("newsp").onclick=function(){st.seed++;st.cx=(Math.random()-.5)*st.half;st.cy=(Math.random()-.5)*st.half;gen();setBest();draw()};
// questions
var QS={onion:["Which structure gives the onion cells their rectangular, brick-like outline?",["Cell wall","Cell membrane","Chloroplast"],0],
 cheek:["Cheek cells have a dark, round structure in the middle. What is it?",["Nucleus","Vacuole","Cell wall"],0],
 para:["Paramecium swims using hair-like structures. What are they called?",["Cilia","Flagella","Pseudopodia"],0],
 blood:["Which cells are the many small, red, biconcave discs?",["Red blood cells","White blood cells","Platelets"],0]};
function q(){var d=QS[st.sp];$("q").textContent=d[0];var idx=[0,1,2].sort(function(){return Math.random()-.5});
  $("opts").innerHTML="";$("qr").textContent="";idx.forEach(function(i){var b=document.createElement("button");b.textContent=d[1][i];b.onclick=function(){var ok=i===d[2];$("qr").innerHTML=ok?'<span class="cl-ok">✔ Correct</span>':'<span class="cl-err">✘ Look again at high power</span>';
    CurioActivity.log("lab","microscope-quiz","Microscope question",$("slide").selectedOptions[0].text+": "+(ok?"correct":"incorrect"))};$("opts").appendChild(b)})}
gen();setBest();q();draw();
window.__mic={st:st,draw:draw,focusBlur:focusBlur};
})();
</script>
