Notes & Cheat Sheets|notes|pages/notes/index.html
<h1>Notes &amp; Cheat Sheets</h1>
<p class="cl-sub">Printable one-to-two page PDFs for quick revision. Free to download, print and share.</p>
<div class="cl-card">
  <div class="cl-row"><input id="q" type="text" placeholder="Search e.g. pH, quadratic, mitosis…" aria-label="Search notes" style="flex:1 1 220px">
  <div class="cl-tabs" style="margin:0" id="chips" role="group" aria-label="Filter by subject"></div></div>
</div>
<div class="cl-grid" id="list" style="margin-top:14px"></div>
<p class="cl-note" id="empty" hidden>No notes match your search.</p>
<div class="cl-card" style="margin-top:18px"><h2>Your downloads</h2><div id="dl" class="cl-note">Nothing downloaded yet.</div></div>
<script>
(function(){
var DATA=/*NOTES_JSON*/;
var ICON={Physics:"⚛️",Chemistry:"⚗️",Biology:"🧬",Mathematics:"📐"},sel="All",$=function(i){return document.getElementById(i)};
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
var subs=["All"].concat(DATA.map(function(d){return d.subject}).filter(function(v,i,a){return a.indexOf(v)===i}));
function chips(){$("chips").innerHTML=subs.map(function(s){return '<button role="button" aria-pressed="'+(s===sel)+'" data-s="'+s+'" '+(s===sel?'style="background:var(--cl-accent);color:var(--cl-accent-ink);border-color:var(--cl-accent)"':'')+'>'+s+'</button>'}).join("")}
function render(){var q=$("q").value.trim().toLowerCase(),n=0;
  $("list").innerHTML=DATA.filter(function(d){return (sel==="All"||d.subject===sel)&&(!q||(d.title+" "+d.desc+" "+d.topics.join(" ")+" "+d.subject).toLowerCase().indexOf(q)>=0)}).map(function(d){n++;
   return '<div class="cl-card"><div class="em" style="font-size:30px">'+ICON[d.subject]+'</div><h3 style="margin:.3em 0 .2em">'+esc(d.title)+'</h3><p class="cl-note" style="margin:0 0 8px">'+esc(d.desc)+'</p>'+
   '<span class="cl-tag">'+d.subject+' · '+esc(d.level)+' · PDF '+d.kb+' KB</span><div class="cl-row" style="margin-top:12px"><a class="cl-btn primary" href="pdf/'+d.id+'.pdf" download data-id="'+d.id+'">⬇ Download PDF</a><a class="cl-btn" href="pdf/'+d.id+'.pdf" target="_blank" rel="noopener" data-id="'+d.id+'">View</a></div></div>'}).join("");
  $("empty").hidden=n>0}
function dls(){var a=CurioActivity.all().filter(function(x){return x.type==="note"}).reverse(),seen={},h=[];
  a.forEach(function(x){if(!seen[x.id]){seen[x.id]=1;h.push("<li>"+esc(x.label)+" <span class='cl-note'>("+new Date(x.ts).toLocaleDateString()+")</span></li>")}});
  $("dl").innerHTML=h.length?"<ul class='steps'>"+h.join("")+"</ul>":"Nothing downloaded yet."}
$("chips").addEventListener("click",function(e){var b=e.target.closest("button");if(b){sel=b.dataset.s;chips();render()}});
$("q").addEventListener("input",render);
$("list").addEventListener("click",function(e){var a=e.target.closest("a[data-id]");if(!a)return;var d=DATA.filter(function(x){return x.id===a.dataset.id})[0];CurioActivity.log("note",d.id,d.title,"Cheat sheet "+(a.hasAttribute("download")?"downloaded":"viewed"));setTimeout(dls,50)});
chips();render();dls();
})();
</script>
