Acid–Base Titration|labs|pages/labs/titration.html
<p><a href="index.html">← All labs</a></p>
<h1>Acid–Base Titration</h1>
<p class="cl-sub">Titrate the acid in the flask with 0.100 M NaOH from the burette. Stop when the indicator just changes colour.</p>

<div class="cl-lab">
  <div>
    <div class="cl-stage"><svg id="apparatus" viewBox="0 0 400 420" role="img" aria-label="Burette above a conical flask containing the solution being titrated"></svg></div>
    <div class="cl-row">
      <button id="b01" class="primary" aria-label="Add 0.1 millilitre">+ 0.1 mL (drop)</button>
      <button id="b1">+ 1 mL</button>
      <button id="b5">+ 5 mL</button>
      <button id="reset">Reset</button>
    </div>
    <div class="cl-row"><label><input type="checkbox" id="hold"> Hold-to-pour (press and hold the <b>+ 0.1</b> button)</label></div>
    <div class="cl-card" style="margin-top:12px"><h2>Titration curve (pH vs volume of NaOH)</h2>
      <div class="cl-stage" style="border:0;padding:0"><canvas id="curve" width="640" height="320" role="img" aria-label="Plot of pH against volume of NaOH added"></canvas></div>
      <p class="cl-note" id="curvenote">The curve is revealed as you add titrant.</p></div>
  </div>

  <div>
    <div class="cl-card">
      <h2>Setup</h2>
      <label class="cl-f" for="mode">Mode</label>
      <select id="mode"><option value="explore">Explore – known concentration</option><option value="unknown">Challenge – find the unknown concentration</option></select>
      <label class="cl-f" for="acid">Acid in flask (25.0 mL)</label>
      <select id="acid"><option value="strong">Strong acid – HCl</option><option value="weak">Weak acid – CH₃COOH (Ka = 1.8×10⁻⁵)</option></select>
      <div id="concBox"><label class="cl-f" for="conc">Acid concentration: <span class="cl-val" id="concv">0.100</span> M</label>
      <input id="conc" type="range" min="0.02" max="0.2" step="0.005" value="0.1"></div>
      <label class="cl-f" for="ind">Indicator</label>
      <select id="ind"><option value="phph">Phenolphthalein (8.2–10.0)</option><option value="mo">Methyl orange (3.1–4.4)</option><option value="btb">Bromothymol blue (6.0–7.6)</option></select>
    </div>
    <div class="cl-card" style="margin-top:12px">
      <h2>Readings</h2>
      <div class="cl-readout">
        <div><small>Burette reading</small><strong id="rv">0.00 mL</strong></div>
        <div><small>Flask colour</small><strong id="rc">–</strong></div>
        <div id="phbox"><small>pH (pH meter)</small><strong id="rph">–</strong></div>
      </div>
      <div class="cl-row"><label><input type="checkbox" id="showph" checked> Show pH meter</label></div>
      <button id="rec" style="width:100%">📝 Record this as my end-point</button>
      <table class="cl-t" id="tbl" style="margin-top:10px"><thead><tr><th>#</th><th>End-point (mL)</th><th>pH</th><th>Calculated conc.</th></tr></thead><tbody></tbody></table>
    </div>
    <div class="cl-card" id="check" style="margin-top:12px;display:none">
      <h2>Check your answer</h2>
      <p class="cl-note">Use <span class="m">C₁V₁ = C₂V₂</span> (1:1 acid–base): C(acid) = 0.100 × V(NaOH) ÷ 25.0</p>
      <label class="cl-f" for="ans">Acid concentration (M)</label>
      <input id="ans" type="number" step="0.001" inputmode="decimal" placeholder="e.g. 0.085">
      <div class="cl-row"><button class="primary" id="submit">Check</button><button id="newq">New unknown</button></div>
      <div id="result" role="status"></div>
    </div>
    <div class="cl-card" style="margin-top:12px"><h2>Tips</h2>
      <ul class="steps"><li>Go fast with <b>+ 5 mL</b>, then slow to single drops near the colour change.</li>
      <li>Try the wrong indicator with the weak acid. Methyl orange changes far too early.</li>
      <li>Turn the pH meter off in Challenge mode to rely on the indicator, like a real lab.</li></ul></div>
  </div>
</div>

<script>
(function(){
var VA=25.0, CB=0.100, KW=1e-14, KA=1.8e-5, BURETTE=50;
var $=function(i){return document.getElementById(i)};
var st={vb:0,unknownC:0,recs:[]};
var INDS={
  phph:{lo:8.2,hi:10.0,acid:[255,255,255,0.08],base:[236,64,140,0.75],an:"colourless",bn:"pink"},
  mo:{lo:3.1,hi:4.4,acid:[230,50,40,0.75],base:[250,200,40,0.75],an:"red",bn:"yellow"},
  btb:{lo:6.0,hi:7.6,acid:[245,210,40,0.75],base:[50,110,220,0.78],an:"yellow",bn:"blue"}
};
function newUnknown(){st.unknownC=Math.round((0.04+Math.random()*0.12)*1000)/1000}
newUnknown();
function Ca(){return $("mode").value==="unknown"?st.unknownC:+$("conc").value}
function pH(vb){
  var weak=$("acid").value==="weak",ka=weak?KA:1e9,ca=Ca();
  var vt=VA+vb,ct=ca*VA/vt,na=CB*vb/vt;
  function f(h){return na+h-KW/h-ct*ka/(ka+h)}
  var lo=-14,hi=1; // log10 h range
  for(var i=0;i<80;i++){var m=(lo+hi)/2;if(f(Math.pow(10,m))>0)hi=m;else lo=m}
  return -(lo+hi)/2;
}
function eqVol(){return Ca()*VA/CB}
function indColor(p){
  var d=INDS[$("ind").value],t=(p-d.lo)/(d.hi-d.lo);t=Math.max(0,Math.min(1,t));
  var c=[0,1,2,3].map(function(i){return d.acid[i]+(d.base[i]-d.acid[i])*t});
  return {css:"rgba("+Math.round(c[0])+","+Math.round(c[1])+","+Math.round(c[2])+","+c[3].toFixed(2)+")",name:t<0.15?d.an:t>0.85?d.bn:"changing…"};
}
var svg=$("apparatus");
function drawApp(){
  var p=pH(st.vb),c=indColor(p),frac=st.vb/BURETTE;
  var liqTop=60+frac*220; // liquid surface falls as titrant used
  svg.innerHTML=
   '<defs><clipPath id="fl"><path d="M165 330 L165 300 L120 395 Q112 410 130 410 L270 410 Q288 410 280 395 L235 300 L235 330 Z"/></clipPath></defs>'+
   '<rect x="188" y="40" width="24" height="260" rx="4" fill="none" stroke="var(--cl-muted)" stroke-width="2"/>'+
   '<rect x="190" y="'+liqTop+'" width="20" height="'+(300-liqTop)+'" fill="rgba(80,140,230,.35)"/>'+
   [0,10,20,30,40,50].map(function(v){var y=60+v/BURETTE*220;return '<line x1="'+(v%10===0?176:182)+'" x2="188" y1="'+y+'" y2="'+y+'" stroke="var(--cl-muted)"/><text x="170" y="'+(y+4)+'" text-anchor="end" font-size="11" fill="var(--cl-muted)">'+v+'</text>'}).join("")+
   '<rect x="196" y="300" width="8" height="14" fill="var(--cl-muted)"/><rect x="184" y="296" width="32" height="6" rx="3" fill="var(--cl-accent)"/>'+
   '<circle id="drop" cx="200" cy="322" r="3.5" fill="rgba(80,140,230,.8)" opacity="0"/>'+
   '<path d="M165 330 L165 300 M235 330 L235 300" stroke="none"/>'+
   '<path d="M175 325 L175 345 L118 398 Q110 412 128 412 L272 412 Q290 412 282 398 L225 345 L225 325" fill="rgba(160,200,230,.12)" stroke="var(--cl-muted)" stroke-width="2.5"/>'+
   '<g clip-path="url(#fl)"><path d="M148 372 L252 372 L290 412 L110 412 Z" fill="'+c.css+'" id="liq"/></g>'+
   '<rect x="170" y="322" width="60" height="6" rx="2" fill="var(--cl-muted)"/>';
  $("rv").textContent=st.vb.toFixed(2)+" mL";
  $("rc").textContent=c.name;
  $("rph").textContent=p.toFixed(2);
  $("phbox").style.display=$("showph").checked?"":"none";
  drawCurve();
}
function drop(){var d=$("drop");if(!d)return;d.setAttribute("opacity","1");d.animate([{transform:"translateY(0)"},{transform:"translateY(40px)",opacity:0}],{duration:300});setTimeout(function(){d.setAttribute("opacity","0")},300)}
function add(v){st.vb=Math.min(BURETTE,Math.round((st.vb+v)*100)/100);drawApp();if(v<=0.1)drop()}
function drawCurve(){
  var cv=$("curve"),x=cv.getContext("2d"),W=cv.width,H=cv.height,L=46,B=34,T=10,R=12;
  var cs=getComputedStyle(document.documentElement),mut=cs.getPropertyValue("--cl-muted")||"#888",acc=cs.getPropertyValue("--cl-accent")||"#55f",brd=cs.getPropertyValue("--cl-border")||"#ccc",bad=cs.getPropertyValue("--cl-c2")||"#e60";
  x.clearRect(0,0,W,H);x.font="12px system-ui";x.fillStyle=mut;x.strokeStyle=brd;x.lineWidth=1;
  var xmax=Math.max(40,Math.ceil(eqVol()*2/5)*5);xmax=Math.min(xmax,50);
  function X(v){return L+v/xmax*(W-L-R)}function Y(p){return T+(14-p)/14*(H-T-B)}
  for(var p=0;p<=14;p+=2){x.beginPath();x.moveTo(L,Y(p));x.lineTo(W-R,Y(p));x.stroke();x.fillText(p,L-22,Y(p)+4)}
  for(var v=0;v<=xmax;v+=10){x.fillText(v,X(v)-6,H-16)}
  x.fillText("Volume NaOH added (mL)",W/2-60,H-2);x.save();x.translate(12,H/2+10);x.rotate(-Math.PI/2);x.fillText("pH",0,0);x.restore();
  // indicator band
  var d=INDS[$("ind").value];x.fillStyle="rgba(120,120,200,.13)";x.fillRect(L,Y(d.hi),W-L-R,Y(d.lo)-Y(d.hi));
  x.strokeStyle=acc;x.lineWidth=2.5;x.beginPath();
  var first=true;for(var v=0;v<=st.vb+1e-9;v+=0.1){var yy=Y(pH(v));if(first){x.moveTo(X(v),yy);first=false}else x.lineTo(X(v),yy)}x.stroke();
  x.fillStyle=acc;x.beginPath();x.arc(X(st.vb),Y(pH(st.vb)),5,0,7);x.fill();
  if($("mode").value==="explore"){var ev=eqVol();if(st.vb>=ev-0.05){x.fillStyle=bad;x.fillText("equivalence "+ev.toFixed(1)+" mL",X(ev)+6,Y(7)+4)}}
}
function recEnd(){
  var calc=0.1*st.vb/VA;
  st.recs.push({v:st.vb,p:pH(st.vb),c:calc});
  var tb=$("tbl").tBodies[0],r=tb.insertRow();[st.recs.length,st.vb.toFixed(2),$("showph").checked?pH(st.vb).toFixed(2):"–",calc.toFixed(4)+" M"].forEach(function(t){r.insertCell().textContent=t});
  if($("mode").value==="explore")CurioActivity.log("lab","titration","Acid–base titration","End-point "+st.vb.toFixed(1)+" mL, C = "+calc.toFixed(3)+" M");
}
function reset(){st.vb=0;drawApp()}
$("b01").onclick=function(){add(0.1)};$("b1").onclick=function(){add(1)};$("b5").onclick=function(){add(5)};
var tm;$("b01").addEventListener("pointerdown",function(){if(!$("hold").checked)return;tm=setInterval(function(){add(0.1)},90)});
["pointerup","pointerleave","pointercancel"].forEach(function(e){$("b01").addEventListener(e,function(){clearInterval(tm)})});
$("reset").onclick=reset;$("rec").onclick=recEnd;
$("conc").oninput=function(){$("concv").textContent=(+this.value).toFixed(3);reset()};
["acid","ind"].forEach(function(i){$(i).onchange=reset});$("showph").onchange=drawApp;
$("mode").onchange=function(){var u=this.value==="unknown";$("concBox").style.display=u?"none":"";$("check").style.display=u?"":"none";if(u){$("showph").checked=false}else $("showph").checked=true;newUnknown();$("result").textContent="";st.recs=[];$("tbl").tBodies[0].innerHTML="";reset()};
$("submit").onclick=function(){var a=parseFloat($("ans").value);if(isNaN(a)){$("result").innerHTML='<span class="cl-err">Enter a number.</span>';return}
  var err=Math.abs(a-st.unknownC)/st.unknownC,ok=err<=0.03;
  $("result").innerHTML=ok?'<span class="cl-ok">✔ Correct! The acid was '+st.unknownC.toFixed(3)+' M.</span>':'<span class="cl-err">✘ Not quite (aim for within 3%). Try a slower approach to the end-point.</span>';
  CurioActivity.log("lab","titration-challenge","Titration challenge",(ok?"Solved":"Missed")+" – unknown "+st.unknownC.toFixed(3)+" M, answered "+a.toFixed(3)+" M");
  if(ok){}};
$("newq").onclick=function(){newUnknown();$("result").textContent="";$("ans").value="";st.recs=[];$("tbl").tBodies[0].innerHTML="";reset()};
window.addEventListener("curio:theme",drawApp);
$("concv").textContent=(+$("conc").value).toFixed(3);
drawApp();
window.__titr={pH:pH,eqVol:eqVol,st:st};
})();
</script>
