Math tools|math|pages/math-tools/index.html
<h1>Graphing Calculator &amp; Equation Solver</h1>
<p class="cl-sub">Plot functions, trace values, find roots and intersections, then solve equations and linear systems with steps.</p>
<div class="cl-tabs" role="tablist"><button role="tab" id="t-g" aria-selected="true">📈 Graph</button><button role="tab" id="t-s" aria-selected="false">🧮 Solve</button></div>

<section id="p-g">
<div class="cl-lab">
  <div>
    <div class="cl-stage"><canvas id="gc" height="440" tabindex="0" role="img" aria-label="Graph of the functions you entered. Drag to pan, scroll or pinch to zoom."></canvas></div>
    <div class="cl-row"><button id="zin" aria-label="Zoom in">＋</button><button id="zout" aria-label="Zoom out">－</button><button id="zreset">Reset view</button><span class="cl-note" id="trace" aria-live="polite">Hover or tap the graph to trace.</span></div>
  </div>
  <div>
    <div class="cl-card"><h2>Functions</h2><div id="fl"></div>
      <div class="cl-row"><button id="addf">＋ Add function</button></div>
      <p class="cl-note">Type like <span class="m">y = 2x^2 − 3</span>, <span class="m">sin(x)/x</span>, <span class="m">sqrt(x+4)</span>, <span class="m">a*cos(b*x)</span>. Constants: <span class="m">pi</span>, <span class="m">e</span>.</p>
      <div id="perr" class="cl-err" role="alert"></div></div>
    <div class="cl-card" style="margin-top:12px"><h2>Sliders</h2>
      <label class="cl-f" for="pa">a = <span class="cl-val" id="pav">1</span></label><input id="pa" type="range" min="-10" max="10" step="0.1" value="1">
      <label class="cl-f" for="pb">b = <span class="cl-val" id="pbv">1</span></label><input id="pb" type="range" min="-10" max="10" step="0.1" value="1">
      <label class="cl-f" for="pc">c = <span class="cl-val" id="pcv">0</span></label><input id="pc" type="range" min="-10" max="10" step="0.1" value="0"></div>
    <div class="cl-card" style="margin-top:12px"><h2>Analyse (visible window)</h2>
      <div class="cl-row"><button id="an" class="primary">Find roots, peaks &amp; intersections</button><button id="anclr">Clear</button></div>
      <div id="anr" class="cl-note"></div></div>
  </div>
</div>
</section>

<section id="p-s" hidden>
<div class="cl-lab">
  <div>
    <div class="cl-card"><h2>Solve an equation for x</h2>
      <label class="cl-f" for="eq">Equation</label><input id="eq" type="text" value="x^2 - 5x + 6 = 0" autocapitalize="off" autocomplete="off" spellcheck="false">
      <div class="cl-row"><button class="primary" id="solve">Solve</button>
        <button data-ex="2x + 3 = 11">2x+3=11</button><button data-ex="x^2 + 2x + 5 = 0">complex</button><button data-ex="x^3 - 6x^2 + 11x - 6 = 0">cubic</button><button data-ex="cos(x) = x">cos x = x</button><button data-ex="2^x = 20">2ˣ = 20</button></div>
      <div id="sres" role="status" aria-live="polite"></div></div>
    <div class="cl-card" style="margin-top:12px"><h2>Quick calculator</h2>
      <input id="qc" type="text" placeholder="e.g. sqrt(2)*pi + 3^4/7" autocomplete="off" spellcheck="false"><div id="qcr" class="cl-val" style="margin-top:8px" aria-live="polite"></div></div>
  </div>
  <div>
    <div class="cl-card"><h2>Linear system</h2>
      <div class="cl-row"><label for="nn">Unknowns</label><select id="nn" style="width:auto"><option value="2">2 (x, y)</option><option value="3">3 (x, y, z)</option></select></div>
      <div id="mx"></div>
      <div class="cl-row"><button class="primary" id="ssolve">Solve system</button></div>
      <div id="sysres" role="status" aria-live="polite"></div></div>
  </div>
</div>
</section>

<script src="mathcore.js"></script>
<script>
(function(){
var M=CurioMath,$=function(i){return document.getElementById(i)};
function esc(s){return String(s).replace(/[&<>]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;"}[c]})}
var COL=["--cl-c1","--cl-c2","--cl-c3","--cl-c4","--cl-c5","--cl-c6"];
function col(i){return getComputedStyle(document.documentElement).getPropertyValue(COL[i%6]).trim()||"#55f"}
var P={a:1,b:1,c:0},fns=[{s:"x^2 - 2",on:true},{s:"sin(x)*2",on:true}],view={cx:0,cy:0,s:50},marks=[],logged=false;
// tabs
function tab(g){$("p-g").hidden=!g;$("p-s").hidden=g;$("t-g").setAttribute("aria-selected",g);$("t-s").setAttribute("aria-selected",!g);if(g)draw()}
$("t-g").onclick=function(){tab(true)};$("t-s").onclick=function(){tab(false)};
// function list
function renderList(){var h="";fns.forEach(function(f,i){h+='<div class="cl-row" style="flex-wrap:nowrap"><input type="checkbox" '+(f.on?"checked":"")+' data-v="'+i+'" aria-label="Show function '+(i+1)+'" style="width:22px;height:22px;accent-color:'+col(i)+'"><span aria-hidden="true" style="width:6px;align-self:stretch;border-radius:3px;background:'+col(i)+'"></span><input type="text" value="'+esc(f.s)+'" data-i="'+i+'" aria-label="Function '+(i+1)+'" autocapitalize="off" autocomplete="off" spellcheck="false"><button data-r="'+i+'" aria-label="Remove function '+(i+1)+'">✕</button></div>'});$("fl").innerHTML=h}
$("fl").addEventListener("input",function(e){if(e.target.dataset.i!==undefined){fns[+e.target.dataset.i].s=e.target.value;compileAll();draw();logOnce()}});
$("fl").addEventListener("change",function(e){if(e.target.dataset.v!==undefined){fns[+e.target.dataset.v].on=e.target.checked;draw()}});
$("fl").addEventListener("click",function(e){var b=e.target.closest("button[data-r]");if(b){fns.splice(+b.dataset.r,1);if(!fns.length)fns.push({s:"",on:true});renderList();compileAll();draw()}});
$("addf").onclick=function(){if(fns.length<6){fns.push({s:"",on:true});renderList();compileAll();draw();var ins=$("fl").querySelectorAll("input[type=text]");ins[ins.length-1].focus()}};
function compileAll(){var errs=[];fns.forEach(function(f,i){f.fn=null;var s=M.rhsOf(f.s||"").trim();if(!s)return;try{f.fn=M.compile(s)}catch(e){errs.push("Function "+(i+1)+": "+e.message)}});$("perr").textContent=errs.join("  ")}
function logOnce(){if(logged)return;if(fns.some(function(f){return f.fn})){logged=true;setTimeout(function(){CurioActivity.log("math","graph","Graphing calculator","Plotted "+fns.filter(function(f){return f.fn}).map(function(f){return M.rhsOf(f.s).trim()}).join(", "))},4000)}}
[["a","pa"],["b","pb"],["c","pc"]].forEach(function(p){$(p[1]).oninput=function(){P[p[0]]=+this.value;$(p[1]+"v").textContent=this.value;draw()}});
// canvas
var cv=$("gc"),ctx=cv.getContext("2d"),dpr=1,W=0,H=0;
function size(){dpr=window.devicePixelRatio||1;var r=cv.parentElement.clientWidth-20;W=Math.max(260,r);H=Math.round(Math.min(480,Math.max(300,W*0.75)));cv.style.width=W+"px";cv.style.height=H+"px";cv.width=W*dpr;cv.height=H*dpr}
function X(x){return W/2+(x-view.cx)*view.s}function Y(y){return H/2-(y-view.cy)*view.s}
function ix(px){return view.cx+(px-W/2)/view.s}function iy(py){return view.cy-(py-H/2)/view.s}
function nice(t){var p=Math.pow(10,Math.floor(Math.log10(t))),f=t/p;return (f<1.5?1:f<3.5?2:f<7.5?5:10)*p}
function draw(){
  if($("p-g").hidden)return;size();ctx.setTransform(dpr,0,0,dpr,0,0);
  var cs=getComputedStyle(document.documentElement),bg=cs.getPropertyValue("--cl-surface").trim(),mut=cs.getPropertyValue("--cl-muted").trim(),brd=cs.getPropertyValue("--cl-border").trim(),txt=cs.getPropertyValue("--cl-text").trim();
  ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);ctx.font="12px system-ui";
  var st=nice(70/view.s),x0=ix(0),x1=ix(W),y1=iy(0),y0=iy(H);
  ctx.lineWidth=1;
  for(var gx=Math.ceil(x0/st)*st;gx<=x1;gx+=st){var px=Math.round(X(gx))+.5;ctx.strokeStyle=Math.abs(gx)<st/1e3?txt:brd;ctx.beginPath();ctx.moveTo(px,0);ctx.lineTo(px,H);ctx.stroke()}
  for(var gy=Math.ceil(y0/st)*st;gy<=y1;gy+=st){var py=Math.round(Y(gy))+.5;ctx.strokeStyle=Math.abs(gy)<st/1e3?txt:brd;ctx.beginPath();ctx.moveTo(0,py);ctx.lineTo(W,py);ctx.stroke()}
  ctx.fillStyle=mut;var ax=Math.min(H-14,Math.max(14,Y(0))),ay=Math.min(W-34,Math.max(4,X(0)+4));
  for(var lx=Math.ceil(x0/st)*st;lx<=x1;lx+=st){if(Math.abs(lx)<st/1e3)continue;ctx.fillText(M.fmt(+lx.toPrecision(6)),X(lx)+3,ax+12>H?H-4:ax+12)}
  for(var ly=Math.ceil(y0/st)*st;ly<=y1;ly+=st){if(Math.abs(ly)<st/1e3)continue;ctx.fillText(M.fmt(+ly.toPrecision(6)),ay,Y(ly)-3)}
  fns.forEach(function(f,i){if(!f.fn||!f.on)return;ctx.strokeStyle=col(i);ctx.lineWidth=2.5;ctx.beginPath();var pen=false,prevY=NaN;
    for(var p=0;p<=W;p+=1){var x=ix(p),y;try{y=f.fn(x,P)}catch(e){y=NaN}
      if(!isFinite(y)){pen=false;prevY=NaN;continue}
      var py=Y(y);if(Math.abs(py)>1e5){pen=false;prevY=NaN;continue}
      if(pen&&isFinite(prevY)&&Math.abs(py-prevY)>H*1.5&&(prevY-H/2)*(py-H/2)<0&&Math.abs(py-prevY)>H){pen=false} // asymptote
      if(!pen){ctx.moveTo(p,py);pen=true}else ctx.lineTo(p,py);prevY=py}
    ctx.stroke()});
  marks.forEach(function(m){ctx.fillStyle=txt;ctx.beginPath();ctx.arc(X(m.x),Y(m.y),5,0,7);ctx.fill();ctx.fillStyle=bg;ctx.beginPath();ctx.arc(X(m.x),Y(m.y),2.5,0,7);ctx.fill()});
  if(tracePt){ctx.strokeStyle=mut;ctx.setLineDash([4,4]);ctx.beginPath();ctx.moveTo(tracePt.px,0);ctx.lineTo(tracePt.px,H);ctx.stroke();ctx.setLineDash([]);
    tracePt.pts.forEach(function(q){ctx.fillStyle=col(q.i);ctx.beginPath();ctx.arc(tracePt.px,Y(q.y),5.5,0,7);ctx.fill();ctx.strokeStyle=bg;ctx.lineWidth=2;ctx.stroke()})}
}
var tracePt=null;
function trace(clientX){var r=cv.getBoundingClientRect(),px=clientX-r.left,x=ix(px),pts=[];
  fns.forEach(function(f,i){if(f.fn&&f.on){var y;try{y=f.fn(x,P)}catch(e){y=NaN}if(isFinite(y))pts.push({i:i,y:y})}});
  tracePt={px:px,pts:pts};$("trace").textContent="x = "+M.fmt(x)+pts.map(function(q){return "   f"+(q.i+1)+" = "+M.fmt(q.y)}).join("");draw()}
// pointers: pan, pinch, hover
var ptrs={},lastD=0,moved=false;
cv.addEventListener("pointerdown",function(e){cv.setPointerCapture(e.pointerId);ptrs[e.pointerId]={x:e.clientX,y:e.clientY};moved=false;lastD=0});
cv.addEventListener("pointermove",function(e){var ids=Object.keys(ptrs);
  if(!ptrs[e.pointerId]){if(e.pointerType==="mouse")trace(e.clientX);return}
  var p=ptrs[e.pointerId];
  if(ids.length===1){var dx=e.clientX-p.x,dy=e.clientY-p.y;if(Math.abs(dx)+Math.abs(dy)>2)moved=true;view.cx-=dx/view.s;view.cy+=dy/view.s;ptrs[e.pointerId]={x:e.clientX,y:e.clientY};draw()}
  else if(ids.length===2){ptrs[e.pointerId]={x:e.clientX,y:e.clientY};var a=ptrs[ids[0]],b=ptrs[ids[1]],d=Math.hypot(a.x-b.x,a.y-b.y);if(lastD){var r=cv.getBoundingClientRect();zoom(d/lastD,(a.x+b.x)/2-r.left,(a.y+b.y)/2-r.top)}lastD=d;moved=true}});
function up(e){if(ptrs[e.pointerId]&&!moved&&e.type==="pointerup")trace(e.clientX);delete ptrs[e.pointerId];lastD=0}
cv.addEventListener("pointerup",up);cv.addEventListener("pointercancel",up);
cv.addEventListener("wheel",function(e){e.preventDefault();var r=cv.getBoundingClientRect();zoom(e.deltaY<0?1.15:1/1.15,e.clientX-r.left,e.clientY-r.top)},{passive:false});
function zoom(k,px,py){var x=ix(px),y=iy(py);view.s=Math.max(0.5,Math.min(1e6,view.s*k));view.cx=x-(px-W/2)/view.s;view.cy=y+(py-H/2)/view.s;draw()}
cv.addEventListener("keydown",function(e){var m={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,1],ArrowDown:[0,-1]}[e.key];if(m){e.preventDefault();view.cx+=m[0]*40/view.s;view.cy+=m[1]*40/view.s;draw()}else if(e.key==="+"||e.key==="="){zoom(1.2,W/2,H/2)}else if(e.key==="-"){zoom(1/1.2,W/2,H/2)}});
$("zin").onclick=function(){zoom(1.4,W/2,H/2)};$("zout").onclick=function(){zoom(1/1.4,W/2,H/2)};$("zreset").onclick=function(){view={cx:0,cy:0,s:50};draw()};
window.addEventListener("resize",draw);window.addEventListener("curio:theme",draw);
// analysis
$("an").onclick=function(){
  var lo=ix(0),hi=ix(W),act=[],out="";marks=[];
  fns.forEach(function(f,i){if(f.fn&&f.on)act.push({f:function(x){return f.fn(x,P)},i:i})});
  if(!act.length){$("anr").textContent="Enter a function first.";return}
  act.forEach(function(a){var rs=M.findRoots(a.f,lo,hi,3000).slice(0,12),ex=M.extrema(a.f,lo,hi,3000).slice(0,12),y0=a.f(0);
    rs.forEach(function(x){marks.push({x:x,y:0})});ex.forEach(function(e){marks.push({x:e.x,y:e.y})});
    out+='<p><b style="color:'+col(a.i)+'">f'+(a.i+1)+'</b>: '+(rs.length?"roots x = "+rs.map(function(x){return M.fmt(x)}).join(", "):"no roots in view")+
      (ex.length?"<br>"+ex.map(function(e){return e.kind+" at ("+M.fmt(e.x)+", "+M.fmt(e.y)+")"}).join("; "):"")+(isFinite(y0)?"<br>y-intercept: "+M.fmt(y0):"")+"</p>"});
  for(var i=0;i<act.length;i++)for(var j=i+1;j<act.length;j++){var d=(function(A,B){return function(x){return A.f(x)-B.f(x)}})(act[i],act[j]);var xs=M.findRoots(d,lo,hi,3000).slice(0,12);
    xs.forEach(function(x){marks.push({x:x,y:act[i].f(x)})});
    out+="<p>f"+(act[i].i+1)+" ∩ f"+(act[j].i+1)+": "+(xs.length?xs.map(function(x){return "("+M.fmt(x)+", "+M.fmt(act[i].f(x))+")"}).join(", "):"no intersections in view")+"</p>"}
  $("anr").innerHTML=out;draw();CurioActivity.log("math","graph-analyse","Graph analysis",act.length+" function(s) analysed")};
$("anclr").onclick=function(){marks=[];$("anr").innerHTML="";draw()};

// ---------------- solver ----------------
function steps(a){return '<ol class="steps">'+a.map(function(s){return "<li>"+s+"</li>"}).join("")+"</ol>"}
function solveEq(){
  var src=$("eq").value.trim(),out=$("sres");if(!src){out.innerHTML="";return}
  var parts=src.split("="),g,sol=[],html="",summary="";
  if(parts.length>2){out.innerHTML='<p class="cl-err">Use only one “=” sign.</p>';return}
  try{var L=M.compile(parts[0]),Rr=parts.length===2?M.compile(parts[1]):function(){return 0};g=function(x){return L(x,P)-Rr(x,P)};if(L.vars.indexOf("a")>=0||L.vars.indexOf("b")>=0||L.vars.indexOf("c")>=0)html+='<p class="cl-note">Using slider values a='+P.a+', b='+P.b+', c='+P.c+'.</p>'}
  catch(e){out.innerHTML='<p class="cl-err">'+esc(e.message)+'</p>';return}
  var c=M.polyCoeffs(g),deg=c?c.length-1:-1;
  if(c&&deg===0){html+=Math.abs(c[0])<1e-9?"<p>Every x is a solution (identity).</p>":"<p>No solution (the equation reduces to "+M.fmt(c[0])+" = 0).</p>";summary="degenerate"}
  else if(c&&deg===1){var a=c[1],b=c[0],x=-b/a;html+="<p><b>Linear equation</b>: "+esc(M.polyString(c))+" = 0</p>"+steps(["Move constant: "+M.fmt(a)+"x = "+M.fmt(-b),"Divide by "+M.fmt(a)+": x = "+M.fmt(-b)+" ÷ "+M.fmt(a)])+"<p><b>x = "+esc(M.fmtRoot([x,0]))+"</b></p>";summary="x = "+M.fmt(x)}
  else if(c&&deg===2){var A=c[2],B=c[1],C=c[0],D=B*B-4*A*C;html+="<p><b>Quadratic equation</b>: "+esc(M.polyString(c))+" = 0 &nbsp; (a="+M.fmt(A)+", b="+M.fmt(B)+", c="+M.fmt(C)+")</p>";
    var st=["Discriminant: Δ = b² − 4ac = ("+M.fmt(B)+")² − 4·("+M.fmt(A)+")·("+M.fmt(C)+") = <b>"+M.fmt(D)+"</b>"];
    if(D>1e-12){var r1=(-B+Math.sqrt(D))/(2*A),r2=(-B-Math.sqrt(D))/(2*A);st.push("Δ &gt; 0 → two real roots: x = (−b ± √Δ) ÷ 2a");st.push("x₁ = "+esc(M.fmtRoot([r1,0]))+", x₂ = "+esc(M.fmtRoot([r2,0])));html+=steps(st);summary="x = "+M.fmt(r1)+", "+M.fmt(r2)}
    else if(Math.abs(D)<=1e-12){var r=-B/(2*A);st.push("Δ = 0 → one repeated root: x = −b ÷ 2a = "+esc(M.fmtRoot([r,0])));html+=steps(st);summary="x = "+M.fmt(r)}
    else{var re=-B/(2*A),im=Math.sqrt(-D)/(2*Math.abs(A));st.push("Δ &lt; 0 → no real roots; two complex roots: x = (−b ± i√|Δ|) ÷ 2a");st.push("x = "+esc(M.fmtRoot([re,im]))+" and "+esc(M.fmtRoot([re,-im])));html+=steps(st);summary="complex roots"}}
  else if(c){var zs=M.durandKerner(c);html+="<p><b>Polynomial of degree "+deg+"</b>: "+esc(M.polyString(c))+" = 0</p><p>Roots (numerical):</p><ul>"+zs.map(function(z){return "<li>x = "+esc(M.fmtRoot(z))+"</li>"}).join("")+"</ul>";
    var real=zs.filter(function(z){return z[1]===0});summary=real.length?"x = "+real.map(function(z){return M.fmt(z[0])}).join(", "):"no real roots"}
  else{var rs=M.findRoots(g,-100,100,20000);html+="<p><b>Numerical solution</b> (searched −100 ≤ x ≤ 100)</p>"+(rs.length?"<ul>"+rs.slice(0,20).map(function(x){return "<li>x ≈ "+M.fmt(x)+"</li>"}).join("")+"</ul>":"<p>No real solutions found in that range.</p>");summary=rs.length?"x ≈ "+rs.slice(0,6).map(M.fmt).join(", "):"none found"}
  html+='<p class="cl-note"><a href="#" id="plotit">Plot this on the graph →</a></p>';
  out.innerHTML=html;
  var pl=$("plotit");if(pl)pl.onclick=function(ev){ev.preventDefault();fns[0]={s:parts[0]+(parts[1]?"-("+parts[1]+")":""),on:true};fns.length=1;renderList();compileAll();tab(true);view={cx:0,cy:0,s:30};marks=[];draw()};
  CurioActivity.log("math","solve","Equation solver",src+" → "+summary)}
$("solve").onclick=solveEq;$("eq").addEventListener("keydown",function(e){if(e.key==="Enter")solveEq()});
document.querySelectorAll("[data-ex]").forEach(function(b){b.onclick=function(){$("eq").value=b.dataset.ex;solveEq()}});
$("qc").addEventListener("input",function(){var v=this.value.trim();if(!v){$("qcr").textContent="";return}try{var r=M.compile(v)(0,P);$("qcr").textContent=isFinite(r)?"= "+M.fmt(r):"undefined"}catch(e){$("qcr").textContent=""}});
// linear systems
function buildMx(){var n=+$("nn").value,h='<div role="group" aria-label="Coefficients" style="display:grid;gap:6px;grid-template-columns:repeat('+(n+1)+',minmax(0,1fr));align-items:center">',vn=["x","y","z"];
  var def=n===2?[[2,1,5],[1,3,10]]:[[1,1,1,6],[0,2,5,-4],[2,5,-1,27]];
  for(var i=0;i<n;i++){for(var j=0;j<=n;j++){h+='<input type="number" step="any" inputmode="decimal" data-r="'+i+'" data-c="'+j+'" value="'+def[i][j]+'" aria-label="'+(j<n?"coefficient of "+vn[j]:"constant")+' in equation '+(i+1)+'">'}}
  $("mx").innerHTML=h+"</div><p class='cl-note'>Each row is one equation: "+(n===2?"a·x + b·y = c":"a·x + b·y + c·z = d")+"</p>"}
$("nn").onchange=buildMx;buildMx();
$("ssolve").onclick=function(){var n=+$("nn").value,A=[],b=[],vn=["x","y","z"];
  for(var i=0;i<n;i++){A.push([]);for(var j=0;j<n;j++)A[i].push(parseFloat($("mx").querySelector('[data-r="'+i+'"][data-c="'+j+'"]').value)||0);b.push(parseFloat($("mx").querySelector('[data-r="'+i+'"][data-c="'+n+'"]').value)||0)}
  var s=M.solveLinear(A,b),h="";
  h+="<p><b>Gaussian elimination</b></p>"+s.steps.map(function(st){return "<p class='cl-note' style='margin:6px 0 2px'>"+esc(st.text)+"</p><pre class='m' style='margin:0;overflow:auto'>"+st.m.map(function(r){return r.map(function(v,k){var t=M.fmt(v);return (k===n?"│ ":"")+("        "+t).slice(-9)}).join(" ")}).join("\n")+"</pre>"}).join("");
  if(s.kind==="unique"){h+="<p>Determinant = "+M.fmt(s.det)+" ≠ 0 → unique solution (back-substitution):</p><p><b>"+s.x.map(function(v,i){return vn[i]+" = "+M.fmt(v)}).join(",&nbsp; ")+"</b></p>"}
  else h+="<p class='cl-err'>"+(s.kind==="none"?"No solution (the equations contradict each other).":"Infinitely many solutions (the equations are dependent).")+"</p>";
  $("sysres").innerHTML=h;CurioActivity.log("math","system","Linear system solver",n+"×"+n+" → "+(s.kind==="unique"?s.x.map(function(v,i){return vn[i]+"="+M.fmt(v)}).join(", "):s.kind))};
renderList();compileAll();draw();
window.__g={view:view,fns:fns,draw:draw,solveEq:solveEq};
})();
</script>
