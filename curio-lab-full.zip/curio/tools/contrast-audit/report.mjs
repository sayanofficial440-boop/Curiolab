#!/usr/bin/env node
// Coverage verification + findings report for results written by audit.mjs.
//   node report.mjs                    # verify coverage, write REPORT.md + findings.json
//   node report.mjs --verify-only      # exit 1 unless every page x viewport x theme x state was measured
//   node report.mjs --baseline old.json   # also list groups that are new / fixed vs an earlier findings.json
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { listPages, readThemes, VIEWPORTS } from "./lib/engine.mjs";
import { CONFIG } from "./config.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const args = Object.fromEntries(process.argv.slice(2).reduce((a, x, i, all) => (x.startsWith("--") ? [...a, [x.slice(2), all[i + 1] && !all[i + 1].startsWith("--") ? all[i + 1] : true]] : a), []));
const publicDir = path.resolve(here, args.public || "../../public");
const outDir = path.resolve(here, args.out || "results");
const viewports = (args.viewports || "desktop,phone").split(",");
const themes = readThemes(publicDir);
const pages = listPages(publicDir, CONFIG.ignore);
const requireExtra = !!args["require-extra"];

const problems = [];
const warn = [];
const stats = { jobs: 0, ok: 0, redirect: 0, measurements: 0, textRuns: 0, skipped: {}, drift: 0, items: 0 };
const groups = new Map();      // finding groups
const layout = [];             // phone layout results
const stuckHidden = [];        // text that stayed invisible after forcing reveals
const load = (f) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return null; } };

for (const vp of viewports) {
  for (const p of pages) {
    stats.jobs++;
    const base = path.join(outDir, vp, p.replace(/\//g, "__"));
    const recs = [load(base + ".json")];
    const extra = load(base + ".extra.json");
    if (extra) recs.push(extra); else if (requireExtra) problems.push(`${vp} ${p}: no extra-state results`);
    if (!recs[0]) { problems.push(`${vp} ${p}: NO RESULT FILE (page was never audited)`); continue; }
    const main = recs[0];
    if (main.status === "redirect") { stats.redirect++; if (!pages.includes(main.redirectTo)) problems.push(`${vp} ${p}: redirects to ${main.redirectTo}, which is not audited`); continue; }
    if (main.status !== "ok") { problems.push(`${vp} ${p}: status=${main.status} ${main.error || ""}`); continue; }
    stats.ok++;
    const expectThemes = main.themed ? themes : ["(no-theme-system)"];
    if (main.layout) layout.push({ vp, page: p, ...main.layout });
    for (const rec of recs) {
      for (const [stName, st] of Object.entries(rec.states)) {
        if (st.error) { problems.push(`${vp} ${p} [${stName}]: ${st.error}`); continue; }
        for (const th of expectThemes) {
          const m = st.themes?.[th];
          if (!m) { problems.push(`${vp} ${p} [${stName}] theme ${th}: not measured`); continue; }
          stats.measurements++; stats.textRuns += m.measured; stats.items += m.items; stats.drift += m.drift;
          if (m.truncated) problems.push(`${vp} ${p} [${stName}] ${th}: page taller than the strip cap (truncated)`);
          if (m.items > 0 && m.measured < m.items * 0.97) problems.push(`${vp} ${p} [${stName}] ${th}: only ${m.measured}/${m.items} text runs measured (drift ${m.drift})`);
          if (stName === "default" && m.items === 0) problems.push(`${vp} ${p} [default] ${th}: found NO text to measure (blank page?)`);
          for (const [k, v] of Object.entries(m.skipped || {})) stats.skipped[k] = (stats.skipped[k] || 0) + v.n;
          if (th === expectThemes[0] && m.skipped?.["opacity-0"]) stuckHidden.push({ vp, page: p, state: stName, n: m.skipped["opacity-0"].n, samples: m.skipped["opacity-0"].samples });
          for (const f of m.failures) {
            const key = [vp, th, f.kind === "placeholder" ? "placeholder" : "", f.sig].join("|");
            let g = groups.get(key);
            if (!g) { g = { viewport: vp, theme: th, sig: f.sig, kind: f.kind, need: f.need, worst: 99, pages: new Set(), states: new Set(), count: 0, fg: f.fg, bgAvg: f.bgAvg, bgSig: f.bgSig, bgCss: f.bgCss, sample: f.text, fs: f.fs, weight: f.weight }; groups.set(key, g); }
            g.count++; g.pages.add(p); g.states.add(stName);
            if (f.ratio < g.worst) { g.worst = f.ratio; g.fg = f.fg; g.bgAvg = f.bgAvg; g.sample = f.text; g.bgSig = f.bgSig; g.bgCss = f.bgCss; }
          }
        }
      }
    }
  }
}
const list = [...groups.values()].map((g) => ({ ...g, pages: [...g.pages].sort(), states: [...g.states] })).sort((a, b) => b.pages.length - a.pages.length || a.worst - b.worst);
fs.writeFileSync(path.join(here, "findings.json"), JSON.stringify(list, null, 1));

// ---------- markdown ----------
const md = [];
md.push(`# Contrast audit report`, ``, `Generated ${new Date().toISOString()}.`, ``);
md.push(`## Coverage`, ``, `- Page x viewport jobs expected: **${stats.jobs}**; ok: **${stats.ok}**; redirect-only: ${stats.redirect}; problems: **${problems.length}**`);
md.push(`- Pages: ${pages.length}, themes: ${themes.length} (${themes.join(", ")}), viewports: ${viewports.map((v) => `${v} ${VIEWPORTS[v].width}x${VIEWPORTS[v].height}`).join(", ")}`);
md.push(`- Measurements (page x viewport x state x theme): **${stats.measurements}**, text runs checked against real pixels: **${stats.textRuns.toLocaleString()}** of ${stats.items.toLocaleString()} found (${stats.drift} lost to layout drift)`);
md.push(`- Text deliberately not measured, by reason: ${Object.entries(stats.skipped).map(([k, v]) => `${k} ${v.toLocaleString()}`).join(", ") || "none"}`, ``);
if (problems.length) { md.push(`### COVERAGE PROBLEMS (${problems.length})`, ``, ...problems.slice(0, 200).map((p) => `- ${p}`), ``); }
if (stuckHidden.length) {
  md.push(`### Text that stays invisible after scrolling and forcing every reveal (${stuckHidden.length} page-states)`, ``, `These are not measured. Check whether they are intentional (loaders, closed menus) or content stuck at opacity 0.`, ``);
  for (const s of stuckHidden.slice(0, 60)) md.push(`- ${s.vp} ${s.page} [${s.state}] x${s.n}: ${s.samples.slice(0, 3).join(" ; ")}`);
  md.push(``);
}
const byTheme = {};
for (const g of list) { const k = `${g.viewport}/${g.theme}`; byTheme[k] = (byTheme[k] || 0) + g.pages.length; }
md.push(`## Contrast failures`, ``, `Failure = the 10th-percentile contrast across the pixels behind a text run is below 4.5:1 (3:1 for large text, 24px or 18.66px bold).`, `Groups: ${list.length}.`, ``);
md.push(`| viewport/theme | failing (element, page) pairs |`, `|---|---|`, ...Object.entries(byTheme).sort((a, b) => b[1] - a[1]).map(([k, v]) => `| ${k} | ${v} |`), ``);
md.push(`### Groups (element x theme), most widespread first`, ``);
for (const g of list.slice(0, 150)) md.push(`- **${g.viewport} ${g.theme}** \`${g.sig}\` ${g.kind} ${g.fs}px/${g.weight}: **${g.worst}:1** (needs ${g.need}) fg ${g.fg} on ${g.bgAvg}; bg from \`${g.bgSig}\`; ${g.pages.length} page(s) e.g. ${g.pages.slice(0, 3).join(", ")}; text "${g.sample}"`);
md.push(``);
if (layout.length) {
  const over = layout.filter((l) => l.overflowBy > 1);
  const tiny = layout.filter((l) => l.tapTooSmall > 0);
  md.push(`## Phone layout (390px)`, ``, `- Pages with horizontal overflow: **${over.length}** of ${layout.length}`);
  for (const l of over.slice(0, 40)) md.push(`  - ${l.page}: scrolls ${l.overflowBy}px sideways; widest: ${l.offenders.slice(0, 3).map((o) => `${o.sig} (right edge ${o.right}px)`).join("; ")}`);
  md.push(`- Pages with tap targets smaller than 24x24px: **${tiny.length}**`);
  const agg = new Map();
  for (const l of layout) for (const t of l.tapTooSmallTop || []) { const k = `${t.sig} ${t.w}x${t.h}`; const e = agg.get(k) || { k, pages: 0, text: t.text }; e.pages++; agg.set(k, e); }
  for (const e of [...agg.values()].sort((a, b) => b.pages - a.pages).slice(0, 25)) md.push(`  - \`${e.k}\` "${e.text}" on ${e.pages} page(s)`);
  md.push(`- Pages with targets under 44px (informational): ${layout.filter((l) => l.tapUnder44 > 0).length}`, ``);
}
if (args.baseline) {
  const old = JSON.parse(fs.readFileSync(args.baseline, "utf8"));
  const key = (g) => `${g.viewport}|${g.theme}|${g.sig}`;
  const oldKeys = new Set(old.map(key)), nowKeys = new Set(list.map(key));
  md.push(`## Versus baseline`, ``, `- Fixed: ${[...oldKeys].filter((k) => !nowKeys.has(k)).length}`, `- New: ${[...nowKeys].filter((k) => !oldKeys.has(k)).length}`);
  for (const k of [...nowKeys].filter((k) => !oldKeys.has(k)).slice(0, 50)) md.push(`  - NEW ${k}`);
  md.push(``);
}
fs.writeFileSync(path.join(here, "REPORT.md"), md.join("\n"));
console.log(md.slice(0, 14).join("\n"));
console.log(`\nfailing groups: ${list.length}; coverage problems: ${problems.length}; full report: tools/contrast-audit/REPORT.md`);
if (problems.length) process.exitCode = 1;
