#!/usr/bin/env node
// Curio Lab contrast + phone-layout audit.
//   node audit.mjs                         # everything: all pages x all themes x desktop+phone
//   node audit.mjs --pages admin/ --viewports phone --themes studio,nocturne
//   node audit.mjs --force                 # ignore previous results
// Results: tools/contrast-audit/results/<viewport>/<page>.json ; then run `node report.mjs`.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright-core";
import { startServer } from "./lib/server.mjs";
import { auditPage, listPages, readThemes, VIEWPORTS } from "./lib/engine.mjs";
import { CONFIG } from "./config.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const args = Object.fromEntries(process.argv.slice(2).reduce((a, x, i, all) => (x.startsWith("--") ? [...a, [x.slice(2), all[i + 1] && !all[i + 1].startsWith("--") ? all[i + 1] : true]] : a), []));
const publicDir = path.resolve(here, args.public || "../../public");
const outDir = path.resolve(here, args.out || "results");
const viewports = (args.viewports || "desktop,phone").split(",");
const allThemes = readThemes(publicDir);
const themes = args.themes ? args.themes.split(",") : allThemes;
for (const t of themes) if (!allThemes.includes(t)) throw new Error(`unknown theme ${t}; have ${allThemes.join(",")}`);
for (const v of viewports) if (!VIEWPORTS[v]) throw new Error(`unknown viewport ${v}`);
const filter = args.pages && args.pages !== true ? new RegExp(args.pages) : null;
const pages = listPages(publicDir, CONFIG.ignore).filter((p) => !filter || filter.test(p));
const statesMode = args.states || "default"; // default | extra | all
if (!["default", "extra", "all"].includes(statesMode)) throw new Error("--states must be default|extra|all");
const suffix = statesMode === "extra" ? ".extra.json" : ".json";
const workers = Math.max(1, parseInt(args.workers || "2", 10));
const debugDir = args.debug ? path.resolve(here, args.debug === true ? "debug" : args.debug) : null;
if (debugDir) fs.mkdirSync(debugDir, { recursive: true });

function findChromium() {
  if (process.env.CHROMIUM_PATH) return process.env.CHROMIUM_PATH;
  const base = process.env.PLAYWRIGHT_BROWSERS_PATH || "/opt/pw-browsers";
  try {
    for (const d of fs.readdirSync(base).filter((d) => d.startsWith("chromium-")).sort().reverse()) {
      for (const sub of ["chrome-linux/chrome", "chrome-linux64/chrome", "chrome-win/chrome.exe", "chrome-mac/Chromium.app/Contents/MacOS/Chromium"]) {
        const p = path.join(base, d, sub); if (fs.existsSync(p)) return p;
      }
    }
  } catch {}
  return undefined; // fall back to playwright's own lookup (`npx playwright install chromium`)
}

const jobs = [];
for (const vp of viewports) for (const p of pages) {
  const file = path.join(outDir, vp, p.replace(/\//g, "__") + suffix);
  if (!args.force && fs.existsSync(file)) {
    try { const r = JSON.parse(fs.readFileSync(file, "utf8")); if (r.status === "ok" || r.status === "redirect") { if (r.themesRun?.join() === themes.join() || r.status === "redirect") continue; } } catch {}
  }
  jobs.push({ vp, p, file });
}
console.log(`pages=${pages.length} themes=${themes.length} viewports=${viewports.join("+")} -> ${jobs.length} jobs to run (${workers} workers)`);

const server = await startServer(publicDir);
const browsers = await Promise.all(Array.from({ length: workers }, () => chromium.launch({ executablePath: findChromium(), args: ["--no-sandbox", "--disable-dev-shm-usage"] })));
let done = 0; const t0 = Date.now(); let failures = 0;

async function worker(browser, id) {
  while (jobs.length) {
    const job = jobs.shift();
    let rec;
    for (let attempt = 1; attempt <= 3; attempt++) {
      rec = await auditPage(browser, server.url, job.p, job.vp, themes, { query: CONFIG.query, signedIn: CONFIG.signedIn, debugDir, statesMode });
      if (rec.status !== "error") break;
      console.log(`  retry ${attempt} ${job.vp} ${job.p}: ${rec.error}`);
    }
    rec.themesRun = themes; rec.attempts = undefined;
    fs.mkdirSync(path.dirname(job.file), { recursive: true });
    fs.writeFileSync(job.file, JSON.stringify(rec));
    done++;
    let nf = 0;
    for (const s of Object.values(rec.states)) for (const t of Object.values(s.themes || {})) nf += t.failureCount || 0;
    if (rec.status === "error") failures++;
    const el = ((Date.now() - t0) / 1000).toFixed(0);
    console.log(`[${done}] ${rec.status.padEnd(8)} ${job.vp.padEnd(7)} ${job.p} (${(rec.ms / 1000).toFixed(1)}s, ${Object.keys(rec.states).length} states, ${nf} fails) t=${el}s`);
  }
}
await Promise.all(browsers.map((b, i) => worker(b, i)));
await Promise.all(browsers.map((b) => b.close()));
await server.close();
console.log(`finished ${done} jobs, ${failures} errored, ${((Date.now() - t0) / 60000).toFixed(1)} min. Next: node report.mjs`);
process.exit(failures ? 2 : 0);
