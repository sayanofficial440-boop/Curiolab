export const CONFIG = {
  // Pages that are pure redirects (their target is audited instead).
  ignore: ["pages/mock-test.html"],
  // Pages that redirect to the login page unless a (browser-only) session exists.
  signedIn: ["dashboard.html"],
  // Pages that need a query string to show real content.
  query: {
    "pages/lesson.html": "?subject=physics&lesson=force",
  },
};
