# Contrast audit report

Generated 2026-10-04T18:45:13.286Z.

## Coverage

- Page x viewport jobs expected: **272**; ok: **24**; redirect-only: 0; problems: **269**
- Pages: 136, themes: 19 (studio, sakura, bloom, lavender, coral, ember, atelier, sandstone, moss, alpine, tide, arctic, prism, nocturne, sapphire, aurora, velvet, dusk, graphite), viewports: desktop 1280x800, phone 390x844
- Measurements (page x viewport x state x theme): **420**, text runs checked against real pixels: **52,351** of 52,855 found (28 lost to layout drift)
- Text deliberately not measured, by reason: no-box(display:none) 13,358, clipped-by-overflow 4,712, visibility-hidden 17,974, offscreen-x 665, opacity-0 14

### COVERAGE PROBLEMS (269)

- desktop dashboard.html [default] dusk: only 126/145 text runs measured (drift 18)
- desktop pages/admin/dashboard.html [default] studio: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] sakura: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] bloom: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] lavender: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] coral: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] ember: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] atelier: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] sandstone: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] moss: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] alpine: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] tide: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] arctic: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] prism: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] nocturne: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] sapphire: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] aurora: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] velvet: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] dusk: only 122/133 text runs measured (drift 0)
- desktop pages/admin/dashboard.html [default] graphite: only 122/133 text runs measured (drift 0)
- desktop pages/biology.html [default] studio: only 243/254 text runs measured (drift 10)
- desktop pages/biology/nervous-system.html: NO RESULT FILE (page was never audited)
- desktop pages/biology/reproductive-system.html: NO RESULT FILE (page was never audited)
- desktop pages/biology/respiratory-system.html: NO RESULT FILE (page was never audited)
- desktop pages/biology/skeletal-system.html: NO RESULT FILE (page was never audited)
- desktop pages/changelog.html: NO RESULT FILE (page was never audited)
- desktop pages/chemistry.html: NO RESULT FILE (page was never audited)
- desktop pages/chemistry/acids-bases-salts.html: NO RESULT FILE (page was never audited)
- desktop pages/chemistry/atom-structure.html: NO RESULT FILE (page was never audited)
- desktop pages/chemistry/carbon-organic-chemistry.html: NO RESULT FILE (page was never audited)
- desktop pages/chemistry/chemical-bonding.html: NO RESULT FILE (page was never audited)
- desktop pages/chemistry/chemical-equation.html: NO RESULT FILE (page was never audited)
- desktop pages/chemistry/chemical-reactions.html: NO RESULT FILE (page was never audited)
- desktop pages/chemistry/elements-compounds-mixtures.html: NO RESULT FILE (page was never audited)
- desktop pages/chemistry/matter.html: NO RESULT FILE (page was never audited)
- desktop pages/chemistry/metals-nonmetals.html: NO RESULT FILE (page was never audited)
- desktop pages/chemistry/mixtures-solutions.html: NO RESULT FILE (page was never audited)
- desktop pages/chemistry/periodic-table.html: NO RESULT FILE (page was never audited)
- desktop pages/computer-science.html: NO RESULT FILE (page was never audited)
- desktop pages/computer-science/algorithms.html: NO RESULT FILE (page was never audited)
- desktop pages/computer-science/automation-scripting.html: NO RESULT FILE (page was never audited)
- desktop pages/computer-science/control-flow.html: NO RESULT FILE (page was never audited)
- desktop pages/computer-science/cyber-ethics.html: NO RESULT FILE (page was never audited)
- desktop pages/computer-science/database-management.html: NO RESULT FILE (page was never audited)
- desktop pages/computer-science/functions-scope.html: NO RESULT FILE (page was never audited)
- desktop pages/computer-science/html5.html: NO RESULT FILE (page was never audited)
- desktop pages/computer-science/java.html: NO RESULT FILE (page was never audited)
- desktop pages/computer-science/python.html: NO RESULT FILE (page was never audited)
- desktop pages/computer-science/robots-robotics.html: NO RESULT FILE (page was never audited)
- desktop pages/contact.html: NO RESULT FILE (page was never audited)
- desktop pages/english.html: NO RESULT FILE (page was never audited)
- desktop pages/english/a-tale-of-two-cities.html: NO RESULT FILE (page was never audited)
- desktop pages/english/daffodils.html: NO RESULT FILE (page was never audited)
- desktop pages/english/frankenstein.html: NO RESULT FILE (page was never audited)
- desktop pages/english/if.html: NO RESULT FILE (page was never audited)
- desktop pages/english/ode-to-a-nightingale.html: NO RESULT FILE (page was never audited)
- desktop pages/english/pride-and-prejudice.html: NO RESULT FILE (page was never audited)
- desktop pages/english/road-not-taken.html: NO RESULT FILE (page was never audited)
- desktop pages/english/romeo-and-juliet.html: NO RESULT FILE (page was never audited)
- desktop pages/english/sonnet-18.html: NO RESULT FILE (page was never audited)
- desktop pages/english/the-gift-of-the-magi.html: NO RESULT FILE (page was never audited)
- desktop pages/english/the-great-gatsby.html: NO RESULT FILE (page was never audited)
- desktop pages/english/the-happy-prince.html: NO RESULT FILE (page was never audited)
- desktop pages/english/the-last-leaf.html: NO RESULT FILE (page was never audited)
- desktop pages/english/the-necklace.html: NO RESULT FILE (page was never audited)
- desktop pages/english/the-tell-tale-heart.html: NO RESULT FILE (page was never audited)
- desktop pages/english/wuthering-heights.html: NO RESULT FILE (page was never audited)
- desktop pages/exams.html: NO RESULT FILE (page was never audited)
- desktop pages/geography.html: NO RESULT FILE (page was never audited)
- desktop pages/geography/africa.html: NO RESULT FILE (page was never audited)
- desktop pages/geography/antarctica.html: NO RESULT FILE (page was never audited)
- desktop pages/geography/asia.html: NO RESULT FILE (page was never audited)
- desktop pages/geography/australia.html: NO RESULT FILE (page was never audited)
- desktop pages/geography/biomes-vegetation.html: NO RESULT FILE (page was never audited)
- desktop pages/geography/europe.html: NO RESULT FILE (page was never audited)
- desktop pages/geography/meteorology-climate.html: NO RESULT FILE (page was never audited)
- desktop pages/geography/north-america.html: NO RESULT FILE (page was never audited)
- desktop pages/geography/plate-tectonics.html: NO RESULT FILE (page was never audited)
- desktop pages/geography/resource-distribution.html: NO RESULT FILE (page was never audited)
- desktop pages/geography/south-america.html: NO RESULT FILE (page was never audited)
- desktop pages/geography/world-landforms.html: NO RESULT FILE (page was never audited)
- desktop pages/glossary.html: NO RESULT FILE (page was never audited)
- desktop pages/history.html: NO RESULT FILE (page was never audited)
- desktop pages/history/ancient-civilizations.html: NO RESULT FILE (page was never audited)
- desktop pages/history/cold-war.html: NO RESULT FILE (page was never audited)
- desktop pages/history/colonialism-and-trade.html: NO RESULT FILE (page was never audited)
- desktop pages/history/delhi-sultanate-mughal-empire.html: NO RESULT FILE (page was never audited)
- desktop pages/history/delhi-sultanate.html: NO RESULT FILE (page was never audited)
- desktop pages/history/independence-movements.html: NO RESULT FILE (page was never audited)
- desktop pages/history/industrial-revolution.html: NO RESULT FILE (page was never audited)
- desktop pages/history/mughal-empire.html: NO RESULT FILE (page was never audited)
- desktop pages/history/political-revolutions.html: NO RESULT FILE (page was never audited)
- desktop pages/history/world-war-1.html: NO RESULT FILE (page was never audited)
- desktop pages/history/world-war-2.html: NO RESULT FILE (page was never audited)
- desktop pages/lesson.html: NO RESULT FILE (page was never audited)
- desktop pages/login.html: NO RESULT FILE (page was never audited)
- desktop pages/mathematics.html: NO RESULT FILE (page was never audited)
- desktop pages/mathematics/algebraic-equations.html: NO RESULT FILE (page was never audited)
- desktop pages/mathematics/calculus-introduction.html: NO RESULT FILE (page was never audited)
- desktop pages/mathematics/commercial-math.html: NO RESULT FILE (page was never audited)
- desktop pages/mathematics/coordinate-geometry.html: NO RESULT FILE (page was never audited)
- desktop pages/mathematics/geometry.html: NO RESULT FILE (page was never audited)
- desktop pages/mathematics/linear-equations.html: NO RESULT FILE (page was never audited)
- desktop pages/mathematics/mensuration.html: NO RESULT FILE (page was never audited)
- desktop pages/mathematics/number-systems.html: NO RESULT FILE (page was never audited)
- desktop pages/mathematics/probability.html: NO RESULT FILE (page was never audited)
- desktop pages/mathematics/rational-numbers.html: NO RESULT FILE (page was never audited)
- desktop pages/mathematics/statistics.html: NO RESULT FILE (page was never audited)
- desktop pages/mathematics/trigonometry.html: NO RESULT FILE (page was never audited)
- desktop pages/physics.html: NO RESULT FILE (page was never audited)
- desktop pages/physics/astrophysics.html: NO RESULT FILE (page was never audited)
- desktop pages/physics/electricity-circuits.html: NO RESULT FILE (page was never audited)
- desktop pages/physics/force.html: NO RESULT FILE (page was never audited)
- desktop pages/physics/gravitation-space.html: NO RESULT FILE (page was never audited)
- desktop pages/physics/heat-thermodynamics.html: NO RESULT FILE (page was never audited)
- desktop pages/physics/light.html: NO RESULT FILE (page was never audited)
- desktop pages/physics/magnetism-induction.html: NO RESULT FILE (page was never audited)
- desktop pages/physics/pressure-fluids.html: NO RESULT FILE (page was never audited)
- desktop pages/physics/sound.html: NO RESULT FILE (page was never audited)
- desktop pages/physics/work-energy-power.html: NO RESULT FILE (page was never audited)
- desktop pages/play.html: NO RESULT FILE (page was never audited)
- desktop pages/practice.html: NO RESULT FILE (page was never audited)
- desktop pages/pricing.html: NO RESULT FILE (page was never audited)
- desktop pages/privacy.html: NO RESULT FILE (page was never audited)
- desktop pages/problem-lab.html: NO RESULT FILE (page was never audited)
- desktop pages/profile.html: NO RESULT FILE (page was never audited)
- desktop pages/report.html: NO RESULT FILE (page was never audited)
- desktop pages/review.html: NO RESULT FILE (page was never audited)
- desktop pages/saved.html: NO RESULT FILE (page was never audited)
- desktop pages/scoreboard.html: NO RESULT FILE (page was never audited)
- desktop pages/signup.html: NO RESULT FILE (page was never audited)
- desktop pages/terms.html: NO RESULT FILE (page was never audited)
- desktop pages/todo.html: NO RESULT FILE (page was never audited)
- phone 404.html: NO RESULT FILE (page was never audited)
- phone dashboard.html: NO RESULT FILE (page was never audited)
- phone index.html: NO RESULT FILE (page was never audited)
- phone offline.html: NO RESULT FILE (page was never audited)
- phone pages/about.html: NO RESULT FILE (page was never audited)
- phone pages/accessibility.html: NO RESULT FILE (page was never audited)
- phone pages/active-recall.html: NO RESULT FILE (page was never audited)
- phone pages/admin/admins.html: NO RESULT FILE (page was never audited)
- phone pages/admin/audit.html: NO RESULT FILE (page was never audited)
- phone pages/admin/dashboard.html: NO RESULT FILE (page was never audited)
- phone pages/admin/login.html: NO RESULT FILE (page was never audited)
- phone pages/admin/setup.html: NO RESULT FILE (page was never audited)
- phone pages/admin/subscriptions.html: NO RESULT FILE (page was never audited)
- phone pages/admin/users.html: NO RESULT FILE (page was never audited)
- phone pages/biology.html: NO RESULT FILE (page was never audited)
- phone pages/biology/biological-diversity.html: NO RESULT FILE (page was never audited)
- phone pages/biology/cell.html: NO RESULT FILE (page was never audited)
- phone pages/biology/circulatory-system.html: NO RESULT FILE (page was never audited)
- phone pages/biology/digestive-system.html: NO RESULT FILE (page was never audited)
- phone pages/biology/excretory-system.html: NO RESULT FILE (page was never audited)
- phone pages/biology/health.html: NO RESULT FILE (page was never audited)
- phone pages/biology/muscular-system.html: NO RESULT FILE (page was never audited)
- phone pages/biology/nervous-system.html: NO RESULT FILE (page was never audited)
- phone pages/biology/reproductive-system.html: NO RESULT FILE (page was never audited)
- phone pages/biology/respiratory-system.html: NO RESULT FILE (page was never audited)
- phone pages/biology/skeletal-system.html: NO RESULT FILE (page was never audited)
- phone pages/browse.html: NO RESULT FILE (page was never audited)
- phone pages/certificates.html: NO RESULT FILE (page was never audited)
- phone pages/changelog.html: NO RESULT FILE (page was never audited)
- phone pages/chemistry.html: NO RESULT FILE (page was never audited)
- phone pages/chemistry/acids-bases-salts.html: NO RESULT FILE (page was never audited)
- phone pages/chemistry/atom-structure.html: NO RESULT FILE (page was never audited)
- phone pages/chemistry/carbon-organic-chemistry.html: NO RESULT FILE (page was never audited)
- phone pages/chemistry/chemical-bonding.html: NO RESULT FILE (page was never audited)
- phone pages/chemistry/chemical-equation.html: NO RESULT FILE (page was never audited)
- phone pages/chemistry/chemical-reactions.html: NO RESULT FILE (page was never audited)
- phone pages/chemistry/elements-compounds-mixtures.html: NO RESULT FILE (page was never audited)
- phone pages/chemistry/matter.html: NO RESULT FILE (page was never audited)
- phone pages/chemistry/metals-nonmetals.html: NO RESULT FILE (page was never audited)
- phone pages/chemistry/mixtures-solutions.html: NO RESULT FILE (page was never audited)
- phone pages/chemistry/periodic-table.html: NO RESULT FILE (page was never audited)
- phone pages/computer-science.html: NO RESULT FILE (page was never audited)
- phone pages/computer-science/algorithms.html: NO RESULT FILE (page was never audited)
- phone pages/computer-science/automation-scripting.html: NO RESULT FILE (page was never audited)
- phone pages/computer-science/control-flow.html: NO RESULT FILE (page was never audited)
- phone pages/computer-science/cyber-ethics.html: NO RESULT FILE (page was never audited)
- phone pages/computer-science/database-management.html: NO RESULT FILE (page was never audited)
- phone pages/computer-science/functions-scope.html: NO RESULT FILE (page was never audited)
- phone pages/computer-science/html5.html: NO RESULT FILE (page was never audited)
- phone pages/computer-science/java.html: NO RESULT FILE (page was never audited)
- phone pages/computer-science/python.html: NO RESULT FILE (page was never audited)
- phone pages/computer-science/robots-robotics.html: NO RESULT FILE (page was never audited)
- phone pages/contact.html: NO RESULT FILE (page was never audited)
- phone pages/english.html: NO RESULT FILE (page was never audited)
- phone pages/english/a-tale-of-two-cities.html: NO RESULT FILE (page was never audited)
- phone pages/english/daffodils.html: NO RESULT FILE (page was never audited)
- phone pages/english/frankenstein.html: NO RESULT FILE (page was never audited)
- phone pages/english/if.html: NO RESULT FILE (page was never audited)
- phone pages/english/ode-to-a-nightingale.html: NO RESULT FILE (page was never audited)
- phone pages/english/pride-and-prejudice.html: NO RESULT FILE (page was never audited)
- phone pages/english/road-not-taken.html: NO RESULT FILE (page was never audited)
- phone pages/english/romeo-and-juliet.html: NO RESULT FILE (page was never audited)
- phone pages/english/sonnet-18.html: NO RESULT FILE (page was never audited)
- phone pages/english/the-gift-of-the-magi.html: NO RESULT FILE (page was never audited)
- phone pages/english/the-great-gatsby.html: NO RESULT FILE (page was never audited)
- phone pages/english/the-happy-prince.html: NO RESULT FILE (page was never audited)
- phone pages/english/the-last-leaf.html: NO RESULT FILE (page was never audited)

### Text that stays invisible after scrolling and forcing every reveal (1 page-states)

These are not measured. Check whether they are intentional (loaders, closed menus) or content stuck at opacity 0.

- desktop pages/certificates.html [default] x9: div.cert-panel.cl-reveal > p.eyebrow :: Official verified certificates ; div.cert-panel.cl-reveal > h2 :: Server-issued, multi-tier ; div.cert-panel.cl-reveal > p :: Unlike the certificate below (

## Contrast failures

Failure = the 10th-percentile contrast across the pixels behind a text run is below 4.5:1 (3:1 for large text, 24px or 18.66px bold).
Groups: 694.

| viewport/theme | failing (element, page) pairs |
|---|---|
| desktop/bloom | 116 |
| desktop/tide | 99 |
| desktop/coral | 89 |
| desktop/arctic | 85 |
| desktop/studio | 85 |
| desktop/atelier | 81 |
| desktop/prism | 81 |
| desktop/sandstone | 80 |
| desktop/sakura | 79 |
| desktop/alpine | 76 |
| desktop/moss | 72 |
| desktop/lavender | 71 |
| desktop/ember | 62 |
| desktop/sapphire | 55 |
| desktop/velvet | 52 |
| desktop/graphite | 46 |
| desktop/aurora | 29 |
| desktop/dusk | 25 |
| desktop/nocturne | 16 |
| desktop/(no-theme-system) | 6 |

### Groups (element x theme), most widespread first

- **desktop sapphire** `div.footer-bottom > span` text 11.5px/400: **3.19:1** (needs 4.5) fg #a7c2e7 on #546480; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop atelier** `div.footer-bottom > span` text 11.5px/400: **3.3:1** (needs 4.5) fg #725249 on #caae9e; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop bloom** `div.footer-bottom > span` text 11.5px/400: **3.38:1** (needs 4.5) fg #725973 on #babfdd; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop tide** `div.footer-bottom > span` text 11.5px/400: **3.43:1** (needs 4.5) fg #416371 on #b8bfbc; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop tide** `div.footer-col.revealed > h5` text 11.2px/700: **3.52:1** (needs 4.5) fg #416371 on #bdc2bf; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Company"
- **desktop bloom** `div.footer-col.revealed > h5` text 11.2px/700: **3.55:1** (needs 4.5) fg #725973 on #c6c2e1; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Company"
- **desktop coral** `div.footer-bottom > span` text 11.5px/400: **3.68:1** (needs 4.5) fg #6d4a46 on #d5aaa0; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop ember** `div.footer-bottom > span` text 11.5px/400: **3.81:1** (needs 4.5) fg #6b433b on #f09986; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop sandstone** `div.footer-bottom > span` text 11.5px/400: **3.84:1** (needs 4.5) fg #5a4933 on #bead80; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop prism** `div.footer-bottom > span` text 11.5px/400: **3.87:1** (needs 4.5) fg #3d5864 on #aabec1; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop velvet** `div.footer-bottom > span` text 11.5px/400: **3.88:1** (needs 4.5) fg #e8d2e5 on #8d5674; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop alpine** `div.footer-bottom > span` text 11.5px/400: **3.94:1** (needs 4.5) fg #34565d on #90bfc4; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop lavender** `div.footer-bottom > span` text 11.5px/400: **3.96:1** (needs 4.5) fg #534570 on #b3aecd; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop arctic** `div.footer-bottom > span` text 11.5px/400: **3.96:1** (needs 4.5) fg #3a5670 on #aabfc4; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop moss** `div.footer-bottom > span` text 11.5px/400: **3.98:1** (needs 4.5) fg #42583c on #b0c090; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop studio** `div.footer-bottom > span` text 11.5px/400: **4:1** (needs 4.5) fg #67574e on #c7c8b7; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop sakura** `div.footer-bottom > span` text 11.5px/400: **4.24:1** (needs 4.5) fg #6e4659 on #e0b5b8; bg from `html.curio-cursor-active.curio-loaded`; 13 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Made with curiosity"
- **desktop atelier** `div.footer-col.revealed > h5` text 11.2px/700: **3.52:1** (needs 4.5) fg #725249 on #f1a79b; bg from `html.curio-cursor-active.curio-loaded`; 12 page(s) e.g. pages/about.html, pages/accessibility.html, pages/active-recall.html; text "Company"
- **desktop sapphire** `div.footer-col.revealed > h5` text 11.2px/700: **3.56:1** (needs 4.5) fg #a7c2e7 on #4c5d7c; bg from `html.curio-cursor-active.curio-loaded`; 9 page(s) e.g. pages/accessibility.html, pages/biology/biological-diversity.html, pages/biology/circulatory-system.html; text "Company"
- **desktop dusk** `div.footer-bottom > span` text 11.5px/400: **3.93:1** (needs 4.5) fg #d9b8c8 on #7c475b; bg from `html.curio-cursor-active.curio-loaded`; 8 page(s) e.g. pages/accessibility.html, pages/biology/biological-diversity.html, pages/biology/circulatory-system.html; text "Made with curiosity"
- **desktop graphite** `div.footer-bottom > span` text 11.5px/400: **4:1** (needs 4.5) fg #a29e96 on #453c27; bg from `html.curio-cursor-active.curio-loaded`; 8 page(s) e.g. pages/accessibility.html, pages/biology/biological-diversity.html, pages/biology/circulatory-system.html; text "Made with curiosity"
- **desktop aurora** `div.footer-bottom > span` text 11.5px/400: **4.27:1** (needs 4.5) fg #9cc4c0 on #524d54; bg from `html.curio-cursor-active.curio-loaded`; 8 page(s) e.g. pages/accessibility.html, pages/biology/biological-diversity.html, pages/biology/circulatory-system.html; text "Made with curiosity"
- **desktop bloom** `div > p` text 16px/400: **3.4:1** (needs 4.5) fg #fcfcfc @0.92 on #cc4e97; bg from `div.wrap > div.hub-cta-inner`; 6 page(s) e.g. pages/biology.html, pages/biology/cell.html, pages/biology/circulatory-system.html; text "Open Cell and try the interactive diagram — abou"
- **desktop coral** `div.footer-col.revealed > h5` text 11.2px/700: **3.93:1** (needs 4.5) fg #6d4a46 on #dbb0a6; bg from `html.curio-cursor-active.curio-loaded`; 6 page(s) e.g. pages/biology/biological-diversity.html, pages/biology/circulatory-system.html, pages/biology/digestive-system.html; text "Company"
- **desktop ember** `div.footer-col.revealed > h5` text 11.2px/700: **3.93:1** (needs 4.5) fg #6b433b on #f09d8b; bg from `html.curio-cursor-active.curio-loaded`; 6 page(s) e.g. pages/biology/biological-diversity.html, pages/biology/circulatory-system.html, pages/biology/digestive-system.html; text "Company"
- **desktop sandstone** `div.footer-col.revealed > h5` text 11.2px/700: **4.04:1** (needs 4.5) fg #5a4933 on #d8aa7c; bg from `html.curio-cursor-active.curio-loaded`; 6 page(s) e.g. pages/biology/biological-diversity.html, pages/biology/circulatory-system.html, pages/biology/digestive-system.html; text "Company"
- **desktop arctic** `div.footer-col.revealed > h5` text 11.2px/700: **4.07:1** (needs 4.5) fg #3a5670 on #c3bcc7; bg from `html.curio-cursor-active.curio-loaded`; 6 page(s) e.g. pages/biology/biological-diversity.html, pages/biology/circulatory-system.html, pages/biology/digestive-system.html; text "Company"
- **desktop prism** `div.footer-col.revealed > h5` text 11.2px/700: **4.08:1** (needs 4.5) fg #3d5864 on #c8bcc6; bg from `html.curio-cursor-active.curio-loaded`; 6 page(s) e.g. pages/biology/biological-diversity.html, pages/biology/circulatory-system.html, pages/biology/digestive-system.html; text "Company"
- **desktop sandstone** `nav.admin-sidebar > a` text 14.1px/400: **1.78:1** (needs 4.5) fg #5a4933 on #25165f; bg from `div.admin-layout > nav.admin-sidebar`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Dashboard"
- **desktop lavender** `nav.admin-sidebar > a` text 14.1px/400: **1.8:1** (needs 4.5) fg #534570 on #25165f; bg from `div.admin-layout > nav.admin-sidebar`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Dashboard"
- **desktop ember** `nav.admin-sidebar > a` text 14.1px/400: **1.82:1** (needs 4.5) fg #6b433b on #25165f; bg from `div.admin-layout > nav.admin-sidebar`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Dashboard"
- **desktop alpine** `nav.admin-sidebar > a` text 14.1px/400: **1.93:1** (needs 4.5) fg #34565d on #25165f; bg from `div.admin-layout > nav.admin-sidebar`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Dashboard"
- **desktop sakura** `nav.admin-sidebar > a` text 14.1px/400: **1.96:1** (needs 4.5) fg #6e4659 on #25165f; bg from `div.admin-layout > nav.admin-sidebar`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Dashboard"
- **desktop moss** `nav.admin-sidebar > a` text 14.1px/400: **1.97:1** (needs 4.5) fg #42583c on #25165f; bg from `div.admin-layout > nav.admin-sidebar`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Dashboard"
- **desktop coral** `nav.admin-sidebar > a` text 14.1px/400: **1.99:1** (needs 4.5) fg #6d4a46 on #25165f; bg from `div.admin-layout > nav.admin-sidebar`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Dashboard"
- **desktop arctic** `nav.admin-sidebar > a` text 14.1px/400: **2.01:1** (needs 4.5) fg #3a5670 on #25165f; bg from `div.admin-layout > nav.admin-sidebar`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Dashboard"
- **desktop prism** `nav.admin-sidebar > a` text 14.1px/400: **2.03:1** (needs 4.5) fg #3d5864 on #25165f; bg from `div.admin-layout > nav.admin-sidebar`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Dashboard"
- **desktop atelier** `nav.admin-sidebar > a` text 14.1px/400: **2.21:1** (needs 4.5) fg #725249 on #25165f; bg from `div.admin-layout > nav.admin-sidebar`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Dashboard"
- **desktop studio** `nav.admin-sidebar > a` text 14.1px/400: **2.23:1** (needs 4.5) fg #67574e on #25165f; bg from `div.admin-layout > nav.admin-sidebar`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Dashboard"
- **desktop aurora** `a.logo > span.admin-badge` text 10.4px/600: **2.23:1** (needs 4.5) fg #ffffff on #f091aa; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop velvet** `a.logo > span.admin-badge` text 10.4px/600: **2.36:1** (needs 4.5) fg #ffffff on #e78db1; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop tide** `nav.admin-sidebar > a` text 14.1px/400: **2.38:1** (needs 4.5) fg #416371 on #25165f; bg from `div.admin-layout > nav.admin-sidebar`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Dashboard"
- **desktop sapphire** `a.logo > span.admin-badge` text 10.4px/600: **2.47:1** (needs 4.5) fg #ffffff on #ef8686; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop bloom** `nav.admin-sidebar > a` text 14.1px/400: **2.48:1** (needs 4.5) fg #725973 on #25165f; bg from `div.admin-layout > nav.admin-sidebar`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Dashboard"
- **desktop dusk** `a.logo > span.admin-badge` text 10.4px/600: **2.58:1** (needs 4.5) fg #ffffff on #ff7293; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop graphite** `a.logo > span.admin-badge` text 10.4px/600: **2.7:1** (needs 4.5) fg #ffffff on #fc7447; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop nocturne** `a.logo > span.admin-badge` text 10.4px/600: **2.8:1** (needs 4.5) fg #ffffff on #f6715e; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop sakura** `a.logo > span.admin-badge` text 10.4px/600: **2.91:1** (needs 4.5) fg #ffffff on #f0715d; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop prism** `a.logo > span.admin-badge` text 10.4px/600: **3.39:1** (needs 4.5) fg #ffffff on #d66c64; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop coral** `a.logo > span.admin-badge` text 10.4px/600: **3.45:1** (needs 4.5) fg #ffffff on #e65e50; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop tide** `a.logo > span.admin-badge` text 10.4px/600: **3.5:1** (needs 4.5) fg #ffffff on #e85a4e; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop bloom** `a.logo > span.admin-badge` text 10.4px/600: **3.55:1** (needs 4.5) fg #ffffff on #df549f; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop alpine** `a.logo > span.admin-badge` text 10.4px/600: **3.72:1** (needs 4.5) fg #ffffff on #cb6854; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop studio** `a.logo > span.admin-badge` text 10.4px/600: **3.91:1** (needs 4.5) fg #ffffff on #dc5527; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop arctic** `a.logo > span.admin-badge` text 10.4px/600: **3.92:1** (needs 4.5) fg #ffffff on #c36656; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop sandstone** `a.logo > span.admin-badge` text 10.4px/600: **4.12:1** (needs 4.5) fg #ffffff on #b9664e; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop aurora** `p.crumb > a` text 12.5px/400: **4.13:1** (needs 4.5) fg #9cc4c0 on #25584d; bg from `main#main-content`; 5 page(s) e.g. pages/biology/biological-diversity.html, pages/biology/circulatory-system.html, pages/biology/digestive-system.html; text "Biology"
- **desktop studio** `div.footer-col.revealed > h5` text 11.2px/700: **4.15:1** (needs 4.5) fg #67574e on #f7bda8; bg from `html.curio-cursor-active.curio-loaded`; 5 page(s) e.g. pages/biology/circulatory-system.html, pages/biology/digestive-system.html, pages/biology/excretory-system.html; text "Company"
- **desktop alpine** `div.footer-col.revealed > h5` text 11.2px/700: **4.16:1** (needs 4.5) fg #34565d on #bcbdb9; bg from `html.curio-cursor-active.curio-loaded`; 5 page(s) e.g. pages/biology/circulatory-system.html, pages/biology/digestive-system.html, pages/biology/excretory-system.html; text "Company"
- **desktop bloom** `div > div.score-badge.pop` text 12.5px/400: **4.2:1** (needs 4.5) fg #725973 on #cfd7e1; bg from `main#main-content`; 5 page(s) e.g. pages/biology/cell.html, pages/biology/circulatory-system.html, pages/biology/excretory-system.html; text "🏆 Best score on this lesson:"
- **desktop moss** `a.logo > span.admin-badge` text 10.4px/600: **4.28:1** (needs 4.5) fg #ffffff on #ba6146; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop lavender** `a.logo > span.admin-badge` text 10.4px/600: **4.35:1** (needs 4.5) fg #ffffff on #b55c7f; bg from `a.logo > span.admin-badge`; 5 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Admin"
- **desktop bloom** `p.crumb > a` text 12.5px/400: **4.39:1** (needs 4.5) fg #725973 on #d4dbe4; bg from `main#main-content`; 5 page(s) e.g. pages/biology/cell.html, pages/biology/circulatory-system.html, pages/biology/excretory-system.html; text "Biology"
- **desktop bloom** `td > span.badge.badge-amber` text 10.4px/400: **1.97:1** (needs 4.5) fg #e29936 on #f9e7d6; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "superadmin"
- **desktop tide** `td > span.badge.badge-amber` text 10.4px/400: **2.01:1** (needs 4.5) fg #e1961b on #f3e8d1; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "superadmin"
- **desktop atelier** `td > span.badge.badge-amber` text 10.4px/400: **2.2:1** (needs 4.5) fg #e08600 on #f9e2c0; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "superadmin"
- **desktop sakura** `td > span.badge.badge-amber` text 10.4px/400: **2.22:1** (needs 4.5) fg #d98a3a on #f7e4d5; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "superadmin"
- **desktop studio** `td > span.badge.badge-amber` text 10.4px/400: **2.41:1** (needs 4.5) fg #d6810c on #f7e4cb; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "superadmin"
- **desktop sakura** `td > span.badge.badge-red` text 10.4px/400: **2.44:1** (needs 4.5) fg #f0705c on #fde5e4; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop alpine** `td > span.badge.badge-amber` text 10.4px/400: **2.52:1** (needs 4.5) fg #c78331 on #eee6d6; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "superadmin"
- **desktop lavender** `td > span.badge.badge-amber` text 10.4px/400: **2.56:1** (needs 4.5) fg #bd8430 on #f0e3d6; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "superadmin"
- **desktop arctic** `td > span.badge.badge-amber` text 10.4px/400: **2.57:1** (needs 4.5) fg #bd8530 on #efe5d6; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "superadmin"
- **desktop prism** `td > span.badge.badge-amber` text 10.4px/400: **2.59:1** (needs 4.5) fg #bf8430 on #f0e6d5; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "superadmin"
- **desktop moss** `td > span.badge.badge-amber` text 10.4px/400: **2.68:1** (needs 4.5) fg #b9822a on #eee6cd; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "superadmin"
- **desktop coral** `td > span.badge.badge-amber` text 10.4px/400: **2.72:1** (needs 4.5) fg #be7a2f on #f2e0d0; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "superadmin"
- **desktop coral** `td > span.badge.badge-red` text 10.4px/400: **2.82:1** (needs 4.5) fg #e65d4f on #fbe2df; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop sakura** `td > span.badge.badge-green` text 10.4px/400: **2.83:1** (needs 4.5) fg #6f9060 on #e2e5dd; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop tide** `td > span.badge.badge-red` text 10.4px/400: **2.86:1** (needs 4.5) fg #e8594d on #f5e4e3; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop sandstone** `td > span.badge.badge-amber` text 10.4px/400: **2.87:1** (needs 4.5) fg #b87828 on #f1e2ce; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "superadmin"
- **desktop prism** `td > span.badge.badge-red` text 10.4px/400: **2.89:1** (needs 4.5) fg #d66b63 on #f6e9e7; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop bloom** `td > span.badge.badge-red` text 10.4px/400: **2.93:1** (needs 4.5) fg #df539f on #fae2f0; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop ember** `td > span.badge.badge-amber` text 10.4px/400: **2.99:1** (needs 4.5) fg #bd6d25 on #f2decd; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "superadmin"
- **desktop bloom** `td > span.badge.badge-green` text 10.4px/400: **3.09:1** (needs 4.5) fg #608b4e on #dfe5db; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop alpine** `td > span.badge.badge-red` text 10.4px/400: **3.11:1** (needs 4.5) fg #cb6753 on #f1e8e5; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop tide** `td > span.badge.badge-green` text 10.4px/400: **3.13:1** (needs 4.5) fg #458c5f on #d4e6de; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop studio** `td > span.badge.badge-red` text 10.4px/400: **3.22:1** (needs 4.5) fg #dc5426 on #fae4db; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop arctic** `td > span.badge.badge-red` text 10.4px/400: **3.25:1** (needs 4.5) fg #c36555 on #f3e6e6; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop sandstone** `td > span.badge.badge-green` text 10.4px/400: **3.33:1** (needs 4.5) fg #71804d on #e3e4d5; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop sandstone** `td > span.badge.badge-red` text 10.4px/400: **3.43:1** (needs 4.5) fg #b9654d on #f5e6de; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop prism** `td > span.badge.badge-green` text 10.4px/400: **3.43:1** (needs 4.5) fg #5d8250 on #dce6db; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop coral** `td > span.badge.badge-green` text 10.4px/400: **3.44:1** (needs 4.5) fg #6d7c4e on #e2e1d6; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop arctic** `td > span.badge.badge-green` text 10.4px/400: **3.44:1** (needs 4.5) fg #60804f on #dce4dc; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop lavender** `td > span.badge.badge-green` text 10.4px/400: **3.51:1** (needs 4.5) fg #687b53 on #dfe1dd; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop ember** `td > span.badge.badge-green` text 10.4px/400: **3.52:1** (needs 4.5) fg #697b45 on #e1e1d3; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop moss** `td > span.badge.badge-red` text 10.4px/400: **3.55:1** (needs 4.5) fg #ba6045 on #f1e7db; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop lavender** `td > span.badge.badge-red` text 10.4px/400: **3.56:1** (needs 4.5) fg #b55b7e on #f2e3ec; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop studio** `td > span.badge.badge-green` text 10.4px/400: **3.58:1** (needs 4.5) fg #4e8048 on #dce4d7; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop velvet** `td > span.badge.badge-red` text 10.4px/400: **3.63:1** (needs 4.5) fg #e78aaf on #643b67; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop alpine** `td > span.badge.badge-green` text 10.4px/400: **3.67:1** (needs 4.5) fg #477d65 on #d5e5e0; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop velvet** `td > span.badge.badge-green` text 10.4px/400: **3.67:1** (needs 4.5) fg #9cb96f on #5d495f; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop atelier** `td > span.badge.badge-red` text 10.4px/400: **3.78:1** (needs 4.5) fg #c84435 on #f7ded8; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop sapphire** `td > span.badge.badge-red` text 10.4px/400: **4.03:1** (needs 4.5) fg #ef8383 on #363e65; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop sapphire** `td > span.badge.badge-green` text 10.4px/400: **4.06:1** (needs 4.5) fg #8bbf7c on #2d4e65; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop ember** `td > span.badge.badge-red` text 10.4px/400: **4.1:1** (needs 4.5) fg #c33a2c on #f6ddd9; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop lavender** `div.footer-col.revealed > h5` text 11.2px/700: **4.13:1** (needs 4.5) fg #534570 on #cfa9d1; bg from `html.curio-cursor-active.curio-loaded`; 4 page(s) e.g. pages/biology/circulatory-system.html, pages/biology/digestive-system.html, pages/biology/excretory-system.html; text "Company"
- **desktop moss** `td > span.badge.badge-green` text 10.4px/400: **4.16:1** (needs 4.5) fg #48733f on #d7e3d1; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop moss** `div.footer-col.revealed > h5` text 11.2px/700: **4.17:1** (needs 4.5) fg #42583c on #ccbe94; bg from `html.curio-cursor-active.curio-loaded`; 4 page(s) e.g. pages/biology/circulatory-system.html, pages/biology/digestive-system.html, pages/biology/health.html; text "Company"
- **desktop dusk** `td > span.badge.badge-red` text 10.4px/400: **4.26:1** (needs 4.5) fg #ff6f91 on #53295d; bg from `td > span.badge.badge-red`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "inactive"
- **desktop graphite** `td > span.badge.badge-green` text 10.4px/400: **4.26:1** (needs 4.5) fg #88ac61 on #333f33; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop velvet** `td > span.badge.badge-amber` text 10.4px/400: **4.27:1** (needs 4.5) fg #edbd66 on #6d4a5d; bg from `td > span.badge.badge-amber`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "Pro"
- **desktop atelier** `td > span.badge.badge-green` text 10.4px/400: **4.36:1** (needs 4.5) fg #526b19 on #dddcc9; bg from `td > span.badge.badge-green`; 4 page(s) e.g. pages/admin/admins.html, pages/admin/audit.html, pages/admin/dashboard.html; text "active"
- **desktop atelier** `div > div.score-badge.pop` text 12.5px/400: **4.43:1** (needs 4.5) fg #725249 on #d1d1c3; bg from `main#main-content`; 4 page(s) e.g. pages/biology/cell.html, pages/biology/excretory-system.html, pages/biology/health.html; text "🏆 Best score on this lesson:"
- **desktop bloom** `div.wrap > p.crumb` text 12.5px/400: **4.44:1** (needs 4.5) fg #725973 on #d7dde6; bg from `main#main-content`; 4 page(s) e.g. pages/biology/cell.html, pages/biology/circulatory-system.html, pages/biology/excretory-system.html; text "/ The Circulatory System"
- **desktop graphite** `div.rail-scroll > div.rail-section-label` text 9.9px/700: **4.33:1** (needs 4.5) fg #a29e96 on #3b3831; bg from `nav#curio-side-rail.side-rail`; 3 page(s) e.g. pages/biology/biological-diversity.html, pages/biology/digestive-system.html, pages/certificates.html; text "Workspace"
- **desktop graphite** `a.rail-item > span.rail-label` text 12.8px/600: **4.33:1** (needs 4.5) fg #a29e96 on #3a3832; bg from `nav#curio-side-rail.side-rail`; 3 page(s) e.g. pages/biology/biological-diversity.html, pages/biology/digestive-system.html, pages/certificates.html; text "Overview"
- **desktop tide** `div > div.score-badge.pop` text 12.5px/400: **4.41:1** (needs 4.5) fg #416371 on #ded4d7; bg from `main#main-content`; 3 page(s) e.g. pages/biology/cell.html, pages/biology/excretory-system.html, pages/biology/health.html; text "🏆 Best score on this lesson:"
- **desktop graphite** `a.rail-item > span.rail-icon.is-code` text 8.6px/800: **4.43:1** (needs 4.5) fg #a29e96 on #323835; bg from `nav#curio-side-rail.side-rail`; 3 page(s) e.g. pages/biology/biological-diversity.html, pages/biology/digestive-system.html, pages/certificates.html; text "PHY"
- **desktop sakura** `td > span.badge.badge-teal` text 10.4px/400: **2.61:1** (needs 4.5) fg #4a9a95 on #dbe7e7; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop tide** `td > span.badge.badge-teal` text 10.4px/400: **2.89:1** (needs 4.5) fg #00918b on #b9e7e7; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop sakura** `div.gf-pills > button.gf-pill` text 13.1px/600: **2.91:1** (needs 4.5) fg #ffffff on #f0715d; bg from `div.gf-pills > button.gf-pill`; 2 page(s) e.g. pages/biology.html, pages/browse.html; text "All"
- **desktop bloom** `td > span.badge.badge-teal` text 10.4px/400: **2.96:1** (needs 4.5) fg #00927c on #cbe6e4; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop coral** `p.auth-switch > a` text 14.1px/600: **3.11:1** (needs 4.5) fg #e65d4f on #ffefec; bg from `div.auth-form-panel > div.auth-card`; 2 page(s) e.g. pages/admin/login.html, pages/admin/setup.html; text "← Back to Curio Lab"
- **desktop prism** `td > span.badge.badge-teal` text 10.4px/400: **3.12:1** (needs 4.5) fg #278d8a on #d1e8e7; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop studio** `td > span.badge.badge-teal` text 10.4px/400: **3.18:1** (needs 4.5) fg #008c72 on #cae6df; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop moss** `td > span.badge.badge-teal` text 10.4px/400: **3.18:1** (needs 4.5) fg #4f8972 on #d9e7dc; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop arctic** `td > span.badge.badge-teal` text 10.4px/400: **3.22:1** (needs 4.5) fg #3e8694 on #d5e5ea; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop bloom** `p.auth-switch > a` text 14.1px/600: **3.24:1** (needs 4.5) fg #df539f on #fff0f7; bg from `div.auth-form-panel > div.auth-card`; 2 page(s) e.g. pages/admin/login.html, pages/admin/setup.html; text "← Back to Curio Lab"
- **desktop coral** `td > span.badge.badge-teal` text 10.4px/400: **3.29:1** (needs 4.5) fg #3d8580 on #d8e3e0; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop sandstone** `td > span.badge.badge-teal` text 10.4px/400: **3.36:1** (needs 4.5) fg #4f837a on #dce5de; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop prism** `div.gf-pills > button.gf-pill` text 13.1px/600: **3.39:1** (needs 4.5) fg #ffffff on #d66c64; bg from `div.gf-pills > button.gf-pill`; 2 page(s) e.g. pages/biology.html, pages/browse.html; text "All"
- **desktop tide** `div.gf-pills > button.gf-pill` text 13.1px/600: **3.41:1** (needs 4.5) fg #fcfcfc on #e85a4e; bg from `div.gf-pills > button.gf-pill`; 2 page(s) e.g. pages/biology.html, pages/browse.html; text "All"
- **desktop tide** `div > p` text 16px/400: **3.42:1** (needs 4.5) fg #fcfcfc @0.92 on #c75853; bg from `div.wrap > div.hub-cta-inner`; 2 page(s) e.g. pages/biology.html, pages/biology/cell.html; text "Open Cell and try the interactive diagram — abou"
- **desktop coral** `div.gf-pills > button.gf-pill` text 13.1px/600: **3.45:1** (needs 4.5) fg #ffffff on #e65e50; bg from `div.gf-pills > button.gf-pill`; 2 page(s) e.g. pages/biology.html, pages/browse.html; text "All"
- **desktop lavender** `td > span.badge.badge-teal` text 10.4px/400: **3.46:1** (needs 4.5) fg #448078 on #d8e2e4; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop bloom** `div.gf-pills > button.gf-pill` text 13.1px/600: **3.46:1** (needs 4.5) fg #fcfcfc on #df549f; bg from `div.gf-pills > button.gf-pill`; 2 page(s) e.g. pages/biology.html, pages/browse.html; text "All"
- **desktop tide** `p.auth-switch > a` text 14.1px/600: **3.47:1** (needs 4.5) fg #00918b on #e8f5f6; bg from `div.auth-form-panel > div.auth-card`; 2 page(s) e.g. pages/admin/login.html, pages/admin/setup.html; text "← Back to Curio Lab"
- **desktop sakura** `p.auth-switch > a` text 14.1px/600: **3.54:1** (needs 4.5) fg #e0457b on #ffeef2; bg from `div.auth-form-panel > div.auth-card`; 2 page(s) e.g. pages/admin/login.html, pages/admin/setup.html; text "← Back to Curio Lab"
- **desktop studio** `p.auth-switch > a` text 14.1px/600: **3.58:1** (needs 4.5) fg #dc5426 on #fef2ec; bg from `div.auth-form-panel > div.auth-card`; 2 page(s) e.g. pages/admin/login.html, pages/admin/setup.html; text "← Back to Curio Lab"
- **desktop ember** `td > span.badge.badge-teal` text 10.4px/400: **3.6:1** (needs 4.5) fg #387d77 on #d7e1dd; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop alpine** `td > span.badge.badge-teal` text 10.4px/400: **3.68:1** (needs 4.5) fg #167c92 on #cbe5e9; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop studio** `div.gf-pills > button.gf-pill` text 13.1px/600: **3.81:1** (needs 4.5) fg #fcfcfc on #dc5527; bg from `div.gf-pills > button.gf-pill`; 2 page(s) e.g. pages/biology.html, pages/browse.html; text "All"
- **desktop graphite** `td > span.badge.badge-teal` text 10.4px/400: **3.9:1** (needs 4.5) fg #34a88d on #233e3d; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop arctic** `div.gf-pills > button.gf-pill` text 13.1px/600: **3.9:1** (needs 4.5) fg #ffffff on #c36656; bg from `div.gf-pills > button.gf-pill`; 2 page(s) e.g. pages/biology.html, pages/browse.html; text "All"
- **desktop velvet** `td > span.badge.badge-teal` text 10.4px/400: **4:1** (needs 4.5) fg #76c9bd on #564d6e; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop sapphire** `td > span.badge.badge-teal` text 10.4px/400: **4.01:1** (needs 4.5) fg #58c1c0 on #234e74; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop moss** `div.gf-pills > button.gf-pill` text 13.1px/600: **4.02:1** (needs 4.5) fg #ffffff on #508a73; bg from `div.gf-pills > button.gf-pill`; 2 page(s) e.g. pages/biology.html, pages/browse.html; text "All"
- **desktop arctic** `p.auth-switch > a` text 14.1px/600: **4.05:1** (needs 4.5) fg #377bb6 on #edf4fa; bg from `div.auth-form-panel > div.auth-card`; 2 page(s) e.g. pages/admin/login.html, pages/admin/setup.html; text "← Back to Curio Lab"
- **desktop atelier** `td > span.badge.badge-teal` text 10.4px/400: **4.07:1** (needs 4.5) fg #157554 on #d0ded4; bg from `td > span.badge.badge-teal`; 2 page(s) e.g. pages/admin/audit.html, pages/admin/dashboard.html; text "signup"
- **desktop sandstone** `div.gf-pills > button.gf-pill` text 13.1px/600: **4.12:1** (needs 4.5) fg #ffffff on #b9664e; bg from `div.gf-pills > button.gf-pill`; 2 page(s) e.g. pages/biology.html, pages/browse.html; text "All"
- **desktop coral** `div > p.eyebrow` text 11.5px/400: **4.19:1** (needs 4.5) fg #a74940 on #fbd5ce; bg from `main#main-content > section.hub-hero`; 2 page(s) e.g. pages/active-recall.html, pages/biology.html; text "CUR—BIO · Science"
