# Contrast audit

Pixel-based contrast + phone-layout audit for every page x every site theme (read from `public/js/site-themes.js`).

Setup: `npm install` (needs `playwright-core`) and a Chromium (`npx playwright install chromium`, or set `CHROMIUM_PATH`).

    node audit.mjs                                   # all pages, all themes, desktop 1280 + phone 390
    node audit.mjs --pages '^pages/admin/' --viewports phone --themes studio,nocturne
    node audit.mjs --states extra                    # lesson tabs, open panels, error banners, side rail
    node audit.mjs --force                           # ignore earlier results
    node report.mjs                                  # coverage check + REPORT.md + findings.json (exit 1 if anything was not measured)
    node report.mjs --baseline old-findings.json     # new / fixed groups

How it works: text is hidden, the viewport is screenshotted, and the pixels behind each text run are compared with its real colour
(10th-percentile contrast; 4.5:1, or 3:1 for large text). Scroll-reveals and animations are forced to their end state.
Admin pages use a stubbed API (`lib/server.mjs`); `dashboard.html` gets a fake session (`config.mjs`).
Results go to `results/` (git-ignored). Re-run after any theme or design change.
