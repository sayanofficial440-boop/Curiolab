# Get the APK
1. Push this project to GitHub (the Lovable-connected repo works).
2. GitHub -> Actions -> "Build Android APK" -> Run workflow (it also runs on every push to main).
3. When it finishes, open the run and download the artifact `curio-lab-debug-apk` (contains app-debug.apk).
4. Send app-debug.apk to your phone and install it (allow "install unknown apps").
The app is the static site in public/ shown in a WebView. Admin pages need a backend and will not work inside the APK.
