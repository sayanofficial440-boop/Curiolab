/* Curio Lab – drop-in dashboard widget. Shows REAL activity from Labs, Math tools and Notes.
   Usage on your dashboard page:
     <div data-curio-activity></div>
     <script src="/features/curio-activity.js"></script>
     <script src="/features/activity-widget.js"></script>
   Uses --cl-* tokens when features.css is loaded, otherwise falls back to neutral colours. Updates live. */
(function(){
  var base=(document.currentScript&&document.currentScript.src)||location.href;function u(p){try{return new URL(p,base).href}catch(e){return p}}
  var css=".ca{font-family:var(--cl-font,system-ui,sans-serif);color:var(--cl-text,#1b2033)}"+
  ".ca-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:8px;margin-bottom:12px}"+
  ".ca-stats div{background:var(--cl-surface2,#eef0f7);border-radius:10px;padding:10px}"+
  ".ca-stats strong{display:block;font-size:1.5rem;font-variant-numeric:tabular-nums}.ca-stats small{color:var(--cl-muted,#5d6580)}"+
  ".ca ul{list-style:none;margin:0;padding:0}.ca li{display:flex;gap:8px;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--cl-border,#d9dcea);font-size:14px}"+
  ".ca li span:last-child{color:var(--cl-muted,#5d6580);white-space:nowrap}.ca-empty{color:var(--cl-muted,#5d6580);font-size:14px}"+
  ".ca a{color:var(--cl-accent,#5b4bdb)}";
  var st=document.createElement("style");st.textContent=css;document.head.appendChild(st);
  function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
  function ago(t){var m=Math.round((Date.now()-t)/60000);return m<1?"just now":m<60?m+" min ago":m<1440?Math.round(m/60)+" h ago":new Date(t).toLocaleDateString()}
  function render(){
    var all=window.CurioActivity?CurioActivity.all():[];
    var n=function(t){return all.filter(function(x){return x.type===t}).length};
    var days={};all.forEach(function(x){days[new Date(x.ts).toDateString()]=1});
    var recent=all.slice(-6).reverse();
    var html='<div class="ca"><div class="ca-stats"><div><strong>'+n("lab")+'</strong><small>Lab actions</small></div><div><strong>'+n("math")+'</strong><small>Math tool uses</small></div><div><strong>'+n("note")+'</strong><small>Notes opened</small></div><div><strong>'+Object.keys(days).length+'</strong><small>Active days</small></div></div>'+
      (recent.length?'<ul>'+recent.map(function(x){return '<li><span><b>'+esc(x.label)+'</b>'+(x.detail?' · '+esc(x.detail):'')+'</span><span>'+ago(x.ts)+'</span></li>'}).join("")+'</ul>':
      '<p class="ca-empty">No activity yet. Try a <a href="'+u("../pages/labs/index.html")+'">virtual lab</a>, the <a href="'+u("../pages/math-tools/index.html")+'">graphing calculator</a>, or a <a href="'+u("../pages/notes/index.html")+'">cheat sheet</a>.</p>')+'</div>';
    document.querySelectorAll("[data-curio-activity]").forEach(function(el){el.innerHTML=html});
  }
  render();window.addEventListener("curio:activity",render);window.addEventListener("storage",render);setInterval(render,60000);
})();
