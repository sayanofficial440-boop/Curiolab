/* Curio Lab – tiny activity logger used by Labs / Math / Notes pages.
   Stores REAL user actions (no sample data) in localStorage under "curio.activity.v1"
   and fires a "curio:activity" window event so your dashboard can listen live.
   Entry: {type:"lab"|"math"|"note", id, label, detail, ts}
   Hook into your existing progress store with:
     window.addEventListener("curio:activity", e => yourStore.add(e.detail));
   or read CurioActivity.all() when rendering the dashboard. */
(function(){
  var KEY="curio.activity.v1";
  function read(){try{return JSON.parse(localStorage.getItem(KEY)||"[]")}catch(e){return []}}
  window.CurioActivity={
    all:read,
    log:function(type,id,label,detail){
      var entry={type:type,id:id,label:label,detail:detail||"",ts:Date.now()};
      try{var a=read();a.push(entry);if(a.length>500)a=a.slice(-500);localStorage.setItem(KEY,JSON.stringify(a))}catch(e){}
      try{window.dispatchEvent(new CustomEvent("curio:activity",{detail:entry}))}catch(e){}
      return entry;
    },
    count:function(type){return read().filter(function(x){return !type||x.type===type}).length}
  };
})();

;(function(){try{new MutationObserver(function(){window.dispatchEvent(new Event("curio:theme"))}).observe(document.documentElement,{attributes:true,attributeFilter:["data-theme"]})}catch(e){}})();
