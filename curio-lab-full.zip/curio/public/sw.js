// Curio Lab service worker — lets lessons you have opened work offline.
// Strategy: stale-while-revalidate for same-origin GETs (pages, css, js, json);
// offline.html is shown for a page that was never cached.
const VERSION = "curio-v10";
const SHELL = ["offline.html", "icons/icon-192.png", "favicon.ico"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL).catch(() => {})).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== "GET" || url.origin !== location.origin || url.pathname.includes("/api/") || url.pathname.startsWith("/verify/")) return;
  e.respondWith((async () => {
    const cache = await caches.open(VERSION);
    const cached = await cache.match(req, { ignoreSearch: req.mode === "navigate" });
    const network = fetch(req).then((res) => { if (res && res.ok) cache.put(req, res.clone()); return res; }).catch(() => null);
    if (cached) { network.catch(() => {}); return cached; }
    const res = await network;
    if (res) return res;
    if (req.mode === "navigate") { const off = await cache.match("offline.html"); if (off) return off; }
    return new Response("Offline", { status: 503, statusText: "Offline" });
  })());
});
// pages the learner asks to keep offline
self.addEventListener("message", (e) => {
  if (!e.data || e.data.type !== "cache-urls") return;
  e.waitUntil(caches.open(VERSION).then((c) => Promise.all((e.data.urls || []).map((u) => fetch(u).then((r) => r.ok && c.put(u, r)).catch(() => {})))));
});

// "Review due today" push (sent by backend/app.py) and tapping the notification.
self.addEventListener("push", (e) => {
  let d = {}; try { d = e.data ? e.data.json() : {}; } catch (_) { /* plain text */ }
  e.waitUntil(self.registration.showNotification(d.title || "Review due today", {
    body: d.body || "Questions in your Mistake Notebook are ready.", icon: "icons/icon-192.png", badge: "icons/icon-192.png",
    tag: "review-due", renotify: false, data: { url: d.url || "pages/review.html" },
  }));
});
self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  const url = new URL((e.notification.data && e.notification.data.url) || "pages/review.html", self.registration.scope).href;
  e.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((cs) => {
    const c = cs.find((w) => w.url.split("?")[0] === url);
    return c ? c.focus() : self.clients.openWindow(url);
  }));
});
