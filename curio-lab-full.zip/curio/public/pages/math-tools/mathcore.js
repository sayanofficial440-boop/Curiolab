/* Curio Lab – math core: expression parser, root finding, polynomial & linear-system solvers.
   Pure functions, no DOM. Exposed as window.CurioMath (and module.exports for tests). */
(function(root){
"use strict";
var FUN={sin:Math.sin,cos:Math.cos,tan:Math.tan,asin:Math.asin,acos:Math.acos,atan:Math.atan,sinh:Math.sinh,cosh:Math.cosh,tanh:Math.tanh,
  sqrt:Math.sqrt,cbrt:Math.cbrt,abs:Math.abs,ln:Math.log,log:Math.log10,exp:Math.exp,floor:Math.floor,ceil:Math.ceil,round:Math.round,sign:Math.sign};
var CONST={pi:Math.PI,e:Math.E};
var FNAMES=Object.keys(FUN).sort(function(a,b){return b.length-a.length});

function tokenize(src){
  var s=src.toLowerCase().replace(/π/g,"pi").replace(/×/g,"*").replace(/÷/g,"/").replace(/−/g,"-").replace(/\s+/g,"");
  var t=[],i=0,m;
  while(i<s.length){
    var ch=s[i];
    if((m=/^(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/.exec(s.slice(i)))&&(/\d|\./.test(ch))){
      // avoid eating the constant 'e' in 2e (e.g. "2e") : regex requires digits after e so fine
      t.push({t:"num",v:parseFloat(m[0])});i+=m[0].length;continue}
    if(/[a-z]/.test(ch)){
      var rest=s.slice(i),hit=null;
      for(var k=0;k<FNAMES.length;k++)if(rest.indexOf(FNAMES[k])===0){hit=FNAMES[k];break}
      if(hit){t.push({t:"fn",v:hit});i+=hit.length;continue}
      if(rest.indexOf("pi")===0){t.push({t:"num",v:Math.PI});i+=2;continue}
      if(ch==="e"){t.push({t:"num",v:Math.E});i++;continue}
      t.push({t:"var",v:ch});i++;continue}
    if("+-*/^(),".indexOf(ch)>=0){t.push({t:ch});i++;continue}
    if(ch==="|"){throw new Error("Use abs(x) instead of |x|")}
    throw new Error("Unexpected character '"+ch+"'");
  }
  return t;
}
function parse(src){
  var tk=tokenize(src),p=0;
  if(!tk.length)throw new Error("Empty expression");
  function peek(){return tk[p]}
  function startsFactor(x){return x&&(x.t==="num"||x.t==="var"||x.t==="fn"||x.t==="(")}
  function expr(){var l=term();while(peek()&&(peek().t==="+"||peek().t==="-")){var op=tk[p++].t,r=term();l=bin(op,l,r)}return l}
  function term(){var l=unary();
    for(;;){var x=peek();
      if(x&&(x.t==="*"||x.t==="/")){p++;l=bin(x.t,l,unary())}
      else if(startsFactor(x)){l=bin("*",l,unary())}
      else break}
    return l}
  function unary(){var x=peek();if(x&&x.t==="-"){p++;var u=unary();return {f:function(e){return -u.f(e)},v:u.v}}
    if(x&&x.t==="+"){p++;return unary()}return power()}
  function power(){var b=primary();if(peek()&&peek().t==="^"){p++;var ex=unary();return bin("^",b,ex)}return b}
  function primary(){var x=tk[p++];
    if(!x)throw new Error("Unexpected end of expression");
    if(x.t==="num"){var v=x.v;return {f:function(){return v},v:{}}}
    if(x.t==="var"){var n=x.v;var o={};o[n]=1;return {f:function(e){var q=e[n];return q===undefined?NaN:q},v:o}}
    if(x.t==="("){var inner=expr();if(!peek()||peek().t!==")")throw new Error("Missing closing parenthesis");p++;return inner}
    if(x.t==="fn"){var fn=FUN[x.v],arg;
      if(peek()&&peek().t==="("){p++;arg=expr();if(!peek()||peek().t!==")")throw new Error("Missing closing parenthesis");p++}
      else arg=unary();
      return {f:function(e){return fn(arg.f(e))},v:arg.v}}
    throw new Error("Unexpected '"+(x.t||"")+"'");}
  function bin(op,l,r){var v={},k;for(k in l.v)v[k]=1;for(k in r.v)v[k]=1;var f;
    if(op==="+")f=function(e){return l.f(e)+r.f(e)};else if(op==="-")f=function(e){return l.f(e)-r.f(e)};
    else if(op==="*")f=function(e){return l.f(e)*r.f(e)};else if(op==="/")f=function(e){return l.f(e)/r.f(e)};
    else f=function(e){var a=l.f(e),b=r.f(e);return (a<0&&Math.abs(b)<1&&b!==0&&Math.abs(1/b-Math.round(1/b))<1e-9&&Math.round(1/b)%2!==0)?-Math.pow(-a,b):Math.pow(a,b)}; // odd roots of negatives, e.g. x^(1/3)
    return {f:f,v:v}}
  var ast=expr();if(p<tk.length)throw new Error("Unexpected '"+(tk[p].t==="num"?tk[p].v:tk[p].v||tk[p].t)+"'");
  return ast;
}
/* compile("x^2+a*x") -> function(x,params) */
function compile(src){
  var ast=parse(src),env={};
  var fn=function(x,params){env.x=x;env.a=params?params.a:0;env.b=params?params.b:0;env.c=params?params.c:0;return ast.f(env)};
  fn.vars=Object.keys(ast.v);return fn;
}
/* "y = x^2", "f(x)=x^2", "x^2" -> expression text */
function rhsOf(s){var m=/^\s*(?:y|f\s*\(\s*x\s*\))\s*=(.*)$/i.exec(s);return m?m[1]:s}

/* ---------- root finding ---------- */
function bisect(f,a,b){var fa=f(a),fb=f(b);if(!(fa*fb<=0))return NaN;
  for(var i=0;i<100;i++){var m=(a+b)/2,fm=f(m);if(fm===0)return m;if(fa*fm<0){b=m;fb=fm}else{a=m;fa=fm}if(Math.abs(b-a)<1e-13*Math.max(1,Math.abs(a)))break}
  return (a+b)/2}
function findRoots(f,lo,hi,n){
  n=n||4000;var out=[],step=(hi-lo)/n,xp=lo,fp=f(xp);
  for(var i=1;i<=n;i++){var x=lo+i*step,fx=f(x);
    if(isFinite(fp)&&isFinite(fx)){
      if(fp===0){out.push(xp)}
      else if(fp*fx<0){var r=bisect(f,xp,x);if(isFinite(r)){var fr=Math.abs(f(r)),sc=Math.max(Math.abs(fp),Math.abs(fx),1e-12);if(fr<1e-6*Math.max(1,sc)&&fr<Math.max(Math.abs(fp),Math.abs(fx)))out.push(r)}}
      else if(i>1){ // touching root (double root): local min of |f| near zero
        var fpp=f(xp-step);if(isFinite(fpp)&&Math.abs(fp)<=Math.abs(fpp)&&Math.abs(fp)<=Math.abs(fx)&&Math.abs(fp)<1e-3*Math.max(1,Math.abs(fpp),Math.abs(fx))&&fp*fx>0){
          var g=goldenMin(function(t){return Math.abs(f(t))},xp-step,x);if(Math.abs(f(g))<1e-9)out.push(g)}}}
    xp=x;fp=fx}
  out.sort(function(a,b){return a-b});var ded=[];out.forEach(function(r){if(!ded.length||Math.abs(r-ded[ded.length-1])>1e-6*Math.max(1,Math.abs(r)))ded.push(r)});
  return ded}
function goldenMin(f,a,b){var g=(Math.sqrt(5)-1)/2,c=b-g*(b-a),d=a+g*(b-a);for(var i=0;i<100;i++){if(f(c)<f(d))b=d;else a=c;c=b-g*(b-a);d=a+g*(b-a)}return (a+b)/2}
function extrema(f,lo,hi,n){
  n=n||3000;var h0=(hi-lo)/n*0.25,d=function(x){var h=Math.max(1e-6,h0);return (f(x+h)-f(x-h))/(2*h)};
  var rs=findRoots(d,lo,hi,n),out=[];
  rs.forEach(function(x){var y=f(x);if(!isFinite(y))return;var h=(hi-lo)/n*2,l=f(x-h),r=f(x+h);
    if(l>y&&r>y)out.push({x:x,y:y,kind:"min"});else if(l<y&&r<y)out.push({x:x,y:y,kind:"max"})});
  return out}

/* ---------- polynomial tools ---------- */
function solveLinear(A,b){ // Gaussian elimination, returns {x,steps,rank,det}
  var n=A.length,M=A.map(function(r,i){return r.concat([b[i]])}),steps=[],det=1;
  steps.push({text:"Augmented matrix",m:clone(M)});
  var row=0,piv=[];
  for(var col=0;col<n&&row<n;col++){
    var best=row;for(var r=row+1;r<n;r++)if(Math.abs(M[r][col])>Math.abs(M[best][col]))best=r;
    if(Math.abs(M[best][col])<1e-12){det=0;continue}
    if(best!==row){var tmp=M[best];M[best]=M[row];M[row]=tmp;det*=-1;steps.push({text:"Swap R"+(row+1)+" ↔ R"+(best+1),m:clone(M)})}
    det*=M[row][col];
    for(var r2=row+1;r2<n;r2++){var f=M[r2][col]/M[row][col];if(f!==0){for(var c=col;c<=n;c++)M[r2][c]-=f*M[row][c];steps.push({text:"R"+(r2+1)+" ← R"+(r2+1)+" − ("+fmt(f)+")·R"+(row+1),m:clone(M)})}}
    piv.push(col);row++}
  var rank=piv.length;
  if(rank<n){ // check consistency
    var incons=false;for(var i=rank;i<n;i++){var allz=true;for(var j=0;j<n;j++)if(Math.abs(M[i][j])>1e-9)allz=false;if(allz&&Math.abs(M[i][n])>1e-9)incons=true}
    return {x:null,steps:steps,rank:rank,det:0,kind:incons?"none":"infinite"}}
  var x=new Array(n);for(var i2=n-1;i2>=0;i2--){var s=M[i2][n];for(var j2=i2+1;j2<n;j2++)s-=M[i2][j2]*x[j2];x[i2]=s/M[i2][i2]}
  return {x:x,steps:steps,rank:rank,det:det,kind:"unique"}}
function clone(M){return M.map(function(r){return r.slice()})}

/* coefficients c[0..d] of polynomial g (c[i] multiplies x^i), or null if g is not a polynomial of degree<=6 */
function polyCoeffs(g){
  var D=6,xs=[],ys=[],i;for(i=0;i<=D;i++){xs.push(i-3);ys.push(g(i-3))}
  for(i=0;i<ys.length;i++)if(!isFinite(ys[i]))return null;
  var A=xs.map(function(x){var r=[];for(var k=0;k<=D;k++)r.push(Math.pow(x,k));return r});
  var s=solveLinear(A,ys);if(!s.x)return null;var c=s.x.map(function(v){var r=Math.round(v*1e6)/1e6;return Math.abs(v-r)<1e-7?r:v});
  var tests=[-7.3,0.37,2.9,5.1,8.4,-1.7];
  for(i=0;i<tests.length;i++){var t=tests[i],p=0;for(var k=D;k>=0;k--)p=p*t+c[k];var gv=g(t);if(!isFinite(gv)||Math.abs(p-gv)>1e-6*Math.max(1,Math.abs(gv)))return null}
  while(c.length>1&&Math.abs(c[c.length-1])<1e-9)c.pop();
  return c}
function durandKerner(c){ // c low->high, returns array of [re,im]
  var n=c.length-1,a=c.map(function(v){return v/c[n]}),z=[],i,j;
  var R=1+Math.max.apply(null,a.slice(0,n).map(Math.abs));
  for(i=0;i<n;i++){var ang=2*Math.PI*i/n+0.4;z.push([R*0.5*Math.cos(ang),R*0.5*Math.sin(ang)])}
  function ev(x){var re=1,im=0;for(var k=n-1;k>=0;k--){var nr=re*x[0]-im*x[1]+a[k],ni=re*x[1]+im*x[0];re=nr;im=ni}return [re,im]}
  for(var it=0;it<2000;it++){var md=0;
    for(i=0;i<n;i++){var p=ev(z[i]),dr=1,di=0;
      for(j=0;j<n;j++)if(j!==i){var xr=z[i][0]-z[j][0],xi=z[i][1]-z[j][1],nr=dr*xr-di*xi,ni=dr*xi+di*xr;dr=nr;di=ni}
      var den=dr*dr+di*di||1e-300,qr=(p[0]*dr+p[1]*di)/den,qi=(p[1]*dr-p[0]*di)/den;z[i][0]-=qr;z[i][1]-=qi;md=Math.max(md,Math.abs(qr)+Math.abs(qi))}
    if(md<1e-14)break}
  return z.map(function(r){var re=r[0],im=r[1];if(Math.abs(im)<1e-6*Math.max(1,Math.abs(re)))im=0;if(Math.abs(re)<1e-9)re=0;return [re,im]}).sort(function(p,q){return p[1]===0&&q[1]!==0?-1:q[1]===0&&p[1]!==0?1:p[0]-q[0]||p[1]-q[1]})}

/* ---------- formatting ---------- */
function fmt(n){if(!isFinite(n))return String(n);if(Math.abs(n)<1e-10)return "0";var s=Number(n.toPrecision(8));return Math.abs(s)>=1e9||Math.abs(s)<1e-5?s.toExponential(4):String(s)}
function frac(x){for(var q=1;q<=64;q++){var p=Math.round(x*q);if(Math.abs(p/q-x)<1e-9*Math.max(1,Math.abs(x)))return q===1?String(p):p+"/"+q}return null}
function fmtRoot(z){var re=z[0],im=z[1];if(im===0){var f=frac(re);return fmt(re)+(f&&f.indexOf("/")>0?" (= "+f+")":"")}
  return fmt(re)+(im<0?" − ":" + ")+fmt(Math.abs(im))+"i"}
function polyString(c){var t=[];for(var k=c.length-1;k>=0;k--){var v=c[k];if(Math.abs(v)<1e-12)continue;var a=Math.abs(v),s=(a===1&&k>0)?"":fmt(a);var x=k===0?"":k===1?"x":"x^"+k;
  t.push((t.length?(v<0?" − ":" + "):(v<0?"−":""))+s+x)}return t.join("")||"0"}

var api={parse:parse,compile:compile,rhsOf:rhsOf,findRoots:findRoots,extrema:extrema,bisect:bisect,solveLinear:solveLinear,polyCoeffs:polyCoeffs,durandKerner:durandKerner,fmt:fmt,frac:frac,fmtRoot:fmtRoot,polyString:polyString};
if(typeof module!=="undefined"&&module.exports)module.exports=api;else root.CurioMath=api;
})(typeof window!=="undefined"?window:this);
