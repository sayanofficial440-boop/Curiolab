// Curio Lab — Smart search bar (client-side match across the topic index)
document.addEventListener("DOMContentLoaded", () => {
  const input = document.querySelector("[data-search-input]");
  const chipWrap = document.querySelector("[data-search-chips]");
  if (!input || !chipWrap) return;

  const INDEX = [
    { label: "Physics — Force", href: "pages/physics/force.html" },
    { label: "Physics — Light", href: "pages/physics/light.html" },
    { label: "Physics — Sound", href: "pages/physics/sound.html" },
    { label: "Physics — Electricity & Circuits", href: "pages/physics/electricity-circuits.html" },
    { label: "Physics — Magnetism & EM Induction", href: "pages/physics/magnetism-induction.html" },
    { label: "Physics — Work, Energy, & Power", href: "pages/physics/work-energy-power.html" },
    { label: "Physics — Heat & Thermodynamics", href: "pages/physics/heat-thermodynamics.html" },
    { label: "Physics — Pressure & Fluid Mechanics", href: "pages/physics/pressure-fluids.html" },
    { label: "Physics — Gravitation & Space", href: "pages/physics/gravitation-space.html" },
    { label: "Physics — Astrophysics", href: "pages/physics/astrophysics.html" },
    { label: "Chemistry — Atomic Structure", href: "pages/chemistry/atom-structure.html" },
    { label: "Chemistry — States of Matter", href: "pages/chemistry/matter.html" },
    { label: "Chemistry — Mixtures & Solutions", href: "pages/chemistry/mixtures-solutions.html" },
    { label: "Chemistry — Chemical Bonding", href: "pages/chemistry/chemical-bonding.html" },
    { label: "Chemistry — The Periodic Table", href: "pages/chemistry/periodic-table.html" },
    { label: "Chemistry — Elements, Compounds & Mixtures", href: "pages/chemistry/elements-compounds-mixtures.html" },
    { label: "Chemistry — Metals & Non-Metals", href: "pages/chemistry/metals-nonmetals.html" },
    { label: "Chemistry — Acids, Bases & Salts", href: "pages/chemistry/acids-bases-salts.html" },
    { label: "Chemistry — Chemical Reactions & Equations", href: "pages/chemistry/chemical-reactions.html" },
    { label: "Chemistry — Carbon & Organic Chemistry", href: "pages/chemistry/carbon-organic-chemistry.html" },
    { label: "Biology — The Cell", href: "pages/biology/cell.html" },
    { label: "Biology — Health & Disease", href: "pages/biology/health.html" },
    { label: "Biology — Tissues", href: "pages/biology/cell.html" },
    { label: "Biology — Diseases", href: "pages/biology/health.html" },
    { label: "English — The Road Not Taken", href: "pages/english/road-not-taken.html" },
    { label: "English — If—", href: "pages/english/if.html" },
    { label: "English — Romeo and Juliet", href: "pages/english/romeo-and-juliet.html" },
    { label: "English — The Happy Prince", href: "pages/english/the-happy-prince.html" },
    { label: "English — The Last Leaf", href: "pages/english/the-last-leaf.html" },
    { label: "English — Daffodils", href: "pages/english/daffodils.html" },
    { label: "English — The Necklace", href: "pages/english/the-necklace.html" },
    { label: "English — A Tale of Two Cities", href: "pages/english/a-tale-of-two-cities.html" },
    { label: "English — Ode to a Nightingale", href: "pages/english/ode-to-a-nightingale.html" },
    { label: "English — Sonnet 18", href: "pages/english/sonnet-18.html" },
    { label: "English — The Gift of the Magi", href: "pages/english/the-gift-of-the-magi.html" },
    { label: "English — The Tell-Tale Heart", href: "pages/english/the-tell-tale-heart.html" },
    { label: "English — The Great Gatsby", href: "pages/english/the-great-gatsby.html" },
    { label: "English — Pride and Prejudice", href: "pages/english/pride-and-prejudice.html" },
    { label: "English — Wuthering Heights", href: "pages/english/wuthering-heights.html" },
    { label: "English — Frankenstein", href: "pages/english/frankenstein.html" },
    { label: "Mathematics — Linear Equations", href: "pages/mathematics/linear-equations.html" },
    { label: "Mathematics — Algebraic Equations", href: "pages/mathematics/algebraic-equations.html" },
    { label: "Mathematics — Rational Numbers", href: "pages/mathematics/rational-numbers.html" },
    { label: "Mathematics — Number Systems", href: "pages/mathematics/number-systems.html" },
    { label: "Mathematics — Trigonometry", href: "pages/mathematics/trigonometry.html" },
    { label: "Mathematics — Mensuration", href: "pages/mathematics/mensuration.html" },
    { label: "Mathematics — Probability", href: "pages/mathematics/probability.html" },
    { label: "Mathematics — Statistics", href: "pages/mathematics/statistics.html" },
    { label: "History — Ancient Civilizations", href: "pages/history/ancient-civilizations.html" },
    { label: "History — Delhi Sultanate & Mughal Empire", href: "pages/history/delhi-sultanate-mughal-empire.html" },
    { label: "History — World War 2", href: "pages/history/world-war-2.html" },
    { label: "History — Delhi Sultanate", href: "pages/history/delhi-sultanate.html" },
    { label: "History — Mughal Empire", href: "pages/history/mughal-empire.html" },
    { label: "History — World War 1", href: "pages/history/world-war-1.html" },
    { label: "History — Colonialism & Trade", href: "pages/history/colonialism-and-trade.html" },
    { label: "History — The Industrial Revolution", href: "pages/history/industrial-revolution.html" },
    { label: "History — The Cold War", href: "pages/history/cold-war.html" },
    { label: "History — Independence Movements", href: "pages/history/independence-movements.html" },
    { label: "History — Political Revolutions", href: "pages/history/political-revolutions.html" },
    { label: "Geography — World Landforms", href: "pages/geography/world-landforms.html" },
    { label: "Geography — Asia", href: "pages/geography/asia.html" },
    { label: "Geography — Europe", href: "pages/geography/europe.html" },
    { label: "Geography — Africa", href: "pages/geography/africa.html" },
    { label: "Geography — North America", href: "pages/geography/north-america.html" },
    { label: "Geography — South America", href: "pages/geography/south-america.html" },
    { label: "Geography — Australia", href: "pages/geography/australia.html" },
    { label: "Geography — Antarctica", href: "pages/geography/antarctica.html" },
    { label: "Geography — Biomes & Vegetation", href: "pages/geography/biomes-vegetation.html" },
    { label: "Geography — Plate Tectonics", href: "pages/geography/plate-tectonics.html" },
    { label: "Geography — Meteorology & Climate", href: "pages/geography/meteorology-climate.html" },
    { label: "Geography — Resource Distribution", href: "pages/geography/resource-distribution.html" },
    { label: "Computer Science — HTML5", href: "pages/computer-science/html5.html" },
    { label: "Computer Science — Robots & Robotics", href: "pages/computer-science/robots-robotics.html" },
    { label: "Computer Science — Cyber Ethics", href: "pages/computer-science/cyber-ethics.html" },
    { label: "Computer Science — Java", href: "pages/computer-science/java.html" },
    { label: "Computer Science — Python", href: "pages/computer-science/python.html" },
    { label: "Computer Science — Algorithms", href: "pages/computer-science/algorithms.html" },
    { label: "Computer Science — Control Flow", href: "pages/computer-science/control-flow.html" },
    { label: "Computer Science — Functions & Scope", href: "pages/computer-science/functions-scope.html" },
    { label: "Computer Science — Database Management", href: "pages/computer-science/database-management.html" },
    { label: "Computer Science — Automation & Scripting", href: "pages/computer-science/automation-scripting.html" },
  ];

  function render(query) {
    chipWrap.innerHTML = "";
    const q = query.trim().toLowerCase();
    const matches = q.length === 0
      ? INDEX.slice(0, 5)
      : INDEX.filter((item) => item.label.toLowerCase().includes(q)).slice(0, 6);

    if (matches.length === 0) {
      const span = document.createElement("span");
      span.className = "chip";
      span.textContent = "No matches yet — try a subject name";
      chipWrap.appendChild(span);
      return;
    }

    matches.forEach((item) => {
      const a = document.createElement("a");
      a.className = "chip";
      a.href = item.href;
      a.textContent = item.label;
      chipWrap.appendChild(a);
    });
  }

  render("");
  input.addEventListener("input", (e) => render(e.target.value));
});
