// Curio Lab — SceneManager
//
// Shared Three.js scene boilerplate, extracted from what globe.js,
// projectile.js, and threed-forces.js each currently reimplement on their
// own: renderer/camera setup, pixel-ratio capping, resize handling, and
// (only in globe.js today) a visibility-aware render loop.
//
// REAL BUG THIS FIXES: projectile.js and threed-forces.js call
// requestAnimationFrame in an unconditional loop — they keep rendering
// even when their tab is hidden (a different subject tab is active) or the
// browser tab itself is backgrounded. globe.js already found and fixed
// this for itself (see its own comment on the isVisible check). Routing
// all three through this class gives the fix to all of them at once.
//
// Plain script, attaches to `window.CurioSceneManager` — matches the rest
// of js/ (theme.js, sound.js, store.js). Not an ES module: this project's
// pages load scripts as `<script src="js/whatever.js">`, not
// `type="module"`, so import/export here would silently do nothing.
//
// USAGE (see js/globe.js for a full worked example):
//   const sm = new CurioSceneManager(container, { panelName: "globe" });
//   sm.scene.add(myMesh);
//   sm.track(myGeometry, myMaterial, myTexture); // disposed on sm.dispose()
//   sm.start((dt) => { myMesh.rotation.y += dt * 0.001; });
//   // later, if the widget is ever torn down (SPA nav, "restart" button):
//   sm.dispose();

(function () {
  "use strict";

  if (window.CurioSceneManager) return; // already loaded on this page

  // --------------------------------------------------------------------
  // Bloom post-processing — lightweight, dependency-free.
  //
  // The project loads Three.js r128 as a single CDN <script> (see
  // pages/physics/force.html, pages/geography/world-landforms.html,
  // js/lesson-engine.js) with no examples/js/postprocessing/* addons
  // (EffectComposer, RenderPass, UnrealBloomPass, CopyShader, etc.) ever
  // loaded anywhere in the repo. Pulling in that whole addon chain from a
  // *second* CDN just for one glow effect would be the first external
  // post-processing dependency in the project and a version-matching risk
  // (addons are versioned per-release, core three.min.js here is pinned to
  // r128 specifically). Instead this is a ~5-pass bloom built from
  // THREE core only (WebGLRenderTarget + ShaderMaterial), so it works
  // wherever THREE already works, with no new <script> tags required.
  //
  // Deliberately restrained: default threshold/strength are tuned for a
  // single glowing accent object on a dark ground (the "one premium 3D
  // object, calm bloom" look), not a full-screen glow wash.
  function BloomPipeline(renderer, width, height, options) {
    var opts = options || {};
    this.renderer = renderer;
    this.threshold = opts.threshold !== undefined ? opts.threshold : 0.75;
    this.strength = opts.strength !== undefined ? opts.strength : 0.55;
    this.radius = opts.radius !== undefined ? opts.radius : 1.0; // blur spread, in texel-multiples
    this.downsample = opts.downsample || 2; // bloom buffers render at 1/downsample resolution
    this.blurPasses = opts.blurPasses || 3; // each pass = 1 horizontal + 1 vertical blur

    var rtOptions = {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      stencilBuffer: false,
      depthBuffer: true,
    };
    var bloomRtOptions = {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      stencilBuffer: false,
      depthBuffer: false,
    };

    this._sceneRT = new THREE.WebGLRenderTarget(1, 1, rtOptions);
    this._brightRT = new THREE.WebGLRenderTarget(1, 1, bloomRtOptions);
    this._pingRT = new THREE.WebGLRenderTarget(1, 1, bloomRtOptions);
    this._pongRT = new THREE.WebGLRenderTarget(1, 1, bloomRtOptions);

    // Shared fullscreen-quad plumbing for every pass below.
    this._quadCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    this._quadScene = new THREE.Scene();
    this._quadGeometry = new THREE.PlaneGeometry(2, 2);
    this._quadMesh = new THREE.Mesh(this._quadGeometry, new THREE.MeshBasicMaterial());
    this._quadScene.add(this._quadMesh);

    this._brightMaterial = new THREE.ShaderMaterial({
      uniforms: { tDiffuse: { value: null }, threshold: { value: this.threshold } },
      vertexShader: BloomPipeline.QUAD_VERTEX,
      fragmentShader:
        "uniform sampler2D tDiffuse;\n" +
        "uniform float threshold;\n" +
        "varying vec2 vUv;\n" +
        "void main() {\n" +
        "  vec4 c = texture2D(tDiffuse, vUv);\n" +
        "  float luma = dot(c.rgb, vec3(0.2126, 0.7152, 0.0722));\n" +
        "  float k = smoothstep(threshold, threshold + 0.2, luma);\n" +
        "  gl_FragColor = vec4(c.rgb * k, 1.0);\n" +
        "}",
    });

    this._blurMaterial = new THREE.ShaderMaterial({
      uniforms: {
        tDiffuse: { value: null },
        direction: { value: new THREE.Vector2(1, 0) },
        texel: { value: new THREE.Vector2(1, 1) },
        radius: { value: this.radius },
      },
      vertexShader: BloomPipeline.QUAD_VERTEX,
      // 9-tap separable gaussian.
      fragmentShader:
        "uniform sampler2D tDiffuse;\n" +
        "uniform vec2 direction;\n" +
        "uniform vec2 texel;\n" +
        "uniform float radius;\n" +
        "varying vec2 vUv;\n" +
        "void main() {\n" +
        "  vec2 step = direction * texel * radius;\n" +
        "  vec4 sum = texture2D(tDiffuse, vUv) * 0.227027;\n" +
        "  sum += texture2D(tDiffuse, vUv + step * 1.0) * 0.1945946;\n" +
        "  sum += texture2D(tDiffuse, vUv - step * 1.0) * 0.1945946;\n" +
        "  sum += texture2D(tDiffuse, vUv + step * 2.0) * 0.1216216;\n" +
        "  sum += texture2D(tDiffuse, vUv - step * 2.0) * 0.1216216;\n" +
        "  sum += texture2D(tDiffuse, vUv + step * 3.0) * 0.054054;\n" +
        "  sum += texture2D(tDiffuse, vUv - step * 3.0) * 0.054054;\n" +
        "  gl_FragColor = vec4(sum.rgb, 1.0);\n" +
        "}",
    });

    this._compositeMaterial = new THREE.ShaderMaterial({
      uniforms: { tScene: { value: null }, tBloom: { value: null }, strength: { value: this.strength } },
      vertexShader: BloomPipeline.QUAD_VERTEX,
      fragmentShader:
        "uniform sampler2D tScene;\n" +
        "uniform sampler2D tBloom;\n" +
        "uniform float strength;\n" +
        "varying vec2 vUv;\n" +
        "void main() {\n" +
        "  vec4 base = texture2D(tScene, vUv);\n" +
        "  vec4 bloom = texture2D(tBloom, vUv);\n" +
        "  gl_FragColor = vec4(base.rgb + bloom.rgb * strength, base.a);\n" +
        "}",
      transparent: true,
    });

    this.setSize(width, height);
  }

  BloomPipeline.QUAD_VERTEX =
    "varying vec2 vUv;\n" +
    "void main() {\n" +
    "  vUv = uv;\n" +
    "  gl_Position = vec4(position.xy, 0.0, 1.0);\n" +
    "}";

  BloomPipeline.prototype.setSize = function (width, height) {
    var w = Math.max(1, Math.floor(width));
    var h = Math.max(1, Math.floor(height));
    var bw = Math.max(1, Math.floor(w / this.downsample));
    var bh = Math.max(1, Math.floor(h / this.downsample));
    this._sceneRT.setSize(w, h);
    this._brightRT.setSize(bw, bh);
    this._pingRT.setSize(bw, bh);
    this._pongRT.setSize(bw, bh);
    this._blurMaterial.uniforms.texel.value.set(1 / bw, 1 / bh);
  };

  BloomPipeline.prototype._pass = function (material, outputTarget) {
    this._quadMesh.material = material;
    this.renderer.setRenderTarget(outputTarget);
    this.renderer.render(this._quadScene, this._quadCamera);
  };

  /** Renders `scene`/`camera` through the bloom pipeline to the screen. */
  BloomPipeline.prototype.render = function (scene, camera) {
    var renderer = this.renderer;
    var prevTarget = renderer.getRenderTarget();

    // Pass 1: normal scene render, off-screen.
    renderer.setRenderTarget(this._sceneRT);
    renderer.clear();
    renderer.render(scene, camera);

    // Pass 2: threshold-extract bright pixels, downsampled.
    this._brightMaterial.uniforms.tDiffuse.value = this._sceneRT.texture;
    this._brightMaterial.uniforms.threshold.value = this.threshold;
    this._pass(this._brightMaterial, this._brightRT);

    // Pass 3..N: ping-pong separable gaussian blur, alternating axes.
    var readRT = this._brightRT;
    var writeRT = this._pingRT;
    for (var i = 0; i < this.blurPasses; i++) {
      this._blurMaterial.uniforms.tDiffuse.value = readRT.texture;
      this._blurMaterial.uniforms.direction.value.set(1, 0);
      this._pass(this._blurMaterial, writeRT);

      this._blurMaterial.uniforms.tDiffuse.value = writeRT.texture;
      this._blurMaterial.uniforms.direction.value.set(0, 1);
      var finalTarget = i === this.blurPasses - 1 ? this._pongRT : this._brightRT;
      this._pass(this._blurMaterial, finalTarget);
      readRT = finalTarget;
      writeRT = readRT === this._pongRT ? this._brightRT : this._pingRT;
    }

    // Final: composite scene + blurred bloom back to the actual screen
    // (or whatever render target the caller had bound, e.g. XR).
    this._compositeMaterial.uniforms.tScene.value = this._sceneRT.texture;
    this._compositeMaterial.uniforms.tBloom.value = readRT.texture;
    this._compositeMaterial.uniforms.strength.value = this.strength;
    this._pass(this._compositeMaterial, prevTarget);
  };

  BloomPipeline.prototype.dispose = function () {
    this._sceneRT.dispose();
    this._brightRT.dispose();
    this._pingRT.dispose();
    this._pongRT.dispose();
    this._quadGeometry.dispose();
    this._brightMaterial.dispose();
    this._blurMaterial.dispose();
    this._compositeMaterial.dispose();
  };

  /**
   * @param {HTMLElement} container - element the canvas is appended into.
   *   Its clientWidth/clientHeight drive the initial camera aspect and
   *   every resize.
   * @param {Object} [options]
   * @param {number} [options.fov=45]
   * @param {number} [options.near=0.1]
   * @param {number} [options.far=100]
   * @param {number} [options.maxPixelRatio=2] - existing files in this repo
   *   cap at 2; pass 1.5 for a widget where mobile GPU cost matters more
   *   than sharpness.
   * @param {string} [options.panelName] - if the canvas lives inside a
   *   `[data-panel="<name>"]` tab panel, the manager checks that panel's
   *   `.active` class (same convention globe.js already uses) to decide
   *   whether to render. Omit for a widget that's always on screen when
   *   its script runs.
   * @param {boolean} [options.alpha=true]
   * @param {boolean} [options.antialias=true]
   * @param {boolean|Object} [options.bloom=false] - opt-in glow pass. Pass
   *   `true` for defaults tuned for one glowing accent object on a dark
   *   ground, or `{ threshold, strength, radius, downsample, blurPasses }`
   *   to tune it. Costs 5 extra offscreen render passes per frame at
   *   `downsample` resolution (default quarter-res), which is why it's
   *   opt-in rather than always-on.
   */
  function CurioSceneManager(container, options) {
    var opts = options || {};
    this.container = container;
    this.panelName = opts.panelName || null;

    var width = container.clientWidth || 1;
    var height = container.clientHeight || 1;

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(
      opts.fov || 45,
      width / height,
      opts.near !== undefined ? opts.near : 0.1,
      opts.far !== undefined ? opts.far : 100
    );
    this.renderer = new THREE.WebGLRenderer({
      antialias: opts.antialias !== false,
      alpha: opts.alpha !== false,
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, opts.maxPixelRatio || 2));
    this.renderer.setSize(width, height);
    container.style.position = container.style.position || "relative";
    container.appendChild(this.renderer.domElement);

    this._bloom = null;
    if (opts.bloom) {
      var bloomOpts = opts.bloom === true ? {} : opts.bloom;
      this._bloom = new BloomPipeline(this.renderer, width, height, bloomOpts);
    }

    // Resources registered via .track() get explicitly disposed. Anything
    // added straight to `this.scene` is also swept in dispose() via
    // scene.traverse, so tracking is only required for things NOT attached
    // to the scene graph (e.g. a texture used only as an environment map).
    this._tracked = [];

    this._isVisible = this._computeVisibility();
    this._rafId = null;
    this._renderFn = null;
    this._lastTime = null;
    this._disposed = false;

    // Bound once so removeEventListener in dispose() actually matches.
    this._onResize = this._resizeToContainer.bind(this);
    this._onTabShown = this._handleTabShown.bind(this);
    this._onVisibilityChange = this._handleVisibilityChange.bind(this);

    window.addEventListener("resize", this._onResize);
    window.addEventListener("curiolab:tab-shown", this._onTabShown);
    document.addEventListener("visibilitychange", this._onVisibilityChange);
  }

  CurioSceneManager.prototype._computeVisibility = function () {
    if (document.hidden) return false;
    if (!this.panelName) return true;
    var panel = this.container.closest('[data-panel="' + this.panelName + '"]');
    return !!(panel && panel.classList.contains("active"));
  };

  CurioSceneManager.prototype._resizeToContainer = function () {
    if (!this._isVisible) return;
    var w = this.container.clientWidth;
    var h = this.container.clientHeight;
    if (!w || !h) return;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    if (this._bloom) this._bloom.setSize(w, h);
  };

  CurioSceneManager.prototype._handleTabShown = function (evt) {
    var wasVisible = this._isVisible;
    this._isVisible = evt.detail && evt.detail.name === this.panelName && !document.hidden;
    if (this._isVisible && !wasVisible) this._resizeToContainer();
  };

  CurioSceneManager.prototype._handleVisibilityChange = function () {
    var wasVisible = this._isVisible;
    this._isVisible = this._computeVisibility();
    if (this._isVisible && !wasVisible) this._resizeToContainer();
  };

  /**
   * Register geometries/materials/textures/render-targets for disposal
   * that aren't reachable by walking `this.scene` (e.g. a texture kept
   * only in a JS closure). Accepts any number of arguments.
   */
  CurioSceneManager.prototype.track = function () {
    for (var i = 0; i < arguments.length; i++) {
      if (arguments[i]) this._tracked.push(arguments[i]);
    }
    return arguments[0];
  };

  /**
   * Start the render loop. `renderFn(deltaMs, isVisible)` runs every frame
   * regardless of visibility (so e.g. a physics step can stay in sync if
   * you want that), but the manager only calls `this.renderer.render(...)`
   * — the actual GPU work — while visible. Most callers should just check
   * `isVisible` inside renderFn and skip their own updates too, the way
   * globe.js does, to save CPU as well as GPU.
   */
  CurioSceneManager.prototype.start = function (renderFn) {
    this._renderFn = renderFn;
    var self = this;
    function loop(time) {
      self._rafId = requestAnimationFrame(loop);
      var dt = self._lastTime === null ? 0 : time - self._lastTime;
      self._lastTime = time;
      if (!self._isVisible) return;
      if (self._renderFn) self._renderFn(dt, true);
      if (self._bloom) {
        self._bloom.render(self.scene, self.camera);
      } else {
        self.renderer.render(self.scene, self.camera);
      }
    }
    this._rafId = requestAnimationFrame(loop);
  };

  CurioSceneManager.prototype.stop = function () {
    if (this._rafId !== null) {
      cancelAnimationFrame(this._rafId);
      this._rafId = null;
    }
  };

  /**
   * Full teardown: stops the loop, disposes every geometry/material/
   * texture reachable in the scene graph plus anything passed to
   * .track(), disposes the renderer/GL context, and removes the canvas
   * and event listeners. Safe to call once; a second call is a no-op.
   *
   * Not needed for a widget that lives for the whole page load (the
   * browser reclaims GPU memory on navigation regardless) — this matters
   * once a scene can be torn down and recreated without a full page
   * reload, e.g. an SPA-style subject switch or a "restart simulation"
   * button.
   */
  CurioSceneManager.prototype.dispose = function () {
    if (this._disposed) return;
    this._disposed = true;
    this.stop();
    if (this._bloom) {
      this._bloom.dispose();
      this._bloom = null;
    }

    window.removeEventListener("resize", this._onResize);
    window.removeEventListener("curiolab:tab-shown", this._onTabShown);
    document.removeEventListener("visibilitychange", this._onVisibilityChange);

    this.scene.traverse(function (obj) {
      if (obj.geometry) obj.geometry.dispose();
      if (obj.material) {
        var mats = Array.isArray(obj.material) ? obj.material : [obj.material];
        mats.forEach(function (mat) {
          for (var key in mat) {
            var val = mat[key];
            if (val && val.isTexture) val.dispose();
          }
          mat.dispose();
        });
      }
    });

    this._tracked.forEach(function (resource) {
      if (resource && typeof resource.dispose === "function") resource.dispose();
    });
    this._tracked.length = 0;

    this.renderer.dispose();
    if (this.renderer.domElement && this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  };

  /**
   * Builds a light-reactive Fresnel "atmosphere shell" material — the
   * standard trick for a glowing planet rim: a slightly larger sphere
   * drawn back-face-only with additive blending, brightest at the silhouette
   * edge (grazing viewing angle) and near-invisible face-on. Pair with a
   * mesh scaled ~1.08–1.15x the planet's own radius.
   *
   * USAGE (see js/globe.js for the planet mesh this wraps around):
   *   var atmo = CurioSceneManager.createAtmosphereMaterial({ color: 0x2E8E80 });
   *   var shell = new THREE.Mesh(new THREE.SphereGeometry(radius * 1.12, 48, 48), atmo);
   *   sceneManager.scene.add(shell);
   *   // in the render loop, if using bloom, this rim glow is exactly what
   *   // the bloom threshold above should pick out.
   *
   * @param {Object} [options]
   * @param {number|string} [options.color=0x6fb7ff] - glow color, any THREE.Color input.
   * @param {number} [options.intensity=1.0] - overall glow brightness.
   * @param {number} [options.power=2.2] - Fresnel falloff exponent; higher
   *   = thinner, sharper rim, lower = softer/wider glow.
   * @returns {THREE.ShaderMaterial}
   */
  CurioSceneManager.createAtmosphereMaterial = function (options) {
    var opts = options || {};
    return new THREE.ShaderMaterial({
      uniforms: {
        glowColor: { value: new THREE.Color(opts.color !== undefined ? opts.color : 0x6fb7ff) },
        intensity: { value: opts.intensity !== undefined ? opts.intensity : 1.0 },
        power: { value: opts.power !== undefined ? opts.power : 2.2 },
      },
      vertexShader:
        "varying vec3 vNormal;\n" +
        "varying vec3 vViewPosition;\n" +
        "void main() {\n" +
        "  vNormal = normalize(normalMatrix * normal);\n" +
        "  vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);\n" +
        "  vViewPosition = -mvPosition.xyz;\n" +
        "  gl_Position = projectionMatrix * mvPosition;\n" +
        "}",
      fragmentShader:
        "uniform vec3 glowColor;\n" +
        "uniform float intensity;\n" +
        "uniform float power;\n" +
        "varying vec3 vNormal;\n" +
        "varying vec3 vViewPosition;\n" +
        "void main() {\n" +
        "  vec3 viewDir = normalize(vViewPosition);\n" +
        "  float fresnel = pow(1.0 - max(dot(viewDir, normalize(vNormal)), 0.0), power);\n" +
        "  gl_FragColor = vec4(glowColor, fresnel * intensity);\n" +
        "}",
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
    });
  };

  window.CurioSceneManager = CurioSceneManager;
})();
