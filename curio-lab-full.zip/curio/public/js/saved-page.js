// Curio Lab — Saved page: every bookmark and note in one searchable place.
(function () {
  "use strict";
  const N = window.CurioNotes, root = document.querySelector("[data-saved-app]");
  if (!N || !root) return;
  const $ = (s) => root.querySelector(s);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  let view = "all";

  function render() {
    const all = N.list(), c = N.counts();
    $("[data-c-bm]").textContent = c.bookmarks; $("[data-c-notes]").textContent = c.notes;
    const subjSel = $("[data-sv-subject]"), keep = subjSel.value;
    const subs = [...new Set(all.map((x) => x.subject).filter(Boolean))].sort();
    subjSel.innerHTML = `<option value="">All subjects</option>` + subs.map((s) => `<option${s === keep ? " selected" : ""}>${esc(s)}</option>`).join("");
    const q = $("[data-sv-search]").value.trim().toLowerCase(), sub = subjSel.value;
    const shown = all.filter((x) =>
      (view === "all" || (view === "bookmarks" && x.bookmarked) || (view === "notes" && x.note && x.note.trim())) &&
      (!sub || x.subject === sub) && (!q || (x.title + " " + x.note).toLowerCase().includes(q)));
    $("[data-sv-export]").hidden = !c.notes;
    const grid = $("[data-sv-grid]");
    if (!all.length) { grid.innerHTML = `<div class="st-empty" style="grid-column:1/-1"><span class="big">🔖</span><b>Nothing saved yet.</b><p>Open any lesson and use <b>Save</b> to bookmark it or <b>Notes</b> to write your own notes.</p><a href="physics.html">Browse lessons →</a></div>`; return; }
    if (!shown.length) { grid.innerHTML = `<div class="st-empty" style="grid-column:1/-1">Nothing matches these filters.</div>`; return; }
    grid.innerHTML = shown.map((x) => `<article class="sv-card">
      <div><span class="nb-chip">${esc(x.subject || "Lesson")}</span>${x.bookmarked ? '<span class="nb-chip">🔖 Bookmarked</span>' : ""}</div>
      <h3><a href="../${esc(x.href)}">${esc(x.title)}</a></h3>
      ${x.note && x.note.trim() ? `<div class="sv-note">${esc(x.note)}</div>` : ""}
      <div class="sv-actions"><a class="st-btn primary" href="../${esc(x.href)}" style="text-decoration:none">Open lesson</a>
      <button class="st-btn ghost" type="button" data-rm="${esc(x.href)}">Remove</button></div></article>`).join("");
    grid.querySelectorAll("[data-rm]").forEach((b) => b.addEventListener("click", () => {
      if (confirm("Remove the bookmark and note for this lesson?")) N.remove(b.getAttribute("data-rm"));
    }));
  }

  function exportNotes() {
    const notes = N.list().filter((x) => x.note && x.note.trim());
    const text = "# My Curio Lab notes\n\n" + notes.map((x) => `## ${x.title} (${x.subject || "Lesson"})\n\n${x.note.trim()}\n`).join("\n");
    const url = URL.createObjectURL(new Blob([text], { type: "text/markdown" }));
    const a = Object.assign(document.createElement("a"), { href: url, download: "curio-lab-notes.md" });
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  root.querySelectorAll("[data-tab]").forEach((t) => t.addEventListener("click", () => {
    view = t.dataset.tab;
    root.querySelectorAll("[data-tab]").forEach((x) => x.setAttribute("aria-selected", String(x === t)));
    render();
  }));
  ["[data-sv-search]", "[data-sv-subject]"].forEach((s) => $(s).addEventListener("input", render));
  $("[data-sv-export]").addEventListener("click", exportNotes);
  window.addEventListener("curio-notes-updated", render);
  render();
})();
