// Curio Lab — Immersion effect (disabled)
//
// This file previously injected a fixed ambient color veil that tinted the
// page per-subject (chemistry -> ember, physics -> celestial, etc.) plus a
// floating toggle button. Both have been removed at the user's request.
// The file is kept as a harmless no-op stub — rather than deleting it and
// its <script> tag from every page — so nothing 404s and no page needs to
// be touched individually. window.CurioImmersion is kept as inert no-ops
// in case any other script references it defensively.
(function () {
  "use strict";
  window.CurioImmersion = {
    setSubject: function () {},
    clear: function () {},
    profiles: {},
    isEnabled: function () { return false; },
    setEnabled: function () {},
  };
})();
