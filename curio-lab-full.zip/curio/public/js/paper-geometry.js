// Curio Lab — Homepage "Paper Geometry" flagship interactions.
// Consolidates what used to be four separate homepage layers into one
// file, scoped to index.html only. Reads existing DOM/localStorage,
// adds no new markup requirements beyond the [data-icon] slots below.
(function () {
  "use strict";
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // ---------- Line-icon set (thin stroke, currentColor — one place to edit) ----------
  const ICONS = {
    physics: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><ellipse cx="12" cy="12" rx="9" ry="4"/><ellipse cx="12" cy="12" rx="9" ry="4" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="9" ry="4" transform="rotate(120 12 12)"/><circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none"/></svg>',
    mathematics: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19h15"/><path d="M4 19 15 5"/><path d="M8.7 15.3A6.5 6.5 0 0 1 11.7 9.6"/></svg>',
    chemistry: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3h4"/><path d="M11 3v6.2L5.8 18a2 2 0 0 0 1.7 3h9a2 2 0 0 0 1.7-3L13 9.2V3"/><path d="M8.2 15h7.6"/></svg>',
    biology: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="8.3"/><circle cx="12" cy="12" r="3"/><circle cx="16.6" cy="8.2" r="1" fill="currentColor" stroke="none"/><circle cx="7.4" cy="15.4" r="1" fill="currentColor" stroke="none"/></svg>',
    english: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 6.3c-1.6-1.3-3.7-2-6.6-2v13.4c2.9 0 5 .7 6.6 2 1.6-1.3 3.7-2 6.6-2V4.3c-2.9 0-5 .7-6.6 2Z"/><path d="M12 6.3v13.4"/></svg>',
    history: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M4 5h16"/><path d="M4 19h16"/><path d="M6.2 8v9"/><path d="M10.4 8v9"/><path d="M13.6 8v9"/><path d="M17.8 8v9"/></svg>',
    geography: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="8.3"/><path d="M3.7 12h16.6"/><path d="M12 3.7c2.7 2.3 4.3 5.2 4.3 8.3s-1.6 6-4.3 8.3c-2.7-2.3-4.3-5.2-4.3-8.3S9.3 6 12 3.7Z"/></svg>',
    "computer-science": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6.3 4.3 12 9 17.7"/><path d="M15 6.3l4.7 5.7-4.7 5.7"/></svg>',
    video: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="14" rx="2"/><path d="M10.4 9.1v5.8l5.1-2.9-5.1-2.9Z" fill="currentColor" stroke="none"/></svg>',
    quiz: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="8" height="8" rx="1.4"/><path d="M5.2 8l1.6 1.6L9.7 6.3"/><rect x="13" y="12" width="8" height="8" rx="1.4"/><path d="M15.2 14.2l3.6 3.6M18.8 14.2l-3.6 3.6"/></svg>',
    "ai-coach": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5.5h16v10H10l-4 3.5v-3.5H4Z"/><path d="M13 8.3l1 2 2 1-2 1-1 2-1-2-2-1 2-1 1-2Z" fill="currentColor" stroke="none"/></svg>',
    "3d-models": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><path d="M12 3.5 20 8v8l-8 4.5L4 16V8l8-4.5Z"/><path d="M4 8l8 4.5 8-4.5"/><path d="M12 12.5V21"/></svg>',
    certificates: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="9" r="5.3"/><path d="M9 13.9 7.3 20l4.7-2.6 4.7 2.6-1.7-6.1"/></svg>',
    timer: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2"/><path d="M9.5 2.5h5"/></svg>',
    tts: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10v4h3.5L13 18V6L7.5 10H4Z"/><path d="M17 9.5a4 4 0 0 1 0 5.5"/><path d="M19.5 7a7.5 7.5 0 0 1 0 10.5"/></svg>',
    debate: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 5.5h9v6H8l-3 2.5v-2.5H3Z"/><path d="M21 10.5h-8v6h3l3 2.5v-2.5h2Z"/></svg>',
    bookmark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3.5h12v17l-6-3.5-6 3.5v-17Z"/></svg>',
    spark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M12 3v4M12 17v4M3 12h4M17 12h4"/><circle cx="12" cy="12" r="3"/></svg>',
  };
  const SUBJECT_LABELS = {
    physics: "CUR—PHY", chemistry: "CUR—CHM", biology: "CUR—BIO", english: "CUR—ENG",
    mathematics: "CUR—MTH", history: "CUR—HIS", geography: "CUR—GEO", "computer-science": "CUR—CS",
  };

  function paintIcons() {
    document.querySelectorAll("[data-icon]").forEach((el) => {
      const svg = ICONS[el.dataset.icon];
      if (svg) el.innerHTML = svg;
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    paintIcons();
    initGeometricField();
    initTilt();
    initSpotlight();
    initCounters();
    initMethodStrip();
    initMethodDot();
    initPlaceholderCycle();
    initFooterThemePreview();
    initScrollProgress();
    initScrollCue();
    initCuriousSpark();
    initCatalogStage();
    initMagneticButtons();
    initResumeStrip();
  });

  // ---------- Hero: fine grid + drifting coordinate nodes ----------
  // ---------- Hero field: drifting aurora light + soft dust + lightning ----
  // Replaces the old node-and-line "web" with a slow-moving field of glowing
  // colour washes, fine twinkling dust, and the occasional soft lightning
  // streak — all built from the same subject accent palette so it still
  // re-colours automatically with every theme.
  function initGeometricField() {
    const canvas = document.querySelector("[data-hero-field]");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let w, h, dpr;
    let orbs = [];
    let dust = [];
    let bolts = [];
    let nextBoltAt = 0;
    let target = { x: 0.5, y: 0.5 };
    let current = { x: 0.5, y: 0.5 };
    let raf = null;
    let dark = false;

    const DARK_THEMES = new Set(["blueprint", "midnight", "aurora", "slate", "obsidian", "nebula", "volt", "indigo"]);
    const ACCENT_VARS = ["--pg-physics", "--pg-math", "--pg-chemistry", "--pg-biology", "--pg-english", "--pg-geography", "--pg-history"];

    function readColors() {
      const cs = getComputedStyle(document.body);
      return ACCENT_VARS.map((v) => cs.getPropertyValue(v).trim() || "#3B82F6");
    }
    function readMood() {
      const t = document.documentElement.getAttribute("data-theme");
      dark = DARK_THEMES.has(t);
    }
    function hexToRgb(hex) {
      const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex.trim());
      return m ? `${parseInt(m[1], 16)},${parseInt(m[2], 16)},${parseInt(m[3], 16)}` : "59,130,246";
    }

    function resize() {
      const rect = canvas.parentElement.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = canvas.width = Math.floor(rect.width * dpr);
      h = canvas.height = Math.floor(rect.height * dpr);
      canvas.style.width = rect.width + "px";
      canvas.style.height = rect.height + "px";
      seed();
    }

    function seed() {
      readMood();
      const colors = readColors().map(hexToRgb);
      const area = (w * h) / (dpr * dpr);

      // A handful of large, slow-drifting colour washes — the "aurora".
      const orbCount = Math.max(3, Math.min(6, Math.floor(area / 90000)));
      orbs = Array.from({ length: orbCount }, (_, i) => ({
        bx: Math.random() * w,
        by: Math.random() * h * 0.85,
        r: (Math.random() * 0.18 + 0.22) * Math.max(w, h),
        c: colors[i % colors.length],
        driftX: 40 + Math.random() * 60,
        driftY: 30 + Math.random() * 40,
        speedX: 0.00012 + Math.random() * 0.00014,
        speedY: 0.00016 + Math.random() * 0.00016,
        phase: Math.random() * Math.PI * 2,
      }));

      // Fine twinkling dust on top, for depth and sparkle.
      const dustCount = Math.max(24, Math.min(60, Math.floor(area / 16000)));
      dust = Array.from({ length: dustCount }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: (Math.random() * 1.1 + 0.5) * dpr,
        c: colors[Math.floor(Math.random() * colors.length)],
        speed: 0.15 + Math.random() * 0.3,
        phase: Math.random() * Math.PI * 2,
        drift: (Math.random() - 0.5) * 0.15,
      }));

      bolts = [];
      nextBoltAt = performance.now() + 2200 + Math.random() * 3200;
    }

    // A single soft, jittered lightning streak that fades in and out.
    function spawnBolt() {
      const colors = readColors().map(hexToRgb);
      const c = colors[Math.floor(Math.random() * colors.length)];
      const startX = w * (0.15 + Math.random() * 0.7);
      const startY = -h * 0.05;
      const endY = h * (0.55 + Math.random() * 0.4);
      const segments = 6;
      const points = [{ x: startX, y: startY }];
      let x = startX, y = startY;
      const stepY = (endY - startY) / segments;
      for (let i = 1; i <= segments; i++) {
        x += (Math.random() - 0.5) * w * 0.09;
        y += stepY;
        points.push({ x, y });
      }
      bolts.push({ points, c, born: performance.now(), life: 650 + Math.random() * 250 });
    }

    function draw(now) {
      ctx.clearRect(0, 0, w, h);
      // gentle parallax drift toward cursor, applied to the whole field
      current.x += (target.x - current.x) * 0.03;
      current.y += (target.y - current.y) * 0.03;
      const ox = (current.x - 0.5) * 36 * dpr;
      const oy = (current.y - 0.5) * 20 * dpr;

      // --- aurora colour washes ---
      const prevComposite = ctx.globalCompositeOperation;
      ctx.globalCompositeOperation = dark ? "lighter" : "multiply";
      for (const o of orbs) {
        const cx = o.bx + Math.sin(now * o.speedX + o.phase) * o.driftX * dpr + ox;
        const cy = o.by + Math.cos(now * o.speedY + o.phase) * o.driftY * dpr + oy;
        const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, o.r);
        const a1 = dark ? 0.30 : 0.14;
        grad.addColorStop(0, `rgba(${o.c},${a1})`);
        grad.addColorStop(0.55, `rgba(${o.c},${a1 * 0.4})`);
        grad.addColorStop(1, `rgba(${o.c},0)`);
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(cx, cy, o.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalCompositeOperation = prevComposite;

      // --- twinkling dust ---
      for (const p of dust) {
        p.y -= p.speed * dpr * 0.35;
        p.x += p.drift * dpr;
        if (p.y < -10) { p.y = h + 10; p.x = Math.random() * w; }
        const twinkle = 0.35 + Math.sin(now * 0.0016 + p.phase) * 0.28;
        ctx.globalAlpha = Math.max(0, twinkle) * (dark ? 1 : 0.55);
        ctx.fillStyle = `rgb(${p.c})`;
        ctx.beginPath();
        ctx.arc(p.x + ox * 0.4, p.y + oy * 0.4, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      // --- occasional soft lightning streak ---
      if (now >= nextBoltAt && bolts.length < 2) {
        spawnBolt();
        nextBoltAt = now + 4500 + Math.random() * 5000;
      }
      bolts = bolts.filter((b) => now - b.born < b.life);
      for (const b of bolts) {
        const t = (now - b.born) / b.life;
        const fade = t < 0.15 ? t / 0.15 : 1 - (t - 0.15) / 0.85;
        ctx.save();
        ctx.globalCompositeOperation = dark ? "lighter" : "source-over";
        ctx.globalAlpha = Math.max(0, fade) * (dark ? 0.5 : 0.22);
        ctx.strokeStyle = `rgb(${b.c})`;
        ctx.lineWidth = 1.6 * dpr;
        ctx.shadowColor = `rgb(${b.c})`;
        ctx.shadowBlur = 14 * dpr;
        ctx.beginPath();
        b.points.forEach((pt, i) => (i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y)));
        ctx.stroke();
        ctx.restore();
      }

      raf = requestAnimationFrame(draw);
    }

    function onMove(e) {
      const rect = canvas.parentElement.getBoundingClientRect();
      target.x = (e.clientX - rect.left) / rect.width;
      target.y = (e.clientY - rect.top) / rect.height;
    }

    resize();
    window.addEventListener("resize", resize);
    canvas.parentElement.addEventListener("mousemove", onMove);

    const themeObserver = new MutationObserver(() => seed());
    themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });

    if (reduce) { draw(performance.now()); cancelAnimationFrame(raf); }
    else raf = requestAnimationFrame(draw);
  }

  // ---------- Specimen card 3D tilt ----------
  function initTilt() {
    if (reduce) return;
    document.querySelectorAll(".spec-card[data-tilt]").forEach((card) => {
      let frame = null;
      card.addEventListener("mousemove", (e) => {
        const rect = card.getBoundingClientRect();
        const px = (e.clientX - rect.left) / rect.width - 0.5;
        const py = (e.clientY - rect.top) / rect.height - 0.5;
        card.classList.add("is-tilting");
        if (frame) cancelAnimationFrame(frame);
        frame = requestAnimationFrame(() => {
          card.style.transform = `perspective(1000px) rotateX(${(-py * 6).toFixed(2)}deg) rotateY(${(px * 8).toFixed(2)}deg) translateY(-3px)`;
        });
      });
      card.addEventListener("mouseleave", () => {
        card.classList.remove("is-tilting");
        card.style.transform = "";
      });
    });
  }

  // ---------- Cursor-follow spotlight on cards ----------
  function initSpotlight() {
    const cards = document.querySelectorAll(".spec-card");
    if (!cards.length) return;
    cards.forEach((card) => {
      const glow = document.createElement("span");
      glow.className = "spec-spotlight";
      glow.setAttribute("aria-hidden", "true");
      card.prepend(glow);
      card.addEventListener("mousemove", (e) => {
        const rect = card.getBoundingClientRect();
        card.style.setProperty("--mx", ((e.clientX - rect.left) / rect.width) * 100 + "%");
        card.style.setProperty("--my", ((e.clientY - rect.top) / rect.height) * 100 + "%");
      });
    });
  }

  // ---------- Count-up stats ----------
  function initCounters() {
    const nums = document.querySelectorAll("[data-count-to]");
    if (!nums.length) return;
    const animate = (el) => {
      const target = parseInt(el.dataset.countTo, 10) || 0;
      const suffix = el.dataset.suffix || "";
      if (reduce) { el.textContent = target + suffix; return; }
      const duration = 1000;
      const start = performance.now();
      const tick = (now) => {
        const t = Math.min(1, (now - start) / duration);
        const eased = 1 - Math.pow(1 - t, 3);
        el.textContent = Math.round(eased * target) + suffix;
        if (t < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    };
    if (!("IntersectionObserver" in window)) { nums.forEach(animate); return; }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) { animate(entry.target); io.unobserve(entry.target); }
      });
    }, { threshold: 0.6 });
    nums.forEach((el) => io.observe(el));
  }

  // ---------- Method strip: light up steps + fill the line ----------
  function initMethodStrip() {
    const track = document.querySelector("[data-method-track]");
    if (!track) return;
    const steps = track.querySelectorAll(".method-step");
    const fill = track.querySelector(".method-line-fill");
    if (!steps.length) return;
    if (!("IntersectionObserver" in window)) {
      steps.forEach((s) => s.classList.add("is-lit"));
      if (fill) fill.style.width = "88%";
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        steps.forEach((step, i) => setTimeout(() => step.classList.add("is-lit"), i * 200));
        if (fill) requestAnimationFrame(() => { fill.style.width = "88%"; });
        io.unobserve(entry.target);
      });
    }, { threshold: 0.4 });
    io.observe(track);
  }

  function initMethodDot() {
    const track = document.querySelector("[data-method-track]");
    if (!track) return;
    if (!("IntersectionObserver" in window)) { track.classList.add("is-traveling"); return; }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        track.classList.add("is-traveling");
        io.unobserve(entry.target);
      });
    }, { threshold: 0.4 });
    io.observe(track);
  }

  // ---------- Cycling search placeholder ----------
  function initPlaceholderCycle() {
    const input = document.querySelector("[data-search-input]");
    if (!input || reduce) return;
    const bar = input.closest(".search-bar");
    const examples = [
      "cell structure", "linear equations", "the Mughal Empire", "for loops",
      "states of matter", "world landforms", "Romeo and Juliet", "force and motion",
    ];
    let i = 0;
    setInterval(() => {
      if (document.activeElement === input || input.value) return;
      i = (i + 1) % examples.length;
      bar && bar.classList.add("is-cycling");
      input.placeholder = `Try "${examples[i]}"…`;
      setTimeout(() => bar && bar.classList.remove("is-cycling"), 200);
    }, 3200);
  }

  // ---------- Footer theme swatch preview ----------
  function initFooterThemePreview() {
    const row = document.querySelector("[data-footer-theme-row]");
    if (!row) return;
    const original = document.documentElement.getAttribute("data-theme");
    row.querySelectorAll("button[data-preview-theme]").forEach((btn) => {
      btn.addEventListener("mouseenter", () => document.documentElement.setAttribute("data-theme", btn.dataset.previewTheme));
      btn.addEventListener("mouseleave", () => {
        if (original) document.documentElement.setAttribute("data-theme", original);
        else document.documentElement.removeAttribute("data-theme");
      });
      btn.addEventListener("click", () => {
        localStorage.setItem("curiolab-theme", btn.dataset.previewTheme);
        window.location.reload();
      });
    });
  }

  // ---------- Scroll progress ----------
  function initScrollProgress() {
    const bar = document.createElement("div");
    bar.className = "scroll-progress";
    document.body.appendChild(bar);
    let ticking = false;
    const update = () => {
      const doc = document.documentElement;
      const scrollable = doc.scrollHeight - doc.clientHeight;
      bar.style.width = (scrollable > 0 ? (doc.scrollTop / scrollable) * 100 : 0) + "%";
      ticking = false;
    };
    window.addEventListener("scroll", () => {
      if (!ticking) { requestAnimationFrame(update); ticking = true; }
    }, { passive: true });
    update();
  }

  // ---------- Scroll cue ----------
  function initScrollCue() {
    const cue = document.querySelector("[data-scroll-cue]");
    const catalog = document.querySelector(".catalog");
    if (!cue || !catalog) return;
    cue.addEventListener("click", () => catalog.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" }));
    if ("IntersectionObserver" in window) {
      const io = new IntersectionObserver((entries) => {
        entries.forEach((entry) => { cue.style.opacity = entry.isIntersecting ? "" : "0"; });
      }, { threshold: 0.4 });
      io.observe(cue.closest(".hero"));
    }
  }

  // ---------- "Curious" word: small spark burst easter egg ----------
  function initCuriousSpark() {
    const trigger = document.querySelector("[data-curious-trigger]");
    if (!trigger) return;
    const MESSAGES = [
      "Curiosity noted. Carry on investigating.",
      "That's the spirit — go open a specimen card.",
      "One spark is all a good question needs.",
      "Logged in the lab notebook: still curious.",
    ];
    let uses = 0;

    function burst(x, y) {
      if (reduce) return;
      const colors = ["--pg-physics", "--pg-chemistry", "--pg-math", "--pg-english", "--pg-geography"]
        .map((v) => getComputedStyle(document.body).getPropertyValue(v).trim());
      const canvas = document.createElement("canvas");
      canvas.className = "spark-burst-canvas";
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      document.body.appendChild(canvas);
      const ctx = canvas.getContext("2d");
      const particles = Array.from({ length: 22 }, () => {
        const angle = Math.random() * Math.PI * 2;
        const speed = (Math.random() * 2.2 + 1.1) * dpr;
        return { x: x * dpr, y: y * dpr, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, r: (Math.random() * 1.6 + 1.2) * dpr, c: colors[Math.floor(Math.random() * colors.length)], life: 1 };
      });
      let frame = 0;
      function tick() {
        frame++;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        let alive = false;
        particles.forEach((p) => {
          p.x += p.vx; p.y += p.vy; p.vy += 0.04 * dpr; p.life -= 0.02;
          if (p.life <= 0) return;
          alive = true;
          ctx.globalAlpha = Math.max(0, p.life);
          ctx.fillStyle = p.c;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
        });
        ctx.globalAlpha = 1;
        if (alive && frame < 90) requestAnimationFrame(tick); else canvas.remove();
      }
      tick();
    }

    function fire(e) {
      const rect = trigger.getBoundingClientRect();
      burst(e && e.clientX ? e.clientX : rect.left + rect.width / 2, e && e.clientY ? e.clientY : rect.top + rect.height / 2);
      if (window.CurioSound && window.CurioSound.play) window.CurioSound.play("success");
      if (window.CurioToast && window.CurioToast.show) window.CurioToast.show(MESSAGES[uses % MESSAGES.length]);
      uses++;
    }
    trigger.addEventListener("click", fire);
    trigger.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fire(e); } });
  }

  // ---------- Catalog live preview stage ----------
  function initCatalogStage() {
    const stage = document.querySelector("[data-catalog-stage]");
    const cards = document.querySelectorAll(".spec-card");
    if (!stage || !cards.length) return;
    const icon = stage.querySelector("[data-stage-icon]");
    const tag = stage.querySelector("[data-stage-tag]");
    const fact = stage.querySelector("[data-stage-fact]");

    function show(card) {
      const subject = card.dataset.subject;
      const factText = card.querySelector(".spec-fact");
      const accent = getComputedStyle(card).getPropertyValue("--accent").trim();
      if (icon) icon.innerHTML = ICONS[subject] || ICONS.physics;
      if (tag) tag.textContent = SUBJECT_LABELS[subject] || "";
      if (fact && factText) fact.textContent = factText.textContent;
      if (accent) stage.style.setProperty("--stage-accent", accent);
      stage.classList.add("is-active");
    }
    cards.forEach((card) => {
      card.addEventListener("mouseenter", () => show(card));
      card.addEventListener("focusin", () => show(card));
    });
  }

  // ---------- Magnetic buttons ----------
  function initMagneticButtons() {
    if (reduce) return;
    document.querySelectorAll("[data-magnetic]").forEach((btn) => {
      let raf = null;
      btn.addEventListener("mousemove", (e) => {
        const rect = btn.getBoundingClientRect();
        const dx = (e.clientX - rect.left - rect.width / 2) * 0.2;
        const dy = (e.clientY - rect.top - rect.height / 2) * 0.2;
        if (raf) cancelAnimationFrame(raf);
        raf = requestAnimationFrame(() => { btn.style.transform = `translate(${dx.toFixed(2)}px, ${(dy - 1).toFixed(2)}px)`; });
      });
      btn.addEventListener("mouseleave", () => { if (raf) cancelAnimationFrame(raf); btn.style.transform = ""; });
    });
  }

  // ---------- "Continue where you left off" strip ----------
  function initResumeStrip() {
    const strip = document.querySelector("[data-resume-strip]");
    if (!strip) return;
    let all = [];
    try { all = JSON.parse(localStorage.getItem("curiolab-scores")) || []; } catch (e) { all = []; }
    if (!all.length) return;
    const last = all[all.length - 1];
    const pct = last.total ? Math.round((last.score / last.total) * 100) : null;
    const SUBJECT_SLUGS = { Physics: "physics", Chemistry: "chemistry", Biology: "biology", English: "english", Mathematics: "mathematics", History: "history", Geography: "geography", "Computer Science": "computer-science" };
    const slug = SUBJECT_SLUGS[last.subject];
    if (!slug) return;
    const label = strip.querySelector("[data-resume-label]");
    const detail = strip.querySelector("[data-resume-detail]");
    const cta = strip.querySelector("[data-resume-cta]");
    if (label) label.textContent = pct === 100 ? "Perfect run — keep the streak going" : "Continue where you left off";
    if (detail) detail.textContent = pct !== null ? `${last.subject} · ${last.lesson} — last score ${pct}%` : `${last.subject} · ${last.lesson}`;
    if (cta) cta.href = `pages/${slug}.html`;
    strip.hidden = false;
  }
})();
