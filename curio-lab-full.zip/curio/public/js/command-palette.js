// Curio Lab — Command Palette (Ctrl/Cmd + K)
// A sitewide quick-nav modal. Works from any page by computing relative paths
// based on how deep the current page is nested.
(function () {
  function depthPrefix() {
    const path = window.location.pathname;
    const parts = path.split("/").filter(Boolean);
    const pagesIdx = parts.lastIndexOf("pages");
    if (pagesIdx === -1) return "pages/";
    const depthAfterPages = parts.length - pagesIdx - 1;
    if (depthAfterPages <= 1) return "";
    return "../";
  }

  function rootPrefix() {
    const path = window.location.pathname;
    const parts = path.split("/").filter(Boolean);
    const pagesIdx = parts.lastIndexOf("pages");
    if (pagesIdx === -1) return "";
    const depthAfterPages = parts.length - pagesIdx - 1;
    return depthAfterPages <= 1 ? "../" : "../../";
  }

  const p = depthPrefix();
  const r = rootPrefix();

  const ITEMS = [
    { group: "Subjects", icon: "⚛️", label: "Physics", desc: "Force, Light, Sound", href: `${p}physics.html` },
    { group: "Subjects", icon: "🧪", label: "Chemistry", desc: "Matter, Equations, Atoms", href: `${p}chemistry.html` },
    { group: "Subjects", icon: "🧬", label: "Biology", desc: "Health, Cell, Tissue", href: `${p}biology.html` },
    { group: "Subjects", icon: "📖", label: "English", desc: "Poems, Stories & Novels", href: `${p}english.html` },
    { group: "Subjects", icon: "📈", label: "Mathematics", desc: "Equations, Numbers", href: `${p}mathematics.html` },
    { group: "Subjects", icon: "🏛️", label: "History", desc: "Ancient World, Mughals, Colonialism, Industry, WW1, WW2, Cold War, Independence, Revolutions", href: `${p}history.html` },
    { group: "Subjects", icon: "🌍", label: "Geography", desc: "Earth, continents, biomes, tectonics, climate, resources", href: `${p}geography.html` },
    { group: "Subjects", icon: "💻", label: "Computer Science", desc: "Java, Python, Algorithms, Control Flow, Functions, Databases, Automation, HTML5, Robotics, Cyber Ethics", href: `${p}computer-science.html` },
    { group: "Lessons", icon: "⚛️", label: "Force", desc: "Physics · Basics", href: `${p}physics/force.html` },
    { group: "Lessons", icon: "⚛️", label: "Light", desc: "Physics · Optics", href: `${p}physics/light.html` },
    { group: "Lessons", icon: "⚛️", label: "Sound", desc: "Physics · Waves", href: `${p}physics/sound.html` },
    { group: "Lessons", icon: "⚛️", label: "Electricity & Circuits", desc: "Physics · Electricity", href: `${p}physics/electricity-circuits.html` },
    { group: "Lessons", icon: "⚛️", label: "Magnetism & EM Induction", desc: "Physics · Magnetism", href: `${p}physics/magnetism-induction.html` },
    { group: "Lessons", icon: "⚛️", label: "Work, Energy, & Power", desc: "Physics · Mechanics", href: `${p}physics/work-energy-power.html` },
    { group: "Lessons", icon: "⚛️", label: "Heat & Thermodynamics", desc: "Physics · Thermal", href: `${p}physics/heat-thermodynamics.html` },
    { group: "Lessons", icon: "⚛️", label: "Pressure & Fluid Mechanics", desc: "Physics · Fluids", href: `${p}physics/pressure-fluids.html` },
    { group: "Lessons", icon: "⚛️", label: "Gravitation & Space", desc: "Physics · Gravity", href: `${p}physics/gravitation-space.html` },
    { group: "Lessons", icon: "⚛️", label: "Astrophysics", desc: "Physics · Cosmology", href: `${p}physics/astrophysics.html` },
    { group: "Lessons", icon: "🧪", label: "Matter", desc: "Chemistry · States", href: `${p}chemistry/matter.html` },
    { group: "Lessons", icon: "🧪", label: "Mixtures & Solutions", desc: "Chemistry · Solubility", href: `${p}chemistry/mixtures-solutions.html` },
    { group: "Lessons", icon: "🧪", label: "Chemical Bonding", desc: "Chemistry · Bonds", href: `${p}chemistry/chemical-bonding.html` },
    { group: "Lessons", icon: "🧪", label: "The Periodic Table", desc: "Chemistry · Elements", href: `${p}chemistry/periodic-table.html` },
    { group: "Lessons", icon: "🧪", label: "Atom & Its Structure", desc: "Chemistry · Atomic", href: `${p}chemistry/atom-structure.html` },
    { group: "Lessons", icon: "🧪", label: "Elements, Compounds & Mixtures", desc: "Chemistry · Classification", href: `${p}chemistry/elements-compounds-mixtures.html` },
    { group: "Lessons", icon: "🧪", label: "Metals & Non-Metals", desc: "Chemistry · Properties", href: `${p}chemistry/metals-nonmetals.html` },
    { group: "Lessons", icon: "🧪", label: "Acids, Bases & Salts", desc: "Chemistry · pH", href: `${p}chemistry/acids-bases-salts.html` },
    { group: "Lessons", icon: "🧪", label: "Chemical Reactions & Equations", desc: "Chemistry · Reactions & Equations", href: `${p}chemistry/chemical-reactions.html` },
    { group: "Lessons", icon: "🧪", label: "Carbon & Organic Chemistry", desc: "Chemistry · Organic", href: `${p}chemistry/carbon-organic-chemistry.html` },
    { group: "Lessons", icon: "🧬", label: "Health", desc: "Biology · Wellness", href: `${p}biology/health.html` },
    { group: "Lessons", icon: "🧬", label: "Cell", desc: "Biology · Cell Structure", href: `${p}biology/cell.html` },
    { group: "Lessons", icon: "🧬", label: "Tissue", desc: "Biology · Tissues", href: `${p}biology/cell.html` },
    { group: "Lessons", icon: "🧬", label: "Diseases", desc: "Biology · Pathogens", href: `${p}biology/health.html` },
    { group: "Lessons", icon: "📈", label: "Linear Equations", desc: "Mathematics · Algebra", href: `${p}mathematics/linear-equations.html` },
    { group: "Lessons", icon: "📈", label: "Algebraic Equations", desc: "Mathematics · Algebra", href: `${p}mathematics/algebraic-equations.html` },
    { group: "Lessons", icon: "📈", label: "Rational Numbers", desc: "Mathematics · Numbers", href: `${p}mathematics/rational-numbers.html` },
    { group: "Lessons", icon: "🏺", label: "Ancient Civilizations", desc: "History · Ancient World", href: `${p}history/ancient-civilizations.html` },
    { group: "Lessons", icon: "🕌", label: "Delhi Sultanate & Mughal Empire", desc: "History · Medieval India", href: `${p}history/delhi-sultanate-mughal-empire.html` },
    { group: "Lessons", icon: "🌍", label: "World War 2", desc: "History · Modern", href: `${p}history/world-war-2.html` },
    { group: "Lessons", icon: "🏛️", label: "Mughal Empire", desc: "History · Medieval India", href: `${p}history/mughal-empire.html` },
    { group: "Lessons", icon: "🏛️", label: "Delhi Sultanate", desc: "History · Medieval India", href: `${p}history/delhi-sultanate.html` },
    { group: "Lessons", icon: "🏛️", label: "World War 1", desc: "History · Modern", href: `${p}history/world-war-1.html` },
    { group: "Lessons", icon: "⛵", label: "Colonialism & Trade", desc: "History · Early Modern", href: `${p}history/colonialism-and-trade.html` },
    { group: "Lessons", icon: "🏭", label: "The Industrial Revolution", desc: "History · Modern", href: `${p}history/industrial-revolution.html` },
    { group: "Lessons", icon: "☢️", label: "The Cold War", desc: "History · Modern", href: `${p}history/cold-war.html` },
    { group: "Lessons", icon: "🕊️", label: "Independence Movements", desc: "History · Modern", href: `${p}history/independence-movements.html` },
    { group: "Lessons", icon: "✊", label: "Political Revolutions", desc: "History · Modern", href: `${p}history/political-revolutions.html` },
    { group: "Lessons", icon: "🌍", label: "World Landforms", desc: "Geography · Physical", href: `${p}geography/world-landforms.html` },
    { group: "Lessons", icon: "🌍", label: "Asia", desc: "Geography · Continents", href: `${p}geography/asia.html` },
    { group: "Lessons", icon: "🌍", label: "Europe", desc: "Geography · Continents", href: `${p}geography/europe.html` },
    { group: "Lessons", icon: "🌍", label: "Africa", desc: "Geography · Continents", href: `${p}geography/africa.html` },
    { group: "Lessons", icon: "🌍", label: "North America", desc: "Geography · Continents", href: `${p}geography/north-america.html` },
    { group: "Lessons", icon: "🌍", label: "South America", desc: "Geography · Continents", href: `${p}geography/south-america.html` },
    { group: "Lessons", icon: "🌍", label: "Australia", desc: "Geography · Continents", href: `${p}geography/australia.html` },
    { group: "Lessons", icon: "🌍", label: "Antarctica", desc: "Geography · Continents", href: `${p}geography/antarctica.html` },
    { group: "Lessons", icon: "🌍", label: "Biomes & Vegetation", desc: "Geography · Physical", href: `${p}geography/biomes-vegetation.html` },
    { group: "Lessons", icon: "🌍", label: "Plate Tectonics", desc: "Geography · Physical", href: `${p}geography/plate-tectonics.html` },
    { group: "Lessons", icon: "🌍", label: "Meteorology & Climate", desc: "Geography · Physical", href: `${p}geography/meteorology-climate.html` },
    { group: "Lessons", icon: "🌍", label: "Resource Distribution", desc: "Geography · Physical", href: `${p}geography/resource-distribution.html` },
    { group: "Lessons", icon: "💻", label: "HTML5", desc: "Computer Science · Web", href: `${p}computer-science/html5.html` },
    { group: "Lessons", icon: "💻", label: "Robots & Robotics", desc: "Computer Science · Tech", href: `${p}computer-science/robots-robotics.html` },
    { group: "Lessons", icon: "💻", label: "Cyber Ethics", desc: "Computer Science · Safety", href: `${p}computer-science/cyber-ethics.html` },
    { group: "Lessons", icon: "💻", label: "Java", desc: "Computer Science · Languages", href: `${p}computer-science/java.html` },
    { group: "Lessons", icon: "💻", label: "Python", desc: "Computer Science · Languages", href: `${p}computer-science/python.html` },
    { group: "Lessons", icon: "💻", label: "Algorithms", desc: "Computer Science · Problem Solving", href: `${p}computer-science/algorithms.html` },
    { group: "Lessons", icon: "💻", label: "Control Flow", desc: "Computer Science · Programming Concepts", href: `${p}computer-science/control-flow.html` },
    { group: "Lessons", icon: "💻", label: "Functions & Scope", desc: "Computer Science · Programming Concepts", href: `${p}computer-science/functions-scope.html` },
    { group: "Lessons", icon: "💻", label: "Database Management", desc: "Computer Science · Data & Systems", href: `${p}computer-science/database-management.html` },
    { group: "Lessons", icon: "💻", label: "Automation & Scripting", desc: "Computer Science · Practical Programming", href: `${p}computer-science/automation-scripting.html` },
    { group: "Lessons", icon: "📖", label: "The Road Not Taken", desc: "English · Poem", href: `${p}english/road-not-taken.html` },
    { group: "Lessons", icon: "📖", label: "If—", desc: "English · Poem", href: `${p}english/if.html` },
    { group: "Lessons", icon: "📖", label: "The Happy Prince", desc: "English · Story", href: `${p}english/the-happy-prince.html` },
    { group: "Lessons", icon: "📖", label: "The Last Leaf", desc: "English · Story", href: `${p}english/the-last-leaf.html` },
    { group: "Lessons", icon: "📖", label: "Romeo and Juliet", desc: "English · Novel", href: `${p}english/romeo-and-juliet.html` },
    { group: "Lessons", icon: "📖", label: "Daffodils", desc: "English · Poem", href: `${p}english/daffodils.html` },
    { group: "Lessons", icon: "📖", label: "The Necklace", desc: "English · Story", href: `${p}english/the-necklace.html` },
    { group: "Lessons", icon: "📖", label: "A Tale of Two Cities", desc: "English · Novel", href: `${p}english/a-tale-of-two-cities.html` },
    { group: "Lessons", icon: "📖", label: "Ode to a Nightingale", desc: "English · Poem", href: `${p}english/ode-to-a-nightingale.html` },
    { group: "Lessons", icon: "📖", label: "Sonnet 18", desc: "English · Poem", href: `${p}english/sonnet-18.html` },
    { group: "Lessons", icon: "📖", label: "The Gift of the Magi", desc: "English · Story", href: `${p}english/the-gift-of-the-magi.html` },
    { group: "Lessons", icon: "📖", label: "The Tell-Tale Heart", desc: "English · Story", href: `${p}english/the-tell-tale-heart.html` },
    { group: "Lessons", icon: "📖", label: "The Great Gatsby", desc: "English · Novel", href: `${p}english/the-great-gatsby.html` },
    { group: "Lessons", icon: "📖", label: "Pride and Prejudice", desc: "English · Novel", href: `${p}english/pride-and-prejudice.html` },
    { group: "Lessons", icon: "📖", label: "Wuthering Heights", desc: "English · Novel", href: `${p}english/wuthering-heights.html` },
    { group: "Lessons", icon: "📖", label: "Frankenstein", desc: "English · Novel", href: `${p}english/frankenstein.html` },
    { group: "Tools", icon: "🎓", label: "Browse by Grade", desc: "Filter lessons by grade & level", href: `${p}browse.html` },
    { group: "Tools", icon: "🧪", label: "Question Bank", desc: "Practise quiz questions by subject, topic and difficulty", href: `${p}question-bank.html` },
    { group: "Tools", icon: "📊", label: "Progress", desc: "Live scoreboard", href: `${p}scoreboard.html` },
    { group: "Tools", icon: "♿", label: "Accessibility & Offline", desc: "Text size, dyslexia font, contrast, offline", href: `${p}accessibility.html` },
    { group: "Tools", icon: "🏋️", label: "Practice Hub", desc: "Practise across lessons: cards, recall, fill the blank", href: `${p}practice.html` },
    { group: "Tools", icon: "🧮", label: "Problem Lab", desc: "Endless problems with worked solutions", href: `${p}problem-lab.html` },
    { group: "Tools", icon: "🧪", label: "Virtual Labs", desc: "Titration, circuits and microscope experiments", href: `${p}labs/index.html` },
    { group: "Tools", icon: "🧪", label: "Acid–Base Titration lab", desc: "Burette, indicator and pH curve", href: `${p}labs/titration.html` },
    { group: "Tools", icon: "💡", label: "Circuit Builder lab", desc: "Series and parallel circuits with live readouts", href: `${p}labs/circuits.html` },
    { group: "Tools", icon: "🔬", label: "Virtual Microscope lab", desc: "Focus slides and switch objectives", href: `${p}labs/microscope.html` },
    { group: "Tools", icon: "📈", label: "Graphing & Equation Solver", desc: "Plot functions, find roots, solve with steps", href: `${p}math-tools/index.html` },
    { group: "Tools", icon: "📄", label: "Revision Notes (PDF)", desc: "Printable cheat sheets for quick revision", href: `${p}notes/index.html` },
    { group: "Tools", icon: "📈", label: "Progress Report", desc: "Mastery heatmap, printable PDF", href: `${p}report.html` },
    { group: "Tools", icon: "📓", label: "Mistake Notebook", desc: "Spaced review of questions you missed", href: `${p}review.html` },
    { group: "Tools", icon: "🔖", label: "Saved & Notes", desc: "Bookmarks and your lesson notes", href: `${p}saved.html` },
    { group: "Tools", icon: "📚", label: "Glossary", desc: "Every term, searchable", href: `${p}glossary.html` },
    { group: "Tools", icon: "🎮", label: "Play & Study", desc: "Speed Match & Term Scramble", href: `${p}play.html` },
    { group: "Tools", icon: "🗺️", label: "Courses", desc: "Ordered lesson paths for all 8 subjects", href: `${p}courses.html` },
    { group: "Tools", icon: "📄", label: "Past Papers", desc: "Exam-style papers with full solutions", href: `${p}past-papers.html` },
    { group: "Tools", icon: "📝", label: "Exam Center", desc: "Timed 100/80/40/20-mark papers, readiness score", href: `${p}exams.html` },
    { group: "Tools", icon: "🎯", label: "Exam Readiness", desc: "How ready you are, subject by subject", href: `${p}exams.html?tab=readiness` },
    { group: "Tools", icon: "▶️", label: "Resume Exam", desc: "Continue an exam in progress", href: `${p}exams.html?resume=1` },
    { group: "Tools", icon: "✅", label: "To-Do List", desc: "Study planner", href: `${p}todo.html` },
    { group: "Tools", icon: "🌍", label: "Community", desc: "Leaderboards, friends and public profiles", href: `${p}community.html` },
    { group: "Tools", icon: "🏆", label: "Certificates & Trophies", desc: "Your achievements", href: `${p}certificates.html` },
    { group: "About", icon: "💬", label: "About Curio Lab", desc: "Our story", href: `${p}about.html` },
    { group: "About", icon: "🗂️", label: "Changelog", desc: "What's been built", href: `${p}changelog.html` },
    { group: "About", icon: "💳", label: "Pricing", desc: "Plans", href: `${p}pricing.html` },
    { group: "About", icon: "🔒", label: "Privacy & Security", desc: "How data is handled", href: `${p}privacy.html` },
    { group: "About", icon: "✉️", label: "Contact Us", desc: "Get in touch", href: `${p}contact.html` },
    { group: "About", icon: "🛟", label: "Help Center", desc: "Step-by-step guides", href: `${p}help.html` },
    { group: "About", icon: "❓", label: "FAQ", desc: "Frequently asked questions", href: `${p}faq.html` },
    { group: "About", icon: "📰", label: "Blog", desc: "Study tips and science explainers", href: `${p}blog.html` },
    { group: "About", icon: "💼", label: "Careers", desc: "Volunteer with Curio Lab", href: `${p}careers.html` },
    { group: "About", icon: "📣", label: "Press", desc: "Media kit and logos", href: `${p}press.html` },
    { group: "About", icon: "🤝", label: "Partners", desc: "Schools, creators, non-profits", href: `${p}partners.html` },
    { group: "About", icon: "🍪", label: "Cookie Policy", desc: "Cookies and storage", href: `${p}cookies.html` },
    { group: "About", icon: "📄", label: "Terms & Conditions", desc: "Legal", href: `${p}terms.html` },
    { group: "Navigate", icon: "🏠", label: "Home", desc: "Curio Lab homepage", href: `${r}index.html` },
  ];

  // Actions are global commands rather than links — they run a function
  // instead of navigating. Each has an optional `available()` guard so, for
  // example, "Open AI Coach" only shows up on pages that actually have a
  // coach panel, instead of appearing everywhere and silently doing nothing.
  const ACTIONS = [
    {
      group: "Actions", icon: "🌗", label: "Toggle theme", desc: "Switch light / dark",
      available: () => !!document.querySelector("[data-theme-toggle]"),
      run: () => document.querySelector("[data-theme-toggle]")?.click(),
    },
    {
      group: "Actions", icon: "🔊", label: "Toggle sound effects", desc: "Mute / unmute UI sounds",
      available: () => !!document.querySelector("[data-sound-toggle]"),
      run: () => document.querySelector("[data-sound-toggle]")?.click(),
    },
    {
      group: "Actions", icon: "🧠", label: "Open AI Coach", desc: "Ask about the current lesson",
      available: () => !!document.querySelector("[data-coach-launcher]"),
      run: () => document.querySelector("[data-coach-launcher]")?.click(),
    },
  ];

  let overlay, input, list, activeIndex = 0, filtered = ITEMS;

  function build() {
    overlay = document.createElement("div");
    overlay.className = "cmdk-overlay";
    overlay.innerHTML = `
      <div class="cmdk-box">
        <div class="cmdk-input-row">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" placeholder="Jump to a subject, lesson, or tool…" data-cmdk-input autocomplete="off" />
          <kbd>Esc</kbd>
        </div>
        <div class="cmdk-list" data-cmdk-list></div>
      </div>
    `;
    document.body.appendChild(overlay);
    input = overlay.querySelector("[data-cmdk-input]");
    list = overlay.querySelector("[data-cmdk-list]");

    overlay.addEventListener("click", (e) => { if (e.target === overlay) close(); });
    input.addEventListener("input", () => render(input.value));
    input.addEventListener("keydown", onKeydown);
  }

  // Subsequence fuzzy matcher: query characters must appear in target in
  // order, but not necessarily contiguously ("frc" matches "Force"). Scores
  // reward consecutive-character runs and matches at the start of a word, so
  // "frc" ranks "Force" above a coincidental scattered match in a longer
  // string — the same family of algorithm used by most editor command
  // palettes (VS Code, Sublime, etc.).
  function fuzzyScore(query, target) {
    if (!query) return 0;
    const q = query.toLowerCase();
    const t = target.toLowerCase();
    let qi = 0;
    let score = 0;
    let consecutive = 0;
    for (let ti = 0; ti < t.length && qi < q.length; ti++) {
      if (t[ti] === q[qi]) {
        const atWordStart = ti === 0 || /[\s\-_/]/.test(t[ti - 1]);
        score += 10 + consecutive * 4 + (atWordStart ? 8 : 0);
        consecutive += 1;
        qi += 1;
      } else {
        consecutive = 0;
      }
    }
    return qi === q.length ? score : -1; // -1 means "not all query chars found"
  }

  function bestScore(query, item) {
    // Try label, description, and group independently and keep the best —
    // e.g. searching "physics" should surface lessons via their group name
    // even though the word "physics" isn't in the lesson's own label.
    return Math.max(
      fuzzyScore(query, item.label),
      fuzzyScore(query, item.desc || "") - 2, // slight penalty vs. a label match
      fuzzyScore(query, item.group) - 4
    );
  }

  function availableActions() {
    return ACTIONS.filter((a) => { try { return a.available(); } catch (e) { return false; } });
  }

  function escapeHtml(str) {
    return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function render(query) {
    const q = query.trim();
    const pool = [...ITEMS, ...availableActions()];

    if (!q) {
      filtered = pool;
    } else {
      filtered = pool
        .map((item) => ({ item, score: bestScore(q, item) }))
        .filter((s) => s.score >= 0)
        .sort((a, b) => b.score - a.score)
        .map((s) => s.item);
    }
    activeIndex = 0;

    if (filtered.length === 0) {
      list.innerHTML = `<div class="cmdk-empty">No matches for "${escapeHtml(query)}"</div>`;
      return;
    }

    let html = "";
    let lastGroup = null;
    filtered.forEach((item, idx) => {
      // Once a query narrows results down, ranked relevance matters more
      // than the group taxonomy — group headers only show while browsing.
      if (!q && item.group !== lastGroup) {
        html += `<div class="cmdk-group-label">${escapeHtml(item.group)}</div>`;
        lastGroup = item.group;
      }
      html += `<div class="cmdk-item ${idx === activeIndex ? "active" : ""}" data-idx="${idx}">
        <span class="cmdk-icon">${item.icon}</span>
        <span>${escapeHtml(item.label)}</span>
        <span class="cmdk-desc">${escapeHtml(item.desc)}</span>
      </div>`;
    });
    list.innerHTML = html;

    list.querySelectorAll("[data-idx]").forEach((el) => {
      el.addEventListener("click", () => go(filtered[+el.dataset.idx]));
      el.addEventListener("mouseenter", () => { activeIndex = +el.dataset.idx; updateActive(); });
    });
  }

  function updateActive() {
    list.querySelectorAll(".cmdk-item").forEach((el) => {
      el.classList.toggle("active", +el.dataset.idx === activeIndex);
    });
    const activeEl = list.querySelector(".cmdk-item.active");
    activeEl?.scrollIntoView({ block: "nearest" });
  }

  function go(item) {
    if (!item) return;
    if (typeof item.run === "function") {
      close();
      item.run();
      return;
    }
    window.location.href = item.href;
  }

  function onKeydown(e) {
    if (e.key === "ArrowDown") { e.preventDefault(); activeIndex = Math.min(activeIndex + 1, filtered.length - 1); updateActive(); window.CurioSound && window.CurioSound.play("navigate"); }
    else if (e.key === "ArrowUp") { e.preventDefault(); activeIndex = Math.max(activeIndex - 1, 0); updateActive(); window.CurioSound && window.CurioSound.play("navigate"); }
    else if (e.key === "Enter") { e.preventDefault(); window.CurioSound && window.CurioSound.play("click"); go(filtered[activeIndex]); }
    else if (e.key === "Escape") { close(); }
  }

  function open() {
    if (!overlay) build();
    overlay.classList.add("open");
    window.CurioSound && window.CurioSound.play("open");
    input.value = "";
    render("");
    setTimeout(() => input.focus(), 10);
  }
  function close() {
    if (overlay?.classList.contains("open")) window.CurioSound && window.CurioSound.play("close");
    overlay?.classList.remove("open");
  }

  document.addEventListener("keydown", (e) => {
    const isK = e.key === "k" || e.key === "K";
    if ((e.metaKey || e.ctrlKey) && isK) {
      e.preventDefault();
      overlay?.classList.contains("open") ? close() : open();
    }
  });

  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("[data-cmdk-trigger]").forEach((btn) => {
      btn.addEventListener("click", open);
    });
  });

  window.CurioCommandPalette = { open, close };
})();
