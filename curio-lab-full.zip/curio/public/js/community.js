// Curio Lab — Community page: join, leaderboards, friends, my public profile.
(function () {
  "use strict";
  const CC = window.CurioCommunity;
  document.addEventListener("DOMContentLoaded", async () => {
    const root = document.querySelector("[data-cm-root]");
    if (!root || !CC) return;
    CC.autoLocalize(root);
    const { esc, avatar, fmt } = CC;
    const toast = (m, o) => (window.CurioToast ? window.CurioToast.show(m, o || {}) : null);
    const SUBJECTS = ["Physics", "Chemistry", "Biology", "Mathematics", "English", "History", "Geography", "Computer Science"];
    const AVATARS = ["#12213B", "#D68C1F", "#2E8E80", "#C94A38", "#5F7A34", "#7C5CBF"];
    const VIS = {
      public: ["Public", "On public leaderboards, and anyone with the link can see your profile page."],
      friends: ["Friends only", "Hidden from public leaderboards. Only accepted friends can open your profile."],
      private: ["Private", "Nobody else can find you, friend you or open your profile. You still see your own stats."],
    };
    let meta = null, me = null, state = { tab: "boards", board: "global", period: "all", subject: "Physics" };

    const msg = (kind, title, body, extra) => { root.innerHTML = `<div class="cm-card cm-notice cm-${kind}"><div class="cm-big" aria-hidden="true">${{ lock: "🔐", kid: "🧒", off: "🛰️", wait: "⏳" }[kind] || "👋"}</div><h2>${title}</h2><p>${body}</p>${extra || ""}</div>`; };

    // ---------------------------------------------------------------- entry
    const elig = CC.eligibility();
    if (elig === "guest") return msg("lock", "Log in to join the community", "Leaderboards and friends are tied to your Curio Lab account on this device.", `<div class="cm-actions"><a class="cm-btn cm-primary" href="login.html">Log in</a><a class="cm-btn" href="signup.html">Create an account</a></div>`);
    if (elig === "child") return msg("kid", "The community is for learners 13 and over", "Public profiles, leaderboards and friends are switched off on children's accounts. That's on purpose, to keep young learners private. Your progress, quizzes and certificates all still work.", `<div class="cm-actions"><a class="cm-btn cm-primary" href="scoreboard.html">See my progress</a></div>`);

    try { meta = await CC.api("/meta"); }
    catch (e) { return msg("off", "The community isn't available right now", esc(e.message) + " Everything else on Curio Lab works as usual. Try again a little later.", `<div class="cm-actions"><button class="cm-btn" type="button" onclick="location.reload()">Try again</button></div>`); }

    if (elig === "unknown-age") return askAge();
    if (CC.saved() && CC.saved().key) {
      try { me = (await CC.api("/me")); } catch (e) { if (e.status === 401 || e.status === 403) { if (e.status === 401) CC.forget(); } else if (e.offline) return msg("off", "Can't reach the community", esc(e.message)); }
    }
    me ? await dashboard() : joinForm();

    // ---------------------------------------------------------------- age (only when this browser never answered the age screen)
    function askAge() {
      const y = new Date().getFullYear();
      root.innerHTML = `<form class="cm-card cm-form" data-age>
        <h2>One quick question first</h2><p>The community is for learners aged 13 and over. Your answer stays on this device and decides what you can use.</p>
        <div class="cm-row"><label>Birth month<select name="m" required>${Array.from({ length: 12 }, (_, i) => `<option value="${i + 1}">${new Date(2000, i, 1).toLocaleString(undefined, { month: "long" })}</option>`).join("")}</select></label>
        <label>Birth year<input name="y" type="number" inputmode="numeric" min="${y - 110}" max="${y}" placeholder="${y - 16}" required></label></div>
        <button class="cm-btn cm-primary" type="submit">Continue</button><p class="cm-err" data-err role="alert"></p></form>`;
      root.querySelector("form").addEventListener("submit", (ev) => {
        ev.preventDefault();
        const f = ev.target, b = window.CurioAge && window.CurioAge.screen(f.m.value, f.y.value);
        if (!b) return (f.querySelector("[data-err]").textContent = "Please enter a real birth month and year.");
        location.reload();
      });
    }

    // ---------------------------------------------------------------- join
    function joinForm() {
      const teen = CC.band() === "teen";
      root.innerHTML = `<div class="cm-join">
        <form class="cm-card cm-form" data-join novalidate>
          <h2>Join the community</h2>
          <p class="cm-sub">Pick a handle. It's the only name other learners see, unless you add a display name.</p>
          <label>Handle<div class="cm-input-pre"><span>@</span><input name="handle" maxlength="20" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="curious_cat" aria-describedby="hcheck" required></div></label>
          <p class="cm-hint" id="hcheck" data-hcheck aria-live="polite">3–20 letters, numbers or underscores.</p>
          <label>Display name <span class="cm-opt">optional</span><input name="display_name" maxlength="30" autocomplete="off" placeholder="e.g. Priya S."></label>
          <fieldset><legend>Avatar colour</legend><div class="cm-swatches">${AVATARS.map((c, i) => `<label class="cm-swatch"><input type="radio" name="avatar" value="${c}" ${i ? "" : "checked"}><span style="background:${c}"></span></label>`).join("")}</div></fieldset>
          <fieldset><legend>Who can see you?</legend>${Object.keys(VIS).filter((k) => !(teen && k === "public")).map((k, i) => `<label class="cm-radio"><input type="radio" name="visibility" value="${k}" ${(teen ? k === "friends" : k === "public") ? "checked" : ""}><span><strong>${VIS[k][0]}</strong><small>${VIS[k][1]}</small></span></label>`).join("")}</fieldset>
          ${teen ? `<p class="cm-hint">For learners under 16, profiles start as friends-only. You can only be found by someone who knows your exact handle.</p>` : ""}
          <label class="cm-check"><input type="checkbox" name="agree"><span>I understand that my handle, level, XP, streak, badges and subject scores are shared as set above. No email or real name is shown. I can leave and erase my profile any time.</span></label>
          <button class="cm-btn cm-primary" type="submit">Create my profile</button>
          <p class="cm-err" data-err role="alert"></p>
        </form>
        <aside class="cm-card cm-side"><h3>How it works</h3>
          <ul class="cm-list"><li><strong>XP</strong>: each quiz you take after joining earns 5–20 XP.</li><li><strong>Leaderboards</strong>: global, weekly, per subject and friends. Weekly resets Monday 00:00 UTC.</li><li><strong>Badges</strong> come from your real quiz results.</li><li><strong>Fair play</strong>: our server grades each quiz itself, with daily limits.</li></ul>
          <details class="cm-restore"><summary>Already have a profile? Restore it</summary><p class="cm-hint">Paste the device key from My profile on your other device.</p>
            <form data-restore class="cm-inline"><input name="key" placeholder="clk_…" autocomplete="off" aria-label="Device key"><button class="cm-btn" type="submit">Restore</button></form><p class="cm-err" data-rerr role="alert"></p></details>
        </aside></div>`;
      const f = root.querySelector("[data-join]"), hc = f.querySelector("[data-hcheck]");
      let t;
      f.handle.addEventListener("input", () => {
        clearTimeout(t); hc.className = "cm-hint";
        const v = f.handle.value.trim().toLowerCase().replace(/^@/, "");
        if (!v) return (hc.textContent = "3–20 letters, numbers or underscores.");
        t = setTimeout(async () => {
          try { const j = await CC.api("/handle-check?h=" + encodeURIComponent(v)); hc.textContent = j.ok ? `@${j.handle} is available` : j.reason; hc.className = "cm-hint " + (j.ok ? "cm-good" : "cm-bad"); } catch (e) { hc.textContent = e.message; }
        }, 350);
      });
      f.addEventListener("submit", async (ev) => {
        ev.preventDefault();
        const err = f.querySelector("[data-err]"); err.textContent = "";
        const btn = f.querySelector("button[type=submit]"); btn.disabled = true;
        try {
          const j = await CC.api("/join", { body: { handle: f.handle.value, display_name: f.display_name.value, avatar: f.avatar.value, visibility: f.visibility.value, agree: f.agree.checked, band: CC.band() } });
          CC.save({ key: j.key, handle: j.profile.handle, lastSync: 0 });
          await CC.sync(true);
          me = await CC.api("/me");
          state.tab = "profile"; state.justJoined = true;
          await dashboard();
        } catch (e) { err.textContent = e.message; btn.disabled = false; }
      });
      root.querySelector("[data-restore]").addEventListener("submit", async (ev) => {
        ev.preventDefault();
        const k = ev.target.key.value.trim(), er = root.querySelector("[data-rerr]"); er.textContent = "";
        CC.save({ key: k, handle: "", lastSync: 0 });
        try { me = await CC.api("/me"); CC.save({ key: k, handle: me.profile.handle, lastSync: 0 }); await CC.sync(true); me = await CC.api("/me"); await dashboard(); }
        catch (e) { CC.forget(); er.textContent = e.status === 401 ? "That key isn't recognised." : e.message; }
      });
    }

    // ---------------------------------------------------------------- dashboard
    async function dashboard() {
      const p = me.profile;
      root.innerHTML = `
        <div class="cm-card cm-me">
          ${avatar(p.display_name, p.avatar, "cm-lg")}
          <div class="cm-me-id"><h2>${esc(p.display_name)}</h2><p><span translate="no">@${esc(p.handle)}</span> · <span>${esc(VIS[p.visibility][0])}</span></p>
            <div class="cm-xpbar" role="img" aria-label="Level ${p.level}, ${fmt(p.xp)} XP, ${fmt(p.next - p.xp)} XP to level ${p.level + 1}"><span style="width:${Math.max(3, Math.min(100, ((p.xp - p.floor) / Math.max(1, p.next - p.floor)) * 100))}%"></span></div>
            <small>${fmt(p.next - p.xp)} <span>XP to next level</span></small></div>
          <dl class="cm-stats"><div><dt>Level</dt><dd>${p.level}</dd></div><div><dt>XP</dt><dd>${fmt(p.xp)}</dd></div><div><dt>This week</dt><dd>${fmt(p.week_xp)}</dd></div><div><dt>Streak</dt><dd>${p.streak_cur}🔥</dd></div><div><dt>Rank</dt><dd>${p.rank ? "#" + p.rank : "—"}</dd></div></dl>
        </div>
        <div data-notices></div>
        <div class="cm-tabs" role="tablist" aria-label="Community sections">
          ${[["boards", "Leaderboards"], ["friends", "Friends" + (me.incoming ? ` <b class="cm-dot">${me.incoming}</b>` : "")], ["groups", "Groups"], ["rooms", "Rooms"], ["duels", "Duels" + (me.duels_waiting ? ` <b class="cm-dot">${me.duels_waiting}</b>` : "")], ["profile", "My profile"]].map(([k, l]) => `<button type="button" role="tab" id="cmt-${k}" aria-controls="cm-panel" aria-selected="${state.tab === k}" tabindex="${state.tab === k ? 0 : -1}" data-tab="${k}">${l}</button>`).join("")}
        </div>
        <div class="cm-panel" id="cm-panel" role="tabpanel" tabindex="0" aria-live="polite"></div>`;
      const tabs = [...root.querySelectorAll("[data-tab]")];
      tabs.forEach((b, i) => {
        b.addEventListener("click", () => { state.tab = b.dataset.tab; tabs.forEach((x) => { const on = x === b; x.setAttribute("aria-selected", on); x.tabIndex = on ? 0 : -1; }); panel(); });
        b.addEventListener("keydown", (ev) => { const d = { ArrowRight: 1, ArrowLeft: -1 }[ev.key]; if (!d) return; ev.preventDefault(); const n = tabs[(i + d + tabs.length) % tabs.length]; n.focus(); n.click(); });
      });
      const nb = root.querySelector("[data-notices]");
      if (nb && window.CurioSocial && window.CurioSocial.notices) window.CurioSocial.notices(nb, { CC, toast, count: me.notices || 0, muted_until: me.muted_until });
      panel();
      CC.sync(false).then((j) => { if (j && j.profile && (j.profile.xp !== p.xp)) refresh(); });
    }
    async function refresh() { try { me = await CC.api("/me"); } catch (_) {} await dashboard(); }
    function panelEl() { return root.querySelector("#cm-panel"); }
    function panel() { panelEl().setAttribute("aria-labelledby", "cmt-" + state.tab); const social = (k) => () => (window.CurioSocial ? window.CurioSocial[k](panelEl(), { CC, toast }) : (panelEl().innerHTML = `<p class="cm-err">This section couldn't load. Refresh the page to try again.</p>`));
      ({ boards, friends, groups: social("groups"), rooms: social("rooms"), duels: social("duels"), profile })[state.tab](); }

    // ---------------------------------------------------------------- leaderboards
    async function boards() {
      const el = panelEl();
      const seg = (name, opts) => `<div class="cm-seg" role="group" aria-label="${name}">${opts.map(([v, l]) => `<button type="button" data-${name.toLowerCase()}="${v}" aria-pressed="${state[name.toLowerCase()] === v}">${l}</button>`).join("")}</div>`;
      el.innerHTML = `<div class="cm-controls">${seg("Board", [["global", "Global"], ["subject", "Subject"], ["friends", "Friends"]])}${seg("Period", [["all", "All time"], ["week", "This week"]])}
        <label class="cm-subj" ${state.board === "subject" ? "" : "hidden"}><span class="cm-sr">Subject</span><select data-subject>${SUBJECTS.map((s) => `<option ${s === state.subject ? "selected" : ""}>${s}</option>`).join("")}</select></label></div>
        <div data-board-box><p class="cm-hint">Loading…</p></div>`;
      el.querySelectorAll("button[data-board]").forEach((b) => b.addEventListener("click", () => { state.board = b.dataset.board; boards(); }));
      el.querySelectorAll("[data-period]").forEach((b) => b.addEventListener("click", () => { state.period = b.dataset.period; boards(); }));
      el.querySelector("[data-subject]").addEventListener("change", (ev) => { state.subject = ev.target.value; boards(); });
      const box = el.querySelector("[data-board-box]");
      try {
        const j = await CC.api(`/leaderboard?board=${state.board}&period=${state.period}` + (state.board === "subject" ? "&subject=" + encodeURIComponent(state.subject) : ""));
        const unit = state.period === "week" ? "XP this week" : "XP";
        const title = `<span>${{ global: "Global", subject: esc(state.subject), friends: "Friends" }[state.board]}</span> · <span>${state.period === "week" ? "This week" : "All time"}</span>`;
        let note = "";
        if (j.me && j.me.on_board === false) note = `<p class="cm-note"><span>You're hidden from public boards by your visibility setting.</span> <button type="button" class="cm-link" data-go-profile>Change visibility</button></p>`;
        else if (j.me && j.me.rank) note = `<p class="cm-note"><span>Your rank</span>: <strong>#${j.me.rank}</strong> · <strong>${fmt(j.me.pts)}</strong> <span>${state.period === "week" ? "XP this week" : "XP"}</span></p>`;
        else if (j.me) note = `<p class="cm-note">${state.period === "week" ? "Take a quiz to get on this board this week." : "Take a quiz to get on this board."}</p>`;
        box.innerHTML = `<h3 class="cm-h">${title}</h3>${note}` + (j.rows.length ? `<ol class="cm-rows">${j.rows.map((r) => `<li class="${r.me ? "is-me" : ""}" ${r.rank <= 3 ? `data-medal="${r.rank}"` : ""}>
            <span class="cm-rank">${r.rank <= 3 ? ["🥇", "🥈", "🥉"][r.rank - 1] : r.rank}</span>${avatar(r.name, r.avatar)}
            <a class="cm-name" href="${CC.profileUrl(r.handle)}">${esc(r.name)}<small>@${esc(r.handle)}</small></a>
            <span class="cm-streak" title="Current streak">${r.streak ? r.streak + "🔥" : ""}</span><span class="cm-pts">${fmt(r.pts)}<small>${unit}</small></span></li>`).join("")}</ol>`
          : `<div class="cm-empty">${state.board === "friends" ? "Add friends to compete with them." : "Nobody is on this board yet. Be the first!"}</div>`);
        const go = box.querySelector("[data-go-profile]"); if (go) go.addEventListener("click", () => root.querySelector("#cmt-profile").click());
      } catch (e) { box.innerHTML = `<p class="cm-err">${esc(e.message)}</p>`; }
    }

    // ---------------------------------------------------------------- friends
    async function friends() {
      const el = panelEl();
      el.innerHTML = `<form class="cm-inline cm-addfriend" data-add><label class="cm-sr" for="cm-fh">Friend's exact handle</label><div class="cm-input-pre"><span>@</span><input id="cm-fh" name="h" placeholder="friend's exact handle" autocomplete="off" autocapitalize="none" maxlength="20"></div><button class="cm-btn cm-primary" type="submit">Send request</button></form>
        <p class="cm-hint">Learners are found only by exact handle, so share yours: <button type="button" class="cm-link" data-copy-handle><span>Copy</span> <span translate="no">@${esc(me.profile.handle)}</span></button>.</p><p class="cm-err" data-err role="alert"></p><div data-flist><p class="cm-hint">Loading…</p></div>`;
      const err = el.querySelector("[data-err]");
      el.querySelector("[data-copy-handle]").addEventListener("click", () => copy("@" + me.profile.handle));
      el.querySelector("[data-add]").addEventListener("submit", async (ev) => {
        ev.preventDefault(); err.textContent = "";
        const h = ev.target.h.value.trim(); if (!h) return;
        try { const j = await CC.api("/friends/request", { body: { handle: h } }); toast(j.status === "friend" ? "You're now friends" : "Request sent", { icon: "🤝" }); ev.target.reset(); list(); }
        catch (e) { err.textContent = e.status === 404 ? "No learner with that exact handle can receive requests." : e.message; }
      });
      list();
      async function list() {
        const box = el.querySelector("[data-flist]");
        try {
          const j = await CC.api("/friends");
          const row = (f, btns) => `<li>${avatar(f.name, f.avatar)}<a class="cm-name" href="${CC.profileUrl(f.handle)}">${esc(f.name)}<small>@${esc(f.handle)}</small></a>${f.xp != null ? `<span class="cm-pts">${fmt(f.xp)}<small>XP</small></span>` : ""}<span class="cm-btns">${btns}</span></li>`;
          const B = (a, h, l, c) => `<button type="button" class="cm-btn cm-sm ${c || ""}" data-act="${a}" data-h="${esc(h)}">${l}</button>`;
          box.innerHTML = (j.incoming.length ? `<h3 class="cm-h">Requests</h3><ul class="cm-rows">${j.incoming.map((f) => row(f, B("accept", f.handle, "Accept", "cm-primary") + B("decline", f.handle, "Decline"))).join("")}</ul>` : "")
            + `<h3 class="cm-h"><span>Friends</span> (${j.friends.length})</h3>` + (j.friends.length ? `<ul class="cm-rows">${j.friends.map((f) => row(f, B("remove", f.handle, "Remove") + B("block", f.handle, "Block"))).join("")}</ul>` : `<div class="cm-empty">No friends yet. Send a request using their exact handle.</div>`)
            + (j.outgoing.length ? `<h3 class="cm-h">Sent</h3><ul class="cm-rows">${j.outgoing.map((f) => row(f, B("remove", f.handle, "Cancel"))).join("")}</ul>` : "");
          box.querySelectorAll("[data-act]").forEach((b) => b.addEventListener("click", async () => {
            const a = b.dataset.act, h = b.dataset.h;
            if (a === "block" && !confirm(`Block @${h}? You'll stop seeing each other everywhere.`)) return;
            try {
              if (a === "accept" || a === "decline") await CC.api("/friends/respond", { body: { handle: h, accept: a === "accept" } });
              else if (a === "remove") await CC.api("/friends/remove", { body: { handle: h } });
              else await CC.api("/block", { body: { handle: h } });
              if (a === "accept" || a === "decline") { me = await CC.api("/me"); root.querySelector("#cmt-friends").innerHTML = "Friends" + (me.incoming ? ` <b class="cm-dot">${me.incoming}</b>` : ""); }
              list();
            } catch (e) { err.textContent = e.message; }
          }));
        } catch (e) { box.innerHTML = `<p class="cm-err">${esc(e.message)}</p>`; }
      }
    }

    // ---------------------------------------------------------------- my profile
    function profile() {
      const p = me.profile, el = panelEl(), have = new Set(p.badges.map((b) => b.id));
      el.innerHTML = `
        ${state.justJoined ? `<div class="cm-card cm-welcome" role="status"><strong><span>Welcome,</span> <span translate="no">@${esc(p.handle)}</span>!</strong> <span>Your device key below is the only way to restore this profile on another device. Keep it somewhere safe.</span></div>` : ""}
        <div class="cm-grid">
        <form class="cm-card cm-form" data-edit><h3>Profile</h3>
          <label>Display name<input name="display_name" maxlength="30" value="${esc(p.display_name === p.handle ? "" : p.display_name)}" placeholder="${esc(p.handle)}"></label>
          <label>Bio <span class="cm-opt">up to 140 characters, no links</span><textarea name="bio" maxlength="140" rows="2">${esc(p.bio)}</textarea></label>
          <fieldset><legend>Avatar colour</legend><div class="cm-swatches">${AVATARS.map((c) => `<label class="cm-swatch"><input type="radio" name="avatar" value="${c}" ${c === p.avatar ? "checked" : ""}><span style="background:${c}"></span></label>`).join("")}</div></fieldset>
          <fieldset><legend>Who can see you?</legend>${Object.keys(VIS).filter((k) => !(me.band === "teen" && k === "public")).map((k) => `<label class="cm-radio"><input type="radio" name="visibility" value="${k}" ${k === p.visibility ? "checked" : ""}><span><strong>${VIS[k][0]}</strong><small>${VIS[k][1]}</small></span></label>`).join("")}</fieldset>
          <div class="cm-actions"><button class="cm-btn cm-primary" type="submit">Save changes</button><a class="cm-btn" href="${CC.profileUrl(p.handle)}">View my page</a><button class="cm-btn" type="button" data-copy-link ${p.visibility === "public" ? "" : "disabled title=\"Only public profiles have a shareable link\""}>Copy share link</button></div><p class="cm-err" data-err role="alert"></p></form>
        <div class="cm-card"><h3>Badges <small>${p.badges.length}/${meta.badges.length}</small></h3>
          <ul class="cm-badges">${meta.badges.map((b) => `<li class="${have.has(b.id) ? "is-on" : ""}"><span class="cm-bi" aria-hidden="true">${b.icon}</span><span><strong>${esc(b.name)}</strong><small>${have.has(b.id) ? "Earned" : esc(b.desc)}</small></span></li>`).join("")}</ul>
          <h3>XP by subject</h3>${subjectBars(p)}</div>
        </div>
        <div class="cm-card cm-data"><h3>Your data and device key</h3>
          <p class="cm-hint">The server stores your handle, display name, bio, colour, visibility and the numbers shown on your profile. It does not store your email, your name, or your quiz questions. Quiz results stay on this device.</p>
          <div class="cm-keyrow"><label class="cm-sr" for="cm-key">Device key</label><input id="cm-key" type="password" readonly value="${esc(CC.saved().key)}"><button class="cm-btn cm-sm" type="button" data-show>Show</button><button class="cm-btn cm-sm" type="button" data-copy-key>Copy</button></div>
          <p class="cm-hint">Anyone with this key can act as you. Don't share it.</p>
          <div class="cm-actions"><button class="cm-btn" type="button" data-sync>Sync progress now</button><button class="cm-btn" type="button" data-leave>Leave and erase my profile</button></div></div>`;
      const f = el.querySelector("[data-edit]"), err = f.querySelector("[data-err]");
      f.addEventListener("submit", async (ev) => {
        ev.preventDefault(); err.textContent = "";
        try { const j = await CC.api("/me", { body: { display_name: f.display_name.value, bio: f.bio.value, avatar: f.avatar.value, visibility: f.visibility.value } }); me.profile = j.profile; state.justJoined = false; toast("Profile saved", { icon: "✅" }); await dashboard(); }
        catch (e) { err.textContent = e.message; }
      });
      el.querySelector("[data-copy-link]").addEventListener("click", () => copy(CC.shareUrl(p.handle)));
      el.querySelector("[data-show]").addEventListener("click", (ev) => { const i = el.querySelector("#cm-key"); i.type = i.type === "password" ? "text" : "password"; ev.target.textContent = i.type === "password" ? "Show" : "Hide"; });
      el.querySelector("[data-copy-key]").addEventListener("click", () => copy(CC.saved().key));
      el.querySelector("[data-sync]").addEventListener("click", async (ev) => { ev.target.disabled = true; const j = await CC.sync(true); ev.target.disabled = false; if (j) { (j.new_badges || []).forEach((b, i) => setTimeout(() => toast(`Badge earned: ${b.name}`, { icon: b.icon, type: "trophy" }), i * 500)); toast("Progress synced", { icon: "🔄" }); await refresh(); } else toast("Couldn't sync just now. Try again in a minute."); });
      el.querySelector("[data-leave]").addEventListener("click", async () => {
        if (!confirm("Erase your community profile, friends and leaderboard entries? This can't be undone. Your quizzes on this device are kept.")) return;
        try { await CC.api("/me", { method: "DELETE" }); CC.forget(); me = null; toast("Your community profile was erased", { icon: "🗑️" }); joinForm(); } catch (e) { err.textContent = e.message; }
      });
    }
    function subjectBars(p) {
      if (!p.subjects.length) return `<p class="cm-hint">Take a quiz and your subjects appear here.</p>`;
      const max = Math.max(...p.subjects.map((s) => s.xp), 1);
      return `<ul class="cm-bars">${p.subjects.map((s) => `<li><span>${esc(s.subject)}</span><span class="cm-bar"><i style="width:${Math.max(4, (s.xp / max) * 100)}%"></i></span><b>${fmt(s.xp)}</b></li>`).join("")}</ul>`;
    }
    async function copy(t) { try { await navigator.clipboard.writeText(t); toast("Copied", { icon: "📋" }); } catch (_) { window.prompt("Copy this:", t); } }
  });
})();
