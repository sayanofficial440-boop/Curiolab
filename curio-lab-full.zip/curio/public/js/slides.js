// Curio Lab — Slides mode
window.onLessonContentReady(() => {
  const frame = document.querySelector("[data-slide-frame]");
  if (!frame) return;

  let slides = [];
  try {
    slides = JSON.parse(document.querySelector("[data-slide-deck]").textContent);
  } catch (e) {
    slides = [];
  }
  // Randomize the order each time the lesson is opened.
  for (let k = slides.length - 1; k > 0; k--) {
    const j = Math.floor(Math.random() * (k + 1));
    [slides[k], slides[j]] = [slides[j], slides[k]];
  }
  let i = 0;
  let autoplay = false;
  let autoplayId = null;
  const AUTOPLAY_MS = 6000;

  const eyebrow = frame.querySelector("[data-slide-eyebrow]");
  const heading = frame.querySelector("[data-slide-title]");
  const body = frame.querySelector("[data-slide-body]");
  const dotsWrap = document.querySelector("[data-slide-dots]");
  const prevBtn = document.querySelector("[data-slide-prev]");
  const nextBtn = document.querySelector("[data-slide-next]");
  const controls = frame.querySelector(".slide-controls");

  const autoplayBtn = document.createElement("button");
  autoplayBtn.type = "button";
  autoplayBtn.className = "timer-btn slide-autoplay";
  autoplayBtn.textContent = "▶ Autoplay";
  controls?.insertBefore(autoplayBtn, dotsWrap);

  function renderDots() {
    if (!dotsWrap) return;
    dotsWrap.innerHTML = "";
    slides.forEach((_, idx) => {
      const dot = document.createElement("span");
      if (idx === i) dot.classList.add("active");
      dotsWrap.appendChild(dot);
    });
  }

  function render() {
    eyebrow.textContent = `Slide ${i + 1} of ${slides.length}`;
    heading.textContent = slides[i].title;
    body.textContent = slides[i].body;
    renderDots();
  }

  function goPrev() { i = (i - 1 + slides.length) % slides.length; render(); }
  function goNext() { i = (i + 1) % slides.length; render(); }

  function stopAutoplay() {
    autoplay = false;
    autoplayBtn.textContent = "▶ Autoplay";
    autoplayBtn.classList.remove("active");
    clearInterval(autoplayId);
  }
  function startAutoplay() {
    autoplay = true;
    autoplayBtn.textContent = "⏸ Autoplay";
    autoplayBtn.classList.add("active");
    clearInterval(autoplayId);
    autoplayId = setInterval(goNext, AUTOPLAY_MS);
  }

  autoplayBtn.addEventListener("click", () => { autoplay ? stopAutoplay() : startAutoplay(); });
  prevBtn?.addEventListener("click", () => { if (autoplay) stopAutoplay(); goPrev(); });
  nextBtn?.addEventListener("click", () => { if (autoplay) stopAutoplay(); goNext(); });

  // Auto-pause when the tab is hidden; resume only if the user had it on.
  let wasAutoplayingBeforeHide = false;
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      wasAutoplayingBeforeHide = autoplay;
      if (autoplay) { clearInterval(autoplayId); }
    } else if (wasAutoplayingBeforeHide && autoplay) {
      autoplayId = setInterval(goNext, AUTOPLAY_MS);
    }
  });

  if (slides.length) render();
});
