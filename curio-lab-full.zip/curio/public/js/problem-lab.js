// Curio Lab — Problem Lab.
// Endless generated problems with worked solutions for Maths, Physics, Chemistry and Computer Science.
// Every problem comes from a generator: f(R, level, P) -> { q, a, u?, t?, tol?, f?, st[] }
//   R(a,b) random int · P(list) random pick · level 0/1/2 = Easy/Medium/Hard
//   a = answer (number, or string when t:"text") · u = unit · tol = relative tolerance · f = hint · st = worked steps
// To add a topic, push one more object onto GENS — the Practice hub and sidebar pick it up automatically.
(function () {
  "use strict";
  if (window.CurioProblemLab) return;
  const S = window.CurioPracticeStore;
  const sg = (n) => (n < 0 ? " − " : " + ") + Math.abs(n);
  const fm = (n) => (Math.abs(n) >= 1e6 || (n !== 0 && Math.abs(n) < 1e-3) ? n.toExponential(2).replace("e+", "e") : String(+n.toFixed(2)));
  const sb = (s) => s.replace(/\d+/g, "<sub>$&</sub>");
  const sum = (a) => a.reduce((s, x) => s + x, 0);
  const fd = (a, b) => Math.floor(a / b);

  // ---- chemistry helpers ----
  const AM = { H: 1, C: 12, N: 14, O: 16, Na: 23, Mg: 24, Al: 27, S: 32, Cl: 35.5, K: 39, Ca: 40, Mn: 55, Fe: 56, Cu: 63.5, Zn: 65 };
  const AMTXT = "Atomic masses: H 1, C 12, N 14, O 16, Na 23, Mg 24, Al 27, S 32, Cl 35.5, K 39, Ca 40, Mn 55, Fe 56, Cu 63.5, Zn 65";
  function cnt(f) {
    const st = [{}], re = /([A-Z][a-z]?)(\d*)|(\()|\)(\d*)/g; let m;
    while ((m = re.exec(f))) {
      if (m[1]) { const c = st[st.length - 1]; c[m[1]] = (c[m[1]] || 0) + (+m[2] || 1); }
      else if (m[3]) st.push({});
      else { const t = st.pop(), n = +m[4] || 1, c = st[st.length - 1]; for (const e in t) c[e] = (c[e] || 0) + t[e] * n; }
    }
    return st[0];
  }
  const mm = (f) => Object.entries(cnt(f)).reduce((s, [e, n]) => s + AM[e] * n, 0);
  const COMPOUNDS = ["H2O", "CO2", "NaCl", "CaCO3", "H2SO4", "Mg(OH)2", "Al2(SO4)3", "NH3", "C6H12O6", "KMnO4", "NaOH", "HCl", "(NH4)2SO4", "Ca(OH)2", "CuSO4", "Fe2O3"];
  const RXNS = [
    { r: [[2, "H2"], [1, "O2"]], p: [[2, "H2O"]] }, { r: [[2, "Mg"], [1, "O2"]], p: [[2, "MgO"]] },
    { r: [[1, "CaCO3"]], p: [[1, "CaO"], [1, "CO2"]] }, { r: [[1, "N2"], [3, "H2"]], p: [[2, "NH3"]] },
    { r: [[1, "Zn"], [2, "HCl"]], p: [[1, "ZnCl2"], [1, "H2"]] }, { r: [[1, "CH4"], [2, "O2"]], p: [[1, "CO2"], [2, "H2O"]] },
  ];
  const side = (a) => a.map(([c, f]) => (c > 1 ? c : "") + sb(f)).join(" + ");

  const GENS = [
    // ================= MATHEMATICS =================
    { id: "m-linear", s: "Mathematics", t: "Linear equations", f: (R, l, P) => {
      let x, a = R(2, 9), b = R(1, 15) * P([1, -1]), c, d;
      if (l === 0) { x = R(-9, 12); return { q: `Solve for x: ${a}x = ${a * x}`, a: x, f: "Divide both sides by the coefficient of x.", st: [`x = ${a * x} ÷ ${a} = <strong>${x}</strong>`] }; }
      if (l === 1) { x = R(-9, 12); return { q: `Solve for x: ${a}x${sg(b)} = ${a * x + b}`, a: x, f: "Undo the constant first, then divide.", st: [`Move ${b} across: ${a}x = ${a * x + b} ${b < 0 ? "+" : "−"} ${Math.abs(b)} = ${a * x}`, `x = ${a * x} ÷ ${a} = <strong>${x}</strong>`] }; }
      do { x = R(-9, 12); a = R(2, 9); c = R(1, 9); if (c === a) c++; d = a * x + b - c * x; } while (d === 0);
      return { q: `Solve for x: ${a}x${sg(b)} = ${c}x${sg(d)}`, a: x, f: "Collect the x terms on one side.", st: [`Collect x terms: (${a} − ${c})x = ${d} − (${b})`, `${a - c}x = ${d - b}`, `x = ${d - b} ÷ ${a - c} = <strong>${x}</strong>`] };
    } },
    { id: "m-quad", s: "Mathematics", t: "Quadratic equations", f: (R, l) => {
      let p = R(l ? -8 : 1, 9), q = R(l ? -8 : 1, 9); if (p === q) q += 1; if (p + q === 0) q += 1;
      const k = l === 2 ? R(2, 3) : 1, B = -k * (p + q), C = k * p * q, hi = Math.max(p, q), fac = (r) => (r === 0 ? "x" : `(x${sg(-r)})`);
      return { q: `Solve ${k > 1 ? k : ""}x² ${B < 0 ? "−" : "+"} ${Math.abs(B)}x${C ? ` ${C < 0 ? "−" : "+"} ${Math.abs(C)}` : ""} = 0. Enter the <b>larger</b> root.`, a: hi, f: "Factorise: find two numbers that add to the middle term and multiply to the constant.",
        st: [`Factorise: ${k > 1 ? k : ""}${fac(p)}${fac(q)} = 0`, `So x = ${p} or x = ${q}`, `The larger root is <strong>${hi}</strong>`] };
    } },
    { id: "m-percent", s: "Mathematics", t: "Percentages", f: (R, l, P) => {
      if (l === 0) { const p = P([5, 10, 15, 20, 25, 30, 40, 60, 75]), N = R(2, 40) * 20; return { q: `What is ${p}% of ${N}?`, a: p * N / 100, f: "Percent means 'out of 100'.", st: [`${p}/100 × ${N} = <strong>${p * N / 100}</strong>`] }; }
      if (l === 1) { const A = R(2, 20) * 20, pc = P([10, 20, 25, 30, 40, 50]), up = P([1, -1]), B = A * (1 + up * pc / 100); return { q: `A price changes from ${A} to ${B}. What is the percentage ${up > 0 ? "increase" : "decrease"}?`, a: pc, u: "%", f: "Change ÷ original × 100", st: [`Change = ${Math.abs(B - A)}`, `${Math.abs(B - A)} ÷ ${A} × 100 = <strong>${pc}%</strong>`] }; }
      const O = R(3, 30) * 20, d = P([10, 20, 25, 40]), sale = O * (1 - d / 100);
      return { q: `After a ${d}% discount a jacket costs $${sale}. What was the original price ($)?`, a: O, f: "The sale price is (100 − d)% of the original.", st: [`Sale price = ${100 - d}% of original, so original × ${(100 - d) / 100} = ${sale}`, `Original = ${sale} ÷ ${(100 - d) / 100} = <strong>$${O}</strong>`] };
    } },
    { id: "m-pythag", s: "Mathematics", t: "Pythagoras' theorem", f: (R, l, P) => {
      const T = [[3, 4, 5], [5, 12, 13], [8, 15, 17], [7, 24, 25], [20, 21, 29]];
      if (l === 2) { const a = R(3, 15), b = R(3, 15), c = Math.sqrt(a * a + b * b); return { q: `A right-angled triangle has legs ${a} and ${b}. Find the hypotenuse (2 d.p.).`, a: c, f: "c² = a² + b²", st: [`c² = ${a}² + ${b}² = ${a * a + b * b}`, `c = √${a * a + b * b} = <strong>${fm(c)}</strong>`] }; }
      const k = R(1, l ? 4 : 2), [a, b, c] = P(T).map((v) => v * k);
      if (l === 0) return { q: `A right-angled triangle has legs ${a} and ${b}. Find the hypotenuse.`, a: c, f: "c² = a² + b²", st: [`c² = ${a}² + ${b}² = ${a * a + b * b}`, `c = <strong>${c}</strong>`] };
      return { q: `The hypotenuse of a right-angled triangle is ${c} and one leg is ${a}. Find the other leg.`, a: b, f: "b² = c² − a²", st: [`b² = ${c}² − ${a}² = ${c * c - a * a}`, `b = <strong>${b}</strong>`] };
    } },
    { id: "m-trig", s: "Mathematics", t: "Trigonometry", f: (R) => {
      return null;
    } },
    { id: "m-stats", s: "Mathematics", t: "Mean, median & range", f: (R, l, P) => {
      const n = l === 2 ? 6 : l === 1 ? 7 : 5, v = Array.from({ length: n }, () => R(2, 30)), kind = l === 0 ? P(["mean", "range"]) : "median";
      if (kind === "mean") v[n - 1] += (n - (sum(v) % n)) % n;
      const sorted = v.slice().sort((x, y) => x - y), list = v.join(", ");
      if (kind === "mean") return { q: `Find the mean of: ${list}`, a: sum(v) / n, f: "Mean = total ÷ count", st: [`Total = ${sum(v)}`, `Mean = ${sum(v)} ÷ ${n} = <strong>${sum(v) / n}</strong>`] };
      if (kind === "range") return { q: `Find the range of: ${list}`, a: sorted[n - 1] - sorted[0], f: "Range = largest − smallest", st: [`Largest ${sorted[n - 1]}, smallest ${sorted[0]}`, `Range = <strong>${sorted[n - 1] - sorted[0]}</strong>`] };
      const med = n % 2 ? sorted[(n - 1) / 2] : (sorted[n / 2 - 1] + sorted[n / 2]) / 2;
      return { q: `Find the median of: ${list}`, a: med, f: "Order the values first; the median is the middle one (or the mean of the middle two).", st: [`Ordered: ${sorted.join(", ")}`, n % 2 ? `Middle value = <strong>${med}</strong>` : `Mean of the middle two (${sorted[n / 2 - 1]} and ${sorted[n / 2]}) = <strong>${med}</strong>`] };
    } },

    // ================= PHYSICS =================
    { id: "p-kinematics", s: "Physics", t: "Motion & kinematics", f: (R) => {
      return null;
    } },
    { id: "p-dynamics", s: "Physics", t: "Force, work & energy", f: (R, l) => {
      if (l === 0) { const m = R(2, 40), a = R(1, 9); return { q: `A ${m} kg trolley accelerates at ${a} m/s². What force acts on it?`, a: m * a, u: "N", f: "F = ma", st: [`F = ${m} × ${a} = <strong>${m * a} N</strong>`] }; }
      if (l === 1) { const m = R(2, 20), v = R(2, 15); return { q: `Find the kinetic energy of a ${m} kg object moving at ${v} m/s.`, a: m * v * v / 2, u: "J", f: "KE = ½mv²", st: [`KE = ½ × ${m} × ${v}² = <strong>${m * v * v / 2} J</strong>`] }; }
      const h = R(5, 80), v = Math.sqrt(2 * 9.8 * h);
      return { q: `A stone falls from rest through ${h} m. How fast is it moving just before it lands? (g = 9.8 m/s², ignore air resistance; 1 d.p.)`, a: v, u: "m/s", f: "Energy: mgh = ½mv², so v = √(2gh)", st: [`mgh = ½mv² ⇒ v = √(2gh)`, `v = √(2 × 9.8 × ${h}) = √${fm(2 * 9.8 * h)} = <strong>${fm(v)} m/s</strong>`] };
    } },
    { id: "p-circuits", s: "Physics", t: "Electric circuits", f: (R) => {
      return null;
    } },
    { id: "p-momentum", s: "Physics", t: "Momentum", f: (R, l) => {
      if (l === 0) { const m = R(2, 50), v = R(2, 20); return { q: `Find the momentum of a ${m} kg cart moving at ${v} m/s.`, a: m * v, u: "kg m/s", f: "p = mv", st: [`p = ${m} × ${v} = <strong>${m * v} kg m/s</strong>`] }; }
      if (l === 1) { const m1 = R(1, 8), u1 = R(2, 12), m2 = R(1, 8), v = m1 * u1 / (m1 + m2); return { q: `A ${m1} kg trolley moving at ${u1} m/s hits a stationary ${m2} kg trolley and they stick together. Find their common speed (2 d.p.).`, a: v, u: "m/s", f: "Momentum before = momentum after", st: [`${m1} × ${u1} = (${m1} + ${m2}) × v`, `v = ${m1 * u1} ÷ ${m1 + m2} = <strong>${fm(v)} m/s</strong>`] }; }
      const M = R(2, 8), g = R(10, 50), vb = R(200, 500), vr = g / 1000 * vb / M;
      return { q: `A ${M} kg gun fires a ${g} g bullet at ${vb} m/s. Find the gun's recoil speed (2 d.p.).`, a: vr, u: "m/s", f: "Total momentum stays zero. Convert grams to kg.", st: [`Bullet momentum = ${g / 1000} × ${vb} = ${fm(g / 1000 * vb)} kg m/s`, `Gun has equal and opposite momentum: v = ${fm(g / 1000 * vb)} ÷ ${M} = <strong>${fm(vr)} m/s</strong>`] };
    } },
    { id: "p-waves", s: "Physics", t: "Waves & sound", f: (R) => {
      return null;
    } },

    // ================= CHEMISTRY =================
    { id: "c-molarmass", s: "Chemistry", t: "Molar mass", f: (R, l, P) => {
      const f = P(COMPOUNDS), c = cnt(f), parts = Object.entries(c).map(([e, n]) => `${n} × ${AM[e]}`), M = mm(f);
      return { q: `Find the molar mass of ${sb(f)} (g/mol).`, a: M, u: "g/mol", f: AMTXT, st: [`Count atoms: ${Object.entries(c).map(([e, n]) => e + n).join(", ")}`, `M = ${parts.join(" + ")} = <strong>${fm(M)} g/mol</strong>`] };
    } },
    { id: "c-moles", s: "Chemistry", t: "The mole", f: (R, l, P) => {
      const f = P(COMPOUNDS), M = mm(f), F = sb(f);
      if (l === 0) { const n = R(1, 8) / 2, m = n * M; return { q: `How many moles are in ${fm(m)} g of ${F}?`, a: n, u: "mol", f: "n = m ÷ M · " + AMTXT, st: [`M(${F}) = ${fm(M)} g/mol`, `n = ${fm(m)} ÷ ${fm(M)} = <strong>${n} mol</strong>`] }; }
      if (l === 1) { const n = R(1, 12) / 4; return { q: `What is the mass of ${n} mol of ${F}?`, a: n * M, u: "g", f: "m = n × M · " + AMTXT, st: [`M(${F}) = ${fm(M)} g/mol`, `m = ${n} × ${fm(M)} = <strong>${fm(n * M)} g</strong>`] }; }
      const m = R(2, 40) * 5, N = m / M * 6.022e23;
      return { q: `How many molecules are in ${m} g of ${F}? Enter as e.g. 1.2e23. (Avogadro: 6.022 × 10²³ per mol)`, a: N, tol: 0.01, f: "N = (m ÷ M) × 6.022×10²³ · " + AMTXT, st: [`M(${F}) = ${fm(M)} g/mol, so n = ${m} ÷ ${fm(M)} = ${fm(m / M)} mol`, `N = ${fm(m / M)} × 6.022×10²³ = <strong>${fm(N)}</strong>`] };
    } },
    { id: "c-stoich", s: "Chemistry", t: "Reacting masses", f: (R, l, P) => {
      const x = P(RXNS), A = P(x.r), B = P(x.p), MA = mm(A[1]), MB = mm(B[1]), mA = MA * A[0] * P([0.5, 1, 2]), mB = mA / MA * B[0] / A[0] * MB;
      return { q: `${side(x.r)} → ${side(x.p)}<br>What mass of ${sb(B[1])} forms when ${fm(mA)} g of ${sb(A[1])} reacts completely?`, a: mB, u: "g", f: "Mass → moles → mole ratio → mass. " + AMTXT,
        st: [`Moles of ${sb(A[1])} = ${fm(mA)} ÷ ${fm(MA)} = ${fm(mA / MA)} mol`, `Ratio ${sb(A[1])} : ${sb(B[1])} = ${A[0]} : ${B[0]}, so moles of ${sb(B[1])} = ${fm(mA / MA * B[0] / A[0])} mol`, `Mass = ${fm(mA / MA * B[0] / A[0])} × ${fm(MB)} = <strong>${fm(mB)} g</strong>`] };
    } },
    { id: "c-ph", s: "Chemistry", t: "pH calculations", f: (R, l, P) => {
      const n = R(l === 2 ? 1 : 2, 9), a = P([1.5, 2, 2.5, 3, 4, 5, 6, 8]);
      if (l === 0) return { q: `[H⁺] = 1 × 10<sup>−${n}</sup> mol/L. Find the pH.`, a: n, f: "pH = −log₁₀[H⁺]", st: [`pH = −log(10<sup>−${n}</sup>) = <strong>${n}</strong>`] };
      if (l === 1) return { q: `[H⁺] = ${a} × 10<sup>−${n}</sup> mol/L. Find the pH (2 d.p.).`, a: n - Math.log10(a), f: "pH = −log₁₀[H⁺]", st: [`pH = −log(${a}) − log(10<sup>−${n}</sup>) = ${fm(-Math.log10(a))} + ${n}`, `pH = <strong>${fm(n - Math.log10(a))}</strong>`] };
      const c = a * Math.pow(10, -Math.min(n, 3));
      return { q: `A solution of NaOH has [OH⁻] = ${a} × 10<sup>−${Math.min(n, 3)}</sup> mol/L. Find its pH at 25 °C (2 d.p.).`, a: 14 + Math.log10(c), f: "pOH = −log₁₀[OH⁻], and pH + pOH = 14", st: [`pOH = −log(${a} × 10<sup>−${Math.min(n, 3)}</sup>) = ${fm(-Math.log10(c))}`, `pH = 14 − ${fm(-Math.log10(c))} = <strong>${fm(14 + Math.log10(c))}</strong>`] };
    } },
    { id: "c-dilution", s: "Chemistry", t: "Dilution", f: (R, l, P) => {
      if (l < 2) { const C1 = R(2, 12), V1 = R(1, 10) * 10, k = R(2, 5); return { q: `${V1} mL of ${C1} mol/L solution is diluted with water to ${V1 * k} mL. What is the new concentration?`, a: C1 / k, u: "mol/L", f: "C₁V₁ = C₂V₂", st: [`${C1} × ${V1} = C₂ × ${V1 * k}`, `C₂ = ${C1 * V1} ÷ ${V1 * k} = <strong>${fm(C1 / k)} mol/L</strong>`] }; }
      const C1 = P([2, 4, 5, 10]), C2 = P([0.1, 0.2, 0.5, 1]), V2 = P([100, 250, 500]), V1 = C2 * V2 / C1;
      return { q: `How many mL of ${C1} mol/L stock solution are needed to make ${V2} mL of ${C2} mol/L solution?`, a: V1, u: "mL", f: "C₁V₁ = C₂V₂", st: [`${C1} × V₁ = ${C2} × ${V2}`, `V₁ = ${fm(C2 * V2)} ÷ ${C1} = <strong>${fm(V1)} mL</strong>`] };
    } },

    // ================= COMPUTER SCIENCE =================
    { id: "cs-base", s: "Computer Science", t: "Number bases", f: (R, l) => {
      if (l === 0) { const n = R(5, 63), b = n.toString(2); return { q: `Convert the binary number ${b} to decimal.`, a: n, f: "Each place is worth double the one to its right: …, 8, 4, 2, 1", st: [`${b.split("").map((d, i) => d + "×" + Math.pow(2, b.length - 1 - i)).join(" + ")}`, `= <strong>${n}</strong>`] }; }
      if (l === 1) { let n = R(10, 127), x = n; const rem = []; while (x > 0) { rem.push(`${x} ÷ 2 = ${fd(x, 2)} r ${x % 2}`); x = fd(x, 2); } return { q: `Convert the decimal number ${n} to binary.`, t: "text", a: n.toString(2), f: "Divide by 2 repeatedly; read the remainders from bottom to top.", st: rem.concat([`Remainders bottom→top: <strong>${n.toString(2)}</strong>`]) }; }
      const n = R(32, 255), h = n.toString(16).toUpperCase();
      return { q: `Convert the decimal number ${n} to hexadecimal.`, t: "text", a: h, f: "Divide by 16; remainders 10–15 are A–F.", st: [`${n} ÷ 16 = ${fd(n, 16)} remainder ${n % 16} (${(n % 16).toString(16).toUpperCase()})`, `${fd(n, 16)} → ${fd(n, 16).toString(16).toUpperCase()}`, `Hex: <strong>${h}</strong>`] };
    } },
    { id: "cs-loops", s: "Computer Science", t: "Tracing loops", f: (R, l) => {
      const a = R(0, 4), b = a + R(5, 10), s = l ? R(2, 3) : 1, k = l === 2 ? 2 : 0, vals = []; let t = 0;
      for (let i = a; i < b; i += s) { if (k && i % k) continue; vals.push(i); t += i; }
      const code = `total = 0\nfor i in range(${a}, ${b}${s > 1 ? ", " + s : ""}):\n${k ? `    if i % ${k} == 0:\n        total += i` : "    total += i"}\nprint(total)`;
      return { q: `What does this program print?<pre class="pl-code">${code}</pre>`, a: t, f: "range(start, stop, step) stops <em>before</em> stop.", st: [`i takes the values ${[...Array(Math.ceil((b - a) / s))].map((_, j) => a + j * s).join(", ")}`, k ? `Only even i are added: ${vals.join(" + ") || "nothing"}` : `Adding them: ${vals.join(" + ")}`, `total = <strong>${t}</strong>`] };
    } },
    { id: "cs-pyops", s: "Computer Science", t: "Python operators", f: (R, l, P) => {
      const b = R(3, 9), a = R(10, 60) * (l === 2 ? -1 : 1), op = l === 0 ? "//" : l === 2 ? P(["//", "%"]) : P(["//", "%", "**"]);
      if (op === "**") { const e = R(2, 4); return { q: `In Python, what does <code>print(${b} ** ${e})</code> display?`, a: Math.pow(b, e), f: "** means 'to the power of'.", st: [`${b}<sup>${e}</sup> = <strong>${Math.pow(b, e)}</strong>`] }; }
      const r = op === "//" ? fd(a, b) : a - b * fd(a, b);
      return { q: `In Python, what does <code>print(${a} ${op} ${b})</code> display?`, a: r, f: "// rounds the quotient down (floor). % is what is left over, with the sign of the divisor.", st: [`${a} ÷ ${b} = ${fm(a / b)}, rounded down = ${fd(a, b)}`, op === "//" ? `Answer: <strong>${r}</strong>` : `${a} − ${b} × ${fd(a, b)} = <strong>${r}</strong>`] };
    } },
    { id: "cs-binsearch", s: "Computer Science", t: "Binary search", f: (R) => {
      const arr = [], n = R(8, 15); let v = R(1, 5); for (let i = 0; i < n; i++) { arr.push(v); v += R(2, 6); }
      const target = arr[R(0, arr.length - 1)], st = []; let lo = 0, hi = arr.length - 1, c = 0;
      while (lo <= hi) { const mid = fd(lo + hi, 2); c++; if (arr[mid] === target) { st.push(`Check #${c}: middle = ${arr[mid]} → found`); break; } if (arr[mid] < target) { st.push(`Check #${c}: middle = ${arr[mid]} < ${target} → search right half`); lo = mid + 1; } else { st.push(`Check #${c}: middle = ${arr[mid]} > ${target} → search left half`); hi = mid - 1; } }
      return { q: `Binary search looks for ${target} in the sorted list [${arr.join(", ")}]. Each step checks the middle item (lower middle if there are two). How many items are checked, including the one found?`, a: c, f: "Halve the search range each time: mid = (low + high) ÷ 2, rounded down.", st: st.concat([`Total checks: <strong>${c}</strong>`]) };
    } },
    { id: "cs-bubble", s: "Computer Science", t: "Bubble sort", f: (R) => {
      const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9].sort(() => R(0, 1) - 0.5).slice(0, R(5, 6)), a = arr.slice(), st = []; let swaps = 0;
      for (let p = 0; p < a.length - 1; p++) { let s = 0; for (let i = 0; i < a.length - 1 - p; i++) if (a[i] > a[i + 1]) { [a[i], a[i + 1]] = [a[i + 1], a[i]]; s++; } swaps += s; st.push(`After pass ${p + 1}: [${a.join(", ")}] (${s} swap${s === 1 ? "" : "s"})`); if (!s) break; }
      return { q: `Bubble sort (swap neighbours when left > right, repeat passes) sorts [${arr.join(", ")}] into ascending order. How many swaps happen in total?`, a: swaps, f: "Each swap fixes exactly one out-of-order pair.", st: st.concat([`Total swaps: <strong>${swaps}</strong>`]) };
    } },
  ];

  // Generators that need two shared patterns are defined below to keep the table above readable.
  function fill(id, fn) { GENS.find((g) => g.id === id).f = fn; }
  fill("m-trig", (R, l) => {
    const th = R(20, 70), h = R(5, 30), rad = th * Math.PI / 180;
    if (l < 2) { const sin = l === 0, v = sin ? Math.sin(rad) : Math.cos(rad), side = h * v; return { q: `In a right-angled triangle the hypotenuse is ${h} cm and θ = ${th}°. Find the side ${sin ? "opposite" : "adjacent"} to θ (2 d.p.).`, a: side, u: "cm", f: sin ? "sin θ = opposite ÷ hypotenuse" : "cos θ = adjacent ÷ hypotenuse", st: [`${sin ? "sin" : "cos"} ${th}° = ${fm(v)}`, `side = ${h} × ${fm(v)} = <strong>${fm(side)} cm</strong>`] }; }
    const o = R(3, 9), hy = o + R(2, 9), ang = Math.asin(o / hy) * 180 / Math.PI;
    return { q: `A ladder ${hy} m long reaches ${o} m up a wall. Find the angle it makes with the ground (1 d.p.).`, a: ang, u: "°", f: "sin θ = opposite ÷ hypotenuse", st: [`sin θ = ${o} ÷ ${hy} = ${fm(o / hy)}`, `θ = sin⁻¹(${fm(o / hy)}) = <strong>${fm(ang)}°</strong>`] };
  });
  fill("p-kinematics", (R, l) => {
    const u = R(0, 15), a = R(1, 6), t = R(2, 10), v = u + a * t;
    if (l === 0) return { q: `A car moving at ${u} m/s accelerates at ${a} m/s² for ${t} s. Find its final speed.`, a: v, u: "m/s", f: "v = u + at", st: [`v = ${u} + ${a} × ${t} = <strong>${v} m/s</strong>`] };
    if (l === 1) return { q: `A car moving at ${u} m/s accelerates at ${a} m/s² for ${t} s. How far does it travel?`, a: u * t + a * t * t / 2, u: "m", f: "s = ut + ½at²", st: [`s = ${u} × ${t} + ½ × ${a} × ${t}² = ${u * t} + ${a * t * t / 2}`, `s = <strong>${u * t + a * t * t / 2} m</strong>`] };
    return { q: `A cyclist at ${u} m/s accelerates uniformly at ${a} m/s² until reaching ${v} m/s. How long does this take?`, a: t, u: "s", f: "v = u + at, rearranged for t", st: [`t = (v − u) ÷ a = (${v} − ${u}) ÷ ${a} = <strong>${t} s</strong>`] };
  });
  fill("p-circuits", (R, l) => {
    if (l === 0) { const I = R(1, 6), r = R(2, 20); return { q: `A ${r} Ω resistor is connected across ${I * r} V. What current flows?`, a: I, u: "A", f: "V = IR", st: [`I = V ÷ R = ${I * r} ÷ ${r} = <strong>${I} A</strong>`] }; }
    if (l === 1) { const r = [R(2, 12), R(2, 12), R(2, 12)], V = R(6, 36), Rt = sum(r); return { q: `Resistors of ${r.join(" Ω, ")} Ω are in series across a ${V} V supply. Find the current (2 d.p.).`, a: V / Rt, u: "A", f: "Series: R_total = R₁ + R₂ + R₃, then I = V ÷ R", st: [`R_total = ${r.join(" + ")} = ${Rt} Ω`, `I = ${V} ÷ ${Rt} = <strong>${fm(V / Rt)} A</strong>`] }; }
    const r1 = R(2, 20), r2 = R(2, 20), Re = r1 * r2 / (r1 + r2);
    return { q: `Two resistors, ${r1} Ω and ${r2} Ω, are connected in parallel. Find the combined resistance (2 d.p.).`, a: Re, u: "Ω", f: "Parallel: R = (R₁ × R₂) ÷ (R₁ + R₂)", st: [`R = (${r1} × ${r2}) ÷ (${r1} + ${r2}) = ${r1 * r2} ÷ ${r1 + r2} = <strong>${fm(Re)} Ω</strong>`] };
  });
  fill("p-waves", (R, l) => {
    if (l === 0) { const f = R(2, 50), w = R(1, 9); return { q: `A wave has frequency ${f} Hz and wavelength ${w} m. Find its speed.`, a: f * w, u: "m/s", f: "v = fλ", st: [`v = ${f} × ${w} = <strong>${f * w} m/s</strong>`] }; }
    if (l === 1) { const f = R(1, 10) * 100, w = 340 / f; return { q: `Sound travels at 340 m/s. Find the wavelength of a ${f} Hz note (2 d.p.).`, a: w, u: "m", f: "λ = v ÷ f", st: [`λ = 340 ÷ ${f} = <strong>${fm(w)} m</strong>`] }; }
    const t = R(1, 8); return { q: `A shout is heard as an echo after ${t} s. The speed of sound is 340 m/s. How far away is the reflecting wall?`, a: 170 * t, u: "m", f: "The sound travels there and back: d = vt ÷ 2", st: [`Total distance = 340 × ${t} = ${340 * t} m`, `Wall is half of that: <strong>${170 * t} m</strong>`] };
  });

  // ================= MORE TOPICS (batch 2) =================
  const gcd = (a, b) => (b ? gcd(b, a % b) : a), lcm = (a, b) => a / gcd(a, b) * b;
  const pn = (n) => (n < 0 ? `(${n})` : String(n)), PI = Math.PI, ifrac = (n, d) => { const g = gcd(Math.abs(n), d); return d / g === 1 ? String(n / g) : n / g + "/" + d / g; };
  const TRI = [[3, 4, 5], [5, 12, 13], [8, 15, 17], [6, 8, 10]];
  GENS.push(
    { id: "m-mensur", s: "Mathematics", t: "Mensuration", f: (R, l, P) => {
      if (l === 0) { const w = R(3, 20), h = R(3, 20); return P([0, 1]) ? { q: `A rectangle is ${w} cm by ${h} cm. Find its area.`, a: w * h, u: "cm²", f: "Area = length × width", st: [`${w} × ${h} = <strong>${w * h} cm²</strong>`] } : { q: `A rectangle is ${w} cm by ${h} cm. Find its perimeter.`, a: 2 * (w + h), u: "cm", f: "Perimeter = 2(length + width)", st: [`2 × (${w} + ${h}) = <strong>${2 * (w + h)} cm</strong>`] }; }
      const r = R(2, 15);
      if (l === 1) return P([0, 1]) ? { q: `Find the area of a circle of radius ${r} cm (π = 3.14159, 2 d.p.).`, a: PI * r * r, u: "cm²", f: "A = πr²", st: [`A = π × ${r}² = π × ${r * r} = <strong>${fm(PI * r * r)} cm²</strong>`] } : { q: `Find the circumference of a circle of radius ${r} cm (π = 3.14159, 2 d.p.).`, a: 2 * PI * r, u: "cm", f: "C = 2πr", st: [`C = 2 × π × ${r} = <strong>${fm(2 * PI * r)} cm</strong>`] };
      const h = R(3, 20); return P([0, 1]) ? { q: `A cylinder has radius ${r} cm and height ${h} cm. Find its volume (2 d.p.).`, a: PI * r * r * h, u: "cm³", f: "V = πr²h", st: [`V = π × ${r}² × ${h} = π × ${r * r * h} = <strong>${fm(PI * r * r * h)} cm³</strong>`] } : { q: `A cone has radius ${r} cm and height ${h} cm. Find its volume (2 d.p.).`, a: PI * r * r * h / 3, u: "cm³", f: "V = ⅓πr²h", st: [`V = ⅓ × π × ${r}² × ${h} = <strong>${fm(PI * r * r * h / 3)} cm³</strong>`] };
    } },
    { id: "m-prob", s: "Mathematics", t: "Probability", f: (R, l, P) => {
      if (l === 0) { const r = R(1, 9), b = R(1, 9), g = R(0, 6), t = r + b + g; return { q: `A bag holds ${r} red, ${b} blue and ${g} green marbles. One is picked at random. What is the probability it is red? (fraction or decimal)`, a: r / t, f: "P = favourable outcomes ÷ total outcomes", st: [`Total marbles = ${t}`, `P(red) = ${r}/${t} = <strong>${ifrac(r, t)}</strong>`] }; }
      if (l === 1) { const k = R(3, 11); let w = 0; for (let i = 1; i <= 6; i++) for (let j = 1; j <= 6; j++) if (i + j === k) w++; return { q: `Two fair dice are rolled. What is the probability that the total is ${k}? (fraction or decimal)`, a: w / 36, f: "List the pairs that make the total; there are 36 equally likely pairs.", st: [`Pairs with total ${k}: ${w}`, `P = ${w}/36 = <strong>${ifrac(w, 36)}</strong>`] }; }
      const r = R(3, 8), b = R(2, 7), t = r + b; return { q: `A bag has ${r} red and ${b} blue counters. Two are drawn <em>without replacement</em>. What is the probability that both are red? (fraction or decimal)`, a: r * (r - 1) / (t * (t - 1)), f: "Multiply: P(first red) × P(second red given first red)", st: [`P(first red) = ${r}/${t}`, `P(second red) = ${r - 1}/${t - 1}`, `P(both) = ${r * (r - 1)}/${t * (t - 1)} = <strong>${ifrac(r * (r - 1), t * (t - 1))}</strong>`] };
    } },
    { id: "m-calc", s: "Mathematics", t: "Calculus", f: (R, l, P) => {
      if (l === 0) { const a = R(2, 9), n = R(2, 5), k = R(1, 4); return { q: `If f(x) = ${a}x<sup>${n}</sup>, find f′(${k}).`, a: a * n * Math.pow(k, n - 1), f: "d/dx (axⁿ) = a·n·xⁿ⁻¹", st: [`f′(x) = ${a * n}x<sup>${n - 1}</sup>`, `f′(${k}) = <strong>${a * n * Math.pow(k, n - 1)}</strong>`] }; }
      if (l === 1) { const a = R(1, 7), b = R(-9, 9), c = R(1, 9), k = R(-4, 6); return { q: `If f(x) = ${a}x²${sg(b)}x${sg(c)}, find the gradient of the curve at x = ${k}.`, a: 2 * a * k + b, f: "Differentiate, then substitute x.", st: [`f′(x) = ${2 * a}x${sg(b)}`, `f′(${k}) = ${2 * a} × ${k}${sg(b)} = <strong>${2 * a * k + b}</strong>`] }; }
      if (P([0, 1])) { const a = R(1, 4), x0 = R(-5, 6), b = -2 * a * x0; return { q: `The curve y = ${a}x²${sg(b)}x + 3 has a turning point. Find its x-coordinate.`, a: x0, f: "At a turning point the gradient dy/dx = 0.", st: [`dy/dx = ${2 * a}x${sg(b)} = 0`, `x = ${-b} ÷ ${2 * a} = <strong>${x0}</strong>`] }; }
      const a = 3 * R(1, 4), b = 2 * R(1, 5), k = R(1, 4), v = a * k * k * k / 3 + b * k * k / 2; return { q: `Evaluate the definite integral ∫ from 0 to ${k} of (${a}x² + ${b}x) dx.`, a: v, f: "Integrate each term (xⁿ → xⁿ⁺¹/(n+1)), then substitute the limits.", st: [`Antiderivative: ${a / 3}x³ + ${b / 2}x²`, `At x = ${k}: ${a / 3 * k * k * k} + ${b / 2 * k * k} = <strong>${v}</strong>; at 0 it is 0`] };
    } },
    { id: "m-coord", s: "Mathematics", t: "Coordinate geometry", f: (R, l, P) => {
      const x1 = R(-6, 6), y1 = R(-6, 6);
      if (l === 0) { const [a, b, c] = P(TRI), k = R(1, 3), dx = a * k * P([1, -1]), dy = b * k * P([1, -1]); return { q: `Find the distance between A(${x1}, ${y1}) and B(${x1 + dx}, ${y1 + dy}).`, a: c * k, f: "d = √((x₂ − x₁)² + (y₂ − y₁)²)", st: [`Differences: ${Math.abs(dx)} and ${Math.abs(dy)}`, `d = √(${dx * dx} + ${dy * dy}) = √${dx * dx + dy * dy} = <strong>${c * k}</strong>`] }; }
      const m = R(-5, 5) || 1, dx = R(1, 5), c = R(-8, 8), x2 = x1 + dx, ya = m * x1 + c, yb = m * x2 + c;
      if (l === 1) return P([0, 1]) ? { q: `Find the gradient of the line through (${x1}, ${ya}) and (${x2}, ${yb}).`, a: m, f: "m = (y₂ − y₁) ÷ (x₂ − x₁)", st: [`m = (${pn(yb)} − ${pn(ya)}) ÷ (${x2} − ${pn(x1)}) = <strong>${m}</strong>`] } : { q: `Find the x-coordinate of the midpoint of (${x1}, ${ya}) and (${x1 + 2 * dx}, ${yb}).`, a: x1 + dx, f: "Midpoint = average of the coordinates", st: [`(${x1} + ${x1 + 2 * dx}) ÷ 2 = <strong>${x1 + dx}</strong>`] };
      return { q: `A straight line passes through (${x1}, ${ya}) and (${x2}, ${yb}). Find its y-intercept.`, a: c, f: "Find the gradient m, then use y = mx + c with one point.", st: [`m = (${pn(yb)} − ${pn(ya)}) ÷ ${dx} = ${m}`, `${ya} = ${pn(m)} × ${pn(x1)} + c, so c = ${ya} − ${pn(m * x1)} = <strong>${c}</strong>`] };
    } },
    { id: "m-commercial", s: "Mathematics", t: "Interest & profit", f: (R, l, P) => {
      if (l === 0) { const p = R(2, 40) * 250, r = P([4, 5, 6, 8, 10]), t = R(1, 5); return { q: `Find the simple interest on $${p} at ${r}% per year for ${t} years.`, a: p * r * t / 100, u: "$", f: "SI = P × R × T ÷ 100", st: [`SI = ${p} × ${r} × ${t} ÷ 100 = <strong>$${p * r * t / 100}</strong>`] }; }
      if (l === 1) { const cp = R(4, 40) * 25, pc = P([10, 20, 25, 30, 40]), up = P([1, -1]), sp = cp * (1 + up * pc / 100); return { q: `An item bought for $${cp} is sold for $${sp}. Find the percentage ${up > 0 ? "profit" : "loss"}.`, a: pc, u: "%", f: "Profit or loss ÷ cost price × 100", st: [`${up > 0 ? "Profit" : "Loss"} = $${Math.abs(sp - cp)}`, `${Math.abs(sp - cp)} ÷ ${cp} × 100 = <strong>${pc}%</strong>`] }; }
      const p = R(2, 20) * 500, r = P([5, 10, 20]), n = R(2, 3), A = p * Math.pow(1 + r / 100, n); return { q: `$${p} is invested at ${r}% compound interest per year for ${n} years. Find the final amount (2 d.p.).`, a: A, u: "$", f: "A = P(1 + r/100)ⁿ", st: [`A = ${p} × ${(1 + r / 100).toFixed(2)}<sup>${n}</sup>`, `A = <strong>$${fm(A)}</strong>`] };
    } },
    { id: "m-geometry", s: "Mathematics", t: "Angles & polygons", f: (R, l, P) => {
      if (l === 0) { const a = R(30, 80), b = R(30, 80); return { q: `Two angles of a triangle are ${a}° and ${b}°. Find the third angle.`, a: 180 - a - b, u: "°", f: "Angles in a triangle add to 180°.", st: [`180 − ${a} − ${b} = <strong>${180 - a - b}°</strong>`] }; }
      const n = P([5, 6, 8, 9, 10, 12]);
      if (l === 1) return P([0, 1]) ? { q: `Find the sum of the interior angles of a polygon with ${n} sides.`, a: (n - 2) * 180, u: "°", f: "Sum = (n − 2) × 180°", st: [`(${n} − 2) × 180 = <strong>${(n - 2) * 180}°</strong>`] } : { q: `Find each exterior angle of a regular polygon with ${n} sides.`, a: 360 / n, u: "°", f: "Exterior angles add to 360°.", st: [`360 ÷ ${n} = <strong>${360 / n}°</strong>`] };
      const ia = 180 - 360 / n; return { q: `Each interior angle of a regular polygon is ${ia}°. How many sides does it have?`, a: n, f: "Exterior angle = 180° − interior angle, and n = 360° ÷ exterior angle.", st: [`Exterior angle = 180 − ${ia} = ${360 / n}°`, `n = 360 ÷ ${360 / n} = <strong>${n}</strong>`] };
    } },
    { id: "m-numsys", s: "Mathematics", t: "HCF & LCM", f: (R, l, P) => {
      if (l < 2) { const g = R(2, 9); let a = g * R(2, 9), b = g * R(2, 9); if (a === b) b += g; const h = gcd(a, b), m = lcm(a, b); return l === 0 ? { q: `Find the HCF of ${a} and ${b}.`, a: h, f: "The largest number that divides both.", st: [`Factors in common: the largest is <strong>${h}</strong>`] } : { q: `Find the LCM of ${a} and ${b}.`, a: m, f: "LCM = (a × b) ÷ HCF", st: [`HCF = ${h}`, `LCM = ${a} × ${b} ÷ ${h} = <strong>${m}</strong>`] }; }
      const a = R(2, 12), b = R(2, 12), c = R(2, 12), m = lcm(lcm(a, b), c); return { q: `What is the smallest number that is divisible by ${a}, ${b} and ${c}?`, a: m, f: "Find the LCM step by step.", st: [`LCM(${a}, ${b}) = ${lcm(a, b)}`, `LCM(${lcm(a, b)}, ${c}) = <strong>${m}</strong>`] };
    } },
    { id: "m-fractions", s: "Mathematics", t: "Fractions", f: (R, l, P) => {
      const D = [2, 3, 4, 5, 6, 8, 10, 12];
      if (l === 0) { const d = P(D), a = R(1, d - 1), b = R(1, d - 1); return { q: `Work out ${a}/${d} + ${b}/${d}. Give a fraction or a decimal.`, a: (a + b) / d, f: "Same denominator: add the numerators.", st: [`(${a} + ${b})/${d} = ${a + b}/${d}`, `Simplified: <strong>${ifrac(a + b, d)}</strong>`] }; }
      const b = P(D), d = P(D), a = R(1, b + 2), c = R(1, d + 2);
      if (l === 1) { const n = a * d + c * b, dn = b * d; return { q: `Work out ${a}/${b} + ${c}/${d}. Give a fraction or a decimal.`, a: n / dn, f: "Use a common denominator: a/b + c/d = (ad + cb)/bd", st: [`(${a}×${d} + ${c}×${b})/(${b}×${d}) = ${n}/${dn}`, `Simplified: <strong>${ifrac(n, dn)}</strong>`] }; }
      return { q: `Work out ${a}/${b} ÷ ${c}/${d}. Give a fraction or a decimal.`, a: a * d / (b * c), f: "Dividing by a fraction = multiplying by its reciprocal.", st: [`${a}/${b} × ${d}/${c} = ${a * d}/${b * c}`, `Simplified: <strong>${ifrac(a * d, b * c)}</strong>`] };
    } },
    { id: "m-algebra", s: "Mathematics", t: "Expressions & simultaneous equations", f: (R, l, P) => {
      if (l === 0) { const a = R(1, 5), b = R(-6, 6), c = R(-9, 9), k = R(-4, 5); return { q: `Find the value of ${a}x²${sg(b)}x${sg(c)} when x = ${k}.`, a: a * k * k + b * k + c, f: "Substitute x, then follow BODMAS: powers first.", st: [`${a} × ${k * k}${b ? ` + (${b})(${k})` : ""} + (${c}) = <strong>${a * k * k + b * k + c}</strong>`] }; }
      const x = R(-8, 10), y = R(-8, 10);
      if (l === 1) return { q: `x + y = ${x + y} and x − y = ${x - y}. Find x.`, a: x, f: "Add the two equations to eliminate y.", st: [`Adding: 2x = ${2 * x}`, `x = <strong>${x}</strong>`] };
      let a1, b1, a2, b2, det; do { a1 = R(1, 5); b1 = R(1, 5); a2 = R(1, 5); b2 = R(-5, -1); det = a1 * b2 - a2 * b1; } while (!det);
      const c1 = a1 * x + b1 * y, c2 = a2 * x + b2 * y;
      return { q: `Solve: ${a1 > 1 ? a1 : ""}x + ${b1 > 1 ? b1 : ""}y = ${c1} and ${a2 > 1 ? a2 : ""}x ${b2 < 0 ? "−" : "+"} ${Math.abs(b2) > 1 ? Math.abs(b2) : ""}y = ${c2}. Enter x.`, a: x, f: "Multiply to match a coefficient, then add or subtract.", st: [`Use elimination (or Cramer's rule, shown next) to remove y`, `x = (${c1}×${pn(b2)} − ${pn(c2)}×${b1}) ÷ (${a1}×${pn(b2)} − ${a2}×${b1}) = ${pn(c1 * b2 - c2 * b1)} ÷ ${pn(det)} = <strong>${x}</strong>`] };
    } },

    { id: "p-heat", s: "Physics", t: "Heat & energy transfer", f: (R, l, P) => {
      if (l === 0) { const m = R(1, 8), t1 = R(10, 30), t2 = t1 + R(10, 60); return { q: `How much heat is needed to warm ${m} kg of water from ${t1} °C to ${t2} °C? (c = 4200 J/kg°C)`, a: m * 4200 * (t2 - t1), u: "J", f: "Q = mcΔT", st: [`Q = ${m} × 4200 × ${t2 - t1} = <strong>${m * 4200 * (t2 - t1)} J</strong>`] }; }
      if (l === 1) { const m1 = R(1, 5), m2 = R(1, 5), t1 = R(60, 90), t2 = R(5, 30), T = (m1 * t1 + m2 * t2) / (m1 + m2); return { q: `${m1} kg of water at ${t1} °C is mixed with ${m2} kg of water at ${t2} °C. Find the final temperature (1 d.p., no heat lost).`, a: T, u: "°C", f: "Heat lost by hot water = heat gained by cold water.", st: [`${m1}(${t1} − T) = ${m2}(T − ${t2})`, `T = (${m1}×${t1} + ${m2}×${t2}) ÷ ${m1 + m2} = <strong>${fm(T)} °C</strong>`] }; }
      const m = R(1, 9) / 2; return { q: `How much energy melts ${m} kg of ice at 0 °C? (latent heat of fusion = 334 kJ/kg). Answer in kJ.`, a: m * 334, u: "kJ", f: "Q = mL", st: [`Q = ${m} × 334 = <strong>${fm(m * 334)} kJ</strong>`] };
    } },
    { id: "p-pressure", s: "Physics", t: "Pressure & fluids", f: (R, l, P) => {
      if (l === 0) { const F = R(2, 40) * 10, A = P([2, 4, 5, 10, 20]); return { q: `A force of ${F} N acts on an area of ${A} m². Find the pressure.`, a: F / A, u: "Pa", f: "P = F ÷ A", st: [`P = ${F} ÷ ${A} = <strong>${fm(F / A)} Pa</strong>`] }; }
      if (l === 1) { const h = R(2, 40); return { q: `Find the pressure due to water at a depth of ${h} m. (ρ = 1000 kg/m³, g = 9.8 m/s²)`, a: 9800 * h, u: "Pa", f: "P = ρgh", st: [`P = 1000 × 9.8 × ${h} = <strong>${9800 * h} Pa</strong>`] }; }
      const F1 = R(2, 20) * 10, A1 = R(2, 10), k = R(3, 12); return { q: `In a hydraulic press a ${F1} N force acts on a piston of area ${A1} cm². The large piston has area ${A1 * k} cm². What force does it exert?`, a: F1 * k, u: "N", f: "Pressure is the same everywhere: F₁/A₁ = F₂/A₂", st: [`F₂ = ${F1} × ${A1 * k} ÷ ${A1} = <strong>${F1 * k} N</strong>`] };
    } },
    { id: "p-gravity", s: "Physics", t: "Gravitation", f: (R, l, P) => {
      if (l === 0) { const [pl, g] = P([["the Moon", 1.6], ["Mars", 3.7], ["Earth", 9.8], ["Jupiter", 24.8]]), m = R(2, 90); return { q: `Find the weight of a ${m} kg object on ${pl}, where g = ${g} N/kg.`, a: m * g, u: "N", f: "W = mg", st: [`W = ${m} × ${g} = <strong>${fm(m * g)} N</strong>`] }; }
      if (l === 1) { const m = R(2, 30), h = R(2, 60); return { q: `Find the gravitational potential energy gained by lifting a ${m} kg mass through ${h} m. (g = 9.8 N/kg)`, a: m * 9.8 * h, u: "J", f: "GPE = mgh", st: [`GPE = ${m} × 9.8 × ${h} = <strong>${fm(m * 9.8 * h)} J</strong>`] }; }
      const F = R(2, 9) * 36, k = P([2, 3, 4, 6]); return { q: `Two masses attract with a force of ${F} N. What is the force if the distance between them is multiplied by ${k}?`, a: F / (k * k), u: "N", f: "Inverse-square law: F ∝ 1/d²", st: [`New force = ${F} ÷ ${k}² = ${F} ÷ ${k * k} = <strong>${fm(F / (k * k))} N</strong>`] };
    } },
    { id: "p-optics", s: "Physics", t: "Light & lenses", f: (R, l, P) => {
      if (l === 0) { const n = P([1.33, 1.5, 2, 2.4]), v = 3e8 / n; return { q: `The refractive index of a material is ${n}. How fast does light travel in it? (c = 3 × 10⁸ m/s; enter e.g. 2e8)`, a: v, u: "m/s", tol: 0.01, f: "n = c ÷ v", st: [`v = 3×10⁸ ÷ ${n} = <strong>${fm(v)} m/s</strong>`] }; }
      if (l === 1) { const i = R(35, 65), r = R(15, i - 8), n = Math.sin(i * PI / 180) / Math.sin(r * PI / 180); return { q: `A ray enters glass from air at an angle of incidence of ${i}° and refracts at ${r}°. Find the refractive index (2 d.p.).`, a: n, f: "Snell's law: n = sin i ÷ sin r", st: [`n = sin ${i}° ÷ sin ${r}° = ${fm(Math.sin(i * PI / 180))} ÷ ${fm(Math.sin(r * PI / 180))} = <strong>${fm(n)}</strong>`] }; }
      const f = R(8, 14), u = f + R(4, 30), v = 1 / (1 / f - 1 / u); return { q: `An object is ${u} cm from a convex lens of focal length ${f} cm. How far from the lens is the (real) image? (1 d.p.)`, a: v, u: "cm", f: "1/f = 1/u + 1/v", st: [`1/v = 1/${f} − 1/${u} = ${(1 / f - 1 / u).toFixed(4)}`, `v = <strong>${fm(v)} cm</strong>`] };
    } },
    { id: "p-power", s: "Physics", t: "Electrical power & cost", f: (R, l, P) => {
      if (l === 0) { const V = P([6, 12, 24, 230]), I = R(1, 9); return { q: `A device runs on ${V} V and draws ${I} A. Find its power.`, a: V * I, u: "W", f: "P = VI", st: [`P = ${V} × ${I} = <strong>${V * I} W</strong>`] }; }
      if (l === 1) { const p = P([500, 800, 1000, 1500, 2000, 2500]), h = R(2, 10); return { q: `How much energy does a ${p} W appliance use in ${h} hours? Answer in kWh.`, a: p * h / 1000, u: "kWh", f: "Energy (kWh) = power (kW) × time (h)", st: [`${p} W = ${p / 1000} kW`, `${p / 1000} × ${h} = <strong>${fm(p * h / 1000)} kWh</strong>`] }; }
      const kw = P([1, 1.5, 2, 3]), h = R(2, 5), d = R(5, 30), c = P([10, 12, 15, 20]); return { q: `A ${kw} kW heater runs ${h} hours a day for ${d} days. Electricity costs ${c} cents per kWh. What is the total cost in dollars?`, a: kw * h * d * c / 100, u: "$", f: "Total kWh × price", st: [`Energy = ${kw} × ${h} × ${d} = ${fm(kw * h * d)} kWh`, `Cost = ${fm(kw * h * d)} × ${c} cents = <strong>$${fm(kw * h * d * c / 100)}</strong>`] };
    } },

    { id: "c-gas", s: "Chemistry", t: "Gas laws", f: (R, l, P) => {
      if (l === 0) { const P1 = R(1, 4), V1 = R(2, 12) * 2, k = P([2, 4]), V2 = V1 / k; return { q: `A gas at ${P1} atm occupies ${V1} L. It is compressed at constant temperature to ${V2} L. Find the new pressure.`, a: P1 * V1 / V2, u: "atm", f: "Boyle's law: P₁V₁ = P₂V₂", st: [`P₂ = ${P1} × ${V1} ÷ ${V2} = <strong>${fm(P1 * V1 / V2)} atm</strong>`] }; }
      const V1 = R(2, 10) * 5, T1 = R(2, 6) * 50, T2 = R(2, 8) * 50;
      if (l === 1) return { q: `${V1} L of gas at ${T1} K is changed to ${T2} K at constant pressure. Find the new volume (2 d.p.).`, a: V1 * T2 / T1, u: "L", f: "Charles's law: V₁/T₁ = V₂/T₂ (temperatures in kelvin)", st: [`V₂ = ${V1} × ${T2} ÷ ${T1} = <strong>${fm(V1 * T2 / T1)} L</strong>`] };
      const c1 = R(0, 30), c2 = c1 + R(20, 100), p1 = R(1, 5) * 100; return { q: `A sealed rigid container holds gas at ${p1} kPa and ${c1} °C. It is warmed to ${c2} °C. Find the new pressure (1 d.p.).`, a: p1 * (c2 + 273) / (c1 + 273), u: "kPa", f: "Constant volume: P₁/T₁ = P₂/T₂. Convert °C to K by adding 273.", st: [`T₁ = ${c1 + 273} K, T₂ = ${c2 + 273} K`, `P₂ = ${p1} × ${c2 + 273} ÷ ${c1 + 273} = <strong>${fm(p1 * (c2 + 273) / (c1 + 273))} kPa</strong>`] };
    } },
    { id: "c-atom", s: "Chemistry", t: "Atomic structure", f: (R, l, P) => {
      const E = [["Na", 11, 23], ["Mg", 12, 24], ["Al", 13, 27], ["O", 8, 16], ["Cl", 17, 35], ["K", 19, 39], ["Ca", 20, 40], ["Fe", 26, 56], ["C", 6, 12], ["S", 16, 32]];
      if (l === 0) { const [s, z, a] = P(E); return { q: `An atom of ${s} has atomic number ${z} and mass number ${a}. How many neutrons does it have?`, a: a - z, f: "Neutrons = mass number − atomic number", st: [`${a} − ${z} = <strong>${a - z}</strong>`] }; }
      if (l === 1) { const [s, z, , ch] = P([["Na", 11, 0, 1], ["Mg", 12, 0, 2], ["Al", 13, 0, 3], ["O", 8, 0, -2], ["Cl", 17, 0, -1], ["Ca", 20, 0, 2]]); return { q: `How many electrons are in a ${s}<sup>${Math.abs(ch) > 1 ? Math.abs(ch) : ""}${ch > 0 ? "+" : "−"}</sup> ion? (atomic number ${z})`, a: z - ch, f: "A positive ion has lost electrons; a negative ion has gained them.", st: [`Neutral atom: ${z} electrons`, `${z} ${ch > 0 ? "−" : "+"} ${Math.abs(ch)} = <strong>${z - ch}</strong>`] }; }
      const m1 = P([10, 35, 63, 79]), m2 = m1 + 2, p = R(2, 9) * 10, A = (m1 * p + m2 * (100 - p)) / 100; return { q: `An element has two isotopes: mass ${m1} (${p}% abundant) and mass ${m2} (${100 - p}% abundant). Find its relative atomic mass (2 d.p.).`, a: A, f: "Weighted average of the isotope masses.", st: [`(${m1} × ${p} + ${m2} × ${100 - p}) ÷ 100`, `= ${m1 * p + m2 * (100 - p)} ÷ 100 = <strong>${fm(A)}</strong>`] };
    } },
    { id: "c-balance", s: "Chemistry", t: "Balancing equations", f: (R, l, P) => {
      const B = [{ r: [[4, "Al"], [3, "O2"]], p: [[2, "Al2O3"]] }, { r: [[1, "C3H8"], [5, "O2"]], p: [[3, "CO2"], [4, "H2O"]] }, { r: [[2, "Fe"], [3, "Cl2"]], p: [[2, "FeCl3"]] }, { r: [[2, "KClO3"]], p: [[2, "KCl"], [3, "O2"]] }, { r: [[1, "N2"], [3, "H2"]], p: [[2, "NH3"]] }, { r: [[1, "CH4"], [2, "O2"]], p: [[1, "CO2"], [2, "H2O"]] }, { r: [[2, "H2"], [1, "O2"]], p: [[2, "H2O"]] }, { r: [[1, "Zn"], [2, "HCl"]], p: [[1, "ZnCl2"], [1, "H2"]] }, { r: [[2, "Na"], [2, "H2O"]], p: [[2, "NaOH"], [1, "H2"]] }, { r: [[1, "Fe2O3"], [3, "CO"]], p: [[2, "Fe"], [3, "CO2"]] }];
      const x = P(B), plain = (a) => a.map(([, f]) => sb(f)).join(" + "), tot = sum(x.r.concat(x.p).map((c) => c[0]));
      return { q: `Balance: ${plain(x.r)} → ${plain(x.p)}<br>What is the sum of all the coefficients in the balanced equation?`, a: tot, f: "Balance one element at a time; a missing coefficient means 1.", st: [`Balanced: ${side(x.r)} → ${side(x.p)}`, `Coefficients: ${x.r.concat(x.p).map((c) => c[0]).join(" + ")} = <strong>${tot}</strong>`] };
    } },
    { id: "c-conc", s: "Chemistry", t: "Molarity & solutions", f: (R, l, P) => {
      if (l === 0) { const n = R(1, 8) / 2, V = P([0.25, 0.5, 1, 2]); return { q: `${n} mol of solute is dissolved to make ${V} L of solution. Find the concentration.`, a: n / V, u: "mol/L", f: "c = n ÷ V", st: [`c = ${n} ÷ ${V} = <strong>${fm(n / V)} mol/L</strong>`] }; }
      if (l === 1) { const c = P([0.1, 0.2, 0.5, 1, 2]), V = P([0.25, 0.5, 1, 2]); return { q: `What mass of NaOH (M = 40 g/mol) is needed to make ${V} L of ${c} mol/L solution?`, a: c * V * 40, u: "g", f: "n = c × V, then m = n × M", st: [`n = ${c} × ${V} = ${fm(c * V)} mol`, `m = ${fm(c * V)} × 40 = <strong>${fm(c * V * 40)} g</strong>`] }; }
      const s = R(2, 24), w = R(4, 20) * 10; return { q: `${s} g of salt is dissolved in ${w} g of water. Find the concentration as a percentage by mass of the solution (1 d.p.).`, a: s / (s + w) * 100, u: "%", f: "% by mass = solute ÷ (solute + solvent) × 100", st: [`Total mass = ${s} + ${w} = ${s + w} g`, `${s} ÷ ${s + w} × 100 = <strong>${fm(s / (s + w) * 100)}%</strong>`] };
    } },
    { id: "c-percent", s: "Chemistry", t: "Percentage composition", f: (R, l, P) => {
      const f = P(["H2O", "CO2", "CaCO3", "NH3", "H2SO4", "NaOH", "Fe2O3", "C6H12O6", "CuSO4", "Mg(OH)2"]), c = cnt(f), els = Object.keys(c), e = P(els), M = mm(f), pc = c[e] * AM[e] / M * 100;
      return { q: `Find the percentage by mass of ${e} in ${sb(f)} (1 d.p.).`, a: pc, u: "%", f: "(atoms × atomic mass) ÷ molar mass × 100 · " + AMTXT, st: [`M(${sb(f)}) = ${fm(M)} g/mol`, `${c[e]} × ${AM[e]} ÷ ${fm(M)} × 100 = <strong>${fm(pc)}%</strong>`] };
    } },

    { id: "cs-logic", s: "Computer Science", t: "Logic gates", f: (R, l, P) => {
      const T = [[["A AND B", (a, b) => a && b], ["A OR B", (a, b) => a || b], ["NOT A", (a) => !a], ["A NAND B", (a, b) => !(a && b)]], [["(A AND B) OR C", (a, b, c) => (a && b) || c], ["A AND (NOT B)", (a, b) => a && !b], ["NOT (A OR B)", (a, b) => !(a || b)], ["(A OR B) AND C", (a, b, c) => (a || b) && c]], [["(A XOR B) AND C", (a, b, c) => (a !== b) && c], ["NOT (A AND B) OR C", (a, b, c) => !(a && b) || c], ["(A NOR B) XOR C", (a, b, c) => !(a || b) !== c], ["A XOR (B AND C)", (a, b, c) => a !== (b && c)]]];
      const [ex, fn] = P(T[l]), a = R(0, 1), b = R(0, 1), c = R(0, 1), v = fn(!!a, !!b, !!c) ? 1 : 0;
      return { q: `A = ${a}, B = ${b}, C = ${c}. What is the output of <code>${ex}</code>? (Enter 1 for true, 0 for false.)`, a: v, f: "Work out the innermost brackets first. XOR is true when the inputs differ; NAND/NOR are the opposites of AND/OR.", st: [`Substitute: A = ${a}, B = ${b}, C = ${c}`, `Evaluate ${ex} step by step → <strong>${v}</strong>`] };
    } },
    { id: "cs-strings", s: "Computer Science", t: "Strings & slicing", f: (R, l, P) => {
      const w = P(["algorithm", "computer", "function", "variable", "program", "network", "keyboard", "database", "compiler"]);
      if (l === 0) return { q: `What does <code>print(len("${w}"))</code> display?`, a: w.length, f: "len() counts the characters.", st: [`"${w}" has <strong>${w.length}</strong> letters`] };
      if (l === 1) { const a = R(0, 3), b = R(a + 2, w.length - 1); return { q: `What does <code>print("${w}"[${a}:${b}])</code> display? (type the letters only)`, t: "text", a: w.slice(a, b), f: "[start:stop] includes start, excludes stop. Index 0 is the first letter.", st: [`Letters at positions ${a} to ${b - 1}`, `Result: <strong>${w.slice(a, b)}</strong>`] }; }
      const k = R(2, 4); return P([0, 1]) ? { q: `What does <code>print("${w}"[-${k}:])</code> display? (type the letters only)`, t: "text", a: w.slice(-k), f: "Negative indices count from the end.", st: [`The last ${k} letters: <strong>${w.slice(-k)}</strong>`] } : { q: `What does <code>print("${w}"[::-1])</code> display? (type the letters only)`, t: "text", a: w.split("").reverse().join(""), f: "A step of −1 reads the string backwards.", st: [`Reversed: <strong>${w.split("").reverse().join("")}</strong>`] };
    } },
    { id: "cs-storage", s: "Computer Science", t: "Data storage", f: (R, l, P) => {
      if (l === 0) { const b = R(2, 90); return { q: `How many bits are there in ${b} bytes?`, a: b * 8, f: "1 byte = 8 bits", st: [`${b} × 8 = <strong>${b * 8}</strong>`] }; }
      if (l === 1) { const w = R(1, 10) * 100, h = R(1, 10) * 100; return { q: `An image is ${w} × ${h} pixels with 24 bits (3 bytes) per pixel. Find its size in kilobytes (1 KB = 1000 bytes).`, a: w * h * 3 / 1000, u: "KB", f: "Pixels × bytes per pixel, then ÷ 1000", st: [`Pixels = ${w} × ${h} = ${w * h}`, `Bytes = ${w * h} × 3 = ${w * h * 3}`, `<strong>${w * h * 3 / 1000} KB</strong>`] }; }
      const sr = P([8000, 16000, 22000]), bits = P([8, 16]), t = R(2, 20); return { q: `Sound is recorded at ${sr} samples per second with ${bits} bits per sample, for ${t} seconds. Find the file size in kilobytes (1 KB = 1000 bytes; mono).`, a: sr * bits * t / 8 / 1000, u: "KB", f: "Size in bits = sample rate × bits × seconds; ÷ 8 for bytes", st: [`Bits = ${sr} × ${bits} × ${t} = ${sr * bits * t}`, `Bytes = ${sr * bits * t / 8}`, `<strong>${fm(sr * bits * t / 8 / 1000)} KB</strong>`] };
    } },
    { id: "cs-complexity", s: "Computer Science", t: "Counting loop steps", f: (R, l, P) => {
      if (l === 0) { const n = R(3, 15); return { q: `How many times is "hi" printed?<pre class="pl-code">for i in range(${n}):\n    print("hi")</pre>`, a: n, f: "range(n) gives n values: 0 to n−1.", st: [`<strong>${n}</strong> times`] }; }
      if (l === 1) { const a = R(2, 9), b = R(2, 9); return { q: `How many times is "x" printed?<pre class="pl-code">for i in range(${a}):\n    for j in range(${b}):\n        print("x")</pre>`, a: a * b, f: "The inner loop runs fully for each pass of the outer loop.", st: [`${a} × ${b} = <strong>${a * b}</strong>`] }; }
      const k = R(3, 9), n = Math.pow(2, k); return { q: `How many times does the loop body run?<pre class="pl-code">i = 1\nwhile i < ${n}:\n    i = i * 2\n    print(i)</pre>`, a: k, f: "List the values of i: it doubles every time.", st: [`i goes 1, 2, 4, … until it reaches ${n}`, `That is ${k} doublings → <strong>${k}</strong> runs`] };
    } },
    { id: "cs-recursion", s: "Computer Science", t: "Recursion", f: (R, l, P) => {
      const fact = (n) => (n <= 1 ? 1 : n * fact(n - 1)), fib = (n) => (n < 2 ? n : fib(n - 1) + fib(n - 2));
      if (l === 0) { const n = R(3, 6); return { q: `What does this print?<pre class="pl-code">def f(n):\n    if n <= 1:\n        return 1\n    return n * f(n - 1)\nprint(f(${n}))</pre>`, a: fact(n), f: "Expand: f(n) = n × f(n−1) until n ≤ 1.", st: [`f(${n}) = ${Array.from({ length: n }, (_, i) => n - i).join(" × ")}`, `= <strong>${fact(n)}</strong>`] }; }
      if (l === 1) { const n = R(4, 9); return { q: `What does this print?<pre class="pl-code">def s(n):\n    if n == 0:\n        return 0\n    return n + s(n - 1)\nprint(s(${n}))</pre>`, a: n * (n + 1) / 2, f: "It adds n + (n−1) + … + 1.", st: [`${Array.from({ length: n }, (_, i) => n - i).join(" + ")} = <strong>${n * (n + 1) / 2}</strong>`] }; }
      const n = R(6, 10); return { q: `What does this print?<pre class="pl-code">def fib(n):\n    if n < 2:\n        return n\n    return fib(n - 1) + fib(n - 2)\nprint(fib(${n}))</pre>`, a: fib(n), f: "Build the sequence 0, 1, 1, 2, 3, 5, …", st: [`Sequence: ${Array.from({ length: n + 1 }, (_, i) => fib(i)).join(", ")}`, `fib(${n}) = <strong>${fib(n)}</strong>`] };
    } },
    { id: "cs-lists", s: "Computer Science", t: "Lists & comprehensions", f: (R, l, P) => {
      const v = Array.from({ length: R(3, 5) }, () => R(1, 9));
      if (l === 0) { const x = R(1, 9); return { q: `What does this print?<pre class="pl-code">nums = [${v.join(", ")}]\nnums.append(${x})\nprint(len(nums))</pre>`, a: v.length + 1, f: "append adds one item to the end.", st: [`${v.length} items + 1 = <strong>${v.length + 1}</strong>`] }; }
      if (l === 1) { const w = v.slice(0, -1); return { q: `What does this print?<pre class="pl-code">nums = [${v.join(", ")}]\nnums.pop()\nprint(sum(nums))</pre>`, a: sum(w), f: "pop() removes the last item.", st: [`After pop: [${w.join(", ")}]`, `Sum = <strong>${sum(w)}</strong>`] }; }
      const n = R(5, 10), k = P([2, 3]), r = []; for (let x = 1; x < n; x++) if (x % k === 0) r.push(x * x);
      return { q: `What does this print?<pre class="pl-code">print(sum([x * x for x in range(1, ${n}) if x % ${k} == 0]))</pre>`, a: sum(r), f: "x runs from 1 to n−1; keep only multiples of " + k + ", square them, add.", st: [`Multiples of ${k}: ${r.map((q) => Math.sqrt(q)).join(", ")}`, `Squares: ${r.join(" + ")} = <strong>${sum(r)}</strong>`] };
    } },
  );

  // ---------- answer checking ----------
  const norm = (x) => String(x).replace(/\s|^0[bx]/gi, "").toLowerCase().replace(/^0+(?=.)/, "");
  function num(s) {
    s = String(s).trim().toLowerCase().replace(/[−–]/g, "-").replace(/,/g, "").replace(/\s*[×x*]\s*10\s*\^?\s*/, "e").replace(/\s+/g, "");
    const m = s.match(/^(-?\d+\/\d+|-?\d*\.?\d+(?:e[-+]?\d+)?)/);
    if (!m) return null;
    if (m[1].includes("/")) { const [a, b] = m[1].split("/"); return +b ? +a / +b : null; }
    return parseFloat(m[1]);
  }
  function check(p, inp) {
    if (p.t === "text") return norm(inp) === norm(p.a);
    const x = num(inp); if (x == null || !isFinite(x)) return null;
    const tol = p.tol != null ? p.tol : Number.isInteger(p.a) ? 0 : 0.01;
    return Math.abs(x - p.a) <= Math.max(Math.abs(p.a) * tol, 1e-9);
  }
  function make(g, level, seed) {
    let s = seed | 0;
    const r = () => { s = (s + 0x6D2B79F5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    return g.f((a, b) => a + Math.floor(r() * (b - a + 1)), level, (list) => list[Math.floor(r() * list.length)]);
  }

  // ---------- UI ----------
  function mount(root) {
    const qs = new URLSearchParams(location.search), LV = ["Easy", "Medium", "Hard"];
    let g = GENS.find((x) => x.id === qs.get("g")) || GENS[0], lvl = Math.min(2, Math.max(0, +qs.get("l") || 0)), p, done = false;
    const sess = { a: 0, c: 0, st: 0 };
    root.classList.add("pl-app");
    root.innerHTML = '<div class="pl-layout"><aside class="pl-side" data-side aria-label="Problem topics"></aside><section class="pl-main" data-main></section></div>';
    const side = root.querySelector("[data-side]"), main = root.querySelector("[data-main]");

    function drawSide() {
      const ps = S ? S.problemStats() : {}; let html = "", cur = "";
      GENS.forEach((x) => {
        if (x.s !== cur) { cur = x.s; html += `<h4>${x.s}</h4>`; }
        const st = ps[x.id], acc = st && st.a ? Math.round(100 * st.c / st.a) + "%" : "–";
        html += `<button type="button" class="pl-gen" data-g="${x.id}" aria-pressed="${x.id === g.id}">${x.t}<em>${acc}</em></button>`;
      });
      side.innerHTML = html;
    }
    function next() {
      done = false; p = make(g, lvl, Math.floor(Math.random() * 1e9));
      history.replaceState(null, "", "?g=" + g.id + "&l=" + lvl);
      main.innerHTML = `<div class="pl-top"><h3 class="pl-title">${g.s} · ${g.t}</h3><div class="pl-sess"><span>Solved <b data-sc>${sess.c}/${sess.a}</b></span><span>Streak <b data-ss>${sess.st}</b></span></div></div>
        <div class="pr-chips" role="group" aria-label="Difficulty">${LV.map((n, i) => `<button type="button" class="pr-chip" data-l="${i}" aria-pressed="${i === lvl}">${n}</button>`).join("")}</div>
        <p class="pl-q">${p.q}</p><div data-hint></div>
        <form class="pl-answer" data-form><input class="pr-input" data-in autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="Your answer" placeholder="${p.t === "text" ? "Type your answer" : "Your answer"}"><span class="pl-unit">${p.u || ""}</span>
          <button class="pr-btn primary" type="submit">Check</button><button class="pr-btn ghost" type="button" data-hintbtn>Hint</button><button class="pr-btn ghost" type="button" data-reveal>Show solution</button></form>
        <div class="pl-result" data-res aria-live="polite"></div>`;
      const inp = main.querySelector("[data-in]"); if (inp && !/Mobi/i.test(navigator.userAgent)) inp.focus();
    }
    function result(ok, counted) {
      const ans = (p.t === "text" ? p.a : fm(p.a)) + (p.u ? " " + p.u : "");
      const head = ok === true ? `<div class="pr-feedback ok"><b>Correct!</b> The answer is <b>${ans}</b>.</div>` : ok === false ? `<div class="pr-feedback bad"><b>Not quite.</b> The answer is <b>${ans}</b>. Follow the working below.</div>` : `<div class="pr-feedback close">The answer is <b>${ans}</b> — this one isn't scored.</div>`;
      main.querySelector("[data-res]").innerHTML = head + `<ol class="pl-steps">${p.st.map((x) => `<li>${x}</li>`).join("")}</ol><div class="pr-actions"><button type="button" class="pr-btn primary" data-next>Next problem →</button></div>`;
      main.querySelector("[data-in]").disabled = true; done = true;
      if (counted) {
        sess.a++; if (ok) { sess.c++; sess.st++; } else sess.st = 0;
        if (S) { S.logProblem(g.id, ok); S.log({ mode: "problems", answered: 1, correct: ok ? 1 : 0, subject: g.s }); }
        main.querySelector("[data-sc]").textContent = sess.c + "/" + sess.a; main.querySelector("[data-ss]").textContent = sess.st; drawSide();
      }
      const nb = main.querySelector("[data-next]"); if (nb) nb.focus();
    }
    root.addEventListener("click", (e) => {
      const t = e.target.closest("button"); if (!t) return;
      if (t.dataset.g) { g = GENS.find((x) => x.id === t.dataset.g); drawSide(); next(); }
      else if (t.dataset.l) { lvl = +t.dataset.l; next(); }
      else if (t.hasAttribute("data-next")) next();
      else if (t.hasAttribute("data-hintbtn") && p.f) main.querySelector("[data-hint]").innerHTML = `<div class="pl-hintbox">💡 ${p.f}</div>`;
      else if (t.hasAttribute("data-reveal") && !done) result(null, false);
    });
    root.addEventListener("submit", (e) => {
      e.preventDefault(); if (done) return;
      const v = main.querySelector("[data-in]").value.trim(), ok = v ? check(p, v) : null;
      if (ok === null) { main.querySelector("[data-res]").innerHTML = '<p class="pr-note">Enter your answer first (numbers, fractions like 3/4, or e.g. 1.2e23).</p>'; return; }
      result(ok, true);
    });
    drawSide(); next();
  }

  window.CurioProblemLab = { GENS, make, check, mount };
  const host = document.querySelector("[data-problem-lab]");
  if (host) mount(host);
})();
