// Curio Lab — "Discuss" tab on lesson pages: upvoted Q&A and comments. Talks to backend/discuss.py.
// Opt-in: only joined community members (13+) can read or write. Everything user-written is escaped before it is shown.
(function () {
  "use strict";
  if (window.__curioDiscuss) return; window.__curioDiscuss = true;
  const m = location.pathname.match(/\/pages\/([a-z-]+)\/([a-z0-9-]+)\.html$/);
  if (!m) return;
  const LESSON = m[1] + "/" + m[2];
  const me = document.currentScript && document.currentScript.src;
  const base = me ? me.replace(/js\/discuss\.js.*$/, "") : "../../";
  const safe = (v, f) => { try { const x = JSON.parse(v); return x == null ? f : x; } catch (_) { return f; } };
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const toast = (t, o) => window.CurioToast && window.CurioToast.show(t, o || {});
  const user = () => safe(localStorage.getItem("curiolab-local-session"), null);
  const key = () => { const u = user(); if (!u || !u.email) return null; const s = safe(localStorage.getItem("curio.community.v1:" + String(u.email).toLowerCase()), null); return s && s.key; };
  const isChild = () => { const u = user(); return !!(u && (u.child || (window.CurioAge && window.CurioAge.isChild && window.CurioAge.isChild()))); };

  async function api(path, body) {
    const h = { Accept: "application/json", Authorization: "Bearer " + key() };
    if (body !== undefined) h["Content-Type"] = "application/json";
    let r;
    try { r = await fetch("/api/community/discuss" + path, { method: body !== undefined ? "POST" : "GET", headers: h, body: body !== undefined ? JSON.stringify(body) : undefined }); }
    catch (_) { throw Object.assign(new Error("The community server can't be reached right now."), { offline: true }); }
    const ct = r.headers.get("content-type") || "";
    if (r.status === 404 && !ct.includes("json")) throw Object.assign(new Error("Discussions aren't running on this site."), { offline: true });
    const j = ct.includes("json") ? await r.json().catch(() => ({})) : {};
    if (!r.ok) throw Object.assign(new Error(j.error || "Something went wrong. Please try again."), { status: r.status, support: !!j.support });
    return j;
  }
  // The shared report dialog (js/report-dialog.js) is loaded the first time someone reports something.
  function ensureReport() {
    if (window.CurioReport) return Promise.resolve(true);
    return new Promise((res) => { const sc = document.createElement("script"); sc.src = base + "js/report-dialog.js"; sc.onload = () => res(!!window.CurioReport); sc.onerror = () => res(false); document.head.appendChild(sc); });
  }
  const ago = (t) => { const s = Math.max(1, Math.floor(Date.now() / 1000 - t)); if (s < 90) return "just now"; if (s < 5400) return Math.round(s / 60) + " min ago"; if (s < 129600) return Math.round(s / 3600) + " h ago"; return Math.round(s / 86400) + " d ago"; };
  const initials = (n) => (String(n || "?").trim().split(/\s+/).slice(0, 2).map((w) => w[0] || "").join("") || "?").toUpperCase();

  function mount() {
    const tabs = document.querySelector(".mode-tabs");
    const panels = [...document.querySelectorAll(".mode-panel")];
    if (!tabs || !panels.length || document.querySelector('[data-panel="discuss"]')) return;
    if (!document.querySelector('link[href*="discuss.css"]')) { const l = document.createElement("link"); l.rel = "stylesheet"; l.href = base + "css/discuss.css"; document.head.appendChild(l); }
    const btn = document.createElement("button");
    btn.className = "mode-tab"; btn.type = "button"; btn.dataset.tab = "discuss"; btn.textContent = "💬 Discuss";
    tabs.appendChild(btn);
    const panel = document.createElement("section");
    panel.className = "mode-panel"; panel.dataset.panel = "discuss";
    panels[panels.length - 1].after(panel);
    const box = document.createElement("div"); box.className = "ds-root"; panel.appendChild(box);
    let loaded = false;
    const show = (on) => { btn.classList.toggle("active", on); panel.classList.toggle("active", on); if (on && !loaded) { loaded = true; start(box); } };
    btn.addEventListener("click", () => {
      document.querySelectorAll("[data-tab]").forEach((t) => t.classList.toggle("active", t === btn));
      document.querySelectorAll("[data-panel]").forEach((p) => p.classList.toggle("active", p === panel));
      window.dispatchEvent(new CustomEvent("curiolab:tab-shown", { detail: { name: "discuss" } }));
    });
    window.addEventListener("curiolab:tab-shown", (e) => show(e.detail && e.detail.name === "discuss"));
    if (location.hash === "#discuss") btn.click();
  }

  function notice(box, title, text, link) {
    box.innerHTML = `<div class="ds-card ds-notice"><h3>${title}</h3><p>${text}</p>${link || ""}</div>`;
  }

  async function start(box) {
    if (!user()) return notice(box, "Log in to join the discussion", "Ask questions, share answers and upvote the best ones with other learners.", `<a class="ds-btn ds-primary" href="${base}pages/login.html">Log in</a>`);
    if (isChild()) return notice(box, "Discussions are for learners 13 and over", "They're switched off on children's accounts to keep young learners private. Everything else on this lesson works as usual.");
    if (!key()) return notice(box, "Join the community to take part", "Pick a handle and you can read, ask, answer and upvote. Joining is optional and free.", `<a class="ds-btn ds-primary" href="${base}pages/community.html">Join the community</a>`);
    const S = { section: "qa", sort: "top", unanswered: false, offset: 0, data: null, open: null };
    box.innerHTML = `<div class="ds-card">
      <div class="ds-head"><div class="ds-seg" role="tablist" aria-label="Discussion sections">
        <button type="button" role="tab" data-sec="qa" aria-selected="true">❓ Questions <b data-n-qa></b></button><button type="button" role="tab" data-sec="comments" aria-selected="false">💬 Comments <b data-n-c></b></button></div>
        <div class="ds-tools"><label class="ds-sr" for="ds-sort">Sort</label><select id="ds-sort" data-sort><option value="top">Top voted</option><option value="new">Newest</option></select>
        <label class="ds-check" data-un-wrap><input type="checkbox" data-un> Unanswered</label></div></div>
      <form class="ds-compose" data-compose novalidate><label class="ds-sr" for="ds-body" data-compose-label>Ask a question</label>
        <textarea id="ds-body" name="body" rows="3" maxlength="300" placeholder="Ask about something in this lesson…" data-body></textarea>
        <div class="ds-row"><small class="ds-hint" data-count>0/300</small><span class="ds-grow"></span><button class="ds-btn ds-primary" type="submit">Post</button></div>
        <p class="ds-hint">Be kind and stay on topic. No links, emails or phone numbers. Never share personal details.</p>
        <p class="ds-err" data-err role="alert"></p></form>
      <div data-list aria-live="polite"><p class="ds-hint">Loading…</p></div></div>`;
    const $ = (s) => box.querySelector(s), list = $("[data-list]"), form = $("[data-compose]"), body = $("[data-body]"), err = $("[data-err]");
    let limits = { question: 300, answer: 800, comment: 500, reply: 300 }, canPost = true, why = "";

    const author = (a) => `<span class="ds-av" aria-hidden="true">${esc(initials(a.name))}</span>` + (a.link ? `<a class="ds-by" href="${base}pages/u.html?h=${encodeURIComponent(a.handle)}" translate="no">${esc(a.name)}</a>` : `<span class="ds-by" translate="no">${esc(a.name)}</span>`)
      + (a.helpful ? `<span class="ds-helpful" title="Accepted answers">✅ ${a.helpful}</span>` : "");
    const vote = (p) => `<button type="button" class="ds-vote" data-vote="${p.id}" aria-pressed="${p.voted}" ${p.mine ? "disabled" : ""} aria-label="Upvote (${p.votes})"><span aria-hidden="true">▲</span><b>${p.votes}</b></button>`;
    const acts = (p, extra) => `<span class="ds-acts">${extra || ""}${p.can_edit ? `<button type="button" class="ds-link" data-edit="${p.id}">Edit</button>` : ""}${p.mine ? `<button type="button" class="ds-link" data-del="${p.id}">Delete</button>` : `<button type="button" class="ds-link" data-rep="${p.id}">Report</button>`}</span>`;
    const child = (p, q) => `<li class="ds-child ${p.accepted ? "is-accepted" : ""}" id="ds-p${p.id}">${vote(p)}<div class="ds-main">
        <div class="ds-meta">${author(p.author)}<span class="ds-time">${ago(p.created_at)}${p.edited ? " · edited" : ""}</span>${p.accepted ? `<span class="ds-ok">✅ Accepted</span>` : ""}</div>
        <p class="ds-text">${esc(p.body)}</p>${acts(p, S.section === "qa" && q.mine && !p.mine ? `<button type="button" class="ds-link" data-acc="${p.id}">${p.accepted ? "Unaccept" : "Accept answer"}</button>` : S.section === "qa" && q.mine ? `<button type="button" class="ds-link" data-acc="${p.id}">${p.accepted ? "Unaccept" : "Accept answer"}</button>` : "")}</div></li>`;
    const item = (p) => `<li class="ds-item ${p.has_accepted ? "is-solved" : ""}" id="ds-p${p.id}">${vote(p)}<div class="ds-main">
        <div class="ds-meta">${author(p.author)}<span class="ds-time">${ago(p.created_at)}${p.edited ? " · edited" : ""}</span>${p.has_accepted ? `<span class="ds-ok">✅ Answered</span>` : ""}</div>
        <p class="ds-text ds-title">${esc(p.body)}</p>${acts(p, canPost ? `<button type="button" class="ds-link" data-reply="${p.id}">${S.section === "qa" ? "Answer" : "Reply"}</button>` : "")}
        <ul class="ds-children">${p.children.map((k) => child(k, p)).join("")}</ul>
        <form class="ds-inline" data-rform="${p.id}" hidden novalidate><label class="ds-sr" for="ds-r${p.id}">${S.section === "qa" ? "Your answer" : "Your reply"}</label><textarea id="ds-r${p.id}" rows="2" maxlength="${S.section === "qa" ? limits.answer : limits.reply}" placeholder="${S.section === "qa" ? "Write an answer…" : "Write a reply…"}"></textarea>
          <div class="ds-row"><button class="ds-btn ds-primary ds-sm" type="submit">Post</button><button class="ds-btn ds-sm" type="button" data-cancel>Cancel</button></div><p class="ds-err" data-rerr role="alert"></p></form></div></li>`;

    function fail(el, e) { el.className = e.support ? "ds-support" : "ds-err"; el.textContent = e.message; }
    function setSection() {
      const qa = S.section === "qa";
      $("[data-compose-label]").textContent = qa ? "Ask a question" : "Add a comment";
      body.placeholder = qa ? "Ask about something in this lesson…" : "Share a thought, tip or mnemonic…";
      body.maxLength = qa ? limits.question : limits.comment; $("[data-count]").textContent = `${body.value.length}/${body.maxLength}`;
      $("[data-un-wrap]").hidden = !qa;
      box.querySelectorAll("[data-sec]").forEach((b) => b.setAttribute("aria-selected", b.dataset.sec === S.section));
      form.hidden = !canPost;
      if (!canPost) { let n = $("[data-why]"); if (!n) { n = document.createElement("p"); n.className = "ds-hint"; n.dataset.why = ""; form.after(n); } n.textContent = why; }
    }
    async function load(append) {
      if (!append) { S.offset = 0; list.innerHTML = `<p class="ds-hint">Loading…</p>`; }
      try {
        const j = await api(`?lesson=${encodeURIComponent(LESSON)}&section=${S.section}&sort=${S.sort}&offset=${S.offset}` + (S.unanswered ? "&unanswered=1" : ""));
        limits = j.limits || limits; canPost = j.can_post; why = j.why || "";
        $("[data-n-qa]").textContent = j.counts.questions || ""; $("[data-n-c]").textContent = j.counts.comments || "";
        setSection();
        const html = j.items.map(item).join("");
        if (!append) list.innerHTML = j.items.length ? `<ul class="ds-items">${html}</ul>` : `<div class="ds-empty">${S.section === "qa" ? (S.unanswered ? "No unanswered questions. Nice!" : "No questions yet. Ask the first one.") : "No comments yet. Start the conversation."}</div>`;
        else list.querySelector(".ds-items").insertAdjacentHTML("beforeend", html);
        list.querySelector("[data-more]") && list.querySelector("[data-more]").remove();
        if (j.more) { S.offset = j.next_offset; list.insertAdjacentHTML("beforeend", `<button type="button" class="ds-btn ds-sm" data-more>Show more</button>`); }
      } catch (e) { list.innerHTML = `<p class="ds-err">${esc(e.message)}</p>`; }
    }
    box.querySelectorAll("[data-sec]").forEach((b) => b.addEventListener("click", () => { S.section = b.dataset.sec; body.value = ""; load(false); }));
    $("[data-sort]").addEventListener("change", (ev) => { S.sort = ev.target.value; load(false); });
    $("[data-un]").addEventListener("change", (ev) => { S.unanswered = ev.target.checked; load(false); });
    body.addEventListener("input", () => { $("[data-count]").textContent = `${body.value.length}/${body.maxLength}`; });
    form.addEventListener("submit", async (ev) => {
      ev.preventDefault(); err.textContent = ""; err.className = "ds-err";
      const btn = form.querySelector("button[type=submit]"); btn.disabled = true;
      try { await api("/post", { lesson: LESSON, kind: S.section === "qa" ? "question" : "comment", body: body.value }); body.value = ""; toast("Posted", { icon: "💬" }); await load(false); }
      catch (e) { fail(err, e); } finally { btn.disabled = false; }
    });
    list.addEventListener("click", async (ev) => {
      const t = ev.target.closest("button"); if (!t) return;
      try {
        if (t.dataset.more !== undefined) return load(true);
        if (t.dataset.vote) { const j = await api("/vote", { post: +t.dataset.vote }); t.setAttribute("aria-pressed", j.voted); t.querySelector("b").textContent = j.votes; return; }
        if (t.dataset.reply) { const f = list.querySelector(`[data-rform="${t.dataset.reply}"]`); f.hidden = !f.hidden; if (!f.hidden) f.querySelector("textarea").focus(); return; }
        if (t.dataset.edit) {
          const host = t.closest(".ds-main"), txt = host.querySelector(".ds-text");
          if (host.querySelector("[data-eform]")) return;
          const f = document.createElement("form"); f.dataset.eform = t.dataset.edit; f.className = "ds-inline"; f.noValidate = true;
          f.innerHTML = `<label class="ds-sr" for="ds-e${t.dataset.edit}">Edit your post</label><textarea id="ds-e${t.dataset.edit}" rows="3"></textarea><div class="ds-row"><button class="ds-btn ds-primary ds-sm" type="submit">Save</button><button class="ds-btn ds-sm" type="button" data-ecancel>Cancel</button></div><p class="ds-err" data-eerr role="alert"></p>`;
          f.querySelector("textarea").value = txt.textContent; txt.hidden = true; txt.after(f); f.querySelector("textarea").focus(); return;
        }
        if (t.dataset.ecancel !== undefined) { const f = t.closest("form"); f.previousElementSibling.hidden = false; f.remove(); return; }
        if (t.dataset.cancel !== undefined) { t.closest("form").hidden = true; return; }
        if (t.dataset.acc) { await api("/accept", { post: +t.dataset.acc }); return load(false); }
        if (t.dataset.del) { if (!confirm("Delete this post? Replies under it are deleted too.")) return; await api("/delete", { post: +t.dataset.del }); toast("Deleted", { icon: "🗑️" }); return load(false); }
        if (t.dataset.rep) {
          const post = +t.dataset.rep;
          if (!(await ensureReport())) { const r = prompt("What is wrong with this post? (kept private; it is hidden from you straight away)"); if (!r) return; await api("/report", { post, reason: r }); toast("Thanks, we'll take a look", { icon: "🚩" }); return load(false); }
          const sent = await window.CurioReport.open({ what: "post", onSend: (x) => api("/report", { post, category: x.category, reason: x.reason }) });
          if (sent) { toast("Thanks, we'll take a look", { icon: "🚩" }); load(false); }
          return;
        }
      } catch (e) { toast(e.message, { icon: "⚠️" }); }
    });
    list.addEventListener("submit", async (ev) => {
      const ef = ev.target.closest("[data-eform]");
      if (ef) { ev.preventDefault(); const er = ef.querySelector("[data-eerr]"); er.textContent = ""; er.className = "ds-err";
        try { await api("/edit", { post: +ef.dataset.eform, body: ef.querySelector("textarea").value }); toast("Saved", { icon: "✅" }); await load(false); } catch (e) { fail(er, e); } return; }
      const f = ev.target.closest("[data-rform]"); if (!f) return; ev.preventDefault();
      const er = f.querySelector("[data-rerr]"); er.textContent = ""; er.className = "ds-err";
      try { await api("/post", { parent: +f.dataset.rform, kind: S.section === "qa" ? "answer" : "reply", body: f.querySelector("textarea").value }); toast("Posted", { icon: "💬" }); await load(false); }
      catch (e) { fail(er, e); }
    });
    load(false);
  }

  if (window.onLessonContentReady) window.onLessonContentReady(mount);
  else document.addEventListener("DOMContentLoaded", mount);
})();
