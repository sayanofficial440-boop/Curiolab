// Curio Lab — Mode tab switching (Video / Audio / Cards / Slides / Quiz / 3D)
window.onLessonContentReady(() => {
  const tabs = document.querySelectorAll("[data-tab]");
  const panels = document.querySelectorAll("[data-panel]");
  if (!tabs.length) return;

  function activate(name) {
    tabs.forEach((t) => t.classList.toggle("active", t.dataset.tab === name));
    panels.forEach((p) => p.classList.toggle("active", p.dataset.panel === name));
    // Safety net: anything tagged for scroll-reveal while its panel was hidden
    // (display:none) never got seen by the IntersectionObserver, so it would
    // otherwise stay stuck at opacity:0 forever. Force-reveal it the moment its tab opens.
    const shown = document.querySelector(`[data-panel="${name}"]`);
    if (shown) {
      shown.querySelectorAll("[data-reveal]:not(.revealed)").forEach((el) => el.classList.add("revealed"));
    }
    window.dispatchEvent(new CustomEvent("curiolab:tab-shown", { detail: { name } }));
  }

  tabs.forEach((t) => t.addEventListener("click", () => activate(t.dataset.tab)));
  activate(tabs[0].dataset.tab);
});
