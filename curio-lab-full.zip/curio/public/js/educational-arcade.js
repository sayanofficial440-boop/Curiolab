// Curio Lab — Canvas Arcade Learning Engine
//
// A third mini-game type alongside js/micro-games.js's sort/match games,
// same embedding convention so lesson authors already know the pattern:
//
//   <div class="arcade-catch" data-arcade-game="ag1"></div>
//   <script type="application/json" data-arcade-config="ag1">
//     {
//       "title": "Catch the Balanced Formulas",
//       "subjectName": "Chemistry",
//       "lessonName": "Ionic and Covalent Bonds",
//       "prompt": "Steer the flask — catch correct compounds, dodge the wrong ones.",
//       "correctItems": ["H2O", "NaCl", "CO2", "CH4"],
//       "incorrectItems": ["H3O2", "NaCl2", "C2O", "CH5"],
//       "durationSeconds": 40,
//       "livesStart": 3
//     }
//   <\/script>
//
// One HTML5 Canvas game loop, config-driven so the same engine plays as a
// chemistry-bond dodger, a vocabulary catcher, or a formula runner — only the
// item labels and correct/incorrect sets change. Scores land in the exact
// same "curiolab-scores" store js/quiz.js writes to (via
// window.CurioScoreboard.saveScore), so an arcade round shows up on the
// scoreboard and counts toward achievements immediately — no separate score
// system to keep in sync. Wins also feed the same cross-game streak counter
// js/micro-games.js maintains, and reuse window.CurioSound / window.CurioToast
// for consistent feedback, same as every other mini-game on the site.
(function () {
  "use strict";

  const STYLE_ID = "curio-arcade-styles";
  const STREAK_KEY = "curiolab-microgame-streak"; // shared with micro-games.js by convention (see quiz.js/achievements.js doing the same with curiolab-scores)
  const DPR = Math.min(window.devicePixelRatio || 1, 2);
  const REDUCE_MOTION = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .arcade-shell {
        border: 1px solid var(--color-line); border-radius: var(--radius-md, 12px);
        background: var(--color-surface); box-shadow: var(--shadow-card);
        padding: 1.1rem 1.2rem 1.3rem; margin: 1rem 0;
      }
      .arcade-title { font-family: var(--font-display); font-size: 1.05rem; margin: 0 0 0.15rem; }
      .arcade-sub { color: var(--color-ink-soft); font-size: 0.82rem; margin: 0 0 0.85rem; }
      .arcade-canvas-wrap {
        position: relative; width: 100%; border-radius: var(--radius-sm, 8px);
        overflow: hidden; border: 1.5px solid var(--color-line); background: var(--color-bg-alt);
        touch-action: none;
      }
      .arcade-canvas-wrap canvas { display: block; width: 100%; height: auto; cursor: grab; }
      .arcade-canvas-wrap canvas:active { cursor: grabbing; }
      .arcade-controls { display: flex; justify-content: space-between; align-items: center; margin-top: 0.85rem; gap: 0.6rem; flex-wrap: wrap; }
      .arcade-touch-btns { display: flex; gap: 0.5rem; }
      .arcade-btn {
        border: 1px solid var(--color-line-strong); background: var(--color-bg);
        color: var(--color-ink); padding: 0.5rem 1rem; border-radius: 999px;
        font-size: 0.82rem; cursor: pointer; font-weight: 600;
        transition: transform 140ms, border-color 140ms;
      }
      .arcade-btn:hover { border-color: var(--accent); transform: translateY(-1px); }
      .arcade-btn.primary { background: var(--accent); color: var(--color-surface); border-color: transparent; }
      .arcade-btn:disabled { opacity: 0.5; cursor: default; transform: none; }
      .arcade-overlay {
        position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center;
        justify-content: center; gap: 0.6rem; background: color-mix(in srgb, var(--color-bg) 82%, transparent);
        text-align: center; padding: 1rem;
      }
      .arcade-overlay h4 { font-family: var(--font-display); font-size: 1.3rem; margin: 0; }
      .arcade-overlay p { color: var(--color-ink-soft); font-size: 0.85rem; margin: 0; }
      .arcade-sr-live { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); }
    `;
    document.head.appendChild(style);
  }

  function readStreak() {
    try { return JSON.parse(localStorage.getItem(STREAK_KEY)) || { current: 0, best: 0 }; }
    catch (e) { return { current: 0, best: 0 }; }
  }
  function writeStreak(s) { localStorage.setItem(STREAK_KEY, JSON.stringify(s)); }

  function registerRoundResult(won, label) {
    const s = readStreak();
    if (won) {
      s.current += 1;
      s.best = Math.max(s.best, s.current);
    } else {
      s.current = 0;
    }
    writeStreak(s);
    if (window.CurioToast) {
      if (won && s.current > 0 && s.current % 5 === 0) {
        window.CurioToast.show(`🔥 ${s.current}-win streak across mini-games!`, { type: "trophy", icon: "🔥", duration: 5000 });
      } else if (won) {
        window.CurioToast.show(`Nice run — ${label} cleared!`, { icon: "🎮" });
      }
    }
    if (window.CurioAchievements && typeof window.CurioAchievements.notifyMicrogameWin === "function" && won) {
      window.CurioAchievements.notifyMicrogameWin(s.current);
    }
    return s;
  }

  function saveArcadeScore(config, score, maxPossible) {
    if (!window.CurioScoreboard) return;
    window.CurioScoreboard.saveScore({
      lesson: config.lessonName || config.title || "Arcade round",
      subject: config.subjectName || "Arcade",
      score: Math.max(0, score),
      total: Math.max(1, maxPossible),
      date: new Date().toISOString(),
    });
  }

  // Fisher-Yates, used to keep the fall sequence from being predictably repetitive.
  function shuffled(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function buildGame(container, config) {
    const title = config.title || "Arcade Challenge";
    const prompt = config.prompt || "Catch the correct answers, dodge the wrong ones.";
    const correctItems = Array.isArray(config.correctItems) && config.correctItems.length ? config.correctItems : ["Correct"];
    const incorrectItems = Array.isArray(config.incorrectItems) && config.incorrectItems.length ? config.incorrectItems : ["Incorrect"];
    const durationSeconds = Number(config.durationSeconds) > 0 ? Number(config.durationSeconds) : 40;
    const livesStart = Number(config.livesStart) > 0 ? Number(config.livesStart) : 3;

    container.innerHTML = `
      <div class="arcade-shell">
        <h4 class="arcade-title">${title}</h4>
        <p class="arcade-sub">${prompt}</p>
        <div class="arcade-canvas-wrap" data-arcade-wrap>
          <canvas data-arcade-canvas></canvas>
          <div class="arcade-sr-live" role="status" aria-live="polite" data-arcade-sr></div>
        </div>
        <div class="arcade-controls">
          <div class="arcade-touch-btns">
            <button type="button" class="arcade-btn" data-arcade-left aria-label="Move left">◀</button>
            <button type="button" class="arcade-btn" data-arcade-right aria-label="Move right">▶</button>
          </div>
          <button type="button" class="arcade-btn primary" data-arcade-start>▶ Start round</button>
        </div>
      </div>
    `;

    const wrap = container.querySelector("[data-arcade-wrap]");
    const canvas = container.querySelector("[data-arcade-canvas]");
    const ctx = canvas.getContext("2d");
    const srLive = container.querySelector("[data-arcade-sr]");
    const startBtn = container.querySelector("[data-arcade-start]");
    const leftBtn = container.querySelector("[data-arcade-left]");
    const rightBtn = container.querySelector("[data-arcade-right]");

    const CSS_HEIGHT = 320;
    let cssWidth = 0;

    function resize() {
      cssWidth = wrap.clientWidth || 480;
      canvas.width = Math.round(cssWidth * DPR);
      canvas.height = Math.round(CSS_HEIGHT * DPR);
      canvas.style.height = CSS_HEIGHT + "px";
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    }
    resize();
    const resizeObserver = new ResizeObserver(() => resize());
    resizeObserver.observe(wrap);

    // --- Game state -------------------------------------------------------
    const AVATAR_W = 54, AVATAR_H = 26, AVATAR_Y_OFFSET = 20;
    const FALL_LABEL_PAD = 10;
    let avatarX = 0;
    let targetX = null; // set by pointer drag; null means keyboard/button control
    let blocks = []; // { x, y, w, h, label, correct, vy }
    let score = 0;
    let lives = livesStart;
    let timeLeft = durationSeconds;
    let running = false;
    let rafId = null;
    let lastTs = null;
    let spawnTimer = 0;
    let spawnInterval = 1100; // ms, ramps down as time passes for difficulty curve
    let itemPool = [];
    let keysDown = { left: false, right: false };

    function resetState() {
      avatarX = cssWidth / 2;
      targetX = null;
      blocks = [];
      score = 0;
      lives = livesStart;
      timeLeft = durationSeconds;
      spawnTimer = 0;
      spawnInterval = 1100;
      itemPool = shuffled([
        ...correctItems.map((label) => ({ label, correct: true })),
        ...incorrectItems.map((label) => ({ label, correct: false })),
      ]);
    }

    function announce(text) {
      srLive.textContent = text;
    }

    function nextItem() {
      if (itemPool.length === 0) {
        itemPool = shuffled([
          ...correctItems.map((label) => ({ label, correct: true })),
          ...incorrectItems.map((label) => ({ label, correct: false })),
        ]);
      }
      return itemPool.pop();
    }

    function spawnBlock() {
      const item = nextItem();
      ctx.font = "600 14px 'JetBrains Mono', monospace";
      const textW = Math.max(60, ctx.measureText(item.label).width + FALL_LABEL_PAD * 2);
      const w = Math.min(textW, cssWidth - 24);
      const x = Math.random() * Math.max(1, cssWidth - w);
      const elapsedFraction = 1 - timeLeft / durationSeconds;
      const baseSpeed = 55 + elapsedFraction * 70; // px/sec, ramps up over the round
      blocks.push({ x, y: -30, w, h: 34, label: item.label, correct: item.correct, vy: baseSpeed });
    }

    function moveAvatar(dt) {
      const speed = 320; // px/sec for keyboard/button control
      if (targetX !== null) {
        avatarX += (targetX - avatarX) * Math.min(1, dt * 10); // smooth follow toward pointer position
      } else {
        if (keysDown.left) avatarX -= speed * dt;
        if (keysDown.right) avatarX += speed * dt;
      }
      avatarX = Math.max(AVATAR_W / 2, Math.min(cssWidth - AVATAR_W / 2, avatarX));
    }

    function update(dt) {
      moveAvatar(dt);
      spawnTimer += dt * 1000;
      if (spawnTimer >= spawnInterval) {
        spawnTimer = 0;
        spawnInterval = Math.max(520, spawnInterval - 6); // gently ramps up spawn rate
        spawnBlock();
      }

      const catchY = CSS_HEIGHT - AVATAR_Y_OFFSET - AVATAR_H / 2;
      const survivors = [];
      for (const b of blocks) {
        b.y += b.vy * dt;
        const reachedAvatar = b.y + b.h / 2 >= catchY - 10 && b.y - b.h / 2 <= catchY + 10;
        const overlapsX = Math.abs((b.x + b.w / 2) - avatarX) <= (b.w / 2 + AVATAR_W / 2 - 6);

        if (reachedAvatar && overlapsX && !b.resolved) {
          b.resolved = true;
          if (b.correct) {
            score += 10;
            window.CurioSound && window.CurioSound.play("success");
            announce(`Caught ${b.label} — correct! Score ${score}.`);
          } else {
            lives -= 1;
            window.CurioSound && window.CurioSound.play("error");
            announce(`Caught ${b.label} — that was wrong. ${Math.max(lives, 0)} lives left.`);
          }
          continue; // remove from play
        }
        if (b.y - b.h / 2 > CSS_HEIGHT) {
          if (b.correct) announce(`Missed ${b.label}.`);
          continue; // fell past the bottom, remove either way
        }
        survivors.push(b);
      }
      blocks = survivors;

      if (lives <= 0) return endRound(false);
      timeLeft -= dt;
      if (timeLeft <= 0) return endRound(true);
    }

    function draw() {
      ctx.clearRect(0, 0, cssWidth, CSS_HEIGHT);

      const styles = getComputedStyle(document.documentElement);
      const ink = styles.getPropertyValue("--color-ink").trim() || "#1B1B18";
      const surface = styles.getPropertyValue("--color-surface").trim() || "#fff";
      const accent = styles.getPropertyValue("--accent").trim() || "#2E8E80";
      const coral = styles.getPropertyValue("--color-coral").trim() || "#C94A38";
      const moss = styles.getPropertyValue("--color-moss").trim() || "#5F7A34";

      // Falling blocks
      blocks.forEach((b) => {
        ctx.fillStyle = surface;
        ctx.strokeStyle = ink;
        ctx.globalAlpha = 0.92;
        ctx.lineWidth = 1.5;
        roundRect(ctx, b.x, b.y - b.h / 2, b.w, b.h, 8);
        ctx.fill();
        ctx.stroke();
        ctx.globalAlpha = 1;
        ctx.fillStyle = ink;
        ctx.font = "600 14px 'JetBrains Mono', monospace";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(b.label, b.x + b.w / 2, b.y);
      });

      // Avatar (simple ship/basket shape — accent-colored so it matches the active theme)
      const catchY = CSS_HEIGHT - AVATAR_Y_OFFSET - AVATAR_H / 2;
      ctx.fillStyle = accent;
      roundRect(ctx, avatarX - AVATAR_W / 2, catchY - AVATAR_H / 2, AVATAR_W, AVATAR_H, 8);
      ctx.fill();

      // HUD — drawn directly on canvas so score/lives/timer update with zero DOM reflow
      ctx.fillStyle = ink;
      ctx.font = "700 15px 'JetBrains Mono', monospace";
      ctx.textAlign = "left";
      ctx.textBaseline = "top";
      ctx.fillText(`Score: ${score}`, 10, 8);
      ctx.textAlign = "right";
      ctx.fillStyle = lives <= 1 ? coral : ink;
      ctx.fillText(`${"❤".repeat(Math.max(lives, 0))}${"♡".repeat(Math.max(livesStart - lives, 0))}`, cssWidth - 10, 8);

      // Timer bar
      const barW = cssWidth - 20;
      const frac = Math.max(0, timeLeft / durationSeconds);
      ctx.fillStyle = "rgba(0,0,0,0.08)";
      ctx.fillRect(10, 30, barW, 5);
      ctx.fillStyle = frac > 0.25 ? moss : coral;
      ctx.fillRect(10, 30, barW * frac, 5);
    }

    function roundRect(c, x, y, w, h, r) {
      c.beginPath();
      c.moveTo(x + r, y);
      c.arcTo(x + w, y, x + w, y + h, r);
      c.arcTo(x + w, y + h, x, y + h, r);
      c.arcTo(x, y + h, x, y, r);
      c.arcTo(x, y, x + w, y, r);
      c.closePath();
    }

    function loop(ts) {
      if (!running) return;
      if (lastTs === null) lastTs = ts;
      const dt = Math.min(0.05, (ts - lastTs) / 1000); // clamp so a backgrounded tab can't cause a huge catch-up jump
      lastTs = ts;
      update(dt);
      if (running) {
        draw();
        rafId = requestAnimationFrame(loop);
      }
    }

    function showOverlay(html) {
      let overlay = wrap.querySelector(".arcade-overlay");
      if (!overlay) {
        overlay = document.createElement("div");
        overlay.className = "arcade-overlay";
        wrap.appendChild(overlay);
      }
      overlay.innerHTML = html;
      return overlay;
    }
    function clearOverlay() {
      const overlay = wrap.querySelector(".arcade-overlay");
      if (overlay) overlay.remove();
    }

    function endRound(won) {
      running = false;
      if (rafId) cancelAnimationFrame(rafId);
      const maxPossible = (correctItems.length + incorrectItems.length) * 10 || 10;
      saveArcadeScore(config, score, Math.max(maxPossible, score, 10));
      const streak = registerRoundResult(won, title);
      draw();
      showOverlay(`
        <h4>${won ? "🏁 Round complete!" : "💥 Out of lives"}</h4>
        <p>Score: <strong>${score}</strong> · Streak: ${streak.current} (best ${streak.best})</p>
        <button type="button" class="arcade-btn primary" data-arcade-replay>Play again</button>
      `);
      const replayBtn = wrap.querySelector("[data-arcade-replay]");
      replayBtn && replayBtn.addEventListener("click", startRound, { once: true });
      startBtn.disabled = false;
      startBtn.textContent = "▶ Start round";
      announce(won ? `Round complete. Final score ${score}.` : `Out of lives. Final score ${score}.`);
    }

    function startRound() {
      clearOverlay();
      resetState();
      running = true;
      lastTs = null;
      startBtn.disabled = true;
      startBtn.textContent = "Playing…";
      announce("Round started.");
      rafId = requestAnimationFrame(loop);
    }

    // --- Controls ----------------------------------------------------------
    function handleKeydown(e) {
      if (!running) return;
      if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") { keysDown.left = true; targetX = null; }
      if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") { keysDown.right = true; targetX = null; }
    }
    function handleKeyup(e) {
      if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") keysDown.left = false;
      if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") keysDown.right = false;
    }
    canvas.tabIndex = 0;
    canvas.addEventListener("keydown", handleKeydown);
    canvas.addEventListener("keyup", handleKeyup);

    function pointerToX(e) {
      const rect = canvas.getBoundingClientRect();
      return ((e.clientX - rect.left) / rect.width) * cssWidth;
    }
    canvas.addEventListener("pointerdown", (e) => {
      if (!running) return;
      canvas.setPointerCapture(e.pointerId);
      targetX = pointerToX(e);
    });
    canvas.addEventListener("pointermove", (e) => {
      if (!running || targetX === null) return;
      targetX = pointerToX(e);
    });
    canvas.addEventListener("pointerup", () => { targetX = null; });

    let heldInterval = null;
    function bindHoldButton(btn, dir) {
      const start = () => {
        if (!running) return;
        targetX = null;
        keysDown[dir] = true;
      };
      const stop = () => { keysDown[dir] = false; };
      btn.addEventListener("pointerdown", start);
      btn.addEventListener("pointerup", stop);
      btn.addEventListener("pointerleave", stop);
      btn.addEventListener("pointercancel", stop);
    }
    bindHoldButton(leftBtn, "left");
    bindHoldButton(rightBtn, "right");

    document.addEventListener("visibilitychange", () => {
      if (document.hidden && running) {
        // Pause rather than let a huge dt land on the next visible frame.
        running = false;
        if (rafId) cancelAnimationFrame(rafId);
        showOverlay(`<h4>⏸ Paused</h4><p>Tab left the background.</p><button type="button" class="arcade-btn primary" data-arcade-resume>Resume</button>`);
        const resumeBtn = wrap.querySelector("[data-arcade-resume]");
        resumeBtn && resumeBtn.addEventListener("click", () => {
          clearOverlay();
          running = true;
          lastTs = null;
          rafId = requestAnimationFrame(loop);
        }, { once: true });
      }
    });

    resetState();
    draw();
    startBtn.addEventListener("click", startRound);
  }

  function initAll() {
    document.querySelectorAll("[data-arcade-game]").forEach((container) => {
      if (container.dataset.arcadeInitialized) return;
      const id = container.getAttribute("data-arcade-game");
      const cfgScript = document.querySelector(`script[data-arcade-config="${CSS.escape(id)}"]`);
      if (!cfgScript) return;
      let config;
      try { config = JSON.parse(cfgScript.textContent); } catch (err) {
        console.error("[educational-arcade] invalid config", id, err);
        return;
      }
      container.dataset.arcadeInitialized = "true";
      injectStyles();
      buildGame(container, config);
    });
  }

  window.CurioArcade = { init: initAll };

  if (window.onLessonContentReady) {
    window.onLessonContentReady(initAll);
  } else if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initAll, { once: true });
  } else {
    initAll();
  }
})();
