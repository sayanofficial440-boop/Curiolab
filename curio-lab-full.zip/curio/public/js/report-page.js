// Curio Lab — Progress report: per-subject mastery, topic heatmap, strengths and
// weaknesses, printable as a PDF. Everything is computed from what the learner
// actually did (CurioLearning + Mistake Notebook); nothing is sample data.
(function () {
  "use strict";
  const root = document.querySelector("[data-report-app]");
  const L = window.CurioLearning;
  if (!root || !L) return;
  const CAT = window.CurioCatalog || { lessons: [], subjects: [] };
  const $ = (s) => root.querySelector(s);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const pct = (e) => Math.round((e.score / e.total) * 100);
  const dayKey = (d) => { d = new Date(d); return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate(); };
  const band = (p) => (p == null ? "none" : p >= 80 ? "strong" : p >= 60 ? "ok" : "weak");
  const BAND_LABEL = { none: "Not attempted", visited: "Opened only", weak: "Needs work", ok: "Developing", strong: "Strong" };

  function compute(state) {
    const events = state.events.filter((e) => e.total > 0);
    const rel = (h) => L.relHref(h);
    const lessons = CAT.lessons.map((l) => {
      const evs = events.filter((e) => (e.href && rel(e.href) === l.h) || (!e.href && e.subject === l.s && e.lesson === l.t) || (e.subject === l.s && e.lesson === l.t));
      const last3 = evs.slice(-3);
      const mastery = last3.length ? Math.round(last3.reduce((a, e) => a + pct(e), 0) / last3.length) : null;
      const visited = state.visits.some((v) => rel(v.href) === l.h);
      return { ...l, attempts: evs.length, mastery, best: evs.length ? Math.max(...evs.map(pct)) : null, visited, band: mastery == null ? (visited ? "visited" : "none") : band(mastery) };
    });
    const subjects = CAT.subjects.map((s) => {
      const ls = lessons.filter((l) => l.s === s.name);
      const evs = events.filter((e) => e.subject === s.name);
      const q = evs.reduce((a, e) => a + e.total, 0), c = evs.reduce((a, e) => a + e.score, 0);
      const attempted = ls.filter((l) => l.mastery != null).length;
      return { name: s.name, code: s.code, lessons: ls, questions: q, accuracy: q ? Math.round((c / q) * 100) : null, attempted, explored: ls.filter((l) => l.band !== "none").length, total: ls.length };
    });
    const days = new Set([...events.map((e) => dayKey(e.at)), ...state.visits.map((v) => dayKey(v.at))]);
    const allQ = events.reduce((a, e) => a + e.total, 0), allC = events.reduce((a, e) => a + e.score, 0);
    const week = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i); const k = dayKey(d);
      const day = events.filter((e) => dayKey(e.at) === k);
      week.push({ label: d.toLocaleDateString(undefined, { weekday: "short" }), q: day.reduce((a, e) => a + e.total, 0), c: day.reduce((a, e) => a + e.score, 0) });
    }
    return { events, lessons, subjects, activeDays: days.size, quizzes: events.filter((e) => e.lesson !== "Mock test" && !/^Exam Center/.test(e.lesson || "")).length + new Set(events.filter((e) => e.lesson === "Mock test" || /^Exam Center/.test(e.lesson || "")).map((e) => (e.lesson === "Mock test" ? "m" : "x") + String(e.at).slice(0, 16))).size, avg: allQ ? Math.round((allC / allQ) * 100) : null, questions: allQ, week };
  }

  function name(state) {
    return (state.profile && state.profile.name) || "";
  }

  // ---- study time (tracked while the learner is actively on a study page) ----
  let timeView = "week";
  const mins = (secs) => Math.round(secs / 60);
  const fmtMin = (m) => (m >= 60 ? Math.floor(m / 60) + " h " + (m % 60 ? (m % 60) + " min" : "") : m + " min");
  function timeSection() {
    const T = window.CurioTime; if (!T) return "";
    T.flush();
    let bars, total, avgNote;
    if (timeView === "week") {
      const sr = T.series(7); total = sr.reduce((a, d) => a + d.secs, 0);
      const mx = Math.max(60, ...sr.map((d) => d.secs));
      bars = sr.map((d) => `<div><b>${d.secs ? mins(d.secs) : ""}</b><i style="height:${Math.round((d.secs / mx) * 100)}%"></i><span>${d.date.toLocaleDateString(undefined, { weekday: "short" })}</span></div>`).join("");
      avgNote = `${fmtMin(mins(total))} this week · about ${fmtMin(mins(total / 7))} per day`;
    } else {
      const sr = T.series(56), weeks = []; for (let i = 0; i < 8; i++) { const chunk = sr.slice(i * 7, i * 7 + 7); weeks.push({ secs: chunk.reduce((a, d) => a + d.secs, 0), start: chunk[0].date }); }
      total = weeks.reduce((a, w) => a + w.secs, 0); const mx = Math.max(60, ...weeks.map((w) => w.secs));
      bars = weeks.map((w) => `<div><b>${w.secs ? mins(w.secs) : ""}</b><i style="height:${Math.round((w.secs / mx) * 100)}%"></i><span>${w.start.toLocaleDateString(undefined, { day: "numeric", month: "short" })}</span></div>`).join("");
      avgNote = `${fmtMin(mins(total))} over the last 8 weeks · about ${fmtMin(mins(total / 8))} per week`;
    }
    return `<section class="st-card rp-sec" data-time-sec><div class="mk-rhead"><h3 class="mk-h" style="margin:0">⏱ Study time</h3><div class="mk-chips"><button class="mk-chip" type="button" data-tv="week" aria-pressed="${timeView === "week"}">Weekly</button><button class="mk-chip" type="button" data-tv="month" aria-pressed="${timeView === "month"}">Monthly</button></div></div>
      ${total ? `<div class="sc-bars" style="margin-top:12px">${bars}</div><p class="rp-note" style="margin-top:6px">Minutes per ${timeView === "week" ? "day" : "week (starting on the date shown)"}. ${avgNote}.</p>` : `<p class="rp-none" style="margin-top:10px">No study time recorded yet. Time is counted while you are actively reading a lesson or reviewing — idle time is ignored.</p>`}</section>`;
  }

  // ---- Exam Center: results and readiness (from js/exam-store.js) ----
  function examSection(state) {
    const X = window.CurioExam; if (!X) return { html: "", rd: null };
    const st = X.stats(); if (!st.count) return { html: "", rd: null };
    const rd = X.readiness(state), rich = X.attempts().slice(-6).reverse();
    const rows = rich.map((a) => `<div class="mk-hist"><span>${esc(a.title)} · ${new Date(a.at).toLocaleDateString(undefined, { day: "numeric", month: "short" })}</span><b>${a.marks}/${a.maxMarks} · ${a.pct}%</b></div>`).join("");
    const subj = rd.subjects.filter((x) => x.value != null).sort((a, b) => a.value - b.value).map((x) => `<div class="rp-subj"><div class="rp-sname"><b>${esc(x.name)}</b><small>${esc(x.band.label)}</small></div><div class="mk-meter" role="img" aria-label="${esc(x.name)} readiness ${x.value} percent"><i style="width:${x.value}%"></i></div><b class="rp-pct">${x.value}%</b></div>`).join("");
    const html = `<section class="st-card rp-sec"><h3 class="mk-h">📝 Exam readiness</h3>
      <p class="rp-note">${rd.overall == null ? "Not enough data yet." : `Estimated readiness <b>${rd.overall}%</b> (${esc(rd.band.label)}) — likely ${rd.range[0]}–${rd.range[1]}% on a full paper, ${rd.confidence} confidence.`} ${st.count} exam${st.count === 1 ? "" : "s"} taken, best ${st.best}%, average ${st.avg}%. <a href="exams.html?tab=readiness">Open Exam Center →</a></p>
      ${subj}${rows ? `<h4 class="mk-h" style="margin:16px 0 6px">Recent exams</h4>${rows}` : ""}</section>`;
    return { html, rd };
  }

  async function render() {
    const state = await L.get();
    const d = compute(state);
    const R = window.CurioReview ? window.CurioReview.stats() : null;
    const user = window.CurioAuth ? await window.CurioAuth.getCurrentUser().catch(() => null) : null;
    const who = name(state) || (user && user.name) || "Learner";
    const today = new Date().toLocaleDateString(undefined, { day: "numeric", month: "long", year: "numeric" });
    const explored = d.lessons.filter((l) => l.band !== "none").length;
    const withScore = d.lessons.filter((l) => l.mastery != null);
    const strong = [...withScore].filter((l) => l.mastery >= 80).sort((a, b) => b.mastery - a.mastery);
    const weak = [...withScore].filter((l) => l.mastery < 60).sort((a, b) => a.mastery - b.mastery);
    const notStarted = d.lessons.filter((l) => l.band === "none");
    const openedOnly = d.lessons.filter((l) => l.band === "visited");

    $("[data-r-name]").textContent = who;
    $("[data-r-date]").textContent = today;

    if (!d.quizzes && !explored) {
      $("[data-r-body]").innerHTML = `<div class="st-card st-empty"><span class="big">📈</span><b>No learning activity recorded yet.</b><p>Open a lesson and finish its quiz, or sit a <a href="exams.html">timed exam</a>. Your report builds itself from real results.</p></div>`;
      $("[data-r-actions]").hidden = true; return;
    }
    $("[data-r-actions]").hidden = false;

    // plain-language summary a parent or teacher can read at a glance
    const sentence = [`${who} has explored ${explored} of ${d.lessons.length} lessons, answered ${d.questions.toLocaleString()} quiz question${d.questions === 1 ? "" : "s"} across ${d.quizzes} quiz${d.quizzes === 1 ? "" : "zes"}${d.avg != null ? ` with an overall accuracy of ${d.avg}%` : ""}, and has studied on ${d.activeDays} different day${d.activeDays === 1 ? "" : "s"}.`];
    const best = d.subjects.filter((s) => s.accuracy != null && s.questions >= 5).sort((a, b) => b.accuracy - a.accuracy);
    if (best.length) sentence.push(`Strongest subject so far: ${best[0].name} (${best[0].accuracy}%).` + (best.length > 1 && best[best.length - 1].accuracy < 70 ? ` Most room to improve: ${best[best.length - 1].name} (${best[best.length - 1].accuracy}%).` : ""));
    if (weak.length) sentence.push(`Topics to revisit: ${weak.slice(0, 3).map((l) => l.t).join(", ")}.`);

    const kpis = [[explored + "/" + d.lessons.length, "Lessons explored"], [d.avg == null ? "—" : d.avg + "%", "Overall accuracy"], [d.quizzes, "Quizzes taken"], [d.activeDays, "Active days"]];

    const subjRows = d.subjects.map((s) => `<div class="rp-subj">
        <div class="rp-sname"><b>${esc(s.name)}</b><small>${s.explored}/${s.total} lessons explored · ${s.questions} questions</small></div>
        <div class="mk-meter" role="img" aria-label="${esc(s.name)} accuracy ${s.accuracy == null ? "none yet" : s.accuracy + " percent"}"><i style="width:${s.accuracy || 0}%"></i></div>
        <b class="rp-pct">${s.accuracy == null ? "—" : s.accuracy + "%"}</b></div>`).join("");

    const heat = d.subjects.map((s) => `<div class="hm-group"><h4>${esc(s.name)}</h4><div class="hm-tiles">${s.lessons.map((l) => `<a class="hm-t hm-${l.band}" href="../${esc(l.h)}" title="${esc(l.t)} — ${BAND_LABEL[l.band]}${l.mastery != null ? " (" + l.mastery + "%, " + l.attempts + " attempt" + (l.attempts === 1 ? "" : "s") + ")" : ""}"><b>${l.mastery != null ? l.mastery + "%" : l.band === "visited" ? "•" : "–"}</b><span>${esc(l.t)}</span></a>`).join("")}</div></div>`).join("");
    const legend = ["strong", "ok", "weak", "visited", "none"].map((b) => `<span class="hm-key"><i class="hm-${b}"></i>${BAND_LABEL[b]}${b === "strong" ? " (80%+)" : b === "ok" ? " (60–79%)" : b === "weak" ? " (<60%)" : ""}</span>`).join("");

    const list = (arr, fn, empty) => (arr.length ? arr.slice(0, 6).map(fn).join("") : `<p class="rp-none">${empty}</p>`);
    const row = (l) => `<div class="mk-hist"><span><a href="../${esc(l.h)}">${esc(l.t)}</a> · ${esc(l.s)}</span><b>${l.mastery}%</b></div>`;
    const maxQ = Math.max(1, ...d.week.map((w) => w.q));
    const weekBars = d.week.map((w) => `<div><b>${w.q || ""}</b><i style="height:${Math.round((w.q / maxQ) * 100)}%"></i><span>${w.label}</span></div>`).join("");

    const ex = examSection(state);
    const nextSteps = [];
    if (weak[0]) nextSteps.push(`Retake the <a href="../${esc(weak[0].h)}">${esc(weak[0].t)}</a> quiz (${weak[0].mastery}%).`);
    if (R && R.due) nextSteps.push(`Clear <a href="review.html">${R.due} due review question${R.due === 1 ? "" : "s"}</a> in the Mistake Notebook.`);
    if (openedOnly[0]) nextSteps.push(`Finish the quiz for <a href="../${esc(openedOnly[0].h)}">${esc(openedOnly[0].t)}</a> — opened but never scored.`);
    if (notStarted[0]) nextSteps.push(`Start something new: <a href="../${esc(notStarted[0].h)}">${esc(notStarted[0].t)}</a> (${esc(notStarted[0].s)}).`);
    if (ex.rd && ex.rd.weak.length >= 2) nextSteps.push(`Run a <a href="exams.html?start=weak">weak-spot drill</a> — ${ex.rd.weak.length} lessons are below 60%.`);
    else if (d.quizzes >= 1) nextSteps.push(`Sit a timed paper in the <a href="exams.html">Exam Center</a> to check exam readiness.`);

    $("[data-r-body]").innerHTML = `
      <section class="st-card rp-sec"><p class="rp-lead">${esc(sentence.join(" "))}</p>
        <div class="st-stats" style="margin:14px 0 0">${kpis.map(([v, l]) => `<div class="st-stat"><b>${v}</b><span>${l}</span></div>`).join("")}</div></section>
      <section class="st-card rp-sec"><h3 class="mk-h">Mastery by subject</h3><p class="rp-note">Accuracy across every quiz question answered in that subject, including mock tests.</p>${subjRows}</section>
      <section class="st-card rp-sec"><h3 class="mk-h">Topic heatmap</h3><p class="rp-note">Each tile is a lesson, shaded by the average of its last three quiz attempts. Tap a tile to open the lesson.</p><div class="hm-legend">${legend}</div>${heat}</section>
      <div class="rp-two">
        <section class="st-card rp-sec"><h3 class="mk-h">💪 Strengths</h3>${list(strong, row, "No lesson has reached 80% yet.")}</section>
        <section class="st-card rp-sec"><h3 class="mk-h">🎯 Needs attention</h3>${list(weak, row, withScore.length ? "Nothing below 60% — great work." : "Finish a lesson quiz to see this.")}</section>
      </div>
      ${ex.html}
      ${timeSection()}
      <div class="rp-two">
        <section class="st-card rp-sec"><h3 class="mk-h">Last 7 days</h3><div class="sc-bars">${weekBars}</div><p class="rp-note" style="margin-top:6px">Quiz questions answered per day.</p></section>
        <section class="st-card rp-sec"><h3 class="mk-h">Review habit</h3>${R && R.total ? `<div class="mk-hist"><span>Questions in Mistake Notebook</span><b>${R.total}</b></div><div class="mk-hist"><span>Mastered (21+ day gap)</span><b>${R.mastered}</b></div><div class="mk-hist"><span>Due for review now</span><b>${R.due}</b></div><div class="mk-hist"><span>Reviewed today</span><b>${R.reviewedToday}</b></div>` : `<p class="rp-none">No missed questions saved yet.</p>`}</section>
      </div>
      <section class="st-card rp-sec rp-noprint-break"><h3 class="mk-h">Suggested next steps</h3>${nextSteps.length ? `<ul class="rp-steps">${nextSteps.slice(0, 5).map((s) => `<li>${s}</li>`).join("")}</ul>` : '<p class="rp-none">Keep going — new suggestions appear as you learn.</p>'}</section>`;
  }

  root.addEventListener("click", (e) => { const b = e.target.closest("[data-tv]"); if (b) { timeView = b.dataset.tv; render(); } });
  window.addEventListener("curio-time-updated", () => { clearTimeout(render.t); render.t = setTimeout(render, 300); });
  $("[data-r-print]").addEventListener("click", () => window.print());
  window.addEventListener("curio-learning-updated", () => { clearTimeout(render.t); render.t = setTimeout(render, 150); });
  window.addEventListener("curio-review-updated", () => { clearTimeout(render.t); render.t = setTimeout(render, 150); });
  L.ready().then(render);
})();
