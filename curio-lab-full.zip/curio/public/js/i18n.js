// Curio Lab — language switcher (58 languages incl. 21 Indian). Exact-match UI dictionary + RTL support.
// Hand-written UI strings for Hindi, Bengali and the other Indian languages live in js/lang/<code>.js and
// load only when that language is chosen (they call CurioLang.pack). Everything else is translated
// on-device or by Google Translate once the learner picks a language.
(function () {
  const SRC = (document.currentScript && document.currentScript.src) || "";
  const KEYS = ["Search", "Home", "Learn", "Recall", "Progress", "Menu"];
  // code|native name|Search|Home|Learn|Recall|Progress|Menu
  const D = `en|English
es|Español|Buscar|Inicio|Aprender|Repasar|Progreso|Menú
fr|Français|Rechercher|Accueil|Apprendre|Réviser|Progrès|Menu
de|Deutsch|Suche|Start|Lernen|Wiederholen|Fortschritt|Menü
it|Italiano|Cerca|Home|Impara|Ripasso|Progressi|Menu
pt|Português|Pesquisar|Início|Aprender|Rever|Progresso|Menu
nl|Nederlands|Zoeken|Home|Leren|Herhalen|Voortgang|Menu
sv|Svenska|Sök|Hem|Lär dig|Repetera|Framsteg|Meny
da|Dansk|Søg|Hjem|Lær|Gentag|Fremskridt|Menu
no|Norsk|Søk|Hjem|Lær|Repeter|Fremgang|Meny
fi|Suomi|Haku|Koti|Opi|Kertaa|Edistyminen|Valikko
pl|Polski|Szukaj|Start|Nauka|Powtórki|Postępy|Menu
cs|Čeština|Hledat|Domů|Učení|Opakování|Pokrok|Nabídka
sk|Slovenčina|Hľadať|Domov|Učenie|Opakovanie|Pokrok|Ponuka
hu|Magyar|Keresés|Kezdőlap|Tanulás|Ismétlés|Haladás|Menü
ro|Română|Căutare|Acasă|Învață|Recapitulare|Progres|Meniu
bg|Български|Търсене|Начало|Учене|Преговор|Напредък|Меню
el|Ελληνικά|Αναζήτηση|Αρχική|Μάθηση|Επανάληψη|Πρόοδος|Μενού
tr|Türkçe|Ara|Ana sayfa|Öğren|Tekrar|İlerleme|Menü
ru|Русский|Поиск|Главная|Учёба|Повторение|Прогресс|Меню
uk|Українська|Пошук|Головна|Навчання|Повторення|Прогрес|Меню
ar|العربية|بحث|الرئيسية|تعلّم|مراجعة|التقدّم|القائمة
he|עברית|חיפוש|בית|למידה|חזרה|התקדמות|תפריט
fa|فارسی|جستجو|خانه|یادگیری|مرور|پیشرفت|منو
ur|اردو|تلاش|ہوم|سیکھیں|دہرائی|پیش رفت|مینو
hi|हिन्दी|खोजें|होम|सीखें|दोहराएँ|प्रगति|मेनू
bn|বাংলা|অনুসন্ধান|হোম|শিখুন|পুনরালোচনা|অগ্রগতি|মেনু
ta|தமிழ்|தேடு|முகப்பு|கற்க|மீள்பார்வை|முன்னேற்றம்|மெனு
te|తెలుగు|వెతకండి|హోమ్|నేర్చుకో|పునశ్చరణ|పురోగతి|మెనూ
mr|मराठी|शोधा|मुख्यपृष्ठ|शिका|उजळणी|प्रगती|मेनू
gu|ગુજરાતી|શોધો|હોમ|શીખો|પુનરાવર્તન|પ્રગતિ|મેનૂ
kn|ಕನ್ನಡ|ಹುಡುಕಿ|ಮುಖಪುಟ|ಕಲಿಯಿರಿ|ಪುನರಾವರ್ತನೆ|ಪ್ರಗತಿ|ಮೆನು
ml|മലയാളം|തിരയുക|ഹോം|പഠിക്കുക|പുനരവലോകനം|പുരോഗതി|മെനു
pa|ਪੰਜਾਬੀ|ਖੋਜੋ|ਹੋਮ|ਸਿੱਖੋ|ਦੁਹਰਾਈ|ਤਰੱਕੀ|ਮੀਨੂ
ne|नेपाली|खोज्नुहोस्|गृहपृष्ठ|सिक्नुहोस्|दोहोर्‍याउनु|प्रगति|मेनु
si|සිංහල|සොයන්න|මුල් පිටුව|ඉගෙන ගන්න|සමාලෝචනය|ප්‍රගතිය|මෙනුව
th|ไทย|ค้นหา|หน้าแรก|เรียนรู้|ทบทวน|ความคืบหน้า|เมนู
vi|Tiếng Việt|Tìm kiếm|Trang chủ|Học|Ôn tập|Tiến độ|Menu
id|Bahasa Indonesia|Cari|Beranda|Belajar|Ulasan|Kemajuan|Menu
ms|Bahasa Melayu|Cari|Laman utama|Belajar|Ulang kaji|Kemajuan|Menu
fil|Filipino|Maghanap|Home|Matuto|Balik-aral|Pag-usad|Menu
zh|简体中文|搜索|首页|学习|复习|进度|菜单
zh-TW|繁體中文|搜尋|首頁|學習|複習|進度|選單
ja|日本語|検索|ホーム|学ぶ|復習|進捗|メニュー
ko|한국어|검색|홈|학습|복습|진도|메뉴
sw|Kiswahili|Tafuta|Mwanzo|Jifunze|Rudia|Maendeleo|Menyu
am|አማርኛ|ፍለጋ|መነሻ|ተማር|ክለሳ|እድገት|ምናሌ
af|Afrikaans|Soek|Tuis|Leer|Hersien|Vordering|Kieslys
hr|Hrvatski|Traži|Početna|Učenje|Ponavljanje|Napredak|Izbornik
sr|Српски|Претрага|Почетна|Учење|Понављање|Напредак|Мени
or|ଓଡ଼ିଆ|ସନ୍ଧାନ|ମୁଖ୍ୟ ପୃଷ୍ଠା|ଶିଖନ୍ତୁ|ପୁନରାବୃତ୍ତି|ପ୍ରଗତି|ମେନୁ
as|অসমীয়া|সন্ধান|ঘৰ|শিকক|পুনৰালোচনা|অগ্ৰগতি|মেনু
sa|संस्कृतम्|अन्वेषणम्|मुखपृष्ठम्|पठतु|पुनरावर्तनम्|प्रगतिः|सूची
mai|मैथिली
bho|भोजपुरी
gom|कोंकणी
doi|डोगरी
sd|سنڌي`;

  const EN_NAMES = {"en": "English", "es": "Spanish", "fr": "French", "de": "German", "it": "Italian", "pt": "Portuguese", "nl": "Dutch", "sv": "Swedish", "da": "Danish", "no": "Norwegian", "fi": "Finnish", "pl": "Polish", "cs": "Czech", "sk": "Slovak", "hu": "Hungarian", "ro": "Romanian", "bg": "Bulgarian", "el": "Greek", "tr": "Turkish", "ru": "Russian", "uk": "Ukrainian", "ar": "Arabic", "he": "Hebrew", "fa": "Persian", "ur": "Urdu", "hi": "Hindi", "bn": "Bengali", "ta": "Tamil", "te": "Telugu", "mr": "Marathi", "gu": "Gujarati", "kn": "Kannada", "ml": "Malayalam", "pa": "Punjabi", "ne": "Nepali", "si": "Sinhala", "th": "Thai", "vi": "Vietnamese", "id": "Indonesian", "ms": "Malay", "fil": "Filipino", "zh": "Chinese (Simplified)", "zh-TW": "Chinese (Traditional)", "ja": "Japanese", "ko": "Korean", "sw": "Swahili", "am": "Amharic", "af": "Afrikaans", "hr": "Croatian", "sr": "Serbian", "or": "Odia", "as": "Assamese", "sa": "Sanskrit", "mai": "Maithili", "bho": "Bhojpuri", "gom": "Konkani", "doi": "Dogri", "sd": "Sindhi"};
    const LANGS = D.split("\n").map((l) => { const p = l.split("|"); const t = {}; KEYS.forEach((k, i) => { if (p[i + 2]) t[k] = p[i + 2]; }); return { code: p[0], name: p[1], en: EN_NAMES[p[0]], t }; });
    /* Hand-written phrases with a natural voice (not word-for-word). Order: es|hi|fr|ar|zh|de */
  const RL = ["es", "hi", "fr", "ar", "zh", "de"];
  const R = `Explore|Descubre|खोजिए|À la découverte|اكتشف|去探索|Entdecken
AI Coach|Tu coach con IA|आपका AI साथी|Ton coach IA|مرشدك الذكي|你的AI学习搭档|Dein KI-Coach
Start|Empezar|शुरू कीजिए|C'est parti|ابدأ الآن|开始吧|Los geht's
Chemistry|Química|रसायन विज्ञान|Chimie|الكيمياء|化学|Chemie
Physics|Física|भौतिकी|Physique|الفيزياء|物理|Physik
Biology|Biología|जीव विज्ञान|Biologie|الأحياء|生物|Biologie
Mathematics|Matemáticas|गणित|Mathématiques|الرياضيات|数学|Mathematik
History|Historia|इतिहास|Histoire|التاريخ|历史|Geschichte
Geography|Geografía|भूगोल|Géographie|الجغرافيا|地理|Geografie
English|Inglés|अंग्रेज़ी|Anglais|اللغة الإنجليزية|英语|Englisch
Computer Science|Informática|कंप्यूटर विज्ञान|Informatique|علوم الحاسوب|计算机科学|Informatik
Certificates|Tus certificados|आपके प्रमाणपत्र|Tes certificats|شهاداتك|我的证书|Zertifikate
Glossary|Glosario|शब्दकोश|Glossaire|المسرد|词汇表|Glossar
Exams|Exámenes|परीक्षाएँ|Examens|الاختبارات|考试|Prüfungen
Dashboard|Tu panel|आपका डैशबोर्ड|Ton tableau de bord|لوحتك|学习面板|Dein Dashboard
Log out|Hasta pronto|फिर मिलेंगे|À bientôt|إلى اللقاء|下次见|Bis bald
About Us|Quiénes somos|हमारे बारे में|Notre histoire|من نحن|关于我们|Über uns
Contact Us|Escríbenos|हमसे बात कीजिए|Écris-nous|تواصل معنا|联系我们|Schreib uns
Made with curiosity|Hecho con curiosidad|जिज्ञासा से बना|Fait avec curiosité|صُنع بفضول|满怀好奇而作|Mit Neugier gemacht
Subjects|Materias|विषय|Matières|المواد|学科|Fächer
Tools|Herramientas|साधन|Outils|أدوات|工具|Werkzeuge
Reset|Reiniciar|फिर से शुरू|Recommencer|من جديد|重来|Neustart`;
  const ALL = new Set(KEYS), RICHSET = new Set(RL);
  R.split("\n").forEach((ln) => { const p = ln.split("|"); ALL.add(p[0]); RL.forEach((c, i) => { const l = LANGS.find((x) => x.code === c); if (l) l.t[p[0]] = p[i + 1]; }); });
  RICHSET.add("en");

const RTL = ["ar", "he", "fa", "ur", "sd"];
  const POPULAR = ["en", "hi", "es", "ar", "zh", "fr"];
  const STORE = "curio-lang";
  let cur = "en";
  try { cur = localStorage.getItem(STORE) || "en"; } catch (e) {}
  if (!LANGS.some((l) => l.code === cur)) cur = "en";
  const meta = (c) => LANGS.find((l) => l.code === c) || LANGS[0];
  const orig = new WeakMap();
  /* Hand-written packs: js/lang/<code>.js -> CurioLang.pack(code, { "English phrase": "translation", ... }). */
  const PACKS = new Set(["hi", "bn", "ta", "te", "mr", "gu", "kn", "ml", "pa", "ur", "ne", "or", "as"]);
  const packState = {};
  function pack(code, map) {
    const l = LANGS.find((x) => x.code === code); if (!l) return;
    Object.keys(map).forEach((k) => { ALL.add(k); l.t[k] = map[k]; });
    RICHSET.add(code); packState[code] = 2;
    if (code === cur) { apply(); document.dispatchEvent(new CustomEvent("curio:langpack", { detail: { lang: code } })); }
  }
  function loadPack(code) {
    if (!PACKS.has(code) || packState[code] || !SRC) return;
    packState[code] = 1;
    const sc = document.createElement("script"); sc.src = SRC.replace(/i18n\.js(\?.*)?$/, "lang/" + code + ".js$1"); sc.async = true;
    sc.onerror = () => { packState[code] = 0; }; document.head.appendChild(sc);
  }
  const t = (k) => (meta(cur).t[k]) || k;
  /* Indic and Perso-Arabic scripts get a matching web font where the device has none. */
  const SCRIPT_FONT = { hi: "Devanagari", mr: "Devanagari", ne: "Devanagari", sa: "Devanagari", mai: "Devanagari", bho: "Devanagari", gom: "Devanagari", doi: "Devanagari", bn: "Bengali", as: "Bengali", ta: "Tamil", te: "Telugu", gu: "Gujarati", kn: "Kannada", ml: "Malayalam", pa: "Gurmukhi", or: "Oriya", ur: "Naskh Arabic", sd: "Naskh Arabic", si: "Sinhala" };
  function loadFont(code) {
    const f = SCRIPT_FONT[code]; if (!f || document.getElementById("curio-sf-" + f.replace(/\s/g, ""))) return;
    const l = document.createElement("link"); l.id = "curio-sf-" + f.replace(/\s/g, ""); l.rel = "stylesheet";
    l.href = "https://fonts.googleapis.com/css2?family=Noto+Sans+" + f.replace(/ /g, "+") + ":wght@400;500;600;700&display=swap"; document.head.appendChild(l);
    const st = document.createElement("style"); st.textContent = 'html[lang="' + code + '"] body{font-family:"Noto Sans ' + f + '",system-ui,sans-serif}'; document.head.appendChild(st);
  }
  const NOTRANS = "pre,code,kbd,samp,canvas,.logo,.m-brand,[data-no-i18n]";

  /* ---- 1. Instant, offline, hand-written translations (no network, no loading) ---- */
  function node(n) {
    if (!orig.has(n)) {
      const m = n.nodeValue.match(/^(\s*[^A-Za-z\s]*\s*)([A-Za-z][A-Za-z0-9 &'’,!?.:;()/%–—-]*?)(\s*)$/);
      if (!m || !ALL.has(m[2])) return;
      orig.set(n, { pre: m[1], key: m[2], post: m[3] });
      if (n.parentElement) n.parentElement.setAttribute("translate", "no");
    }
    const o = orig.get(n), tr = meta(cur).t[o.key];
    n.nodeValue = o.pre + (tr || o.key) + o.post;
  }
  function walk(root) {
    if (root.nodeType === 1) {
      if (root.matches && root.matches(NOTRANS)) root.setAttribute("translate", "no");
      root.querySelectorAll && root.querySelectorAll(NOTRANS).forEach((e) => e.setAttribute("translate", "no"));
    }
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n; while ((n = w.nextNode())) { if (n.parentElement && n.parentElement.closest("script,style,[data-no-i18n]")) continue; node(n); }
  }
  function apply() {
    const m = meta(cur);
    document.documentElement.setAttribute("lang", cur);
    document.documentElement.dir = RTL.indexOf(cur) >= 0 ? "rtl" : "ltr";
    walk(document.body);
    document.querySelectorAll("[data-lang-btn]").forEach((b) => b.setAttribute("title", m.name));
  }
  function set(code) {
    cur = code; try { localStorage.setItem(STORE, code); } catch (e) {}
    loadPack(code); loadFont(code);
    if (window.CurioA11y) window.CurioA11y.announce(meta(code).name);
    const calm = !matchMedia("(prefers-reduced-motion: reduce)").matches && !(window.CurioA11y && window.CurioA11y.reducedMotion());
    if (calm && document.body.animate) document.body.animate([{ opacity: 1 }, { opacity: .35 }, { opacity: 1 }], { duration: 380, easing: "ease-in-out" });
    setTimeout(() => { apply(); wholePage(); }, calm ? 150 : 0);
    document.dispatchEvent(new CustomEvent("curio:langchange", { detail: { lang: code } }));
  }

/* ---- 2. Whole-page translation: on-device translator first, hidden Google fallback, branded progress pill ---- */
  const GCODE = { zh: "zh-CN", he: "iw", fil: "tl" };
  const SKIP = "script,style,pre,code,kbd,samp,canvas,[data-no-i18n],[translate=no]";
  let nat = null, natCode = null, gState = "idle", gTimer = null; const touched = [], wo = new WeakMap();
  const pcss = document.createElement("style");
  pcss.textContent = `iframe.skiptranslate,.goog-te-banner-frame,#goog-gt-tt,.goog-te-balloon-frame,.goog-tooltip{display:none!important}body{top:0!important}#curio_gt{display:none!important}.goog-text-highlight{background:none!important;box-shadow:none!important}
.curio-pill{position:fixed;left:50%;bottom:92px;transform:translate(-50%,18px);opacity:0;pointer-events:none;z-index:2147482000;display:flex;gap:10px;align-items:center;padding:10px 18px;border-radius:999px;background:rgba(18,38,46,.92);color:#fff;font:600 14px system-ui,sans-serif;backdrop-filter:blur(10px);box-shadow:0 10px 30px #0004;transition:all .4s cubic-bezier(.16,1,.3,1)}.curio-pill.on{opacity:1;transform:translate(-50%,0)}.curio-pill i{width:14px;height:14px;border-radius:50%;border:2px solid #fff4;border-top-color:#f4a259;animation:cps .8s linear infinite}@keyframes cps{to{transform:rotate(360deg)}}`;
  document.head.appendChild(pcss);
  const pill = document.createElement("div"); pill.className = "curio-pill"; pill.setAttribute("data-no-i18n", ""); pill.setAttribute("translate", "no"); pill.innerHTML = "<i></i><span></span>";
  function busy(on) { if (on) { pill.lastChild.textContent = "✦ " + meta(cur).name + "…"; if (!pill.isConnected) document.body.appendChild(pill); requestAnimationFrame(() => pill.classList.add("on")); } else pill.classList.remove("on"); }

  async function translateTree(root) {
    if (!nat) return;
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), list = []; let n;
    while ((n = w.nextNode())) { const p = n.parentElement; if (!p || p.closest(SKIP) || !/[A-Za-z]{2,}/.test(n.nodeValue)) continue; list.push(n); }
    for (let i = 0; i < list.length; i += 12) {
      if (natCode !== cur) return;
      await Promise.all(list.slice(i, i + 12).map(async (t) => {
        if (!wo.has(t)) { wo.set(t, t.nodeValue); touched.push(t); }
        const src = wo.get(t), core = src.trim();
        try { const out = await nat.translate(core); if (natCode === cur) t.nodeValue = src.replace(core, out); } catch (e) {}
      }));
    }
  }
  function restoreEnglish() { touched.forEach((t) => { if (wo.has(t)) t.nodeValue = wo.get(t); }); }
  async function nativeSync() {
    if (!("Translator" in self)) return false;
    try {
      if ((await Translator.availability({ sourceLanguage: "en", targetLanguage: cur })) === "unavailable") return false;
      nat = await Translator.create({ sourceLanguage: "en", targetLanguage: cur }); natCode = cur;
    } catch (e) { return false; }
    await translateTree(document.body); return true;
  }
  function combo() { return document.querySelector("select.goog-te-combo"); }
  function loadGoogle() {
    if (gState !== "idle") return;
    if (window.CurioAge && !window.CurioAge.allowed("translate")) { gState = "failed"; busy(false); return; }
    gState = "loading";
    const h = document.createElement("div"); h.id = "curio_gt"; h.setAttribute("translate", "no"); document.body.appendChild(h);
    window.curioGTInit = function () { new google.translate.TranslateElement({ pageLanguage: "en", autoDisplay: false, includedLanguages: LANGS.map((l) => GCODE[l.code] || l.code).join(",") }, "curio_gt"); gState = "ready"; };
    const sc = document.createElement("script"); sc.src = "https://translate.google.com/translate_a/element.js?cb=curioGTInit"; sc.async = true;
    sc.onerror = () => { gState = "failed"; busy(false); }; document.head.appendChild(sc);
  }
  function googleSync() {
    clearInterval(gTimer);
    if (cur === "en" && gState === "idle") return;
    if (cur !== "en") { loadGoogle(); busy(true); }
    let tries = 0;
    gTimer = setInterval(() => {
      const c = combo(); tries++;
      if (c) {
        const want = cur === "en" ? "" : (GCODE[cur] || cur);
        if (c.value !== want) { c.value = want; c.dispatchEvent(new Event("change")); }
        if (cur === "en" || /translated-/.test(document.documentElement.className) || tries > 60) { clearInterval(gTimer); busy(false); }
      } else if (gState === "failed" || tries > 80) { clearInterval(gTimer); busy(false); }
    }, 150);
  }
  async function wholePage() {
    if (cur === "en") { natCode = null; restoreEnglish(); googleSync(); return; }
    busy(true);
    if (await nativeSync()) { busy(false); return; }
    googleSync();
  }

/* ---- 3. Language menu (shadow DOM, so page CSS can't distort it) ---- */
  const GLOBE = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/></svg>';
  const CHECK = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>';
  const MENU_CSS = `
*{box-sizing:border-box;margin:0;padding:0}
:host{all:initial}
.wrap{position:fixed;inset:0;z-index:2147483000;font:15px/1.35 "Plus Jakarta Sans",system-ui,-apple-system,"Segoe UI",Roboto,"Noto Sans",sans-serif;--ink:var(--color-ink,#16323a);color:var(--ink);-webkit-tap-highlight-color:transparent;--ac:var(--accent,#1b7f95);--aci:var(--accent-ink,#fff);--bg:var(--sheet-bg,var(--color-surface,#fff));color-scheme:inherit}
.bg{position:absolute;inset:0;background:rgba(10,22,28,.5);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);animation:f .25s ease}
.sheet{position:absolute;left:0;right:0;bottom:0;height:min(86vh,700px);background:var(--bg);border:1px solid color-mix(in srgb,var(--ink) 10%,transparent);border-bottom:0;border-radius:28px 28px 0 0;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 -14px 50px rgba(0,0,0,.3);animation:u .38s cubic-bezier(.16,1,.3,1);direction:ltr;text-align:left}
.sheet::before{content:"";position:absolute;inset:0 0 auto;height:190px;background:radial-gradient(120% 90% at 15% 0%,color-mix(in srgb,var(--ac) 30%,transparent),transparent 70%),radial-gradient(90% 80% at 100% 0%,color-mix(in srgb,#f4a259 26%,transparent),transparent 70%);pointer-events:none}
@media(min-width:700px){.bg{background:transparent;backdrop-filter:none;-webkit-backdrop-filter:none}.sheet{left:auto;right:16px;bottom:auto;top:64px;width:400px;height:min(74vh,620px);border-radius:26px;box-shadow:0 24px 70px rgba(0,0,0,.28),0 0 0 1px rgba(0,0,0,.06);animation:d .3s cubic-bezier(.16,1,.3,1)}}
@keyframes f{from{opacity:0}}@keyframes u{from{transform:translateY(60px);opacity:0}}@keyframes d{from{transform:translateY(-10px) scale(.97);opacity:0}}
@keyframes r{from{transform:translateY(8px);opacity:0}}
.grab{width:42px;height:4px;border-radius:2px;background:color-mix(in srgb,var(--ink) 28%,transparent);margin:10px auto 0;flex:none;position:relative}
@media(min-width:700px){.grab{display:none}}
.head{display:flex;align-items:center;gap:12px;padding:16px 18px 4px;flex:none;position:relative}
.orb{width:42px;height:42px;border-radius:14px;display:grid;place-items:center;color:var(--aci);background:linear-gradient(135deg,var(--ac),color-mix(in srgb,var(--ac) 55%,#f4a259));box-shadow:0 6px 16px color-mix(in srgb,var(--ac) 40%,transparent)}
.ht{flex:1;min-width:0}
.ht h2{font-size:20px;font-weight:800;letter-spacing:-.02em}
.ht p{font-size:12.5px;opacity:.65;margin-top:1px}
.x{all:unset;width:36px;height:36px;border-radius:50%;display:grid;place-items:center;cursor:pointer;background:color-mix(in srgb,var(--ink,#16323a) 8%,transparent);font-size:20px;line-height:1;transition:transform .2s,background .2s}
.x:hover{transform:rotate(90deg);background:color-mix(in srgb,var(--ink,#16323a) 15%,transparent)}
.sw{position:relative;margin:12px 16px 10px;flex:none}
.sw svg{position:absolute;left:15px;top:50%;transform:translateY(-50%);opacity:.5;pointer-events:none}
input{all:unset;box-sizing:border-box;width:100%;height:48px;padding:0 16px 0 44px;border-radius:16px;background:color-mix(in srgb,var(--bg) 70%,transparent);backdrop-filter:blur(8px);font-size:16px;color:inherit;border:1.5px solid color-mix(in srgb,var(--ink,#16323a) 14%,transparent);transition:border-color .2s,box-shadow .2s}
input:focus{border-color:var(--ac);box-shadow:0 0 0 4px color-mix(in srgb,var(--ac) 18%,transparent)}
input::placeholder{opacity:.5;color:inherit}
.chips{display:flex;gap:8px;padding:0 16px 12px;overflow-x:auto;flex:none;scrollbar-width:none}
.chips::-webkit-scrollbar{display:none}
.chip{all:unset;flex:none;padding:8px 15px;border-radius:999px;background:color-mix(in srgb,var(--ink,#16323a) 6%,transparent);font-size:14px;font-weight:600;cursor:pointer;white-space:nowrap;transition:transform .15s,background .2s}
.chip:hover{transform:translateY(-1px)}
.chip[aria-pressed=true]{background:var(--ac);color:var(--aci)}
.list{list-style:none;overflow-y:auto;overscroll-behavior:contain;padding:4px 14px 20px;flex:1;display:grid;grid-template-columns:1fr 1fr;gap:10px;align-content:start;scrollbar-width:thin}
.list li{animation:r .4s cubic-bezier(.16,1,.3,1) both;animation-delay:calc(var(--i,0)*14ms);min-width:0}
.row{all:unset;box-sizing:border-box;display:flex;align-items:center;gap:10px;width:100%;height:100%;padding:12px;border-radius:18px;cursor:pointer;direction:ltr;text-align:left;border:1.5px solid color-mix(in srgb,var(--ink,#16323a) 10%,transparent);background:color-mix(in srgb,var(--bg) 90%,var(--ink) 5%);transition:transform .18s,box-shadow .18s,border-color .18s}
.row:hover{transform:translateY(-2px);border-color:color-mix(in srgb,var(--ac) 55%,transparent);box-shadow:0 8px 20px color-mix(in srgb,var(--ac) 16%,transparent)}
.row:focus-visible,.x:focus-visible,.chip:focus-visible,input:focus-visible,h2:focus-visible{outline:3px solid var(--ac);outline-offset:2px}
h2:focus{outline:none}
.row[aria-current=true]{border-color:var(--ac);background:color-mix(in srgb,var(--ac) 13%,var(--bg))}
.g{flex:none;width:36px;height:36px;border-radius:12px;display:grid;place-items:center;font-weight:800;font-size:15px;color:color-mix(in srgb,var(--ac) 68%,var(--ink));background:color-mix(in srgb,var(--ac) 14%,transparent);text-transform:uppercase}
.row[aria-current=true] .g{background:var(--ac);color:var(--aci)}
.txt{flex:1;min-width:0;display:flex;flex-direction:column;gap:1px}
.nm{font-size:15.5px;font-weight:700;unicode-bidi:isolate;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.en{font-size:12px;opacity:.6;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.st{flex:none;color:#f4a259;font-size:13px}
.empty{grid-column:1/-1;padding:30px 12px;text-align:center;opacity:.6}
.note{font-size:12px;opacity:.65;padding:11px 18px 14px;border-top:1px solid color-mix(in srgb,var(--ink,#16323a) 9%,transparent);flex:none}
.note b{color:#e08a3c}
@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}`;

  let menuHost = null, menuRoot = null, menuOpener = null;
  function closeMenu() {
    if (!menuHost) return;
    menuHost.remove(); menuHost = menuRoot = null; document.removeEventListener("keydown", onKey, true);
    const o = menuOpener; menuOpener = null;
    if (o && document.contains(o)) o.focus(); else { const b = document.querySelector("[data-lang-btn]"); if (b) b.focus(); }
  }
  function onKey(e) {
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); closeMenu(); return; }
    if (e.key !== "Tab" || !menuRoot) return;
    // keep Tab inside the dialog
    const f = Array.from(menuRoot.querySelectorAll("button,input")).filter((x) => x.offsetParent !== null || x === menuRoot.activeElement);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1], act = menuRoot.activeElement;
    if (e.shiftKey && (act === first || !act || act.id === "lm-t")) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && act === last) { e.preventDefault(); first.focus(); }
  }
  function openMenu() {
    if (menuHost) { closeMenu(); return; }
    menuOpener = document.activeElement;
    menuHost = document.createElement("div"); menuHost.setAttribute("data-no-i18n", ""); menuHost.setAttribute("translate", "no");
    const root = menuHost.attachShadow({ mode: "open" });
    root.innerHTML = `<style>${MENU_CSS}</style><div class="wrap"><div class="bg"></div><div class="sheet" role="dialog" aria-modal="true" aria-labelledby="lm-t">
      <div class="grab"></div>
      <div class="head"><div class="orb">${GLOBE}</div><div class="ht"><h2 id="lm-t" tabindex="-1">Choose your language</h2><p>Learn in the words that feel like home</p></div><button class="x" aria-label="Close"><span aria-hidden="true">×</span></button></div>
      <div class="sw"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg><input type="text" inputmode="search" enterkeyhint="search" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Search ${LANGS.length} languages" aria-label="Search language"></div>
      <div class="chips"></div>
      <ul class="list"></ul>
      <div class="note"><span class="st">✦</span> <b>Hand-written</b> labels, plus whole pages translated automatically.</div></div></div>`;
    const $ = (s) => root.querySelector(s), list = $(".list"), inp = $("input"), chips = $(".chips");
    function pick(code) { set(code); closeMenu(); }
    function draw(q) {
      q = (q || "").trim().toLowerCase(); list.innerHTML = "";
      const rows = LANGS.filter((l) => !q || l.name.toLowerCase().includes(q) || l.en.toLowerCase().includes(q) || l.code.toLowerCase() === q);
      if (!rows.length) { list.innerHTML = '<li class="empty">No language found</li>'; return; }
      rows.forEach((l, i) => {
        const li = document.createElement("li"), b = document.createElement("button");
        li.style.setProperty("--i", Math.min(i, 24));
        b.className = "row"; b.type = "button"; if (l.code === cur) b.setAttribute("aria-current", "true");
        b.innerHTML = `<span class="g"></span><span class="txt"><span class="nm"></span><span class="en"></span></span>${RICHSET.has(l.code) ? '<span class="st" title="Hand-written">✦</span>' : ""}`;
        b.querySelector(".g").textContent = l.code.slice(0, 2); b.querySelector(".nm").textContent = l.name; b.querySelector(".nm").setAttribute("lang", l.code); b.querySelector(".en").textContent = l.en;
        b.addEventListener("click", () => pick(l.code)); li.appendChild(b); list.appendChild(li);
      });
    }
    POPULAR.forEach((c) => { const b = document.createElement("button"); b.className = "chip"; b.type = "button"; b.textContent = meta(c).name; b.setAttribute("aria-pressed", String(c === cur)); b.addEventListener("click", () => pick(c)); chips.appendChild(b); });
    inp.addEventListener("input", () => { draw(inp.value); chips.style.display = inp.value ? "none" : "flex"; });
    $(".bg").addEventListener("click", closeMenu); $(".x").addEventListener("click", closeMenu);
    draw(""); document.body.appendChild(menuHost); menuRoot = root; document.addEventListener("keydown", onKey, true);
    const cr = list.querySelector("[aria-current]"); if (cr) list.scrollTop = Math.max(0, cr.closest("li").offsetTop - 120);
    if (window.matchMedia("(hover:hover)").matches) inp.focus(); else $("#lm-t").focus({ preventScroll: true });
  }

const css = document.createElement("style");
  css.textContent = `.lang-btn{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:50%;border:1px solid var(--color-line,var(--line,rgba(0,0,0,.15)));background:var(--color-surface,var(--surface,#fff));color:var(--color-ink,var(--ink,#16323a));cursor:pointer;flex:none;padding:0;transition:border-color .15s,transform .15s}.lang-btn:hover{border-color:var(--accent,currentColor);transform:translateY(-1px)}`;
  document.head.appendChild(css);

  function mk(extra) {
    const b = document.createElement("button");
    b.type = "button"; b.className = "lang-btn " + (extra || ""); b.setAttribute("data-lang-btn", ""); b.setAttribute("data-no-sfx", "");
    b.setAttribute("aria-label", "Change language"); b.setAttribute("aria-haspopup", "dialog"); b.setAttribute("translate", "no"); b.innerHTML = GLOBE;
    b.addEventListener("click", openMenu); return b;
  }
  function inject() {
    document.querySelectorAll(".site-header [data-sound-toggle]").forEach((s) => { if (!s.parentElement.querySelector("[data-lang-btn]")) s.after(mk("sound-toggle")); });
    const tr = document.querySelector(".main .topbar .top-right");
    if (tr && !tr.querySelector("[data-lang-btn]")) tr.insertBefore(mk(), tr.firstChild);
  }

  function init() {
    loadPack(cur); loadFont(cur);
    inject(); apply(); if (cur !== "en") wholePage();
    new MutationObserver((muts) => {
      inject();
      muts.forEach((m) => m.addedNodes.forEach((n) => { if (n.nodeType === 3) node(n); else if (n.nodeType === 1 && n.id !== "curio_gt" && !n.classList.contains("curio-pill")) { walk(n); if (nat && natCode === cur && cur !== "en") translateTree(n); } }));
    }).observe(document.body, { childList: true, subtree: true });
  }
  window.CurioLang = { set, get: () => cur, languages: LANGS, pack, t };
  if (document.body) init(); else document.addEventListener("DOMContentLoaded", init);
})();
