// Curio Lab — dashboard. Every number, list and chart here is computed from what
// the learner has actually done (lessons opened, quizzes finished), read from
// CurioLearning. Nothing is sample data: with no activity you see zeros and
// clear prompts to start.
(function () {
  "use strict";
  const CAT = window.CurioCatalog || { subjects: [], lessons: [] };
  const META = {
    Physics: { code: "PHY", color: "#177d75" }, Chemistry: { code: "CHM", color: "#bc7c27" },
    Biology: { code: "BIO", color: "#4f8b2c" }, English: { code: "ENG", color: "#6547da" },
    Mathematics: { code: "MTH", color: "#c23b82" }, History: { code: "HIS", color: "#b5541c" },
    Geography: { code: "GEO", color: "#1f7fa6" }, "Computer Science": { code: "CS", color: "#7656d6" },
    Exam: { code: "EXM", color: "#24165e" },
  };
  const PAGE_SIZE = 5;
  const ui = { tab: "inprogress", more: false, view: "list", calOffset: 0, selDay: null };
  let lastState = null;
  let account = null;

  const $ = (s) => document.querySelector(s);
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const setText = (s, v) => { const el = $(s); if (el) el.textContent = v; };
  const setHTML = (s, v) => { const el = $(s); if (el) el.innerHTML = v; };
  const setWidth = (s, p) => { const el = $(s); if (el) el.style.width = Math.max(0, Math.min(100, p)) + "%"; };
  const meta = (s) => META[s] || { code: String(s || "?").slice(0, 3).toUpperCase(), color: "#6547da" };
  const dayKey = (d) => { d = new Date(d); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };
  const startOfDay = (d) => { d = new Date(d); d.setHours(0, 0, 0, 0); return d; };
  const byAt = (a, b) => String(a.at).localeCompare(String(b.at));
  const pctOf = (e) => Math.round((e.score / e.total) * 100);
  const plural = (n, w) => n + " " + w + (n === 1 ? "" : "s");
  const timeFmt = new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" });
  const shortFmt = new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" });
  const longDate = new Intl.DateTimeFormat(undefined, { weekday: "long", day: "numeric", month: "long" });
  function when(iso) {
    const d = new Date(iso), diff = Math.round((startOfDay(new Date()) - startOfDay(d)) / 86400000);
    if (diff === 0) return "Today, " + timeFmt.format(d);
    if (diff === 1) return "Yesterday, " + timeFmt.format(d);
    return shortFmt.format(d) + ", " + timeFmt.format(d);
  }

  const catByHref = new Map(CAT.lessons.map((l) => [l.h, l]));
  const findLesson = (subject, title) => CAT.lessons.find((l) => l.s === subject && l.t === title);
  const subjectHref = (s) => { if (s === "Exam") return "pages/exams.html"; const x = CAT.subjects.find((y) => y.name === s); return x ? x.href : "pages/physics.html"; };
  const eventHref = (e) => e.href || (findLesson(e.subject, e.lesson) || {}).h || subjectHref(e.subject);

  /* ---------------- analysis ---------------- */
  function averageOf(list) {
    const answered = list.reduce((s, e) => s + e.total, 0), correct = list.reduce((s, e) => s + e.score, 0);
    return answered ? Math.round((correct / answered) * 100) : null;
  }

  function analyze(state) {
    const quizzes = state.events.slice().sort(byAt);
    const lessons = new Map();
    state.lessonProgress.forEach((p) => {
      let href = p.href, cat = href && catByHref.get(href);
      if (!cat) { cat = findLesson(p.subject, p.title); if (cat) href = cat.h; }
      const key = href || p.subject + ":" + p.title;
      const cur = lessons.get(key) || { href: href || subjectHref(p.subject), title: cat ? cat.t : p.title, subject: cat ? cat.s : p.subject, attempts: 0, best: null, at: null };
      cur.attempts += p.attempts;
      if (p.best != null) cur.best = cur.best == null ? p.best : Math.max(cur.best, p.best);
      if (!cur.at || String(p.visitedAt) > String(cur.at)) cur.at = p.visitedAt;
      lessons.set(key, cur);
    });
    lessons.forEach((l) => {
      l.status = l.best == null ? "visited" : l.best >= 60 ? "completed" : "attempted";
      l.pct = l.status === "completed" ? 100 : l.status === "attempted" ? 65 : 30;
    });
    const list = [...lessons.values()].sort((a, b) => String(b.at).localeCompare(String(a.at)));
    const listByHref = new Map(list.map((l) => [l.href, l]));

    // activity by calendar day
    const days = new Map();
    const addDay = (at, item) => { const k = dayKey(at); if (!days.has(k)) days.set(k, []); days.get(k).push(item); };
    state.visits.forEach((v) => { const cat = catByHref.get(v.href) || findLesson(v.subject, v.title); addDay(v.at, { kind: "Lesson", title: cat ? cat.t : v.title, detail: v.subject + " · opened", href: cat ? cat.h : v.href, at: v.at }); });
    quizzes.forEach((e) => addDay(e.at, { kind: "Quiz", title: e.lesson, detail: e.subject + " · " + pctOf(e) + "% (" + e.score + "/" + e.total + ")", href: eventHref(e), at: e.at }));
    days.forEach((items) => items.sort(byAt).reverse());

    const today = dayKey(new Date());
    let streak = 0;
    const cursor = startOfDay(new Date());
    if (!days.has(dayKey(cursor))) cursor.setDate(cursor.getDate() - 1);
    while (days.has(dayKey(cursor))) { streak += 1; cursor.setDate(cursor.getDate() - 1); }
    const activeToday = days.has(today);
    const quizToday = quizzes.filter((e) => dayKey(e.at) === today).length;

    const xp = quizzes.reduce((s, e) => s + 50 + Math.round((e.score / e.total) * 50), 0) + list.length * 10;
    const level = Math.floor(xp / 250) + 1, into = xp % 250;

    const scores = quizzes.map((e) => ({ score: e.score, total: e.total, subject: e.subject, lesson: e.lesson }));
    const trophies = (window.CurioAchievements && window.CurioAchievements.TROPHIES) || [];
    const earned = trophies.filter((t) => t.test(scores));
    const locked = trophies.filter((t) => !t.test(scores));

    const subjects = CAT.subjects.map((s) => {
      const total = CAT.lessons.filter((l) => l.s === s.name).length;
      const mine = list.filter((l) => l.subject === s.name);
      const qs = quizzes.filter((e) => e.subject === s.name);
      return { name: s.name, href: s.href, total, explored: Math.min(total, mine.length), completed: mine.filter((l) => l.status === "completed").length, attempts: qs.length, avg: averageOf(qs), lastAt: mine[0] ? mine[0].at : null };
    });
    const avgBySubject = [...new Set(quizzes.map((e) => e.subject))].map((name) => {
      const qs = quizzes.filter((e) => e.subject === name);
      return { name, attempts: qs.length, avg: averageOf(qs) };
    });

    const weekStart = startOfDay(new Date()); weekStart.setDate(weekStart.getDate() - 6);
    const prevStart = new Date(weekStart); prevStart.setDate(prevStart.getDate() - 7);
    const week = Array.from({ length: 7 }, (_, i) => { const d = new Date(weekStart); d.setDate(d.getDate() + i); return { date: d, count: quizzes.filter((e) => dayKey(e.at) === dayKey(d)).length }; });
    const last7 = quizzes.filter((e) => new Date(e.at) >= weekStart);
    const prev7 = quizzes.filter((e) => new Date(e.at) >= prevStart && new Date(e.at) < weekStart);
    const trend = last7.length && prev7.length ? averageOf(last7) - averageOf(prev7) : null;

    const focus = (state.profile && CAT.subjects.some((s) => s.name === state.profile.course) && state.profile.course)
      || (state.resume && CAT.subjects.some((s) => s.name === state.resume.subject) && state.resume.subject) || "Physics";

    return { quizzes, list, listByHref, days, streak, activeToday, quizToday, xp, level, into, earned, locked, trophies, subjects, avgBySubject, week, trend, average: averageOf(quizzes), focus, weekQuizzes: last7.length };
  }

  // "Next for you": next lesson chosen from the learner's weak spots (js/next-lesson.js); null when nothing is weak.
  const nextFor = (a) => { try { return window.CurioNext ? window.CurioNext.recommend(a.list) : null; } catch (_) { return null; } };
  const nextNew = (a, subject, n) => CAT.lessons.filter((l) => l.s === subject && !a.listByHref.has(l.h)).slice(0, n);

  /* ---------------- pieces ---------------- */
  function lessonRow(l, opts) {
    const m = meta(l.subject);
    let label, detail, icon, pct = l.pct;
    if (opts && opts.isNew) { label = "New lesson"; detail = l.subject + " · not started"; icon = "NEW"; pct = 0; }
    else if (l.status === "completed") { label = "Completed"; detail = l.subject + " · best quiz " + l.best + "%"; icon = "✓"; }
    else if (l.status === "attempted") { label = "Quiz taken"; detail = l.subject + " · best quiz " + l.best + "% · 60% completes it"; icon = l.best + "%"; }
    else { label = "Opened"; detail = l.subject + " · take the quiz to finish"; icon = "▶"; }
    return `<a class="subject-row" href="${esc(l.href)}"><div class="subj-badge" style="background:var(--accent-soft);--sc:${m.color};"><span class="tag">${m.code}</span><span class="code">${esc(icon)}</span></div><div class="subj-info"><div class="name">${esc(l.title)}</div><div class="topic">${esc(detail)}${l.at ? " · " + esc(when(l.at)) : ""}</div></div><div class="subj-meta"><div class="fig"><span>${esc(label)}</span><span>${pct}%</span></div><div class="subj-bar"><span style="width:${pct}%;background:${m.color};"></span></div></div><div class="chev">›</div></a>`;
  }
  function subjectRow(s) {
    const m = meta(s.name), pct = s.total ? Math.round((s.explored / s.total) * 100) : 0;
    return `<a class="subject-row" href="${esc(s.href)}"><div class="subj-badge" style="background:var(--accent-soft);--sc:${m.color};"><span class="tag">${m.code}</span><span class="code">${String(s.explored).padStart(2, "0")}</span></div><div class="subj-info"><div class="name">${esc(s.name)}</div><div class="topic">${s.completed} completed${s.avg != null ? " · " + s.avg + "% quiz average" : " · no quizzes yet"}</div></div><div class="subj-meta"><div class="fig"><span>${s.explored} of ${s.total} explored</span><span>${pct}%</span></div><div class="subj-bar"><span style="width:${pct}%;background:${m.color};"></span></div></div><div class="chev">›</div></a>`;
  }
  const emptyBox = (text, href, cta) => `<div class="empty-copy">${esc(text)}${href ? ` <a class="empty-link" href="${esc(href)}">${esc(cta)} ›</a>` : ""}</div>`;

  function renderSubjects(a) {
    const holder = $("[data-subject-list]"); if (!holder) return;
    const inprog = a.list.filter((l) => l.status !== "completed");
    const done = a.list.filter((l) => l.status === "completed");
    const nx = nextFor(a);
    const nxRow = nx ? [{ l: a.listByHref.get(nx.lesson.h) || { href: nx.lesson.h, title: nx.lesson.t, subject: nx.lesson.subject, pct: 0 }, isNew: !a.listByHref.has(nx.lesson.h) }] : [];
    const rec = [
      ...nxRow,
      ...a.list.filter((l) => l.status === "attempted").sort((x, y) => x.best - y.best).slice(0, 2).map((l) => ({ l, isNew: false })),
      ...nextNew(a, a.focus, 3).map((c) => ({ l: { href: c.h, title: c.t, subject: c.s, pct: 0 }, isNew: true })),
      ...CAT.subjects.filter((s) => s.name !== a.focus).map((s) => nextNew(a, s.name, 1)[0]).filter(Boolean).slice(0, 3).map((c) => ({ l: { href: c.h, title: c.t, subject: c.s, pct: 0 }, isNew: true })),
    ].filter((r, i, all) => all.findIndex((x) => x.l.href === r.l.href) === i);
    const counts = { inprogress: inprog.length, completed: done.length, recommended: rec.length, all: a.subjects.length };
    document.querySelectorAll("[data-tab]").forEach((btn) => {
      const on = btn.dataset.tab === ui.tab;
      btn.classList.toggle("active", on); btn.setAttribute("aria-selected", on ? "true" : "false");
      const c = btn.querySelector(".count"); if (c) c.textContent = counts[btn.dataset.tab];
    });
    let rows, total;
    if (ui.tab === "all") { rows = a.subjects.map(subjectRow); }
    else if (ui.tab === "completed") { rows = done.map((l) => lessonRow(l)); }
    else if (ui.tab === "recommended") { rows = rec.map((r) => lessonRow(r.l, { isNew: r.isNew })); }
    else { rows = inprog.map((l) => lessonRow(l)); }
    total = rows.length;
    if (!total) {
      holder.innerHTML = ui.tab === "completed"
        ? emptyBox("No completed lessons yet. Score 60% or more on a lesson's quiz and it lands here.", subjectHref(a.focus), "Open " + a.focus)
        : emptyBox("Nothing in progress yet. Open any lesson and it appears here with your progress.", subjectHref(a.focus), "Browse " + a.focus);
      return;
    }
    const shown = ui.more ? rows : rows.slice(0, PAGE_SIZE);
    holder.innerHTML = shown.join("") + (total > PAGE_SIZE ? `<button type="button" class="more-btn" data-more>${ui.more ? "Show fewer" : "Show " + (total - PAGE_SIZE) + " more"}</button>` : "");
  }

  function planItems(a, state) {
    const items = [];
    const nx = nextFor(a);
    if (nx) items.push({ t: (nx.kind === "review" ? "Review " : "Learn ") + nx.lesson.t, s: nx.short, href: nx.lesson.h, tag: nx.tag });
    const cont = a.list.find((l) => l.status !== "completed");
    if (cont && nx && cont.href === nx.lesson.h) { /* already shown as the next step */ }
    else if (cont) items.push({ t: "Continue " + cont.title, s: cont.subject + " · " + (cont.status === "attempted" ? "quiz " + cont.best + "% — retake to complete" : "take the quiz to finish"), href: cont.href, tag: "CONTINUE" });
    else if (!a.list.length) { const first = nextNew(a, a.focus, 1)[0]; if (first) items.push({ t: "Start " + first.t, s: a.focus + " · your first lesson", href: first.h, tag: "START" }); }
    const weak = a.list.filter((l) => l.status === "attempted" && (!cont || l.href !== cont.href)).sort((x, y) => x.best - y.best)[0];
    if (weak && !(nx && weak.href === nx.lesson.h)) items.push({ t: "Retake " + weak.title, s: "Best so far " + weak.best + "% · 60% completes it", href: weak.href, tag: "RETAKE" });
    const low = a.avgBySubject.filter((s) => s.avg != null && s.avg < 75 && s.name !== "Exam").sort((x, y) => x.avg - y.avg)[0];
    if (low) items.push({ t: "Review " + low.name, s: low.avg + "% average across " + plural(low.attempts, "quiz"), href: subjectHref(low.name), tag: "REVIEW" });
    const nn = nextNew(a, a.focus, 1)[0];
    if (nn && a.list.length && !(nx && nx.lesson.h === nn.h)) items.push({ t: "Learn " + nn.t, s: a.focus + " · new lesson", href: nn.h, tag: "NEW" });
    if (a.list.length && !a.quizToday) items.push({ t: "Finish a quiz today", s: a.streak ? "Keeps your " + a.streak + "-day streak going" : "Starts your streak", href: (cont || a.list[0]).href, tag: "GOAL" });
    return items.slice(0, 4);
  }

  function renderUpcoming(a, state) {
    const holder = $("[data-upcoming-list]"); if (!holder) return;
    document.querySelectorAll("[data-view]").forEach((b) => { const on = b.dataset.view === ui.view; b.classList.toggle("active", on); b.setAttribute("aria-pressed", on ? "true" : "false"); });
    if (ui.view === "calendar") return renderCalendar(a, holder);
    const items = planItems(a, state);
    holder.innerHTML = items.length ? items.map((it, i) => `<a class="up-item" href="${esc(it.href)}"><div class="up-date"><div class="mo">STEP</div><div class="day">${i + 1}</div></div><div class="up-info"><div class="t">${esc(it.t)}</div><div class="s">${esc(it.s)}</div></div><div class="up-pill pill-quiz">${it.tag}</div></a>`).join("") : emptyBox("Your study plan builds itself from your activity.", subjectHref(a.focus), "Start " + a.focus);
  }

  function renderCalendar(a, holder) {
    const base = new Date(); base.setDate(1); base.setMonth(base.getMonth() + ui.calOffset);
    const y = base.getFullYear(), m = base.getMonth(), first = new Date(y, m, 1).getDay(), count = new Date(y, m + 1, 0).getDate();
    const todayKey = dayKey(new Date());
    if (!ui.selDay || ui.selDay.slice(0, 7) !== dayKey(base).slice(0, 7)) ui.selDay = ui.calOffset === 0 ? todayKey : dayKey(base);
    let cells = ["S", "M", "T", "W", "T", "F", "S"].map((d) => `<span class="cal-h">${d}</span>`).join("") + '<span class="cal-e"></span>'.repeat(first);
    let activeCount = 0;
    for (let d = 1; d <= count; d++) {
      const k = dayKey(new Date(y, m, d)), n = (a.days.get(k) || []).length;
      if (n) activeCount += 1;
      cells += `<button type="button" class="cal-d${n ? " has" : ""}${k === todayKey ? " today" : ""}${k === ui.selDay ? " sel" : ""}" data-cal-day="${k}" aria-label="${d}${n ? ", " + plural(n, "activity") : ""}">${d}</button>`;
    }
    const items = a.days.get(ui.selDay) || [];
    const detail = items.length
      ? items.slice(0, 5).map((it) => `<a class="cal-item" href="${esc(it.href)}"><b>${esc(it.kind)}</b><span>${esc(it.title)}<small>${esc(it.detail)}</small></span></a>`).join("")
      : `<p class="empty-copy" style="padding:6px 0 0">No lessons or quizzes on ${esc(shortFmt.format(new Date(ui.selDay + "T12:00:00")))}.</p>`;
    holder.innerHTML = `<div class="cal"><div class="cal-top"><button type="button" class="cal-nav" data-cal-nav="-1" aria-label="Previous month">‹</button><strong>${new Intl.DateTimeFormat(undefined, { month: "long", year: "numeric" }).format(base)}</strong><button type="button" class="cal-nav" data-cal-nav="1" aria-label="Next month"${ui.calOffset >= 0 ? " disabled" : ""}>›</button></div><div class="cal-grid">${cells}</div><div class="cal-sum">${plural(activeCount, "active day")} this month</div><div class="cal-list">${detail}</div></div>`;
  }

  function renderInsights(a) {
    const holder = $("[data-insights]"); if (!holder) return;
    const max = Math.max(...a.week.map((w) => w.count), 1);
    const chip = a.trend != null ? (a.trend >= 0 ? "↑ " : "↓ ") + Math.abs(a.trend) + "% vs last week" : a.quizzes.length ? plural(a.quizzes.length, "attempt") : "No attempts yet";
    const subs = a.avgBySubject.slice().sort((x, y) => y.attempts - x.attempts).slice(0, 5);
    const weakest = a.avgBySubject.filter((s) => s.name !== "Exam").sort((x, y) => x.avg - y.avg)[0];
    const weakLesson = weakest ? a.list.filter((l) => l.subject === weakest.name && l.best != null).sort((x, y) => x.best - y.best)[0] : null;
    let tip;
    if (!a.quizzes.length) tip = ["Your insights start with your first quiz", "Finish a lesson quiz and your averages and weak spots show up here."];
    else if (weakest.avg >= 80) tip = ["Strong across the board", "Every subject you've tried is at " + weakest.avg + "% or better. Try a new subject to keep growing."];
    else tip = ["Focus area: " + weakest.name, "Your average is " + weakest.avg + "%." + (weakLesson ? " Revisit " + weakLesson.title + " (best " + weakLesson.best + "%) to lift it." : "")];
    holder.innerHTML = `<div class="insight-top"><div><div class="lbl">Quiz average</div><div class="big">${a.average != null ? a.average + "%" : "—"}</div></div><div class="insight-chip">${esc(chip)}</div></div><div class="chart-row" role="img" aria-label="Quizzes completed per day over the last 7 days">${a.week.map((w, i) => `<div class="bar-wrap" title="${plural(w.count, "quiz")}"><div class="bar${i === 6 ? " today" : ""}" style="height:${w.count ? Math.max(18, Math.round((w.count / max) * 100)) : 4}%;"></div></div>`).join("")}</div><div class="chart-labels">${a.week.map((w) => `<span>${new Intl.DateTimeFormat(undefined, { weekday: "short" }).format(w.date)}</span>`).join("")}</div><div class="chart-cap">Quizzes completed per day · last 7 days</div><div class="subject-bars">${subs.length ? subs.map((s) => `<div class="sbar-row"><div class="top"><span>${esc(s.name)}</span><span>${s.avg}%</span></div><div class="sbar-track"><span style="width:${s.avg}%;background:${meta(s.name).color};"></span></div></div>`).join("") : '<p class="empty-copy">Take a quiz to see your average for each subject.</p>'}</div><div class="focus-tip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18h6M10 22h4M12 2a6 6 0 0 0-4 10.5c.6.5 1 1.2 1 2v.5h6v-.5c0-.8.4-1.5 1-2A6 6 0 0 0 12 2Z"/></svg><div><strong>${esc(tip[0])}</strong><span>${esc(tip[1])}</span></div></div>`;
  }

  function renderAchievements(a) {
    const holder = $("[data-achievements]"); if (!holder) return;
    const top = a.earned[a.earned.length - 1], next = a.locked[0];
    const hero = top
      ? `<div class="badge-hero"><div class="badge-icon" style="font-size:26px">${esc(top.icon)}</div><div><div class="lbl">Latest badge</div><strong>${esc(top.name)}</strong><span>${esc(top.desc)}</span></div></div>`
      : `<div class="badge-hero"><div class="badge-icon" style="font-size:24px">✦</div><div><div class="lbl">Your journey starts here</div><strong>No badges yet</strong><span>${esc(next ? next.desc : "Finish a quiz to earn your first badge.")}</span></div></div>`;
    const row = a.earned.length ? `<div class="badge-row">${a.earned.slice(-4).map((t) => `<div class="mini-badge" title="${esc(t.name)}" style="background:var(--gold-soft);">${esc(t.icon)}</div>`).join("")}${a.earned.length > 4 ? `<div class="mini-badge more">+${a.earned.length - 4}</div>` : ""}</div>` : "";
    const foot = next
      ? `<a class="rank-box" href="pages/certificates.html"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="5"/><path d="M8.5 12.5 6 22l6-3 6 3-2.5-9.5"/></svg><div><strong>Next: ${esc(next.name)}</strong><span>${esc(next.desc)}</span></div><div class="chev">›</div></a>`
      : `<a class="rank-box" href="pages/certificates.html"><div><strong>All ${a.trophies.length} badges earned 🎉</strong><span>See your certificates</span></div><div class="chev">›</div></a>`;
    holder.innerHTML = hero + row + foot;
  }

  function renderActivity(a) {
    const holder = $("[data-activity-list]"); if (!holder) return;
    const entries = [];
    a.days.forEach((items) => items.forEach((it) => entries.push(it)));
    entries.sort(byAt).reverse();
    holder.innerHTML = entries.length
      ? entries.slice(0, 5).map((it) => `<a class="note-item" href="${esc(it.href)}"><span class="note-bar" style="background:${it.kind === "Quiz" ? "var(--teal)" : "var(--accent)"};"></span><span class="note-body"><span class="t">${esc(it.title)}</span><span class="q">${esc(it.detail)}</span><span class="m">${esc(when(it.at))}</span></span><span class="bk">›</span></a>`).join("")
      : emptyBox("Lessons you open and quizzes you finish are logged here.", subjectHref(a.focus), "Open a lesson");
  }

  function renderCoach(a) {
    const box = $("[data-coach]"); if (!box) return;
    let title = "Curio Coach", text, href;
    const weak = a.list.filter((l) => l.status === "attempted").sort((x, y) => x.best - y.best)[0];
    const nx = nextFor(a);
    if (nx) { text = nx.reason; href = nx.lesson.h; }
    else if (!a.quizzes.length) { const f = nextNew(a, a.focus, 1)[0]; text = "Finish your first lesson quiz and your coach will build a study plan from it."; href = f ? f.h : subjectHref(a.focus); }
    else if (weak) { text = "Focus on " + weak.title + " — your best is " + weak.best + "%. Retake it to reach 60% and complete the lesson."; href = weak.href; }
    else { const nn = nextNew(a, a.focus, 1)[0]; text = a.average != null && a.average >= 80 ? "Strong " + a.average + "% average. Keep the momentum with a new lesson." : "Your average is " + a.average + "%. Use active recall to lock in what you've learned."; href = nn && a.average >= 80 ? nn.h : "pages/active-recall.html"; }
    box.setAttribute("href", href);
    setText("[data-coach-title]", title); setText("[data-coach-text]", text);
  }

  function renderHero(a, state) {
    const holder = $("[data-continue]"); if (!holder) return;
    const cont = a.list[0];
    const sub = a.subjects.find((s) => s.name === (cont ? cont.subject : a.focus)) || a.subjects.find((s) => s.name === a.focus) || { name: a.focus, explored: 0, total: 1 };
    let tag, title, line, href, cta;
    if (cont) {
      tag = "CONTINUE LEARNING · " + cont.subject.toUpperCase(); title = cont.title; href = cont.href;
      line = cont.status === "completed" ? cont.subject + " · completed with " + cont.best + "% — revisit or move on" : cont.status === "attempted" ? cont.subject + " · best quiz " + cont.best + "% — retake to complete" : cont.subject + " · opened, quiz not taken yet";
      cta = cont.status === "completed" ? "Revisit lesson" : "Continue learning";
    } else {
      const f = nextNew(a, a.focus, 1)[0];
      tag = "START LEARNING · " + a.focus.toUpperCase(); title = f ? f.t : "Begin " + a.focus; href = f ? f.h : subjectHref(a.focus);
      line = a.focus + " · your learning path starts here"; cta = "Start learning";
    }
    const pct = sub.total ? Math.round((sub.explored / sub.total) * 100) : 0;
    holder.innerHTML = `<div class="hero-tag">${esc(tag)}</div><h2>${esc(title)}</h2><div class="sub">${esc(line)}</div><div class="hero-progress"><div class="hero-bar"><span style="width:${pct}%"></span></div><div class="hero-pct">${pct}% of ${esc(sub.name)}</div></div><div class="hero-actions"><a class="btn-resume" href="${esc(href)}">▶ ${esc(cta)}</a><div class="hero-time">${a.quizzes.length ? plural(a.quizzes.length, "quiz attempt") + " recorded" : "No quizzes taken yet"}</div></div><div class="hero-badge"><div class="tag">LESSONS</div><div class="num">${String(a.list.length).padStart(2, "0")}</div><div class="status">EXPLORED</div></div>`;
  }

  function notifications(a) {
    const n = [];
    if (!a.quizToday) n.push({ icon: "🎯", text: "Daily goal: finish 1 quiz today" + (a.streak ? " to keep your " + a.streak + "-day streak." : " to start a streak."), href: a.list[0] ? a.list[0].href : subjectHref(a.focus) });
    else n.push({ icon: "✅", text: "Daily goal complete — nice work today.", href: "pages/scoreboard.html" });
    if (a.streak >= 2) n.push({ icon: "🔥", text: a.streak + "-day learning streak.", href: "pages/scoreboard.html" });
    const top = a.earned[a.earned.length - 1];
    if (top) n.push({ icon: top.icon, text: "Badge earned: " + top.name + ".", href: "pages/certificates.html" });
    const weak = a.list.filter((l) => l.status === "attempted").sort((x, y) => x.best - y.best)[0];
    if (weak) n.push({ icon: "🔁", text: "Retake " + weak.title + " — best " + weak.best + "%.", href: weak.href });
    return n;
  }
  function renderBell(a) {
    const list = notifications(a), pop = $("[data-bell-pop]"), dot = $("[data-bell-dot]");
    const sig = dayKey(new Date()) + "|" + list.map((n) => n.text).join("|");
    if (pop) pop.innerHTML = '<div class="bell-h">Notifications</div>' + list.map((n) => `<a class="bell-i" href="${esc(n.href)}"><span>${esc(n.icon)}</span><span>${esc(n.text)}</span></a>`).join("");
    let seen = ""; try { seen = localStorage.getItem("curiolab-bell-seen") || ""; } catch (_) { /* ignore */ }
    if (dot) dot.hidden = seen === sig;
    const bell = $("[data-bell]"); if (bell) bell.dataset.sig = sig;
  }

  /* ---------------- main render ---------------- */
  function render(state) {
    lastState = state;
    const a = analyze(state);
    const name = (state.profile && state.profile.name) || (account && account.name) || "Learner";
    const first = name.trim().split(/\s+/)[0] || "Learner";
    const initials = name.trim().split(/\s+/).slice(0, 2).map((p) => p[0]).join("").toUpperCase() || "CL";
    document.querySelectorAll("[data-user-name]").forEach((el) => { el.textContent = name; });
    document.querySelectorAll("[data-first-name]").forEach((el) => { el.textContent = first; });
    document.querySelectorAll("[data-user-initials]").forEach((el) => { el.textContent = initials; });
    setText("[data-user-sub]", "Level " + a.level + " learner");
    setText("[data-dashboard-date]", longDate.format(new Date()).toUpperCase());
    setText("[data-dashboard-greeting]", a.quizzes.length || a.list.length
      ? plural(a.list.length, "lesson") + " explored · " + plural(a.quizzes.length, "quiz") + (a.average != null ? " · " + a.average + "% average" : "")
      : "Open any lesson to begin — your progress will show up here.");

    const focusSub = a.subjects.find((s) => s.name === a.focus) || { explored: 0, total: 1 };
    const completion = focusSub.total ? Math.round((focusSub.explored / focusSub.total) * 100) : 0;
    setText("[data-stat-completion-label]", a.focus + " path explored");
    setText("[data-stat-completion]", completion + "%");
    setText("[data-completion-foot]", focusSub.explored + " of " + focusSub.total + " " + a.focus + " lessons explored");
    setText("[data-stat-streak]", plural(a.streak, "day"));
    setText("[data-streak-foot]", a.streak ? (a.activeToday ? "You're active today — keep it going" : "Study today to keep your streak") : "Open a lesson or quiz to begin a streak");
    setText("[data-stat-xp]", a.xp.toLocaleString());
    setText("[data-xp-foot]", (250 - a.into) + " XP to Level " + (a.level + 1));
    setText("[data-stat-badges]", a.earned.length + " / " + a.trophies.length);
    setText("[data-badges-foot]", a.earned.length ? a.earned.length + " earned from real milestones" : "Your first quiz unlocks a badge");
    setWidth("[data-completion-bar]", completion); setWidth("[data-streak-bar]", (a.streak / 7) * 100); setWidth("[data-xp-bar]", a.into / 2.5); setWidth("[data-badges-bar]", a.trophies.length ? (a.earned.length / a.trophies.length) * 100 : 0);

    const ring = $(".level-ring");
    if (ring) { ring.style.background = `conic-gradient(var(--accent) 0% ${a.into / 2.5}%, var(--line-soft) ${a.into / 2.5}% 100%)`; ring.style.setProperty("--lv", '"' + a.level + '"'); }
    setText("[data-level-label]", "Level " + a.level); setText("[data-level-next]", (250 - a.into) + " XP to Level " + (a.level + 1)); setWidth("[data-level-bar]", a.into / 2.5);

    const goalPct = a.quizToday ? 100 : a.activeToday ? 50 : 0;
    const goalRing = $("[data-goal-ring]"); if (goalRing) goalRing.style.background = `conic-gradient(var(--accent) 0% ${goalPct}%, var(--line-soft) ${goalPct}% 100%)`;
    setText("[data-goal-title]", a.quizToday ? "Daily goal complete" : "Daily goal");
    setText("[data-goal-text]", a.quizToday ? "You finished a quiz today. See you tomorrow!" : a.activeToday ? "Lesson opened — finish its quiz to reach today's goal." : a.streak ? "Finish 1 quiz today to keep your " + a.streak + "-day streak." : "Finish 1 quiz today to start your streak.");

    renderHero(a, state); renderSubjects(a); renderUpcoming(a, state); renderInsights(a); renderAchievements(a); renderActivity(a); renderCoach(a); renderBell(a);
  }

  /* ---------------- interactions ---------------- */
  document.addEventListener("click", (event) => {
    const t = event.target.closest && event.target.closest("[data-tab],[data-view],[data-more],[data-cal-nav],[data-cal-day],[data-bell]");
    const pop = $("[data-bell-pop]");
    if (!t) { if (pop && !pop.hidden && !event.target.closest("[data-bell-pop]")) pop.hidden = true; return; }
    if (t.matches("[data-bell]")) {
      if (!pop) return; pop.hidden = !pop.hidden;
      if (!pop.hidden) { try { localStorage.setItem("curiolab-bell-seen", t.dataset.sig || ""); } catch (_) { /* ignore */ } const dot = $("[data-bell-dot]"); if (dot) dot.hidden = true; }
      return;
    }
    if (!lastState) return;
    if (t.dataset.tab) { ui.tab = t.dataset.tab; ui.more = false; }
    else if (t.dataset.view) ui.view = t.dataset.view;
    else if ("more" in t.dataset) ui.more = !ui.more;
    else if (t.dataset.calNav) { ui.calOffset = Math.min(0, ui.calOffset + Number(t.dataset.calNav)); ui.selDay = null; }
    else if (t.dataset.calDay) ui.selDay = t.dataset.calDay;
    const a = analyze(lastState); renderSubjects(a); renderUpcoming(a, lastState);
  });

  function hasActivity(state) { return state.events.length > 0 || state.visits.length > 0; }
  function showOnboarding() {
    const modal = $("[data-onboarding]"); if (!modal || modal.dataset.bound) return;
    modal.dataset.bound = "1"; modal.hidden = false;
    const form = $("[data-onboarding-form]"); $("[data-onboarding-name]").value = (account && account.name) || "";
    const finish = async (data) => { await window.CurioLearning.completeOnboarding(data); modal.hidden = true; };
    form.addEventListener("submit", async (event) => {
      event.preventDefault(); const f = new FormData(form); const age = Number(f.get("age"));
      if (age && (age < 5 || age > 100)) { setText("[data-onboarding-error]", "Enter an age between 5 and 100, or leave it blank."); return; }
      await finish({ name: f.get("name"), age, course: f.get("course") });
    });
    const skip = $("[data-onboarding-skip]");
    if (skip) skip.addEventListener("click", () => finish({ name: ($("[data-onboarding-name]").value || (account && account.name) || "Learner"), age: null, course: "" }));
  }

  async function boot() {
    try { account = window.CurioAuth ? await window.CurioAuth.getCurrentUser() : null; } catch (_) { account = null; }
    const state = await window.CurioLearning.get();
    render(state);
    if (!state.profile && !hasActivity(state)) showOnboarding();
  }
  window.addEventListener("curio-learning-updated", (e) => { if (lastState) render(e.detail); });
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
