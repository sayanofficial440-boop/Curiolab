// Curio Lab — lesson metadata (grade range + difficulty).
// EDIT ME: this is the single source of truth for the grade/level filters.
// Format:  "subject/lesson-slug": [minGrade, maxGrade, level]
//   level: 1 = Beginner, 2 = Intermediate, 3 = Advanced
// Grades are a guide (6–13, where 13 = college / beyond school), not a board syllabus.
window.CurioMeta = {
  bands: [
    { id: "6-8",   label: "Grades 6–8",   short: "6–8",   min: 6,  max: 8 },
    { id: "9-10",  label: "Grades 9–10",  short: "9–10",  min: 9,  max: 10 },
    { id: "11-12", label: "Grades 11–12", short: "11–12", min: 11, max: 12 },
    { id: "13",    label: "College+",     short: "College+", min: 13, max: 99 }
  ],
  levels: [
    { id: 1, label: "Beginner" },
    { id: 2, label: "Intermediate" },
    { id: 3, label: "Advanced" }
  ],
  lessons: {
    // Physics
    "physics/force": [8, 10, 1], "physics/light": [8, 10, 1], "physics/sound": [8, 9, 1],
    "physics/work-energy-power": [9, 10, 2], "physics/electricity-circuits": [9, 12, 2],
    "physics/magnetism-induction": [10, 12, 2], "physics/heat-thermodynamics": [9, 12, 2],
    "physics/pressure-fluids": [8, 10, 2], "physics/gravitation-space": [9, 11, 2],
    "physics/astrophysics": [11, 13, 3],
    // Chemistry
    "chemistry/matter": [6, 8, 1], "chemistry/atom-structure": [8, 10, 1],
    "chemistry/mixtures-solutions": [6, 9, 1], "chemistry/chemical-bonding": [9, 11, 2],
    "chemistry/periodic-table": [8, 11, 2], "chemistry/elements-compounds-mixtures": [6, 9, 1],
    "chemistry/metals-nonmetals": [8, 10, 1], "chemistry/acids-bases-salts": [8, 10, 2],
    "chemistry/chemical-reactions": [8, 10, 2], "chemistry/carbon-organic-chemistry": [10, 12, 3],
    "chemistry/chemical-equation": [8, 10, 2],
    // Biology
    "biology/health": [6, 8, 1], "biology/cell": [8, 10, 1], "biology/nervous-system": [9, 11, 2],
    "biology/digestive-system": [6, 9, 1], "biology/circulatory-system": [7, 10, 1],
    "biology/respiratory-system": [7, 10, 1], "biology/skeletal-system": [6, 9, 1],
    "biology/muscular-system": [6, 9, 1], "biology/excretory-system": [8, 10, 2],
    "biology/reproductive-system": [9, 12, 2], "biology/biological-diversity": [8, 11, 2],
    // English
    "english/road-not-taken": [8, 10, 1], "english/if": [8, 10, 1], "english/the-happy-prince": [6, 9, 1],
    "english/the-last-leaf": [8, 10, 1], "english/romeo-and-juliet": [9, 12, 2], "english/daffodils": [6, 9, 1],
    "english/the-necklace": [9, 11, 2], "english/a-tale-of-two-cities": [11, 13, 3],
    "english/ode-to-a-nightingale": [11, 13, 3], "english/sonnet-18": [9, 12, 2],
    "english/the-gift-of-the-magi": [8, 10, 1], "english/the-tell-tale-heart": [9, 12, 2],
    "english/the-great-gatsby": [11, 13, 3], "english/pride-and-prejudice": [11, 13, 3],
    "english/wuthering-heights": [11, 13, 3], "english/frankenstein": [10, 13, 3],
    // Mathematics
    "mathematics/linear-equations": [7, 9, 1], "mathematics/algebraic-equations": [8, 10, 2],
    "mathematics/rational-numbers": [7, 9, 1], "mathematics/number-systems": [6, 9, 1],
    "mathematics/geometry": [8, 10, 2], "mathematics/trigonometry": [10, 12, 2],
    "mathematics/mensuration": [8, 10, 2], "mathematics/probability": [9, 12, 2],
    "mathematics/statistics": [9, 12, 2], "mathematics/coordinate-geometry": [9, 11, 2],
    "mathematics/calculus-introduction": [11, 13, 3], "mathematics/commercial-math": [7, 10, 1],
    // History
    "history/ancient-civilizations": [6, 8, 1], "history/delhi-sultanate-mughal-empire": [7, 10, 2],
    "history/world-war-1": [9, 11, 2], "history/world-war-2": [9, 12, 2],
    "history/colonialism-and-trade": [8, 11, 2], "history/industrial-revolution": [8, 11, 2],
    "history/cold-war": [10, 12, 3], "history/independence-movements": [8, 11, 2],
    "history/political-revolutions": [10, 12, 3], "history/delhi-sultanate": [7, 10, 2],
    "history/mughal-empire": [7, 10, 2],
    // Geography
    "geography/world-landforms": [6, 8, 1], "geography/asia": [6, 9, 1], "geography/europe": [6, 9, 1],
    "geography/africa": [6, 9, 1], "geography/north-america": [6, 9, 1], "geography/south-america": [6, 9, 1],
    "geography/australia": [6, 8, 1], "geography/antarctica": [6, 8, 1],
    "geography/biomes-vegetation": [8, 10, 2], "geography/plate-tectonics": [9, 11, 2],
    "geography/meteorology-climate": [9, 12, 2], "geography/resource-distribution": [10, 12, 3],
    // Computer Science
    "computer-science/html5": [6, 9, 1], "computer-science/robots-robotics": [6, 9, 1],
    "computer-science/cyber-ethics": [8, 11, 1], "computer-science/java": [9, 12, 2],
    "computer-science/python": [8, 12, 1], "computer-science/algorithms": [10, 13, 2],
    "computer-science/control-flow": [8, 10, 1], "computer-science/functions-scope": [9, 12, 2],
    "computer-science/database-management": [11, 13, 2], "computer-science/automation-scripting": [10, 13, 3]
  }
};
