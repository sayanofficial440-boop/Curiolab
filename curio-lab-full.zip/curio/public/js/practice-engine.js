// Curio Lab — Practice engine.
//
// Five ways to practise one set of items (term + definition, plus short-answer questions):
//   cards    Smart Cards     spaced repetition (SM-2): what's due, plus a few new cards a day
//   type     Type It         read a definition, type the term — typos forgiven
//   cloze    Fill the Blank  one key word is missing from a definition
//   explain  Explain It      write the answer from memory, then check which key ideas you covered
//   tf       True or False   does this definition belong to this term?
//
// The same engine runs inside every lesson (js/lesson-practice.js) and on the Practice hub
// (pages/practice.html). It is given a list of items; where they come from is not its business.
//
//   const pr = CurioPractice.mount(element, { items, title, compact });
//   pr.setItems(newItems);   pr.destroy();
(function () {
  "use strict";
  if (window.CurioPractice) return;

  const T = window.CurioPracticeText;
  const S = window.CurioPracticeStore;
  if (!T || !S) { console.warn("CurioPractice: practice-text.js and practice-store.js must load first"); return; }

  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const shuffled = (a) => { const x = a.slice(); for (let i = x.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [x[i], x[j]] = [x[j], x[i]]; } return x; };
  const hash = (str) => { let h = 5381; for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0; return (h >>> 0).toString(36); };
  const UI_KEY = "curiolab-practice-ui";
  const loadUi = () => { try { return JSON.parse(localStorage.getItem(UI_KEY)) || {}; } catch (_) { return {}; } };
  const saveUi = (patch) => { try { localStorage.setItem(UI_KEY, JSON.stringify(Object.assign(loadUi(), patch))); } catch (_) { /* ignore */ } };
  const fmtTime = (s) => (s >= 60 ? Math.floor(s / 60) + " min " + (s % 60 ? (s % 60) + " s" : "") : s + " s").trim();

  const MODES = [
    { id: "cards", icon: "🗂️", label: "Smart Cards", tag: "Spaced repetition", fixed: false,
      desc: "Flip a card, say the answer to yourself, then rate how well you knew it. Cards you find hard come back sooner; easy ones fade into the future — so you spend time where it counts." },
    { id: "type", icon: "⌨️", label: "Type It", tag: "Written recall", fixed: true,
      desc: "You get a definition with the key word hidden. Type the term from memory — small spelling slips are forgiven. Writing an answer sticks far better than recognising it." },
    { id: "cloze", icon: "🧩", label: "Fill the Blank", tag: "Cued recall", fixed: true,
      desc: "One key word is missing from a definition. Recall it, type it in, and see the full sentence. Stuck? Ask for the first letter or three choices." },
    { id: "explain", icon: "✍️", label: "Explain It", tag: "Free recall", fixed: true,
      desc: "Write the answer in your own words, then reveal the model answer. The key ideas you covered are ticked off, so you can judge yourself honestly." },
    { id: "tf", icon: "⚖️", label: "True or False", tag: "Quick check", fixed: true,
      desc: "A term appears next to a definition. Does it belong, or has the definition been swapped? Fast rounds that expose half-remembered facts." },
  ];
  const MODE = Object.fromEntries(MODES.map((m) => [m.id, m]));

  // ---------- items ----------
  // item = { id, kind: "card"|"qa", term, def, q, a, lesson, lessonKey, subject, href }
  let globalIdf = null;
  function getIdf(items) {
    if (globalIdf) return globalIdf;
    const bank = window.CURIO_BANK && window.CURIO_BANK.recall;
    const defs = bank ? [].concat(...bank.lessons.map((l) => l.c.map((c) => c[1]))) : items.map((i) => i.def).filter(Boolean);
    globalIdf = T.buildIdf(defs.length >= 50 ? defs : items.map((i) => i.def).filter(Boolean));
    return globalIdf;
  }

  // Items from the generated recall bank (js/bank/bank-recall.js). href is relative to /pages/.
  function itemsFromBank(filter) {
    const bank = window.CURIO_BANK && window.CURIO_BANK.recall;
    if (!bank) return [];
    const f = filter || {};
    const out = [];
    bank.lessons.forEach((l) => {
      const sub = bank.subjects[l.s];
      if (!sub) return;
      if (f.subject && f.subject !== sub.k) return;
      if (f.lessonKey && f.lessonKey !== l.k) return;
      if (f.lessonKeys && !f.lessonKeys.includes(l.k)) return;
      const base = { lesson: l.t, lessonKey: l.k, subject: sub.l, subjectKey: sub.k, href: l.k + ".html" };
      l.c.forEach(([term, def]) => out.push(Object.assign({ id: l.k + "#" + T.bare(term), kind: "card", term: T.bare(term), def }, base)));
      (l.r || []).forEach(([q, a]) => out.push(Object.assign({ id: l.k + "#q:" + hash(q), kind: "qa", q, a }, base)));
    });
    return out;
  }

  // Items from the lesson page that is open: its flashcard deck and its hand-written quiz questions.
  function itemsFromPage(meta) {
    const out = [];
    let deck = [], quiz = [];
    try { deck = JSON.parse(document.querySelector("script[data-card-deck]").textContent); } catch (_) { deck = []; }
    try { quiz = JSON.parse(document.querySelector("script[data-quiz-data]").textContent); } catch (_) { quiz = []; }
    const base = { lesson: meta.lesson, lessonKey: meta.lessonKey, subject: meta.subject, href: meta.href || "" };
    const seen = new Set();
    (Array.isArray(deck) ? deck : []).forEach((c) => {
      if (!c || !c.term || !c.def) return;
      const term = T.bare(c.term);
      if (!term || seen.has(term)) return;
      seen.add(term);
      out.push(Object.assign({ id: meta.lessonKey + "#" + term, kind: "card", term, def: String(c.def) }, base));
    });
    (Array.isArray(quiz) ? quiz : []).forEach((q) => {
      if (!q || q.auto || !q.q || !Array.isArray(q.options) || !Number.isInteger(q.correct)) return;
      const a = String(q.options[q.correct] || "");
      if (!a || /\b(all|none|both|neither) of (the|these|above)\b/i.test(a)) return;
      out.push(Object.assign({ id: meta.lessonKey + "#q:" + hash(q.q), kind: "qa", q: q.q, a }, base));
    });
    return out;
  }

  const cardsOf = (items) => items.filter((i) => i.kind === "card");

  // ---------- picking & exercise building ----------
  // Weighted random sample without replacement: weak and never-practised items are more likely, recent ones less.
  function weightedPick(pool, n) {
    const map = S.cardMap(), now = Date.now();
    return pool.map((it) => {
      const c = map[it.id];
      let w = 1;
      if (c && c.m > 0) w += 2.5 + Math.min(c.m, 3) * 0.5;
      if (!c || (!c.n && !c.x)) w += 1.2;
      else w += Math.min((now - (c.t || 0)) / 864e5, 14) / 14;
      return { it, k: Math.pow(Math.random(), 1 / w) };
    }).sort((a, b) => b.k - a.k).slice(0, n).map((x) => x.it);
  }

  function typeEligible(i) {
    if (i.kind !== "card" || i.term.length > 45) return false;
    const masked = T.maskTerm(i.def, i.term);
    return T.termVariants(i.term).length > 0 && masked.replace(/_{5}/g, "").trim().length >= 20;
  }

  function prepare(modeId, items, n) {
    const cards = cardsOf(items);
    if (modeId === "type") {
      return weightedPick(cards.filter(typeEligible), n).map((item) => ({ item, prompt: T.maskTerm(item.def, item.term), variants: T.termVariants(item.term) }));
    }
    if (modeId === "cloze") {
      const idf = getIdf(items);
      const out = [];
      weightedPick(cards, Math.min(cards.length, n * 2)).forEach((item) => {
        if (out.length >= n) return;
        const cz = T.buildCloze(item.def, item.term, idf, Math.random() * 0.999);
        if (cz) out.push({ item, cz, pool: cards });
      });
      return out;
    }
    if (modeId === "explain") {
      const idf = getIdf(items);
      const eligible = [];
      items.forEach((item) => {
        const model = item.kind === "qa" ? item.a : item.def;
        const kws = T.keywords(model, item.kind === "qa" ? "" : item.term, idf, 5);
        if (kws.length >= 2) eligible.push({ item, model, kws });
      });
      const byId = new Map(eligible.map((e) => [e.item.id, e]));
      return weightedPick(eligible.map((e) => e.item), n).map((it) => byId.get(it.id));
    }
    if (modeId === "tf") {
      if (cards.length < 4) return [];
      return weightedPick(cards, n).map((item, idx) => {
        const truth = idx % 2 === 0 ? Math.random() < 0.5 : Math.random() >= 0.5;
        let shownDef = item.def, other = null;
        if (!truth) {
          const sameLesson = cards.filter((c) => c !== item && c.lessonKey === item.lessonKey && T.norm(c.def) !== T.norm(item.def) && T.norm(c.term) !== T.norm(item.term));
          const pool = sameLesson.length >= 2 ? sameLesson : cards.filter((c) => c !== item && T.norm(c.def) !== T.norm(item.def) && T.norm(c.term) !== T.norm(item.term));
          other = pool.length ? pool[Math.floor(Math.random() * pool.length)] : null;
          if (other) shownDef = other.def; else return { item, shownDef, truth: true, other: null };
        }
        return { item, shownDef, truth: !other, other };
      });
    }
    return [];
  }

  function availability(items) {
    const cards = cardsOf(items);
    const q = S.queueFor(cards.map((c) => c.id));
    return {
      cards: cards.length,
      type: cards.filter(typeEligible).length,
      cloze: cards.length,
      explain: items.length,
      tf: cards.length >= 4 ? cards.length : 0,
      due: q.due.length, fresh: Math.min(q.fresh.length, q.newBudget), later: q.later.length, newBudget: q.newBudget,
    };
  }

  // =====================================================================
  function mount(root, opts) {
    opts = opts || {};
    let items = (opts.items || []).slice();
    const ui = loadUi();
    const cfg = {
      mode: MODE[ui.mode] ? ui.mode : "cards",
      length: [5, 10, 20].includes(ui.length) ? ui.length : 10,
      direction: ["term", "def", "mixed"].includes(ui.direction) ? ui.direction : "term",
    };
    let view = "home";           // home | run | summary
    let run = null;              // active session
    let awaitNext = false, lastAnswerAt = 0;

    root.classList.add("pr-app");
    root.innerHTML = '<div class="pr-home"></div><div class="pr-run" hidden></div>';
    const homeEl = root.querySelector(".pr-home");
    const runEl = root.querySelector(".pr-run");
    root.setAttribute("data-pr-ready", "");

    const visible = () => root.isConnected && root.offsetParent !== null;
    const setView = (v) => { view = v; homeEl.hidden = v !== "home"; runEl.hidden = v === "home"; if (v !== "home") runEl.scrollIntoView({ block: "nearest", behavior: "smooth" }); };

    // ---------- home ----------
    function statBar() {
      const st = S.stats();
      const a = availability(items);
      const cell = (n, l, hot) => `<div class="pr-stat${hot ? " hot" : ""}"><b>${n}</b><span>${l}</span></div>`;
      return `<div class="pr-statbar" aria-label="Your practice today">
        ${cell(a.due, "cards due", a.due > 0)}${cell(a.fresh, "new today", false)}${cell(st.weak, "weak spots", st.weak > 0)}${cell(st.todayAnswered, "answered today", false)}${cell(st.streak + (st.streak ? " 🔥" : ""), "day streak", false)}
      </div>`;
    }

    function renderHome() {
      const a = availability(items);
      if (!items.length) {
        homeEl.innerHTML = `<div class="pr-empty"><span class="big" aria-hidden="true">🗂️</span><b>Nothing to practise here yet.</b><p>${esc(opts.emptyText || "This lesson has no flashcards or quiz questions to practise with yet.")}</p></div>`;
        return;
      }
      const m = MODE[cfg.mode];
      const count = a[cfg.mode];
      const tiles = MODES.map((x) => {
        const n = a[x.id];
        const badge = x.id === "cards" ? (a.due + a.fresh ? `${a.due + a.fresh} to do` : "all caught up") : `${n} available`;
        return `<button type="button" class="pr-mode" role="radio" aria-checked="${x.id === cfg.mode}" data-mode="${x.id}" ${n === 0 ? "disabled" : ""}>
          <span class="pr-ico" aria-hidden="true">${x.icon}</span><b>${x.label}</b><small>${x.tag}</small><em>${badge}</em></button>`;
      }).join("");
      let options = "";
      if (m.id === "cards") {
        options = `<div class="pr-opt"><span class="pr-optl">Show first</span><div class="pr-chips">${[["term", "Term"], ["def", "Definition"], ["mixed", "Mixed"]].map(([k, l]) => `<button type="button" class="pr-chip" aria-pressed="${cfg.direction === k}" data-dir="${k}">${l}</button>`).join("")}</div></div>
          <div class="pr-opt"><span class="pr-optl">New cards per day</span><div class="pr-chips">${[5, 10, 20, 40].map((n) => `<button type="button" class="pr-chip" aria-pressed="${S.getSettings().newPerDay === n}" data-newper="${n}">${n}</button>`).join("")}</div></div>`;
      } else {
        options = `<div class="pr-opt"><span class="pr-optl">Questions</span><div class="pr-chips">${[5, 10, 20].map((n) => `<button type="button" class="pr-chip" aria-pressed="${cfg.length === n}" data-len="${n}">${n}</button>`).join("")}</div></div>`;
      }
      let startLabel = "Start practice";
      let note = "";
      if (m.id === "cards") {
        const todo = a.due + a.fresh;
        startLabel = todo ? `Study ${todo} card${todo === 1 ? "" : "s"}` : "Practise anyway";
        note = todo ? `${a.due} due for review · ${a.fresh} new` : (a.cards ? "You're all caught up. You can still cram a random set — it won't change your schedule." : "");
      } else {
        note = `${Math.min(cfg.length, count)} of ${count} available this round${weakCount() ? " · weak spots come first" : ""}`;
      }
      homeEl.innerHTML = `${statBar()}
        <div class="pr-modes" role="radiogroup" aria-label="Practice mode">${tiles}</div>
        <div class="pr-panel" aria-live="polite">
          <div class="pr-panel-head"><span class="pr-ico" aria-hidden="true">${m.icon}</span><div><h3>${m.label}</h3><p class="pr-tag">${m.tag}</p></div></div>
          <p class="pr-desc">${m.desc}</p>
          ${options}
          <div class="pr-startrow"><button type="button" class="pr-btn primary" data-start ${count === 0 ? "disabled" : ""}>${startLabel}</button><span class="pr-note">${esc(note)}</span></div>
        </div>`;
    }
    const weakCount = () => { const map = S.cardMap(); return items.filter((i) => map[i.id] && map[i.id].m > 0).length; };

    homeEl.addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b || b.disabled) return;
      if (b.dataset.mode) { cfg.mode = b.dataset.mode; saveUi({ mode: cfg.mode }); renderHome(); const t = homeEl.querySelector(`[data-mode="${cfg.mode}"]`); if (t) t.focus(); }
      else if (b.dataset.len) { cfg.length = Number(b.dataset.len); saveUi({ length: cfg.length }); renderHome(); homeEl.querySelector(`[data-len="${cfg.length}"]`).focus(); }
      else if (b.dataset.dir) { cfg.direction = b.dataset.dir; saveUi({ direction: cfg.direction }); renderHome(); homeEl.querySelector(`[data-dir="${cfg.direction}"]`).focus(); }
      else if (b.dataset.newper) { S.setSettings({ newPerDay: Number(b.dataset.newper) }); renderHome(); homeEl.querySelector(`[data-newper="${b.dataset.newper}"]`).focus(); }
      else if (b.hasAttribute("data-start")) start();
    });
    // arrow keys move between modes (radio-group pattern)
    homeEl.addEventListener("keydown", (e) => {
      const tile = e.target.closest(".pr-mode"); if (!tile || !/^Arrow(Left|Right|Up|Down)$/.test(e.key)) return;
      e.preventDefault();
      const ids = MODES.map((x) => x.id).filter((id) => availability(items)[id] > 0);
      const at = ids.indexOf(tile.dataset.mode);
      const next = ids[(at + (/Right|Down/.test(e.key) ? 1 : -1) + ids.length) % ids.length];
      cfg.mode = next; saveUi({ mode: next }); renderHome(); homeEl.querySelector(`[data-mode="${next}"]`).focus();
    });

    // ---------- session plumbing ----------
    function start(only) {
      const pool = only || items;
      if (cfg.mode === "cards") return startCards(pool, !!opts.cram);
      const ex = prepare(cfg.mode, pool, Math.min(cfg.length, pool.length));
      if (!ex.length) { renderHome(); return; }
      run = { mode: cfg.mode, kind: "fixed", ex, i: 0, results: [], t0: Date.now(), pool };
      setView("run"); renderExercise();
    }

    function head(extra) {
      const total = run.kind === "fixed" ? run.ex.length : run.total;
      const done = run.kind === "fixed" ? run.i : run.done;
      const pct = total ? Math.round((done / total) * 100) : 0;
      return `<div class="pr-head"><div class="pr-headrow"><span class="pr-badge">${MODE[run.mode].icon} ${MODE[run.mode].label}</span><span class="pr-count">${extra || (run.kind === "fixed" ? `${Math.min(run.i + 1, total)} / ${total}` : `${run.queue.length} left`)}</span><button type="button" class="pr-btn ghost" data-quit>End session</button></div>
        <div class="pr-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}"><i style="width:${pct}%"></i></div></div>`;
    }

    runEl.addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b || b.disabled) return;
      if (b.hasAttribute("data-quit")) { if (!run) return; if (run.results.length === 0 && !(run.graded)) { goHome(); } else finish(true); }
      else if (b.hasAttribute("data-home")) goHome();
      else if (b.hasAttribute("data-again-all")) { start(); }
      else if (b.hasAttribute("data-again-missed")) { const ids = new Set(run.missed.map((r) => r.item.id)); start(run.pool.filter((i) => ids.has(i.id))); }
      else if (b.hasAttribute("data-next")) next();
    });

    function goHome() { run = null; awaitNext = false; setView("home"); renderHome(); }

    function next() {
      if (!run || run.kind !== "fixed") return;
      awaitNext = false;
      run.i += 1;
      if (run.i >= run.ex.length) finish(false); else renderExercise();
    }

    // Called by each mode when the learner has answered.
    function record(res, feedbackHtml) {
      run.results.push(res);
      if (res.counted !== false) {
        if (res.hinted && res.correct) { /* a hinted success is not evidence of mastery: skip the miss balance */ }
        else S.noteResult(res.item.id, !!res.correct);
      }
      const body = runEl.querySelector(".pr-body");
      const fb = document.createElement("div");
      fb.className = "pr-feedback " + (res.correct ? (res.close ? "close" : "ok") : "bad");
      fb.setAttribute("role", "status");
      fb.innerHTML = feedbackHtml;
      body.appendChild(fb);
      const last = run.i >= run.ex.length - 1;
      const nb = document.createElement("button");
      nb.type = "button"; nb.className = "pr-btn primary pr-nextbtn"; nb.setAttribute("data-next", "");
      nb.innerHTML = last ? "See results <kbd>Enter</kbd>" : "Next <kbd>Enter</kbd>";
      body.appendChild(nb);
      awaitNext = true; lastAnswerAt = Date.now();
      nb.focus({ preventScroll: true });
    }

    function renderExercise() {
      const ex = run.ex[run.i];
      awaitNext = false;
      runEl.innerHTML = head() + '<div class="pr-body" data-mode-body="' + run.mode + '"></div>';
      const body = runEl.querySelector(".pr-body");
      RENDER[run.mode](ex, body);
    }

    function summaryList(rows) {
      return rows.map((r) => `<li><b>${esc(r.prompt)}</b><span>${esc(r.answer)}</span></li>`).join("");
    }

    function finish(early) {
      if (!run) return;
      const secs = Math.max(1, Math.round((Date.now() - run.t0) / 1000));
      const rs = run.results;
      const correct = rs.filter((r) => r.correct && !r.hinted).length;
      const answered = rs.length;
      // log per subject so the report can split practice by subject
      const bySubj = {};
      rs.forEach((r) => { const k = r.item.subject || ""; (bySubj[k] = bySubj[k] || { a: 0, c: 0 }).a += 1; if (r.correct && !r.hinted) bySubj[k].c += 1; });
      Object.keys(bySubj).forEach((k) => S.log({ mode: run.mode, answered: bySubj[k].a, correct: bySubj[k].c, subject: k }));
      if (answered) S.logSession(run.mode);
      const missed = rs.filter((r) => !r.correct);
      run.missed = missed;
      run.finished = true;
      awaitNext = false;
      const pct = answered ? Math.round((correct / answered) * 100) : 0;
      const circ = 2 * Math.PI * 52;
      const verdict = !answered ? "Session ended" : pct === 100 ? "Flawless" : pct >= 80 ? "Strong recall" : pct >= 60 ? "Getting there" : "Keep going — this is how it sticks";
      const hinted = rs.filter((r) => r.correct && r.hinted).length;
      const others = MODES.filter((m) => m.id !== run.mode && availability(items)[m.id] > 0).slice(0, 2);
      runEl.innerHTML = `<div class="pr-summary">
        <div class="pr-ringwrap"><svg viewBox="0 0 130 130" width="120" height="120" role="img" aria-label="${pct} percent"><circle cx="65" cy="65" r="52" fill="none" stroke="var(--color-line)" stroke-width="9"/><circle cx="65" cy="65" r="52" fill="none" stroke="var(--accent,var(--color-teal))" stroke-width="9" stroke-linecap="round" stroke-dasharray="${circ}" stroke-dashoffset="${circ - circ * pct / 100}" transform="rotate(-90 65 65)"/><text x="65" y="73" text-anchor="middle" font-size="26" font-weight="700" fill="currentColor">${pct}%</text></svg></div>
        <div class="pr-sumtext"><h3>${early && answered ? "Session saved" : verdict}</h3>
          <p>${run.mode === "cards" ? `${answered} card${answered === 1 ? "" : "s"} reviewed · ${correct} recalled · ${missed.length} to see again soon` : `${correct} of ${answered} correct${hinted ? ` · ${hinted} with a hint (not counted)` : ""}`} · ${fmtTime(secs)}</p>
          ${run.mode === "cards" && !run.cram ? `<p class="pr-next-due">${nextDueText()}</p>` : ""}
          <div class="pr-actions">${missed.length && run.mode !== "cards" ? '<button type="button" class="pr-btn primary" data-again-missed>Practise the ' + missed.length + " I missed</button>" : ""}<button type="button" class="pr-btn${missed.length && run.mode !== "cards" ? "" : " primary"}" data-again-all>${run.mode === "cards" ? "Study more" : "Another round"}</button><button type="button" class="pr-btn ghost" data-home>Change mode</button></div>
        </div>
        ${missed.length ? `<div class="pr-missed"><h4>${run.mode === "cards" ? "Cards you marked Again" : "Worth another look"}</h4><ul>${summaryList(missed.map((r) => ({ prompt: r.promptText || r.item.term || r.item.q, answer: r.answerText || r.item.def || r.item.a })))}</ul></div>` : ""}
        ${others.length ? `<p class="pr-try">Try next: ${others.map((o) => `<button type="button" class="pr-linkbtn" data-switch="${o.id}">${o.icon} ${o.label}</button>`).join(" · ")}</p>` : ""}
      </div>`;
      runEl.querySelectorAll("[data-switch]").forEach((b) => b.addEventListener("click", () => { cfg.mode = b.dataset.switch; saveUi({ mode: cfg.mode }); goHome(); }));
      window.dispatchEvent(new CustomEvent("curio-practice-finished", { detail: { mode: run.mode, answered, correct } }));
    }

    function nextDueText() {
      const ids = cardsOf(items).map((c) => c.id), map = S.cardMap();
      const upcoming = ids.map((id) => map[id]).filter((c) => c && c.n && c.d > Date.now()).map((c) => c.d).sort((a, b) => a - b);
      if (!upcoming.length) return "";
      const mins = Math.max(1, Math.round((upcoming[0] - Date.now()) / 60000));
      return "Next review: " + (mins < 90 ? `in ${mins} min` : mins < 2160 ? `in ${Math.round(mins / 60)} h` : `in ${Math.round(mins / 1440)} days`) + ".";
    }

    // ---------- Smart Cards (spaced repetition) ----------
    function startCards(pool, cram) {
      const cards = cardsOf(pool);
      let queue;
      if (cram) {
        queue = shuffled(cards).slice(0, 15).map((c) => c.id);
      } else {
        const q = S.queueFor(cards.map((c) => c.id));
        queue = q.due.slice(0, 40).concat(shuffled(q.fresh).slice(0, q.newBudget));
        if (!queue.length) { startCards(pool, true); return; }
      }
      const byId = new Map(cards.map((c) => [c.id, c]));
      run = { mode: "cards", kind: "queue", queue: queue.map((id) => ({ item: byId.get(id), dir: pickDir(), tries: 0 })), results: [], total: queue.length, done: 0, t0: Date.now(), pool, cram, graded: 0 };
      setView("run"); renderCard();
    }
    const pickDir = () => (cfg.direction === "mixed" ? (Math.random() < 0.5 ? "term" : "def") : cfg.direction);

    function renderCard() {
      if (!run.queue.length) return finish(false);
      const cur = run.queue[0], it = cur.item;
      const front = cur.dir === "term" ? it.term : it.def, back = cur.dir === "term" ? it.def : it.term;
      awaitNext = false;
      runEl.innerHTML = head(`${run.queue.length} left`) + `<div class="pr-body" data-mode-body="cards">
        <div class="pr-flip" data-flip tabindex="0" role="button" aria-label="Card. Press space to reveal the answer." aria-expanded="false">
          <div class="pr-flipface front"><small>${esc(it.subject)} · ${esc(it.lesson)}${cur.tries ? " · again" : ""}</small><p class="${cur.dir === "term" ? "pr-term" : "pr-def"}">${esc(front)}</p><span class="pr-hint">Think of the answer, then press <kbd>Space</kbd> or tap</span></div>
          <div class="pr-flipface back" hidden><small>${esc(cur.dir === "term" ? "Definition" : "Term")}</small><p class="${cur.dir === "term" ? "pr-def" : "pr-term"}">${esc(back)}</p></div>
        </div>
        <div class="pr-rate" hidden aria-label="How well did you know it?"></div></div>`;
      const flip = runEl.querySelector("[data-flip]");
      flip.focus({ preventScroll: true });
      flip.addEventListener("click", revealCard);
    }

    function revealCard() {
      const flip = runEl.querySelector("[data-flip]"); if (!flip || flip.classList.contains("open")) return;
      flip.classList.add("open"); flip.setAttribute("aria-expanded", "true");
      flip.querySelector(".back").hidden = false;
      flip.querySelector(".pr-hint").hidden = true;
      const cur = run.queue[0];
      const pv = S.preview(cur.item.id);
      const rate = runEl.querySelector(".pr-rate");
      const lab = (g) => (run.cram ? "" : `<small>${S.fmtInterval(pv[g])}</small>`);
      rate.innerHTML = [[1, "Again", "again"], [3, "Hard", "hard"], [4, "Good", "good"], [5, "Easy", "easy"]].map(([g, l, c], i) => `<button type="button" class="pr-rbtn ${c}" data-grade="${g}"><b>${l}</b>${lab(g)}<kbd>${i + 1}</kbd></button>`).join("");
      rate.hidden = false;
      rate.querySelectorAll("[data-grade]").forEach((b) => b.addEventListener("click", () => gradeCard(Number(b.dataset.grade))));
    }

    function gradeCard(g) {
      if (!run || run.mode !== "cards" || !run.queue.length) return;
      const cur = run.queue.shift();
      const first = cur.tries === 0;
      if (!run.cram) S.gradeCard(cur.item.id, g); else S.noteResult(cur.item.id, g >= 3);
      if (first) {
        run.results.push({ item: cur.item, correct: g >= 3, promptText: cur.dir === "term" ? cur.item.term : cur.item.def, answerText: cur.dir === "term" ? cur.item.def : cur.item.term, counted: false });
        run.done += 1; run.graded += 1;
      }
      if (g < 3) { cur.tries += 1; cur.dir = cur.dir; run.queue.splice(Math.min(run.queue.length, 3 + cur.tries), 0, cur); }
      renderCard();
    }

    // ---------- Type It ----------
    function renderType(ex, body) {
      const it = ex.item;
      let hinted = false;
      body.innerHTML = `<p class="pr-ctx">${esc(it.subject)} · ${esc(it.lesson)}</p>
        <p class="pr-prompt">${esc(ex.prompt)}</p>
        <p class="pr-sub">Which term is this? <span class="pr-shape">${esc(it.term.split(/\s+/).map((w) => w.length + " letters").slice(0, 4).join(" · "))}</span></p>
        <form class="pr-form" autocomplete="off"><label class="sr-only" for="pr-type-in">Your answer</label><input id="pr-type-in" class="pr-input" type="text" inputmode="text" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="Type the term…" />
        <div class="pr-formrow"><button type="submit" class="pr-btn primary">Check</button><button type="button" class="pr-btn" data-hint>Show first letter</button><button type="button" class="pr-btn ghost" data-giveup>I don't know</button></div></form>`;
      const input = body.querySelector("input"); input.focus();
      const form = body.querySelector("form");
      const lock = () => { form.querySelectorAll("input,button").forEach((x) => { x.disabled = true; }); };
      form.querySelector("[data-hint]").addEventListener("click", (e) => { hinted = true; const f = T.bare(it.term)[0]; input.value = input.value || f; input.focus(); e.target.disabled = true; e.target.textContent = `Starts with “${f}”`; });
      form.querySelector("[data-giveup]").addEventListener("click", () => { lock(); record({ item: it, correct: false, given: "", promptText: it.def, answerText: it.term }, `<b>The answer is ${esc(it.term)}.</b><p>${esc(it.def)}</p>`); });
      form.addEventListener("submit", (e) => {
        e.preventDefault(); e.stopPropagation();
        const val = input.value.trim(); if (!val) { input.focus(); return; }
        const r = T.check(val, ex.variants);
        lock();
        if (r.ok) {
          const msg = r.close ? `<b>Close enough!</b> It’s spelt <b>${esc(it.term)}</b>.` : `<b>Correct${hinted ? " (with a hint)" : ""}.</b> ${esc(it.term)}`;
          record({ item: it, correct: true, close: r.close, hinted, given: val, promptText: it.def, answerText: it.term }, `${msg}<p>${esc(it.def)}</p>`);
        } else {
          record({ item: it, correct: false, given: val, promptText: it.def, answerText: it.term }, `<b>Not quite.</b> You wrote “${esc(val)}”. The answer is <b>${esc(it.term)}</b>.<p>${esc(it.def)}</p><button type="button" class="pr-linkbtn" data-override>Actually, I was right — count it</button>`);
          bindOverride(body);
        }
      });
    }

    // The checker can be too strict (synonyms, abbreviations): the learner is allowed to overrule it.
    function bindOverride(body) {
      const o = body.querySelector("[data-override]"); if (!o) return;
      o.addEventListener("click", () => {
        const r = run.results[run.results.length - 1];
        r.correct = true; r.overridden = true;
        S.noteResult(r.item.id, true);
        const fb = body.querySelector(".pr-feedback"); fb.className = "pr-feedback ok";
        o.replaceWith(Object.assign(document.createElement("em"), { textContent: "Counted as correct." }));
      });
    }

    // ---------- Fill the Blank ----------
    function renderCloze(ex, body) {
      const it = ex.item, cz = ex.cz;
      let hinted = false;
      body.innerHTML = `<p class="pr-ctx">${esc(it.subject)} · ${esc(it.lesson)}</p>
        <p class="pr-term-line">Term: <b>${esc(it.term)}</b></p>
        <form class="pr-form" autocomplete="off"><p class="pr-sentence"></p>
        <div class="pr-formrow"><button type="submit" class="pr-btn primary">Check</button><button type="button" class="pr-btn" data-hint>First letter</button><button type="button" class="pr-btn" data-choices>Give me choices</button><button type="button" class="pr-btn ghost" data-giveup>Skip</button></div>
        <div class="pr-choices" hidden></div></form>`;
      const sentence = body.querySelector(".pr-sentence");
      sentence.append(document.createTextNode(cz.before));
      const input = document.createElement("input");
      input.type = "text"; input.className = "pr-input inline"; input.setAttribute("aria-label", "Missing word"); input.autocapitalize = "off"; input.spellcheck = false; input.autocomplete = "off";
      input.size = Math.max(6, Math.min(cz.length + 2, 24)); input.style.width = Math.max(6, Math.min(cz.length + 2, 24)) + "ch";
      sentence.append(input, document.createTextNode(cz.after));
      input.focus();
      const form = body.querySelector("form");
      const lock = () => { form.querySelectorAll("input,button").forEach((x) => { x.disabled = true; }); };
      const full = () => `${esc(cz.before)}<mark>${esc(cz.answer)}</mark>${esc(cz.after)}`;
      form.querySelector("[data-hint]").addEventListener("click", (e) => { hinted = true; input.value = input.value || cz.hint; input.focus(); e.target.disabled = true; e.target.textContent = `Starts with “${cz.hint}”`; });
      form.querySelector("[data-choices]").addEventListener("click", (e) => {
        hinted = true; e.target.disabled = true;
        const wrong = [];
        const idf = getIdf(items);
        shuffled(ex.pool.filter((c) => c !== it)).some((c) => {
          const o = T.buildCloze(c.def, c.term, idf, Math.random());
          if (o && T.norm(o.answer) !== T.norm(cz.answer) && !wrong.includes(o.answer) && Math.abs(o.answer.length - cz.answer.length) <= 5) wrong.push(o.answer);
          return wrong.length >= 3;
        });
        const opts2 = shuffled([cz.answer].concat(wrong));
        const box = form.querySelector(".pr-choices"); box.hidden = false;
        box.innerHTML = opts2.map((o) => `<button type="button" class="pr-chip" data-choice="${esc(o)}">${esc(o)}</button>`).join("");
        box.addEventListener("click", (ev) => { const c = ev.target.closest("[data-choice]"); if (!c) return; input.value = c.dataset.choice; form.requestSubmit(); });
      });
      form.querySelector("[data-giveup]").addEventListener("click", () => { lock(); record({ item: it, correct: false, given: "", promptText: `${it.term}: ${cz.before}____${cz.after}`, answerText: cz.answer }, `<b>The missing word was “${esc(cz.answer)}”.</b><p>${full()}</p>`); });
      form.addEventListener("submit", (e) => {
        e.preventDefault(); e.stopPropagation();
        const val = input.value.trim(); if (!val) { input.focus(); return; }
        const r = T.checkWord(val, cz.answer);
        lock();
        const meta = { item: it, given: val, promptText: `${it.term}: ${cz.before}____${cz.after}`, answerText: cz.answer };
        if (r.ok) record(Object.assign(meta, { correct: true, close: r.close, hinted }), `<b>${r.close ? "Close enough — it’s “" + esc(cz.answer) + "”." : "Correct" + (hinted ? " (with help)" : "") + "."}</b><p>${full()}</p>`);
        else { record(Object.assign(meta, { correct: false }), `<b>Not quite.</b> You wrote “${esc(val)}” — the missing word was <b>${esc(cz.answer)}</b>.<p>${full()}</p><button type="button" class="pr-linkbtn" data-override>Actually, I was right — count it</button>`); bindOverride(body); }
      });
    }

    // ---------- Explain It ----------
    function renderExplain(ex, body) {
      const it = ex.item, isQ = it.kind === "qa";
      const promptText = isQ ? it.q : `Explain: ${it.term}`;
      body.innerHTML = `<p class="pr-ctx">${esc(it.subject)} · ${esc(it.lesson)}</p>
        <p class="pr-prompt">${esc(promptText)}</p>
        <p class="pr-sub">${isQ ? "Answer in a sentence or two." : "What is it, and why does it matter? Write it in your own words."} Be honest — nobody is marking this but you.</p>
        <form class="pr-form"><label class="sr-only" for="pr-ex-in">Your answer</label><textarea id="pr-ex-in" class="pr-input area" rows="4" placeholder="Type your answer from memory…"></textarea>
        <div class="pr-formrow"><button type="submit" class="pr-btn primary">Check my answer <kbd>Ctrl</kbd>+<kbd>Enter</kbd></button></div></form>`;
      const ta = body.querySelector("textarea"); ta.focus();
      const form = body.querySelector("form");
      ta.addEventListener("keydown", (e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); form.requestSubmit(); } e.stopPropagation(); });
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const text = ta.value.trim();
        const cov = T.coverage(text, ex.kws);
        const ratio = cov.total ? cov.found / cov.total : 0;
        const suggest = !text ? null : ratio >= 0.6 ? "got" : ratio >= 0.3 ? "part" : "miss";
        form.querySelectorAll("textarea,button").forEach((x) => { x.disabled = true; });
        const chips = text ? `<p class="pr-kwtitle">Key ideas in the model answer</p><p class="pr-kws">${cov.hit.map((h) => `<span class="pr-kw ${h.found ? "yes" : "no"}">${h.found ? "✓" : "○"} ${esc(h.word)}</span>`).join("")}</p><p class="pr-kwnote">${cov.found} of ${cov.total} key ideas appeared in your answer.${suggest === "miss" ? " Not many yet — compare them with the model answer." : ""}</p>` : `<p class="pr-kwnote">You skipped writing — compare the model answer with what you had in mind.</p>`;
        const panel = document.createElement("div");
        panel.className = "pr-reveal";
        panel.innerHTML = `<p class="pr-modeltitle">Model answer</p><p class="pr-model">${esc(ex.model)}</p>${chips}
          <p class="pr-rateq">How did you do?</p>
          <div class="pr-selfrate" role="group" aria-label="Rate your answer"><button type="button" class="pr-btn${suggest === "got" ? " suggested" : ""}" data-self="got">✅ Nailed it</button><button type="button" class="pr-btn${suggest === "part" ? " suggested" : ""}" data-self="part">🟡 Partly</button><button type="button" class="pr-btn${suggest === "miss" ? " suggested" : ""}" data-self="miss">❌ Missed it</button></div>`;
        body.appendChild(panel);
        panel.querySelector(`[data-self="${suggest || "part"}"]`).focus();
        panel.querySelectorAll("[data-self]").forEach((b) => b.addEventListener("click", () => {
          const v = b.dataset.self;
          panel.querySelectorAll("button").forEach((x) => { x.disabled = true; });
          const res = { item: it, correct: v === "got", given: text, promptText, answerText: ex.model, counted: v !== "part" };
          const msg = v === "got" ? "<b>Nailed it.</b> Honest self-checking is the whole point." : v === "part" ? "<b>Partly there.</b> Re-read the model answer once more — it will come back." : "<b>No problem.</b> This one will come back sooner.";
          record(res, msg);
        }));
      });
    }

    // ---------- True or False ----------
    function renderTf(ex, body) {
      const it = ex.item;
      body.innerHTML = `<p class="pr-ctx">${esc(it.subject)} · ${esc(it.lesson)}</p>
        <p class="pr-sub">Does this definition belong to this term?</p>
        <div class="pr-tf"><b class="pr-tf-term">${esc(it.term)}</b><p class="pr-tf-def">${esc(ex.shownDef)}</p></div>
        <div class="pr-tfbtns"><button type="button" class="pr-btn big yes" data-tf="true">✓ True <kbd>T</kbd></button><button type="button" class="pr-btn big no" data-tf="false">✗ False <kbd>F</kbd></button></div>`;
      body.querySelectorAll("[data-tf]").forEach((b) => b.addEventListener("click", () => answerTf(ex, body, b.dataset.tf === "true")));
      body.querySelector("[data-tf]").focus({ preventScroll: true });
    }
    function answerTf(ex, body, said) {
      if (awaitNext || !run || run.results.length > run.i) return;
      const ok = said === ex.truth, it = ex.item;
      body.querySelectorAll("[data-tf]").forEach((b) => { b.disabled = true; });
      const explain = ex.truth ? `<p>Yes — <b>${esc(it.term)}</b>: ${esc(it.def)}</p>` : `<p>That definition belongs to <b>${esc(ex.other ? ex.other.term : "another term")}</b>. The real meaning of <b>${esc(it.term)}</b>: ${esc(it.def)}</p>`;
      record({ item: it, correct: ok, given: said ? "True" : "False", promptText: `${it.term} — ${ex.shownDef}`, answerText: ex.truth ? "True — " + it.def : `False — ${it.term} means: ${it.def}` }, `<b>${ok ? "Correct." : "Not quite."}</b>${explain}`);
    }

    const RENDER = { type: renderType, cloze: renderCloze, explain: renderExplain, tf: renderTf };

    // ---------- keyboard ----------
    function onKey(e) {
      if (!visible() || view === "home" || !run || e.ctrlKey || e.metaKey || e.altKey) return;
      const tag = (e.target && e.target.tagName) || "";
      const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(tag);
      if (run.mode === "cards") {
        if (e.key === " " || e.key === "Enter") {
          if (e.target.closest && e.target.closest("[data-grade]")) return;
          if (typing) return;
          e.preventDefault(); revealCard();
        } else if (/^[1-4]$/.test(e.key) && !typing) {
          const flip = runEl.querySelector("[data-flip]");
          if (flip && flip.classList.contains("open")) gradeCard([1, 3, 4, 5][Number(e.key) - 1]);
        }
        return;
      }
      if (awaitNext && e.key === "Enter" && Date.now() - lastAnswerAt > 200) { e.preventDefault(); next(); return; }
      if (run.mode === "tf" && !awaitNext && !typing && (e.key === "t" || e.key === "T" || e.key === "f" || e.key === "F")) {
        const ex = run.ex[run.i]; answerTf(ex, runEl.querySelector(".pr-body"), e.key.toLowerCase() === "t");
      }
    }
    document.addEventListener("keydown", onKey);

    const refresh = () => { if (view === "home") renderHome(); };
    window.addEventListener("curio-practice-updated", refresh);
    window.addEventListener("curio-review-updated", refresh);

    function setItems(next) { items = (next || []).slice(); if (view !== "home") { run = null; setView("home"); } renderHome(); }

    function destroy() {
      document.removeEventListener("keydown", onKey);
      window.removeEventListener("curio-practice-updated", refresh);
      window.removeEventListener("curio-review-updated", refresh);
      root.innerHTML = "";
    }

    renderHome();
    return { setItems, destroy, getItems: () => items, startMode: (id) => { if (MODE[id]) { cfg.mode = id; saveUi({ mode: id }); renderHome(); } } };
  }

  window.CurioPractice = { mount, itemsFromBank, itemsFromPage, MODES, availability, prepare };
})();
