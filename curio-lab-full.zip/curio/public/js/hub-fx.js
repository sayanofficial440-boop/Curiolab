// Curio Lab — Subject hub page interactions
// Animated network canvas in the hero, count-up stats, tabbed live preview,
// and an FAQ accordion. Scoped to pages that include a .hub-hero.
(function () {
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  document.addEventListener("DOMContentLoaded", () => {
    initHeroCanvas();
    initCounters();
    initPreviewTabs();
    initFaqAccordion();
    initFlipTilt();
  });

  // ---------- Hero network canvas (color follows the subject's --accent) ----------
  function initHeroCanvas() {
    const hero = document.querySelector(".hub-hero");
    if (!hero || reduce) return;
    const canvas = hero.querySelector(".hub-hero-canvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const accent = getComputedStyle(hero).getPropertyValue("--accent").trim() || "#2E8E80";

    let w, h, dpr, nodes;
    function size() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = hero.clientWidth; h = hero.clientHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      canvas.style.width = w + "px"; canvas.style.height = h + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    function makeNodes() {
      const count = Math.max(18, Math.min(38, Math.round((w * h) / 26000)));
      nodes = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.25,
        vy: (Math.random() - 0.5) * 0.25,
        r: Math.random() * 1.6 + 0.8,
      }));
    }
    size(); makeNodes();
    window.addEventListener("resize", () => { size(); makeNodes(); });

    function step() {
      ctx.clearRect(0, 0, w, h);
      nodes.forEach((n) => {
        n.x += n.vx; n.y += n.vy;
        if (n.x < 0 || n.x > w) n.vx *= -1;
        if (n.y < 0 || n.y > h) n.vy *= -1;
      });
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i], b = nodes[j];
          const d = Math.hypot(a.x - b.x, a.y - b.y);
          if (d < 130) {
            ctx.strokeStyle = accent;
            ctx.globalAlpha = (1 - d / 130) * 0.35;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }
      ctx.globalAlpha = 0.8;
      ctx.fillStyle = accent;
      nodes.forEach((n) => {
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.globalAlpha = 1;
      requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  // ---------- Count-up hero stats ----------
  function initCounters() {
    const stats = document.querySelectorAll("[data-count-to]");
    if (!stats.length) return;
    const animate = (el) => {
      const target = parseFloat(el.dataset.countTo);
      const suffix = el.dataset.countSuffix || "";
      if (reduce) { el.textContent = target + suffix; return; }
      const dur = 900;
      const start = performance.now();
      function frame(now) {
        const p = Math.min((now - start) / dur, 1);
        const eased = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(target * eased) + suffix;
        if (p < 1) requestAnimationFrame(frame);
      }
      requestAnimationFrame(frame);
    };
    if (!("IntersectionObserver" in window)) { stats.forEach(animate); return; }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) { animate(entry.target); io.unobserve(entry.target); }
      });
    }, { threshold: 0.6 });
    stats.forEach((el) => io.observe(el));
  }

  // ---------- Tabbed live preview ----------
  function initPreviewTabs() {
    const shell = document.querySelector(".preview-shell");
    if (!shell) return;
    const tabs = Array.from(shell.querySelectorAll(".preview-tab"));
    const panels = Array.from(shell.querySelectorAll(".preview-panel"));
    function activate(id) {
      tabs.forEach((t) => t.setAttribute("aria-selected", String(t.dataset.tab === id)));
      panels.forEach((p) => p.classList.toggle("is-active", p.dataset.panel === id));
    }
    tabs.forEach((tab) => {
      tab.addEventListener("click", () => activate(tab.dataset.tab));
    });
    // cycle automatically once, gently, so visitors notice it's interactive
    if (!reduce && tabs.length) {
      let i = 0;
      const auto = setInterval(() => {
        i = (i + 1) % tabs.length;
        activate(tabs[i].dataset.tab);
        if (i === tabs.length - 1) clearInterval(auto);
      }, 2600);
      shell.addEventListener("pointerenter", () => clearInterval(auto), { once: true });
    }
  }

  // ---------- FAQ accordion ----------
  function initFaqAccordion() {
    document.querySelectorAll(".faq-item").forEach((item) => {
      const btn = item.querySelector(".faq-q");
      const panel = item.querySelector(".faq-a");
      if (!btn || !panel) return;
      btn.addEventListener("click", () => {
        const willOpen = !item.classList.contains("is-open");
        item.parentElement.querySelectorAll(".faq-item.is-open").forEach((open) => {
          if (open !== item) {
            open.classList.remove("is-open");
            open.querySelector(".faq-a").style.maxHeight = "";
          }
        });
        item.classList.toggle("is-open", willOpen);
        panel.style.maxHeight = willOpen ? panel.scrollHeight + "px" : "";
      });
    });
  }

  // ---------- Flashcard mock fan-out ----------
  function initFlipTilt() {
    document.querySelectorAll(".pv-flip").forEach((el, i) => {
      el.style.setProperty("--r", String(((i % 3) - 1) * 6));
    });
  }
})();
