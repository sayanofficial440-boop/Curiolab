// Curio Lab — Custom Cursor
//
// A dual-ring cursor: a small dot that tracks the pointer exactly, and a
// larger ring that trails it with spring-like smoothing and stretches
// along the direction of travel based on pointer velocity. On hover over
// anything interactive — real links/buttons, or a 3D hotspot marked with
// `data-cursor-hotspot` (for canvas-based scenes like globe.js/
// threed-forces.js, where there's no real DOM element under the pointer
// for :hover to see) — the ring snaps to that element's bounding box
// instead of staying a fixed circle, so it reads as "this is clickable"
// rather than just decoration.
//
// Plain script, attaches to `window.CurioCursor` — matches the rest of
// js/ (theme.js, sound.js, store.js, scene-manager.js). Additive: creates
// its own two <div>s and <style>, touches no existing markup. No-ops
// entirely on touch/coarse-pointer devices and under
// prefers-reduced-motion (both send the browser's own cursor, which is
// what you want there anyway).
//
// USAGE
//   Nothing required — include the script and it activates itself on
//   DOMContentLoaded for every real hover target (a, button, [role=button],
//   input, [data-cursor-hotspot]).
//   For a 3D hotspot (e.g. a clickable planet mesh under raycasting),
//   toggle it manually from the render loop / raycast hit-test:
//     CurioCursor.setHotspot(canvasElement.getBoundingClientRect(), { round: true });
//     CurioCursor.clearHotspot();
//   To temporarily suppress (e.g. during a drag-to-rotate interaction):
//     CurioCursor.setEnabled(false); ... CurioCursor.setEnabled(true);

(function () {
  "use strict";

  if (window.CurioCursor) return; // already loaded on this page

  var supportsFinePointer =
    window.matchMedia && window.matchMedia("(pointer: fine)").matches;
  var reduceMotion =
    window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  var HOVER_SELECTOR =
    'a, button, [role="button"], input, textarea, select, summary, label, ' +
    "[data-cursor-hotspot], .btn, [onclick]";

  var CurioCursor = {
    /** @returns {boolean} whether the cursor is active on this device/page. */
    isActive: function () {
      return !!(this._enabled && supportsFinePointer && !reduceMotion);
    },
    /** Toggle on/off without tearing down (e.g. during a drag interaction). */
    setEnabled: function (on) {
      this._enabled = !!on;
      if (this._dot && this._ring) {
        var display = this.isActive() ? "" : "none";
        this._dot.style.display = display;
        this._ring.style.display = display;
      }
      if (on) document.documentElement.classList.add("curio-cursor-active");
      else document.documentElement.classList.remove("curio-cursor-active");
    },
    /**
     * Snap the ring to an arbitrary rect — for 3D/canvas hotspots that
     * have no real DOM element for CSS :hover to key off of.
     * @param {DOMRect|{left:number,top:number,width:number,height:number}} rect
     * @param {Object} [opts]
     * @param {boolean} [opts.round=false] - true for a circular hotspot
     *   (e.g. a round planet), false for a rectangular one (e.g. a button).
     */
    setHotspot: function (rect, opts) {
      if (!this.isActive() || !rect) return;
      this._hotspotRect = rect;
      this._hotspotRound = !!(opts && opts.round);
      this._hovering = true;
    },
    clearHotspot: function () {
      this._hotspotRect = null;
      this._hovering = false;
    },

    _enabled: true,
    _hovering: false,
    _hotspotRect: null,
    _hotspotRound: false,
  };

  if (!supportsFinePointer || reduceMotion) {
    // Nothing to build — leave the browser's native cursor alone. Still
    // expose the API as no-ops so calling code (e.g. globe.js hotspot
    // hooks) doesn't need to feature-detect before calling it.
    CurioCursor.setEnabled = function () {};
    CurioCursor.setHotspot = function () {};
    CurioCursor.clearHotspot = function () {};
    window.CurioCursor = CurioCursor;
    return;
  }

  document.addEventListener("DOMContentLoaded", init);

  function init() {
    injectStyle();

    var dot = document.createElement("div");
    dot.className = "curio-cursor-dot";
    var ring = document.createElement("div");
    ring.className = "curio-cursor-ring";
    document.body.appendChild(dot);
    document.body.appendChild(ring);

    CurioCursor._dot = dot;
    CurioCursor._ring = ring;
    document.documentElement.classList.add("curio-cursor-active");

    // Target (raw pointer) vs. rendered (smoothed) positions.
    var targetX = window.innerWidth / 2;
    var targetY = window.innerHeight / 2;
    var dotX = targetX;
    var dotY = targetY;
    var ringX = targetX;
    var ringY = targetY;
    var prevX = targetX;
    var prevY = targetY;
    var visible = false;

    // Ring box state, lerped independently of ring position so a hover
    // snap animates in smoothly rather than popping.
    var ringW = 32;
    var ringH = 32;
    var ringRadius = 16; // px; large value + round rect = pill/circle
    var targetW = ringW;
    var targetH = ringH;
    var targetRadius = ringRadius;
    var pressScale = 1;
    var pressTarget = 1;

    window.addEventListener(
      "pointermove",
      function (e) {
        if (e.pointerType && e.pointerType !== "mouse" && e.pointerType !== "pen") return;
        targetX = e.clientX;
        targetY = e.clientY;
        if (!visible) {
          visible = true;
          dot.style.opacity = "1";
          ring.style.opacity = "1";
          dotX = ringX = targetX;
          dotY = ringY = targetY;
        }
        updateHoverTarget(e.clientX, e.clientY);
      },
      { passive: true }
    );

    window.addEventListener("pointerdown", function () {
      ring.classList.add("is-pressed");
      pressTarget = 0.82;
    });
    window.addEventListener("pointerup", function () {
      ring.classList.remove("is-pressed");
      pressTarget = 1;
    });
    document.addEventListener("mouseleave", function () {
      visible = false;
      dot.style.opacity = "0";
      ring.style.opacity = "0";
    });
    document.addEventListener("mouseenter", function () {
      if (targetX && targetY) {
        visible = true;
        dot.style.opacity = "1";
        ring.style.opacity = "1";
      }
    });

    function updateHoverTarget(clientX, clientY) {
      if (CurioCursor._hotspotRect) return; // 3D hotspot API takes priority
      var el = document.elementFromPoint(clientX, clientY);
      var hoverEl = el ? el.closest(HOVER_SELECTOR) : null;
      CurioCursor._hovering = !!hoverEl;
      CurioCursor._domHoverEl = hoverEl || null;
    }

    function currentHoverRect() {
      if (CurioCursor._hotspotRect) {
        return { rect: CurioCursor._hotspotRect, round: CurioCursor._hotspotRound };
      }
      if (CurioCursor._domHoverEl) {
        return { rect: CurioCursor._domHoverEl.getBoundingClientRect(), round: false };
      }
      return null;
    }

    function loop() {
      requestAnimationFrame(loop);
      if (!visible) return;

      // Dot: near-instant, just enough smoothing to avoid sub-pixel jitter.
      dotX += (targetX - dotX) * 0.55;
      dotY += (targetY - dotY) * 0.55;

      // Ring: slower spring, so it visibly trails the dot.
      ringX += (targetX - ringX) * 0.16;
      ringY += (targetY - ringY) * 0.16;

      // Velocity → directional stretch. Skips entirely while snapped to a
      // hover target, since a stretched ring over a button looks broken.
      var vx = targetX - prevX;
      var vy = targetY - prevY;
      prevX = targetX;
      prevY = targetY;
      var speed = Math.min(Math.sqrt(vx * vx + vy * vy), 40);
      var angle = Math.atan2(vy, vx) * (180 / Math.PI);
      var stretch = 1 + speed / 40 * 0.35;

      var hover = currentHoverRect();
      dot.style.transform = "translate3d(" + dotX + "px, " + dotY + "px, 0) translate(-50%, -50%)";

      if (hover) {
        var padding = 6;
        targetW = hover.rect.width + padding * 2;
        targetH = hover.rect.height + padding * 2;
        targetRadius = hover.round ? Math.max(targetW, targetH) : 14;
        ringX = hover.rect.left + hover.rect.width / 2;
        ringY = hover.rect.top + hover.rect.height / 2;
        ring.classList.add("is-hovering");
      } else {
        targetW = 32;
        targetH = 32;
        targetRadius = 16;
        ring.classList.remove("is-hovering");
      }

      ringW += (targetW - ringW) * 0.22;
      ringH += (targetH - ringH) * 0.22;
      ringRadius += (targetRadius - ringRadius) * 0.22;
      pressScale += (pressTarget - pressScale) * 0.3;

      var skew = hover ? 1 : stretch; // no velocity-skew while snapped
      ring.style.width = ringW + "px";
      ring.style.height = ringH + "px";
      ring.style.borderRadius = ringRadius + "px";
      ring.style.transform =
        "translate3d(" + ringX + "px, " + ringY + "px, 0) " +
        "translate(-50%, -50%) " +
        (hover ? "" : "rotate(" + angle + "deg) scaleX(" + skew + ") rotate(" + -angle + "deg) ") +
        "scale(" + pressScale + ")";
    }
    requestAnimationFrame(loop);
  }

  function injectStyle() {
    if (document.getElementById("curio-cursor-style")) return;
    var style = document.createElement("style");
    style.id = "curio-cursor-style";
    style.textContent =
      ".curio-cursor-active, .curio-cursor-active * { cursor: none !important; }\n" +
      ".curio-cursor-dot, .curio-cursor-ring {\n" +
      "  position: fixed; top: 0; left: 0; margin: 0; opacity: 0;\n" +
      "  pointer-events: none; z-index: 9999; will-change: transform;\n" +
      "  transform-origin: center center;\n" +
      "  transition: opacity 0.2s ease;\n" +
      "}\n" +
      ".curio-cursor-dot {\n" +
      "  width: 6px; height: 6px; border-radius: 50%;\n" +
      "  background: var(--color-coral, #C94A38);\n" +
      "  box-shadow: 0 0 6px rgba(201, 74, 56, 0.45);\n" +
      "}\n" +
      ".curio-cursor-ring {\n" +
      "  width: 32px; height: 32px;\n" +
      "  border: 1.5px solid var(--color-ink, #1B1B18);\n" +
      "  border-radius: 16px; box-sizing: border-box;\n" +
      "  transition: border-color 0.2s ease, background-color 0.2s ease, box-shadow 0.25s ease;\n" +
      "}\n" +
      ".curio-cursor-ring.is-hovering {\n" +
      "  border-color: var(--color-coral, #C94A38);\n" +
      "  background-color: rgba(201, 74, 56, 0.08);\n" +
      "  box-shadow: 0 0 22px rgba(201, 74, 56, 0.22);\n" +
      "}\n" +
      ".curio-cursor-ring.is-pressed { border-color: var(--color-teal, #2E8E80); }\n" +
      "@media (max-width: 900px), (pointer: coarse) {\n" +
      "  .curio-cursor-dot, .curio-cursor-ring { display: none !important; }\n" +
      "  .curio-cursor-active, .curio-cursor-active * { cursor: auto !important; }\n" +
      "}\n";
    document.head.appendChild(style);
  }

  window.CurioCursor = CurioCursor;
})();
