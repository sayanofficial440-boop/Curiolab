// Curio Lab — browser-only authentication.
// Accounts and the current session are stored in this browser only. There is
// no external authentication service, shared database, or Google sign-in.
window.CurioAuth = (function () {
  const LOCAL_ACCOUNTS_KEY = "curiolab-local-accounts";
  const LOCAL_DEMO_SESSION_KEY = "curiolab-local-session";

  function getLocalAccounts() {
    try { return JSON.parse(localStorage.getItem(LOCAL_ACCOUNTS_KEY)) || {}; } catch (e) { return {}; }
  }
  function saveLocalAccounts(accounts) {
    localStorage.setItem(LOCAL_ACCOUNTS_KEY, JSON.stringify(accounts));
  }
  function getDemoSession() {
    try { return JSON.parse(localStorage.getItem(LOCAL_DEMO_SESSION_KEY)); } catch (e) { return null; }
  }
  function setDemoSession(user) {
    localStorage.setItem(LOCAL_DEMO_SESSION_KEY, JSON.stringify(user));
  }
  function clearDemoSession() {
    localStorage.removeItem(LOCAL_DEMO_SESSION_KEY);
  }
  // NOT cryptographically secure — this only exists so a demo account isn't
  // stored as fully plain text. Real password security requires the real
  // backend (werkzeug's hasher — see backend/auth.py).
  function weakHash(str) {
    return btoa(unescape(encodeURIComponent(str))).split("").reverse().join("");
  }

  async function backendAvailable() {
    return false;
  }

  async function getCurrentUser() {
    const demo = getDemoSession();
    return demo ? { ...demo, mode: "local" } : null;
  }

  async function signup({ name, email, password }) {
    const accounts = getLocalAccounts();
    const key = email.toLowerCase().trim();
    if (accounts[key]) throw new Error("An account with that email already exists (demo storage on this browser).");
    if (!name.trim()) throw new Error("Enter your name.");
    if (password.length < 8) throw new Error("Password must be at least 8 characters.");
    accounts[key] = { name, email: key, passwordHash: weakHash(password), provider: "email" };
    saveLocalAccounts(accounts);
    const user = { name, email: key, provider: "email", mode: "local" };
    setDemoSession(user);
    return user;
  }

  // ---- Children under 13 --------------------------------------------------------------------------------
  // A child account has a nickname instead of a name and NO email. The synthetic address below only keeps the
  // per-account progress stores working; it never leaves this browser. The parent's email goes to the server
  // (once, to ask permission) and is not kept here.
  const CHILD_KEY = "curio.child.v1";
  const childEmail = (nick) => "nick-" + nick.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") + "@child.curiolab.invalid";
  function validNickname(n) {
    n = (n || "").trim();
    if (n.length < 2 || n.length > 20) return "Pick a nickname between 2 and 20 characters.";
    if (!/^[A-Za-z0-9 _.\-]+$/.test(n)) return "Use letters, numbers, spaces, dots, dashes or underscores only.";
    if (/\d{5,}/.test(n) || /https?|www|\.com|\.net|\.org/i.test(n)) return "Please don't use phone numbers or web addresses in a nickname.";
    return null;
  }
  async function requestParentConsent(nickname, parentEmail) {
    let r;
    try {
      r = await fetch("/api/coppa/request", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nickname, parent_email: parentEmail }) });
    } catch (e) { return { ok: false, offline: true }; }
    const j = await r.json().catch(() => ({}));
    if (r.status === 404 || r.status === 405 || r.status >= 500) return { ok: false, offline: true };
    if (!r.ok) throw new Error(j.error || "We couldn't send the request. Please check the email address.");
    return { ok: true, ref: j.child_ref, status: j.status, delivery: j.delivery, devLink: j.dev_link };
  }
  async function signupChild({ nickname, password, parentEmail }) {
    const bad = validNickname(nickname);
    if (bad) throw new Error(bad);
    if (password.length < 8) throw new Error("Password must be at least 8 characters.");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s.]{2,}$/.test((parentEmail || "").trim())) throw new Error("Enter your parent or guardian's email address.");
    const accounts = getLocalAccounts();
    const email = childEmail(nickname);
    if (accounts[email]) throw new Error("That nickname is already used on this device. Pick another.");
    const res = await requestParentConsent(nickname.trim(), parentEmail.trim());
    const status = res.ok ? "pending" : "unverified";
    accounts[email] = { name: nickname.trim(), email, passwordHash: weakHash(password), provider: "email", child: true };
    saveLocalAccounts(accounts);
    try { localStorage.setItem(CHILD_KEY, JSON.stringify({ ref: res.ok ? res.ref : null, status, nickname: nickname.trim() })); } catch (e) {}
    const user = { name: nickname.trim(), email, provider: "email", mode: "local", child: true };
    setDemoSession(user);
    return { user, consent: res };
  }
  // For an account that is still "unverified" (the server could not be reached at sign-up) or whose email never arrived.
  async function resendParentConsent(parentEmail) {
    const u = getDemoSession();
    if (!u || !u.child) throw new Error("Only children's accounts need this.");
    const res = await requestParentConsent(u.name, (parentEmail || "").trim());
    if (!res.ok) throw new Error("The server can't be reached right now. Try again later.");
    localStorage.setItem(CHILD_KEY, JSON.stringify({ ref: res.ref, status: "pending", nickname: u.name }));
    if (window.CurioAge) window.CurioAge.setChild({ ref: res.ref, status: "pending", nickname: u.name });
    return res;
  }

  async function login({ email, password }) {
    const accounts = getLocalAccounts();
    let key = email.toLowerCase().trim();
    if (!accounts[key] && !key.includes("@")) key = childEmail(key);   // children sign in with their nickname
    const account = accounts[key];
    if (!account || account.passwordHash !== weakHash(password)) {
      throw new Error("Incorrect email/nickname or password (checked against this browser's accounts).");
    }
    const user = { name: account.name, email: key, provider: "email", mode: "local", ...(account.child ? { child: true } : {}) };
    setDemoSession(user);
    return user;
  }

  async function logout() {
    clearDemoSession();
  }

  function oauthUrl(provider) {
    return "";
  }

  return { getCurrentUser, signup, signupChild, resendParentConsent, validNickname, login, logout, oauthUrl, backendAvailable };
})();
