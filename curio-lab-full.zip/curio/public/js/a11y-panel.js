// Curio Lab — accessibility quick panel + runtime ARIA fixes.
// Loaded by a11y.js on every page.
//  1. A header button (and Alt+Shift+A) that opens the quick panel: text size, dyslexia-friendly
//     font, line spacing, high contrast (light/dark), reduce motion, link underlines,
//     colour-blind-safe charts, default captions, language.
//  2. Roles, names and keyboard behaviour that older pages don't have in their markup:
//     lesson tabs (tablist, arrow keys), unlabeled inputs and navs, chart/diagram text alternatives.
//  3. Loads a11y-media.js (captions + transcripts) on pages that have video or audio.
(function () {
  "use strict";
  const A = window.CurioA11y;
  if (!A || window.CurioA11yPanel) return;
  const me = document.getElementById("a11y-panel-js");
  const JS_BASE = me ? me.src.replace(/a11y-panel\.js(\?.*)?$/, "") : "js/";
  const SITE_BASE = JS_BASE.replace(/js\/$/, "");
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));

  /* ---------- translation helper: hand-written packs via CurioLang, English otherwise ---------- */
  // Keys such as "hc:Light" are namespaced so they never collide with page words (a Physics lesson is also called "Light").
  const T = (k) => { let r = k; try { if (window.CurioLang && window.CurioLang.t) r = window.CurioLang.t(k) || k; } catch (_) { /* keep English */ } return r === k ? k.replace(/^[a-z0-9]+:/, "") : r; };
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  /* =====================================================================
     1. QUICK PANEL
     ===================================================================== */
  const ICON = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="7.3" r="1.2" fill="currentColor"/><path d="M6.8 9.6c3.4 1 6.6 1 10.4 0M12 10v4.2M12 14.2l-2.8 4.4M12 14.2l2.8 4.4"/></svg>';
  const CSS = `
  .a11yp-btn{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;flex:none;border-radius:50%;border:1px solid var(--color-line,var(--line,rgba(0,0,0,.18)));background:var(--color-surface,var(--panel,#fff));color:var(--color-ink,var(--ink,#16323a));cursor:pointer;padding:0;font:inherit;line-height:1}
  .a11yp-btn:hover{border-color:var(--accent,#1b7f95)}
  .a11yp-btn.a11yp-float{position:fixed;left:16px;bottom:76px;z-index:2147482500;box-shadow:0 4px 16px rgba(0,0,0,.2);width:44px;height:44px}
  .a11yp-backdrop{position:fixed;inset:0;z-index:2147483000;background:rgba(10,18,26,.5)}
  .a11yp{position:fixed;z-index:2147483001;right:12px;top:64px;width:min(400px,calc(100vw - 24px));max-height:calc(100vh - 80px);max-height:calc(100dvh - 80px);overflow:auto;overscroll-behavior:contain;background:var(--color-surface,var(--panel,#fff));color:var(--color-ink,var(--ink,#16202a));border:1px solid var(--color-line-strong,var(--line,#ccd));border-radius:18px;box-shadow:0 24px 64px rgba(0,0,0,.3);font:15px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;padding:0}
  .a11yp *{box-sizing:border-box}
  .a11yp-head{display:flex;align-items:center;gap:10px;padding:16px 16px 8px;position:sticky;top:0;background:inherit;z-index:1}
  .a11yp-head h2{margin:0;font-size:1.15rem;font-weight:800;flex:1;letter-spacing:-.01em}
  .a11yp-x{width:40px;height:40px;border-radius:50%;border:1px solid var(--color-line,#ccd);background:transparent;color:inherit;font-size:22px;line-height:1;cursor:pointer;padding:0}
  .a11yp-body{padding:4px 16px 16px;display:grid;gap:14px}
  .a11yp-sec{border:0;margin:0;padding:0;min-width:0}
  .a11yp-sec legend,.a11yp-lab{padding:0;font-weight:700;font-size:.9rem;margin:0 0 6px;display:block}
  .a11yp-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
  .a11yp-chip{appearance:none;font:inherit;font-weight:600;font-size:.9rem;min-height:44px;min-width:44px;padding:8px 14px;border-radius:12px;border:1.5px solid var(--color-line-strong,#9aa5b1);background:var(--color-surface,#fff);color:inherit;cursor:pointer}
  .a11yp-chip[aria-pressed=true]{background:var(--accent,#1b6f87);border-color:var(--accent,#1b6f87);color:#fff}
  .a11yp-out{min-width:3.6em;text-align:center;font-weight:800;font-variant-numeric:tabular-nums}
  .a11yp input[type=range]{width:100%;min-height:32px;accent-color:var(--accent,#1b6f87)}
  .a11yp-sw{display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:48px;padding:8px 12px;border:1.5px solid var(--color-line,#d5dbe3);border-radius:12px;cursor:pointer;font-weight:600}
  .a11yp-sw small{display:block;font-weight:400;font-size:.78rem;opacity:.75}
  .a11yp-sw input{width:24px;height:24px;flex:none;accent-color:var(--accent,#1b6f87)}
  .a11yp-sub{margin:6px 0 0 12px}
  .a11yp-foot{display:flex;gap:8px;flex-wrap:wrap;align-items:center;justify-content:space-between;border-top:1px solid var(--color-line,#dde);padding-top:12px}
  .a11yp-link{color:var(--accent,#1b6f87);font-weight:600}
  .a11yp-hint{font-size:.78rem;opacity:.75;margin:0}
  @media(max-width:700px){.a11yp{left:0;right:0;top:auto;bottom:0;width:auto;max-height:88vh;max-height:88dvh;border-radius:22px 22px 0 0}}`;
  const st = document.createElement("style"); st.id = "a11yp-css"; st.textContent = CSS; document.head.appendChild(st);

  let btn = null, dlg = null, back = null, opener = null;

  function makeButton() {
    const b = document.createElement("button");
    b.type = "button"; b.className = "a11yp-btn"; b.setAttribute("data-a11yp-btn", ""); b.setAttribute("data-no-sfx", "");
    b.setAttribute("aria-haspopup", "dialog"); b.setAttribute("aria-expanded", "false");
    b.innerHTML = ICON; b.addEventListener("click", () => (dlg ? close() : open(b)));
    return b;
  }
  function labelButton() { if (btn) { btn.setAttribute("aria-label", T("Accessibility settings")); btn.title = T("Accessibility settings") + " (Alt+Shift+A)"; } }
  function injectButton() {
    if (document.querySelector("[data-a11yp-btn]")) return;
    const lang = $(".site-header [data-lang-btn]") || $(".main .topbar .top-right [data-lang-btn]");
    const sound = $(".site-header [data-sound-toggle]");
    const topRight = $(".main .topbar .top-right");
    btn = makeButton();
    if (lang) { lang.before(btn); btn.classList.add(...(lang.className.split(/\s+/).filter((c) => c && c !== "lang-btn"))); }
    else if (sound) { sound.before(btn); btn.classList.add("sound-toggle"); }
    else if (topRight) topRight.insertBefore(btn, topRight.firstChild);
    else return false;
    labelButton(); return true;
  }
  function floatButton() {
    if (document.querySelector("[data-a11yp-btn]")) return;
    btn = makeButton(); btn.classList.add("a11yp-float"); document.body.appendChild(btn); labelButton();
  }

  function build() {
    const p = A.get();
    const langs = (window.CurioLang && window.CurioLang.languages) || [];
    const cur = window.CurioLang ? window.CurioLang.get() : document.documentElement.lang || "en";
    const curName = (langs.find((l) => l.code === cur) || {}).name || "English";
    const chip = (attr, val, label, on) => `<button type="button" class="a11yp-chip" ${attr}="${val}" aria-pressed="${on}">${esc(label)}</button>`;
    const sw = (k, label, hint, on) => `<label class="a11yp-sw"><span>${esc(label)}${hint ? `<small>${esc(hint)}</small>` : ""}</span><input type="checkbox" data-sw="${k}" ${on ? "checked" : ""}></label>`;
    return `
    <div class="a11yp-head"><h2 id="a11yp-title" tabindex="-1">${esc(T("Accessibility settings"))}</h2><button type="button" class="a11yp-x" data-x aria-label="${esc(T("Close"))}">×</button></div>
    <div class="a11yp-body">
      <fieldset class="a11yp-sec"><legend>${esc(T("Text size"))}</legend>
        <div class="a11yp-row"><button type="button" class="a11yp-chip" data-step="-5" aria-label="${esc(T("Smaller text"))}">A−</button>
        <output class="a11yp-out" data-out aria-live="polite">${p.scale}%</output>
        <button type="button" class="a11yp-chip" data-step="5" aria-label="${esc(T("Larger text"))}">A+</button>
        <button type="button" class="a11yp-chip" data-step="0">${esc(T("a11y:Default"))}</button></div>
        <input type="range" min="85" max="200" step="5" value="${p.scale}" data-range aria-label="${esc(T("Text size"))}"></fieldset>
      <fieldset class="a11yp-sec"><legend>${esc(T("Font"))}</legend><div class="a11yp-row">
        ${chip("data-font", "default", T("a11y:Default"), p.font === "default")}${chip("data-font", "dyslexia", T("Dyslexia-friendly"), p.font === "dyslexia")}${chip("data-font", "readable", T("High legibility"), p.font === "readable")}</div></fieldset>
      <fieldset class="a11yp-sec"><legend>${esc(T("Line spacing"))}</legend><div class="a11yp-row">
        ${chip("data-spacing", "normal", T("sp:Normal"), p.spacing === "normal")}${chip("data-spacing", "relaxed", T("sp:Relaxed"), p.spacing === "relaxed")}${chip("data-spacing", "loose", T("sp:Loose"), p.spacing === "loose")}</div></fieldset>
      <div>
        ${sw("contrast", T("High contrast"), "", p.contrast)}
        <div class="a11yp-sub a11yp-row" data-hcrow ${p.contrast ? "" : "hidden"} role="group" aria-label="${esc(T("High contrast"))}">${chip("data-hc", "light", T("hc:Light"), p.hc !== "dark")}${chip("data-hc", "dark", T("hc:Dark"), p.hc === "dark")}</div>
      </div>
      ${sw("motion", T("Reduce motion"), "", p.motion)}
      ${sw("links", T("Underline links"), "", p.links)}
      ${sw("cb", T("Colour-blind-safe charts"), "", p.cb)}
      ${sw("captions", T("Captions on by default"), "", p.captions !== false)}
      <div><span class="a11yp-lab">${esc(T("Language"))}</span><button type="button" class="a11yp-chip" data-lang>${esc(curName)} — ${esc(T("Change language"))}</button></div>
      <div class="a11yp-foot"><button type="button" class="a11yp-chip" data-reset>${esc(T("Reset all"))}</button><a class="a11yp-link" href="${esc(SITE_BASE)}pages/accessibility.html">${esc(T("More settings"))}</a></div>
      <p class="a11yp-hint">Alt + Shift + A</p>
    </div>`;
  }

  function wire() {
    const set = (patch, msg) => { A.set(patch); sync(); if (msg) A.announce(msg); };
    const range = $("[data-range]", dlg), out = $("[data-out]", dlg);
    range.addEventListener("input", () => { A.set({ scale: Number(range.value) }); out.textContent = range.value + "%"; });
    $$("[data-step]", dlg).forEach((b) => b.addEventListener("click", () => {
      const s = Number(b.dataset.step), cur = A.get().scale, next = s === 0 ? 100 : Math.max(85, Math.min(200, cur + s));
      A.set({ scale: next }); range.value = next; out.textContent = next + "%";
    }));
    $$("[data-font]", dlg).forEach((b) => b.addEventListener("click", () => set({ font: b.dataset.font })));
    $$("[data-spacing]", dlg).forEach((b) => b.addEventListener("click", () => set({ spacing: b.dataset.spacing })));
    $$("[data-hc]", dlg).forEach((b) => b.addEventListener("click", () => set({ hc: b.dataset.hc })));
    $$("[data-sw]", dlg).forEach((i) => i.addEventListener("change", () => set({ [i.dataset.sw]: i.checked })));
    $("[data-reset]", dlg).addEventListener("click", () => { A.reset(); render(); A.announce(T("Reset all")); });
    $("[data-x]", dlg).addEventListener("click", close);
    $("[data-lang]", dlg).addEventListener("click", () => { close(); const lb = $("[data-lang-btn]"); if (lb) lb.click(); });
  }
  function sync() {
    if (!dlg) return;
    const p = A.get();
    $$("[data-font]", dlg).forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.font === p.font)));
    $$("[data-spacing]", dlg).forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.spacing === p.spacing)));
    $$("[data-hc]", dlg).forEach((b) => b.setAttribute("aria-pressed", String((b.dataset.hc === "dark") === (p.hc === "dark"))));
    const row = $("[data-hcrow]", dlg); if (row) row.hidden = !p.contrast;
  }
  function render() {
    dlg.innerHTML = build(); wire();
    const h = $("#a11yp-title", dlg); if (h) h.focus({ preventScroll: true });
  }
  function focusables() { return $$("button:not([disabled]),input:not([disabled]),a[href],[tabindex]:not([tabindex='-1'])", dlg).filter((e) => !e.hidden && !e.closest("[hidden]") && e.offsetParent !== null); }
  function onKey(e) {
    if (!dlg) return;
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); return; }
    if (e.key !== "Tab") return;
    const f = focusables(); if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && (document.activeElement === first || document.activeElement === dlg || document.activeElement.id === "a11yp-title")) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
  function open(from) {
    if (dlg) return;
    opener = from || document.activeElement;
    back = document.createElement("div"); back.className = "a11yp-backdrop"; back.addEventListener("click", close);
    dlg = document.createElement("div"); dlg.className = "a11yp"; dlg.setAttribute("role", "dialog"); dlg.setAttribute("aria-modal", "true"); dlg.setAttribute("aria-labelledby", "a11yp-title");
    document.body.appendChild(back); document.body.appendChild(dlg);
    render();
    if (btn) btn.setAttribute("aria-expanded", "true");
    document.addEventListener("keydown", onKey, true);
  }
  function close() {
    if (!dlg) return;
    document.removeEventListener("keydown", onKey, true);
    dlg.remove(); back.remove(); dlg = back = null;
    if (btn) btn.setAttribute("aria-expanded", "false");
    const back2 = opener && document.contains(opener) ? opener : btn; opener = null;
    if (back2) back2.focus();
  }
  document.addEventListener("keydown", (e) => {
    if (e.altKey && e.shiftKey && !e.ctrlKey && !e.metaKey && e.code === "KeyA") { e.preventDefault(); dlg ? close() : open(btn || document.activeElement); }
  });
  document.addEventListener("curio:langchange", () => { labelButton(); if (dlg) render(); setTimeout(enhanceAll, 400); });

  /* =====================================================================
     2. RUNTIME ARIA / KEYBOARD FIXES
     ===================================================================== */
  const NAV_LABELS = [
    [".site-footer-rich nav, footer nav", "Footer"],
    [".breadcrumb, nav[class*=crumb]", "Breadcrumb"],
    [".main-nav", "Subjects"],
    [".diagram-switcher", "Choose a scenario"],
    [".mode-tabs", "Study modes"],
    [".side-rail, .rail, aside nav, .sidebar nav", "Main navigation"],
    ["[class*=pager], [class*=pagination]", "Pagination"],
    ["[class*=toc]", "On this page"],
  ];
  let tabSeq = 0;
  function enhanceTabs() {
    $$(".mode-tabs").forEach((nav) => {
      if (nav.__a11y) return;
      const tabs = $$("[data-tab]", nav); if (!tabs.length) return;
      nav.__a11y = true;
      nav.setAttribute("role", "tablist");
      if (!nav.getAttribute("aria-label")) nav.setAttribute("aria-label", T("Study modes"));
      const panelFor = (t) => document.querySelector(`[data-panel="${t.dataset.tab}"]`);
      tabs.forEach((t) => {
        const id = t.id || ("a11y-tab-" + (++tabSeq)); t.id = id;
        t.setAttribute("role", "tab");
        const pn = panelFor(t);
        if (pn) { if (!pn.id) pn.id = "a11y-panel-" + (++tabSeq); t.setAttribute("aria-controls", pn.id); pn.setAttribute("role", "tabpanel"); pn.setAttribute("aria-labelledby", id); }
        // decorative emoji at the start of a tab name is not read aloud
        const tn = t.firstChild; if (tn && tn.nodeType === 3) { const m = tn.nodeValue.match(/^(\s*(?:\p{Extended_Pictographic}️?‍?)+\s*)(.*)$/su); if (m && m[2]) { const sp = document.createElement("span"); sp.setAttribute("aria-hidden", "true"); sp.textContent = m[1]; tn.nodeValue = m[2]; t.insertBefore(sp, tn); } }
      });
      const sync = () => tabs.forEach((t) => { const on = t.classList.contains("active"); t.setAttribute("aria-selected", String(on)); t.tabIndex = on ? 0 : -1; });
      new MutationObserver(sync).observe(nav, { attributes: true, attributeFilter: ["class"], subtree: true });
      sync();
      nav.addEventListener("keydown", (e) => {
        const list = tabs.filter((t) => !t.disabled && t.offsetParent !== null), i = list.indexOf(document.activeElement);
        if (i < 0) return;
        let n = -1;
        if (e.key === "ArrowRight" || e.key === "ArrowDown") n = (i + 1) % list.length;
        else if (e.key === "ArrowLeft" || e.key === "ArrowUp") n = (i - 1 + list.length) % list.length;
        else if (e.key === "Home") n = 0; else if (e.key === "End") n = list.length - 1;
        if (n < 0) return;
        e.preventDefault(); list[n].focus(); list[n].click();
      });
    });
  }
  const INPUT_NAMES = [
    ["[data-tts-rate]", "Reading speed"], ["[data-ln-text]", "Your notes"], ["[data-timer-input]", "Minutes"],
  ];
  function nameInputs() {
    $$("input:not([type=hidden]):not([type=submit]):not([type=button]),select,textarea").forEach((el) => {
      if (el.getAttribute("aria-label") || el.getAttribute("aria-labelledby") || (el.labels && el.labels.length)) return;
      let name = "";
      for (const [sel, n] of INPUT_NAMES) if (el.matches(sel)) { name = T(n); break; }
      if (!name) name = el.getAttribute("title") || el.getAttribute("placeholder") || "";
      if (!name) { const prev = el.closest("label, div, p, li"); const t = prev && prev.querySelector("span, b, strong, small"); name = t ? t.textContent.trim().slice(0, 60) : ""; }
      if (name) el.setAttribute("aria-label", name);
    });
  }
  function nameNavs() {
    $$("nav:not([aria-label]):not([aria-labelledby])").forEach((n) => {
      const hit = NAV_LABELS.find(([sel]) => { try { return n.matches(sel); } catch (_) { return false; } });
      if (hit) { n.setAttribute("aria-label", T(hit[1])); return; }
      const h = n.querySelector("h2,h3,h4,h5,b,strong"); // e.g. a footer column heading
      n.setAttribute("aria-label", h ? h.textContent.trim() : (n.closest("header") ? T("Main navigation") : n.closest("footer") ? T("Footer") : T("Page navigation")));
    });
  }
  function markCurrent() {
    const here = location.pathname.replace(/\/index\.html$/, "/");
    $$("nav a[href]").forEach((a) => {
      if (a.hasAttribute("aria-current") || a.getAttribute("href").startsWith("#")) return;
      try { const u = new URL(a.href, location.href); if (u.origin === location.origin && u.pathname.replace(/\/index\.html$/, "/") === here && !u.hash) a.setAttribute("aria-current", "page"); } catch (_) { /* ignore */ }
    });
  }
  function altForGraphics() {
    const label = (el) => {
      const own = el.querySelector && el.querySelector(":scope > title"); if (own && own.textContent.trim()) return own.textContent.trim();
      const fig = el.closest("figure"); const fc = fig && fig.querySelector("figcaption"); if (fc) return fc.textContent.trim();
      const sec = el.closest("section, article, [data-panel], .card, .st-card"); const h = sec && sec.querySelector("h1,h2,h3,h4"); return h ? h.textContent.trim() : "";
    };
    $$("canvas:not([role]):not([aria-label]):not([aria-hidden]):not([tabindex])").forEach((c) => {
      const t = label(c) || T("Interactive illustration"); c.setAttribute("role", "img"); c.setAttribute("aria-label", t);
    });
    $$("svg:not([role]):not([aria-label]):not([aria-labelledby]):not([aria-hidden])").forEach((s) => {
      if (s.closest("button, a, [role=button], .lang-btn")) { s.setAttribute("aria-hidden", "true"); s.setAttribute("focusable", "false"); return; }
      const r = s.getBoundingClientRect();
      if (r.width < 90 && r.height < 90) { s.setAttribute("aria-hidden", "true"); s.setAttribute("focusable", "false"); return; }
      const t = label(s); if (t) { s.setAttribute("role", "img"); s.setAttribute("aria-label", t); }
    });
  }
  function liveRegions() {
    // quiz / practice feedback is announced when it appears
    $$(".quiz-feedback,.quiz-explain,.pr-feedback,.pl-result,[data-quiz-feedback],.rv-feedback,.xc-feedback").forEach((e) => { if (!e.hasAttribute("aria-live") && !e.hasAttribute("role")) { e.setAttribute("aria-live", "polite"); } });
  }
  function enhanceAll() {
    try { enhanceTabs(); nameInputs(); nameNavs(); markCurrent(); altForGraphics(); liveRegions(); } catch (e) { if (window.console) console.warn("[a11y-panel]", e); }
    if (!btn) { if (!injectButton() && document.readyState === "complete") floatButton(); }
  }
  let t = null;
  const later = () => { clearTimeout(t); t = setTimeout(enhanceAll, 250); };
  new MutationObserver(later).observe(document.body, { childList: true, subtree: true });
  enhanceAll();
  window.addEventListener("load", () => { enhanceAll(); setTimeout(() => { if (!document.querySelector("[data-a11yp-btn]")) floatButton(); }, 900); });

  /* =====================================================================
     3. Captions + transcripts for video and audio
     ===================================================================== */
  const needsMedia = () => document.querySelector("iframe[src*='youtube'],iframe[data-consent-src*='youtube'],[data-tts-text],video,audio") || window.CURIO_DYNAMIC_LESSON;
  function loadMedia() {
    if (document.getElementById("a11y-media-js") || !needsMedia()) return;
    const s = document.createElement("script"); s.id = "a11y-media-js"; s.src = JS_BASE + "a11y-media.js"; s.async = true; document.head.appendChild(s);
  }
  loadMedia(); window.addEventListener("load", loadMedia);

  window.CurioA11yPanel = { open: () => open(btn), close, enhance: enhanceAll, t: T };
})();
