// Curio Lab — "Review due today" reminders. Real web push when the Flask backend (backend/app.py) is
// reachable; otherwise a local reminder while the site is open. The server only learns the push
// endpoint, the time the next review falls due and a count -- never your questions or answers.
(function () {
  "use strict";
  const R = window.CurioReview, me = document.currentScript;
  if (!R || !me || !me.src || window.CurioReviewPush) return;
  const root = new URL("../", me.src), ENABLED = "curiolab-review-push";
  const can = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window && /^https?:$/.test(location.protocol);
  const b64 = (s) => { const p = "=".repeat((4 - (s.length % 4)) % 4), r = atob((s + p).replace(/-/g, "+").replace(/_/g, "/")); return Uint8Array.from(r, (c) => c.charCodeAt(0)); };
  const quiet = () => { const h = new Date().getHours(); return h >= 22 || h < 7; };
  const on = () => localStorage.getItem(ENABLED) === "1" && can && Notification.permission === "granted";

  async function sub() { const reg = await navigator.serviceWorker.ready; return { reg, s: await reg.pushManager.getSubscription() }; }
  function snapshot() {
    const items = R.all().filter((x) => x.due).sort((a, b) => a.due - b.due);
    if (!items.length) return { nextDue: 0, dueCount: 0 };
    const nextDue = items[0].due;
    return { nextDue, dueCount: items.filter((x) => x.due <= nextDue + 12 * 3600000).length };
  }
  async function sync() {
    if (!on()) return false;
    if (window.CurioAge && !window.CurioAge.allowed("push")) return false;
    try {
      const { s } = await sub(); if (!s) return false;
      const r = await fetch(new URL("api/push/sync", root), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ subscription: s.toJSON(), ...snapshot(), tzOffset: new Date().getTimezoneOffset() }) });
      return r.ok;
    } catch (_) { return false; }
  }
  async function enable() {
    if (window.CurioAge && !window.CurioAge.allowed("push")) return { ok: false, why: window.CurioAge.why("push") };
    if (!can) return { ok: false, why: "This browser can't show reminders. On iPhone, add the site to your Home Screen first." };
    if ((await Notification.requestPermission()) !== "granted") return { ok: false, why: "Notifications are blocked. Allow them in your browser's site settings." };
    localStorage.setItem(ENABLED, "1");
    let server = false;
    try {
      const k = await fetch(new URL("api/push/key", root)); if (!k.ok) throw 0;
      const { reg, s } = await sub();
      const pushSub = s || (await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64((await k.json()).key) }));
      server = await sync(); if (!server) await pushSub.unsubscribe();
    } catch (_) { /* no backend: local mode */ }
    return { ok: true, server };
  }
  async function disable() {
    localStorage.removeItem(ENABLED);
    try { const { s } = await sub(); if (s) { fetch(new URL("api/push/unsubscribe", root), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ endpoint: s.endpoint }) }).catch(() => {}); await s.unsubscribe(); } } catch (_) { /* ignore */ }
  }

  // Local fallback: while a tab is open, remind at most every 12 hours, never in quiet hours.
  async function localNudge() {
    if (!on() || quiet()) return;
    const { s } = await sub().catch(() => ({})); if (s) return; // real push already covers it
    const n = R.due().length, last = +localStorage.getItem("curiolab-review-nudged") || 0;
    if (!n || Date.now() - last < 12 * 3600000) return;
    localStorage.setItem("curiolab-review-nudged", String(Date.now()));
    (await navigator.serviceWorker.ready).showNotification("Review due today", { body: n + " question" + (n === 1 ? "" : "s") + " ready in your Mistake Notebook.", icon: new URL("icons/icon-192.png", root).href, data: { url: "pages/review.html" } });
  }

  window.CurioReviewPush = { supported: can, enabled: on, enable, disable, sync };
  window.addEventListener("curio-review-updated", () => { sync(); });
  window.addEventListener("load", () => { sync(); localNudge(); setInterval(localNudge, 5 * 60000); });

  // Switch on the Mistake Notebook page.
  const app = document.querySelector("[data-review-app]");
  if (app) {
    const box = document.createElement("div");
    box.className = "st-card"; box.style.cssText = "display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:12px";
    box.innerHTML = '<div style="flex:1;min-width:200px"><b>Daily review reminder</b><div class="s" style="font-size:12.5px;opacity:.75" data-rp-msg></div></div><button class="st-btn" type="button" data-rp-btn></button>';
    app.insertBefore(box, app.firstChild);
    const msg = box.querySelector("[data-rp-msg]"), btn = box.querySelector("[data-rp-btn]");
    const paint = (note) => { btn.hidden = !can; btn.textContent = on() ? "Turn off" : "Remind me"; msg.textContent = note || (!can ? "Not supported in this browser (on iPhone, add Curio Lab to the Home Screen first)." : on() ? "On. You'll get a notification when reviews fall due (never between 22:00 and 07:00)." : "Get a notification when questions in your notebook are due."); };
    btn.addEventListener("click", async () => {
      if (on()) { await disable(); paint(); return; }
      const r = await enable(); paint(r.ok ? (r.server ? null : "On while Curio Lab is open. Deploy the backend (see backend/README.md) for reminders when it's closed.") : r.why);
    });
    paint();
  }
})();
