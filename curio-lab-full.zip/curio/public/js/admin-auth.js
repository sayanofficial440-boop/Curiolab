// Curio Lab — Admin Authentication
// Lives entirely on the backend (no demo/localStorage mode).
window.CurioAdminAuth = (function () {
  const BACKEND_URL = "";
  const SESSION_KEY = "curiolab-admin-session";

  function getSession() {
    try { return JSON.parse(localStorage.getItem(SESSION_KEY)); } catch (e) { return null; }
  }
  function setSession(admin) {
    localStorage.setItem(SESSION_KEY, JSON.stringify(admin));
  }
  function clearSession() {
    localStorage.removeItem(SESSION_KEY);
  }

  async function backendAvailable() {
    try {
      const controller = new AbortController();
      const t = setTimeout(() => controller.abort(), 1200);
      const res = await fetch(`${BACKEND_URL}/api/admin/me`, { credentials: "include", signal: controller.signal });
      clearTimeout(t);
      return res.ok;
    } catch (e) {
      return false;
    }
  }

  async function login({ email, password }) {
    const res = await fetch(`${BACKEND_URL}/api/admin/login`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Admin login failed.");
    setSession(data.admin);
    return data.admin;
  }

  async function logout() {
    clearSession();
    try {
      await fetch(`${BACKEND_URL}/api/admin/logout`, { method: "POST", credentials: "include" });
    } catch (e) { /* already cleared */ }
  }

  async function checkSession() {
    try {
      const res = await fetch(`${BACKEND_URL}/api/admin/me`, { credentials: "include" });
      if (!res.ok) { clearSession(); return null; }
      const data = await res.json();
      if (data.admin) { setSession(data.admin); return data.admin; }
      clearSession(); return null;
    } catch (e) {
      // Backend unreachable — fail closed rather than trusting a stale cached
      // session. The admin panel is meant to require a live backend, always.
      clearSession();
      return null;
    }
  }

  return { getSession, setSession, clearSession, login, logout, checkSession, backendAvailable };
})();
