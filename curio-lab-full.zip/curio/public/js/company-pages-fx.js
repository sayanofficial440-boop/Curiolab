// Curio Lab — Company & Legal Pages FX
// Purely additive interaction layer for about, contact, pricing, privacy,
// terms and changelog. Never overrides page-specific logic (contact form
// submit handler, pricing checkout fetch, etc) — only observes the DOM
// and layers motion/behavior on top, same philosophy as core-pages-fx.js.
(function () {
  "use strict";

  function ready(fn) {
    if (document.readyState !== "loading") fn();
    else document.addEventListener("DOMContentLoaded", fn);
  }

  /* ---------------- 1. Scroll reveal ---------------- */
  function initReveal() {
    const targets = document.querySelectorAll(
      ".about-block, .impact-stats, .contact-card, .contact-info-card, .price-card, .pricing-faq, .building-panel, .changelog-entry, .quick-fact, .changelog-stats .cs-card, .roadmap-panel, .principle-card"
    );
    if (!targets.length) return;
    targets.forEach((el) => el.classList.add("cl-reveal"));
    if (!("IntersectionObserver" in window)) {
      targets.forEach((el) => el.classList.add("is-in"));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-in");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    targets.forEach((el) => io.observe(el));
  }

  /* ---------------- 2. Count-up for impact stats (about page) ---------------- */
  function initCounters() {
    const nums = document.querySelectorAll("[data-count-to]");
    if (!nums.length) return;
    const run = (el) => {
      const target = parseFloat(el.dataset.countTo);
      const suffix = el.dataset.countSuffix || "";
      if (Number.isNaN(target)) return;
      const start = performance.now();
      const duration = 900;
      function step(now) {
        const t = Math.min(1, (now - start) / duration);
        const eased = 1 - Math.pow(1 - t, 3);
        el.textContent = Math.round(target * eased) + suffix;
        if (t < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
    };
    if (!("IntersectionObserver" in window)) { nums.forEach(run); return; }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) { run(e.target); io.unobserve(e.target); }
      });
    }, { threshold: 0.4 });
    nums.forEach((el) => io.observe(el));
  }

  /* ---------------- 3. Ripple on any button/.cl-submit-btn ---------------- */
  function initRipple() {
    document.addEventListener("click", (e) => {
      const btn = e.target.closest(".cl-submit-btn, .price-card button, .timer-btn, .cmdk-trigger, .back-home");
      if (!btn || btn.disabled) return;
      const rect = btn.getBoundingClientRect();
      const ripple = document.createElement("span");
      const size = Math.max(rect.width, rect.height) * 1.2;
      ripple.className = "cl-ripple";
      ripple.style.width = ripple.style.height = size + "px";
      ripple.style.left = e.clientX - rect.left - size / 2 + "px";
      ripple.style.top = e.clientY - rect.top - size / 2 + "px";
      btn.appendChild(ripple);
      ripple.addEventListener("animationend", () => ripple.remove());
    });
  }

  /* ---------------- 4. Contact form — floating labels + demo success state ---------------- */
  function initContactForm() {
    const form = document.querySelector("[data-contact-form]");
    if (!form) return;
    const submitBtn = form.querySelector("[data-cl-submit]");
    const successNote = document.querySelector("[data-cl-success]");

    form.querySelectorAll(".cl-field input, .cl-field textarea").forEach((field) => {
      const wrap = field.closest(".cl-field");
      const check = () => wrap.classList.toggle("cl-valid", field.checkValidity() && field.value.trim() !== "");
      field.addEventListener("input", check);
      field.addEventListener("blur", check);
    });

    form.addEventListener("submit", () => {
      if (!submitBtn) return;
      submitBtn.classList.add("is-loading");
      window.setTimeout(() => {
        submitBtn.classList.remove("is-loading");
        if (successNote) {
          successNote.classList.add("is-visible");
          window.setTimeout(() => successNote.classList.remove("is-visible"), 4500);
        }
      }, 650);
    });
  }

  /* ---------------- 5. Pricing toggle (monthly/yearly, visual-only demo) ---------------- */
  function initPricingToggle() {
    const toggle = document.querySelector("[data-pricing-toggle]");
    if (!toggle) return;
    const prices = document.querySelectorAll("[data-monthly][data-yearly]");
    toggle.addEventListener("click", () => {
      const yearly = !toggle.classList.contains("is-yearly");
      toggle.classList.toggle("is-yearly", yearly);
      prices.forEach((p) => {
        p.textContent = yearly ? p.dataset.yearly : p.dataset.monthly;
      });
      document.querySelectorAll("[data-period-label]").forEach((el) => {
        el.textContent = yearly ? "/year" : "/month";
      });
    });
  }

  /* ---------------- 6. Legal pages — reading progress bar + TOC scrollspy ---------------- */
  function initLegalLayout() {
    const panels = document.querySelectorAll(".building-panel[id]");
    if (!panels.length) return;

    const bar = document.createElement("div");
    bar.className = "cl-read-progress";
    document.body.appendChild(bar);
    const updateBar = () => {
      const h = document.documentElement;
      const scrolled = h.scrollTop;
      const max = h.scrollHeight - h.clientHeight;
      bar.style.width = (max > 0 ? (scrolled / max) * 100 : 0) + "%";
    };
    document.addEventListener("scroll", updateBar, { passive: true });
    updateBar();

    const tocLinks = document.querySelectorAll(".legal-toc a");
    if (!tocLinks.length || !("IntersectionObserver" in window)) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          tocLinks.forEach((a) => a.classList.remove("is-active"));
          const link = document.querySelector(`.legal-toc a[href="#${entry.target.id}"]`);
          if (link) link.classList.add("is-active");
        });
      },
      { rootMargin: "-20% 0px -70% 0px" }
    );
    panels.forEach((p) => io.observe(p));
  }

  /* ---------------- 7. Changelog — filter chips ---------------- */
  function initChangelogFilters() {
    const bar = document.querySelector("[data-changelog-filters]");
    if (!bar) return;
    const entries = document.querySelectorAll(".changelog-entry");
    bar.addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-filter]");
      if (!btn) return;
      bar.querySelectorAll("button").forEach((b) => b.classList.remove("is-active"));
      btn.classList.add("is-active");
      const filter = btn.dataset.filter;
      entries.forEach((entry) => {
        const tags = (entry.dataset.tags || "").split(",");
        const show = filter === "all" || tags.includes(filter);
        entry.classList.toggle("cl-hidden", !show);
      });
    });
  }

  ready(function () {
    initReveal();
    initCounters();
    initRipple();
    initContactForm();
    initPricingToggle();
    initLegalLayout();
    initChangelogFilters();
  });
})();
