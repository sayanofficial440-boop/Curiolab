// Curio Lab — Progress Dashboard
document.addEventListener("DOMContentLoaded", () => {
  const tableBody = document.querySelector("[data-scoreboard-body]");
  const statLessons = document.querySelector("[data-stat-lessons]");
  const statAttempts = document.querySelector("[data-stat-attempts]");
  const statAvg = document.querySelector("[data-stat-avg]");
  const statStreak = document.querySelector("[data-stat-streak]");
  const streakCard = document.querySelector(".stat-card[data-flame]");
  const emptyState = document.querySelector("[data-scoreboard-empty]");
  const emptyQuickstart = document.querySelector("[data-empty-quickstart]");
  const tableWrap = document.querySelector("[data-scoreboard-table-wrap]");
  const analysisEl = document.querySelector("[data-ai-analysis]");
  const recsEl = document.querySelector("[data-recommendations]");
  const masteryEl = document.querySelector("[data-subject-mastery]");
  const activityCountEl = document.querySelector("[data-activity-count]");
  if (!tableBody) return;

  let all = [];
  try { all = JSON.parse(localStorage.getItem("curiolab-scores")) || []; } catch (e) { all = []; }

  // Canonical subject catalog — kept in sync with data-quiz-subject values
  // used across pages/<subject>/<slug>.html
  const SUBJECTS = [
    { name: "Physics", accent: "var(--color-teal)", flagship: "physics/force.html", flagshipTitle: "Force" },
    { name: "Chemistry", accent: "var(--color-amber)", flagship: "chemistry/atom-structure.html", flagshipTitle: "Atom Structure" },
    { name: "Biology", accent: "var(--color-coral)", flagship: "biology/cell.html", flagshipTitle: "The Cell" },
    { name: "Mathematics", accent: "var(--color-amber)", flagship: "mathematics/linear-equations.html", flagshipTitle: "Linear Equations" },
    { name: "English", accent: "var(--color-coral)", flagship: "english/road-not-taken.html", flagshipTitle: "The Road Not Taken" },
    { name: "History", accent: "var(--color-navy)", flagship: "history/mughal-empire.html", flagshipTitle: "Mughal Empire" },
    { name: "Geography", accent: "var(--color-moss)", flagship: "geography/world-landforms.html", flagshipTitle: "World Landforms" },
    { name: "Computer Science", accent: "var(--color-navy)", flagship: "computer-science/html5.html", flagshipTitle: "HTML5" },
  ];
  const subjectByName = Object.fromEntries(SUBJECTS.map((s) => [s.name, s]));

  function renderQuickstart(subjects) {
    if (!emptyQuickstart) return;
    emptyQuickstart.innerHTML = subjects.map((s) => `
      <a href="${s.flagship}" style="--qs-accent:${s.accent};">
        <div class="qs-subject">${s.name}</div>
        <div class="qs-lesson">${s.flagshipTitle} &rarr;</div>
      </a>
    `).join("");
  }

  if (all.length === 0) {
    if (emptyState) emptyState.style.display = "block";
    if (tableWrap) tableWrap.style.display = "none";
    if (statLessons) statLessons.textContent = "0";
    if (statAttempts) statAttempts.textContent = "0";
    if (statAvg) statAvg.textContent = "—";
    if (statStreak) statStreak.textContent = "0";
    renderQuickstart(SUBJECTS.slice(0, 3));
    return;
  }

  if (emptyState) emptyState.style.display = "none";
  if (tableWrap) tableWrap.style.display = "block";

  const uniqueLessons = new Set(all.map((s) => s.lesson));
  const avgPct = Math.round(
    (all.reduce((sum, s) => sum + s.score / s.total, 0) / all.length) * 100
  );

  if (statLessons) statLessons.textContent = uniqueLessons.size;
  if (statAttempts) statAttempts.textContent = all.length;
  if (statAvg) statAvg.textContent = `${avgPct}%`;

  // ---- Best streak: longest run of consecutive calendar days with >=1 attempt ----
  const dayMs = 86400000;
  const uniqueDayNums = [...new Set(all.map((s) => Math.floor(new Date(s.date).getTime() / dayMs)))].sort((a, b) => a - b);
  let bestStreak = uniqueDayNums.length ? 1 : 0;
  let running = 1;
  for (let i = 1; i < uniqueDayNums.length; i++) {
    running = uniqueDayNums[i] === uniqueDayNums[i - 1] + 1 ? running + 1 : 1;
    if (running > bestStreak) bestStreak = running;
  }
  if (statStreak) statStreak.textContent = bestStreak;
  if (streakCard) streakCard.setAttribute("data-flame", bestStreak >= 2 ? "on" : "off");

  // ---- Recent activity (redesigned rows) ----
  const sorted = [...all].sort((a, b) => new Date(b.date) - new Date(a.date));
  if (activityCountEl) activityCountEl.textContent = `${all.length} attempt${all.length === 1 ? "" : "s"}`;

  tableBody.innerHTML = sorted.map((s) => {
    const pct = Math.round((s.score / s.total) * 100);
    const date = new Date(s.date);
    const dateStr = date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
    const accent = (subjectByName[s.subject] && subjectByName[s.subject].accent) || "var(--accent)";
    return `<div class="cl-activity-row" style="--ar-accent:${accent}; --ar-pct:${pct}%;">
      <div class="ar-lesson">${s.lesson}<span class="ar-date">${dateStr}</span></div>
      <div class="ar-subject">${s.subject}</div>
      <div class="ar-bar-wrap"><div class="ar-bar-fill"></div></div>
      <div class="ar-pct">${pct}%</div>
    </div>`;
  }).join("");

  // ---- Subject mastery breakdown ----
  const bySubject = {};
  all.forEach((s) => {
    if (!bySubject[s.subject]) bySubject[s.subject] = [];
    bySubject[s.subject].push(s.score / s.total);
  });

  const attemptedRows = SUBJECTS
    .filter((s) => bySubject[s.name])
    .map((s) => {
      const pcts = bySubject[s.name];
      const avg = pcts.reduce((a, b) => a + b, 0) / pcts.length;
      return { ...s, avg, attempts: pcts.length };
    })
    .sort((a, b) => b.avg - a.avg);

  const untriedRows = SUBJECTS.filter((s) => !bySubject[s.name]);

  if (masteryEl) {
    masteryEl.innerHTML = [
      ...attemptedRows.map((s) => `
        <div class="subject-mastery-row" style="--sm-accent:${s.accent}; --sm-pct:${Math.round(s.avg * 100)}%;">
          <span class="sm-dot"></span>
          <span class="sm-name">${s.name}</span>
          <span class="sm-track"><span class="sm-fill"></span></span>
          <span class="sm-val">${Math.round(s.avg * 100)}% · ${s.attempts}×</span>
        </div>
      `),
      ...untriedRows.map((s) => `
        <div class="subject-mastery-row is-untried" style="--sm-accent:${s.accent};">
          <span class="sm-dot"></span>
          <span class="sm-name">${s.name}</span>
          <span class="sm-track"></span>
          <span class="sm-val"><a href="${s.flagship}">Start &rarr;</a></span>
        </div>
      `),
    ].join("");
  }

  // ---- AI Analysis & Smart Recommendation ----
  const weakest = attemptedRows[attemptedRows.length - 1];
  const strongest = attemptedRows[0];

  if (analysisEl) {
    let text = "";
    if (strongest && weakest && strongest.name !== weakest.name) {
      text = `You're strongest in <strong>${strongest.name}</strong> (${Math.round(strongest.avg * 100)}% average) and could use more practice in <strong>${weakest.name}</strong> (${Math.round(weakest.avg * 100)}% average). `;
    } else if (strongest) {
      text = `Your average across <strong>${strongest.name}</strong> is ${Math.round(strongest.avg * 100)}%. `;
    }
    if (avgPct >= 85) text += "Overall you're performing very well — consider trying a Monthly Deep Exam to test retention.";
    else if (avgPct >= 60) text += "Overall you're on solid ground — a bit more repetition on your weaker topics should push this higher.";
    else text += "Overall there's room to grow — try reviewing the Slides mode before retaking quizzes on your lower-scoring topics.";
    if (bestStreak >= 3) text += ` You're also on a ${bestStreak}-day study streak — keep it going.`;
    analysisEl.innerHTML = `<p>${text}</p>`;
  }

  if (recsEl) {
    const recSubject = untriedRows.length ? untriedRows[0] : weakest;
    if (recSubject) {
      const reason = untriedRows.length
        ? `You haven't tried ${recSubject.name} yet — ${SUBJECTS.length - untriedRows.length} of ${SUBJECTS.length} subjects explored so far.`
        : `Your average in ${recSubject.name} is ${Math.round(recSubject.avg * 100)}%, the lowest of your subjects.`;
      recsEl.innerHTML = `
        <p style="font-size:0.9rem; color:var(--color-ink-soft); margin-bottom:0.6rem;">${reason}</p>
        <a class="back-home" href="${recSubject.flagship}" style="justify-content:flex-start;">Try it now &rarr;</a>
      `;
    } else {
      recsEl.innerHTML = `<p style="color:var(--color-ink-soft); font-size:0.9rem;">You've tried every subject — nice work. Keep retaking quizzes to push your averages up.</p>`;
    }
  }
});
