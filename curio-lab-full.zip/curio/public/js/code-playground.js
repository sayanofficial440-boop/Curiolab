// Curio Lab — Code Playground (Computer Science centerpiece)
//
// TWO INDEPENDENT UPGRADES FROM THE PREVIOUS VERSION:
//
// 1) EDITOR: progressive enhancement over the plain <textarea data-code-editor>.
//    The textarea is the full, working, zero-dependency implementation (same
//    behavior as before). If CodeMirror 6 loads successfully from the CDN,
//    it's mounted next to the textarea, kept in sync with it, and the
//    textarea is hidden. If the CDN is blocked (offline, ad-blocker,
//    corporate proxy), the textarea stays visible and fully functional —
//    a dependency outage degrades the experience, it never breaks "Run".
//
// 2) SANDBOX: student code used to run via `new Function(...)` in this main
//    window, which meant it had real access to `document`, `window`,
//    cookies, and localStorage for this origin, plus the ability to hang
//    the tab with an infinite loop. It now runs inside a same-run-throwaway
//    <iframe sandbox="allow-scripts"> — deliberately WITHOUT
//    "allow-same-origin". That combination is what makes this a real
//    security boundary: without allow-same-origin, the browser assigns the
//    iframe a unique opaque origin, so its script cannot read this page's
//    DOM/cookies/storage and cannot navigate the parent, no matter what the
//    student's code tries to do. The only channel in or out is postMessage,
//    and we validate every message's source and shape before trusting it.
window.onLessonContentReady(() => {
  const editor = document.querySelector("[data-code-editor]");
  const runBtn = document.querySelector("[data-code-run]");
  const resetBtn = document.querySelector("[data-code-reset]");
  const consoleEl = document.querySelector("[data-code-console]");
  if (!editor || !runBtn) return;

  const starter = editor.value;
  const MAX_OUTPUT_LINES = 500;
  const RUN_TIMEOUT_MS = 3000;

  // ---- Console output ---------------------------------------------------
  let lineCount = 0;
  function printLine(text, cls) {
    if (lineCount >= MAX_OUTPUT_LINES) return;
    lineCount += 1;
    if (lineCount === MAX_OUTPUT_LINES) {
      text = "(output truncated at 500 lines — check for an infinite loop)";
      cls = "muted";
    }
    const div = document.createElement("div");
    div.className = "line" + (cls ? " " + cls : "");
    div.textContent = text;
    consoleEl.appendChild(div);
  }
  function clearConsole() {
    consoleEl.innerHTML = "";
    lineCount = 0;
  }

  // ---- Sandboxed iframe runtime ------------------------------------------
  // Built as a string and loaded via `srcdoc` rather than a same-origin file
  // so it works with the "no allow-same-origin" sandbox restriction and
  // needs no server route of its own.
  const SANDBOX_HTML = `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body><script>
    (function () {
      function send(type, payload) {
        try { parent.postMessage({ __curioSandbox: true, type: type, payload: payload }, "*"); }
        catch (e) { /* parent gone — nothing to do */ }
      }
      function serialize(arg) {
        if (typeof arg === "string") return arg;
        if (arg === undefined) return "undefined";
        try { return JSON.stringify(arg); } catch (e) { return String(arg); }
      }
      var fakeConsole = {
        log: function () { send("log", Array.prototype.map.call(arguments, serialize).join(" ")); },
        info: function () { send("log", Array.prototype.map.call(arguments, serialize).join(" ")); },
        warn: function () { send("warn", Array.prototype.map.call(arguments, serialize).join(" ")); },
        error: function () { send("error", Array.prototype.map.call(arguments, serialize).join(" ")); },
      };
      window.addEventListener("message", function (e) {
        if (!e.data || e.data.__curioRun !== true) return;
        try {
          var fn = new Function("console", e.data.code);
          fn(fakeConsole);
        } catch (err) {
          send("error", "Error: " + err.message);
        }
        send("done", null);
      });
      send("ready", null);
    })();
  <\/script></body></html>`;

  let iframe = null;
  let timeoutId = null;
  let runToken = 0;

  function destroySandbox() {
    if (iframe) {
      iframe.remove(); // removing the iframe reliably aborts its running script
      iframe = null;
    }
    if (timeoutId) {
      clearTimeout(timeoutId);
      timeoutId = null;
    }
  }

  function createSandbox() {
    destroySandbox();
    const frame = document.createElement("iframe");
    frame.setAttribute("sandbox", "allow-scripts");
    frame.setAttribute("aria-hidden", "true");
    frame.style.cssText = "position:absolute; width:0; height:0; border:0; opacity:0; pointer-events:none;";
    frame.srcdoc = SANDBOX_HTML;
    document.body.appendChild(frame);
    iframe = frame;
    return frame;
  }

  let runHadError = false;
  let runHadOutput = false;
  let isManualRun = false;

  // Feeds backend/certificates.py's "Compiler Streak" tier. A "clean" run
  // requires actual console output, not just the absence of an error —
  // otherwise running empty/no-op code would trivially count.
  const PLAYGROUND_STREAK_KEY = "curiolab-playground-streak";
  function readPlaygroundStreak() {
    try { return JSON.parse(localStorage.getItem(PLAYGROUND_STREAK_KEY)) || { current: 0, best: 0 }; }
    catch (e) { return { current: 0, best: 0 }; }
  }
  function registerPlaygroundRun(clean) {
    const s = readPlaygroundStreak();
    if (clean) {
      s.current += 1;
      s.best = Math.max(s.best, s.current);
      if (window.CurioToast && s.current > 0 && s.current % 5 === 0) {
        window.CurioToast.show(`🧪 ${s.current} clean runs in a row!`, { icon: "🧪" });
      }
    } else {
      s.current = 0;
    }
    localStorage.setItem(PLAYGROUND_STREAK_KEY, JSON.stringify(s));
    return s;
  }

  function handleSandboxMessage(e) {
    if (!iframe || e.source !== iframe.contentWindow) return; // ignore anything not from our own live sandbox
    const data = e.data;
    if (!data || data.__curioSandbox !== true) return;

    if (data.type === "ready") {
      iframe.contentWindow.postMessage({ __curioRun: true, code: getCurrentCode() }, "*");
    } else if (data.type === "log") {
      printLine(String(data.payload));
      runHadOutput = true;
    } else if (data.type === "warn") {
      printLine("Warning: " + data.payload, "muted");
    } else if (data.type === "error") {
      printLine(String(data.payload), "err");
      runHadError = true;
    } else if (data.type === "done") {
      clearTimeout(timeoutId);
      timeoutId = null;
      if (!consoleEl.children.length) printLine("(no output — try adding a console.log)", "muted");
      window.CurioSound && window.CurioSound.play(runHadError ? "compileError" : "compileSuccess");
      if (isManualRun) registerPlaygroundRun(!runHadError && runHadOutput);
    }
  }
  window.addEventListener("message", handleSandboxMessage);

  function run() {
    clearConsole();
    runToken += 1;
    const thisRun = runToken;
    runHadError = false;
    runHadOutput = false;
    createSandbox();
    timeoutId = setTimeout(() => {
      if (thisRun !== runToken) return; // a newer run already replaced this one
      printLine("Execution timed out — check for an infinite loop.", "err");
      window.CurioSound && window.CurioSound.play("compileError");
      if (isManualRun) registerPlaygroundRun(false);
      destroySandbox();
    }, RUN_TIMEOUT_MS);
  }

  // ---- CodeMirror 6 progressive enhancement ------------------------------
  let cmView = null;

  function getCurrentCode() {
    return cmView ? cmView.state.doc.toString() : editor.value;
  }

  async function mountCodeMirror() {
    try {
      const [{ EditorView, basicSetup }, { EditorState }, { javascript }] = await Promise.all([
        import("https://esm.sh/codemirror@6.0.1"),
        import("https://esm.sh/@codemirror/state@6.4.1"),
        import("https://esm.sh/@codemirror/lang-javascript@6.2.2"),
      ]);

      const mount = document.createElement("div");
      mount.className = "code-editor-cm";
      mount.setAttribute("data-code-cm-mount", "");
      editor.insertAdjacentElement("afterend", mount);

      cmView = new EditorView({
        state: EditorState.create({
          doc: editor.value,
          extensions: [
            basicSetup,
            javascript(),
            EditorView.updateListener.of((update) => {
              if (update.docChanged) editor.value = cmView.state.doc.toString();
            }),
          ],
        }),
        parent: mount,
      });

      editor.style.display = "none";
    } catch (err) {
      console.warn("Curio Lab: CodeMirror failed to load — using the plain textarea instead.", err);
    }
  }

  function setEditorValue(code) {
    editor.value = code;
    if (cmView) {
      cmView.dispatch({ changes: { from: 0, to: cmView.state.doc.length, insert: code } });
    }
  }

  runBtn.addEventListener("click", () => { isManualRun = true; run(); });
  resetBtn?.addEventListener("click", () => {
    setEditorValue(starter);
    clearConsole();
  });

  mountCodeMirror();
  isManualRun = false;
  run(); // run once on load so the panel isn't empty, matching prior behavior — not counted toward the clean-run streak
});
