/* Curio Lab - age screen and child-account rules (COPPA-style).
 *
 * Load this early on every page (it is tiny). It answers one question for the rest of the site:
 * "may this visitor use a feature that sends data off the device?"
 *
 *   CurioAge.isChild()          true for a child account, or for a browser where an under-13 birth date was entered
 *   CurioAge.allowed(feature)   feature: contact | liveAI | push | certificates | media | translate | social | subscribe
 *   CurioAge.why(feature)       short sentence to show when allowed() is false
 *   CurioAge.screen(m, y)       the neutral age screen; stores ONLY the resulting band, never the birth date
 *   CurioAge.refresh()          asks the server whether a parent has approved (child accounts only)
 *
 * What we store locally:  curio.age.v1 = { band: "child" | "teen" | "adult", ts }   curio.child.v1 = { ref, status, nickname }
 * Anonymous visitors are never asked for an age: browsing and learning collect nothing.
 * Honest limits: an age screen cannot stop a child from typing a false birth year. It is a neutral gate (it does not
 * hint at the "right" answer) plus a lock so changing the answer on the same browser needs site data to be cleared.
 */
(function () {
  "use strict";
  var AGE_KEY = "curio.age.v1", CHILD_KEY = "curio.child.v1", SESSION_KEY = "curiolab-local-session";
  var listeners = [];

  function read(key) { try { return JSON.parse(localStorage.getItem(key)); } catch (e) { return null; } }
  function write(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); } catch (e) { /* private mode */ } }
  function session() { return read(SESSION_KEY); }
  function childInfo() { return read(CHILD_KEY); }
  function band() { var a = read(AGE_KEY); return a && a.band || null; }

  function bandFor(month, year) {
    var now = new Date();
    var months = (now.getFullYear() * 12 + now.getMonth() + 1) - (year * 12 + month);
    // Month-level precision only: someone who turns 13 later this month is still treated as a child (the cautious side).
    if (months <= 13 * 12) return "child";
    if (months < 16 * 12) return "teen";
    return "adult";
  }

  var api = {
    band: band,
    screen: function (month, year) {
      month = +month; year = +year;
      var thisYear = new Date().getFullYear();
      if (!(month >= 1 && month <= 12) || !(year >= thisYear - 110 && year <= thisYear)) return null;
      var locked = band();
      if (locked) return locked;                      // already answered on this browser: the answer does not change
      var b = bandFor(month, year);
      write(AGE_KEY, { band: b, ts: Date.now() });
      fire();
      return b;
    },
    isChildAccount: function () { var s = session(); return !!(s && s.child); },
    isChild: function () { return api.isChildAccount() || band() === "child"; },
    consent: function () {
      if (!api.isChildAccount()) return band() === "child" ? "none" : "n/a";
      var c = childInfo(); return (c && c.status) || "unverified";
    },
    approved: function () { return api.consent() === "granted"; },
    allowed: function (feature) {
      if (!api.isChild()) return true;
      if (feature === "certificates" || feature === "push" || feature === "media") return api.approved();
      return false;                                   // contact, liveAI, translate, social, subscribe: never for children
    },
    why: function (feature) {
      var need = api.isChildAccount() ? "a parent has to approve this account first" : "ask a parent or teacher to help";
      var m = {
        contact: "Children's accounts can't send messages from this site. Ask a parent or teacher to write to us.",
        liveAI: "The AI coach runs in practice mode on children's accounts. Your questions are not sent anywhere.",
        translate: "Page translation uses Google, so it is switched off on children's accounts.",
        social: "Sharing buttons for other websites are hidden on children's accounts. You can still copy the link.",
        subscribe: "Plans are for adults. Everything in Curio Lab's free plan is already open to you.",
        push: "Reminders need a parent's approval, and " + need + ".",
        certificates: "Certificates need a parent's approval, and " + need + ".",
        media: "Embedded videos need a parent's approval, and " + need + "."
      };
      return m[feature] || "This isn't available on children's accounts.";
    },
    refresh: function () {
      var c = childInfo();
      if (!api.isChildAccount() || !c || !c.ref) return Promise.resolve(api.consent());
      return fetch("/api/coppa/status/" + encodeURIComponent(c.ref), { cache: "no-store" })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (j) {
          if (!j) return api.consent();
          if (j.status === "gone") {                   // a parent deleted the account: sign the child out of it
            try { localStorage.removeItem(SESSION_KEY); localStorage.removeItem(CHILD_KEY); } catch (e) {}
            fire(); return "gone";
          }
          if (j.status !== c.status) { c.status = j.status; write(CHILD_KEY, c); fire(); }
          return j.status;
        })
        .catch(function () { return api.consent(); });
    },
    setChild: function (info) { write(CHILD_KEY, info); fire(); },
    onChange: function (fn) { listeners.push(fn); }
  };
  function fire() { listeners.forEach(function (fn) { try { fn(); } catch (e) {} }); try { document.dispatchEvent(new CustomEvent("curio:age")); } catch (e) {} }

  window.CurioAge = api;
  if (api.isChildAccount()) { try { api.refresh(); } catch (e) {} }   // also catches a parent withdrawing approval or deleting the account

  // Keep a small, polite notice on every page while a child account waits for approval.
  document.addEventListener("DOMContentLoaded", function () {
    if (!api.isChildAccount() || api.approved() || /\/(parent|login|signup)\.html/.test(location.pathname)) return;
    if (document.getElementById("cl-child-note")) return;
    var d = document.createElement("div"); d.id = "cl-child-note"; d.setAttribute("role", "status");
    d.style.cssText = "position:fixed;left:12px;bottom:"+(window.innerWidth<=780?"84px":"12px")+";max-width:min(92vw,360px);z-index:50;padding:.7rem .9rem;border-radius:12px;background:#12213b;color:#fff;font:500 .85rem/1.4 system-ui,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.25)";
    d.innerHTML = "👋 Waiting for a parent to approve this account. Lessons and quizzes work now; certificates and reminders unlock after approval. ";
    var b = document.createElement("button"); b.type = "button"; b.textContent = "OK";
    b.style.cssText = "margin-left:.4rem;min-height:32px;padding:0 .8rem;border-radius:999px;border:1px solid #fff8;background:none;color:#fff;cursor:pointer";
    b.onclick = function () { d.remove(); }; d.appendChild(b); document.body.appendChild(d);
  });
})();
