// Curio Lab — guided Class 8 / 9 / 10 tracks for "Browse by Grade".
// Each lesson (from js/lesson-meta.js) is placed in exactly one class track, ordered
// easy -> hard, and the track shows real progress from CurioLearning (60%+ on the quiz = done).
(function () {
  "use strict";
  const META = window.CurioMeta, CAT = window.CurioCatalog, L = window.CurioLearning;
  const host = document.querySelector("[data-tracks]");
  if (!META || !CAT || !host) return;
  const CLASSES = [8, 9, 10];
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const rel = (h) => String(h).replace(/^pages\//, "");
  const levelLabel = (n) => (META.levels.find((l) => l.id === n) || {}).label || "";

  // Home class: beginner lessons start in Class 8, intermediate in 9 (or 10 if they only open
  // at Grade 9+ and end by 11), advanced in 10 - always kept inside the lesson's own grade range.
  const homeClass = (m) => {
    const h = m[2] === 1 ? (m[0] <= 8 ? 8 : 9) : m[2] === 2 ? (m[0] >= 9 && m[1] <= 11 ? 10 : 9) : 10;
    return Math.min(Math.max(h, m[0], 8), Math.max(m[1], 8), 10);
  };
  const order = new Map(CAT.lessons.map((l, i) => [l.h, i]));
  const lessons = CAT.lessons.map((l) => {
    const m = l.h.match(/pages\/([a-z-]+\/[a-z0-9-]+)\.html/);
    const meta = m ? META.lessons[m[1]] : null;
    return meta && meta[0] <= 10 ? { ...l, m: meta, home: homeClass(meta) } : null;
  }).filter(Boolean);
  const track = (n) => lessons.filter((l) => l.home === n)
    .sort((a, b) => a.m[2] - b.m[2] || order.get(a.h) - order.get(b.h));

  const qs = new URLSearchParams(location.search);
  let cls = CLASSES.includes(Number(qs.get("track"))) ? Number(qs.get("track")) : 0;
  let done = new Set(), seen = new Set();

  const style = document.createElement("style");
  style.textContent = `
  .tr-wrap{margin:22px 0 8px;text-align:left}
  .tr-head{display:flex;flex-wrap:wrap;align-items:baseline;gap:8px 14px;margin-bottom:10px}
  .tr-head h2{margin:0;font-size:20px} .tr-head p{margin:0;font-size:13.5px;opacity:.75}
  .tr-tabs{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 14px}
  .tr-tab{border:1px solid var(--line,#d9d4ee);background:transparent;color:inherit;border-radius:12px;padding:10px 16px;font:inherit;font-weight:700;cursor:pointer;text-align:left;min-width:120px}
  .tr-tab small{display:block;font-weight:500;font-size:12px;opacity:.75;margin-top:2px}
  .tr-tab[aria-pressed="true"]{background:var(--accent,#6547da);color:#fff;border-color:transparent}
  .tr-tab:focus-visible,.tr-step:focus-visible,.tr-go:focus-visible{outline:2px solid var(--accent,#6547da);outline-offset:2px}
  .tr-bar{height:8px;border-radius:99px;background:var(--line-soft,rgba(128,128,160,.2));overflow:hidden;margin:0 0 14px}
  .tr-bar i{display:block;height:100%;background:var(--teal,#177d75);border-radius:99px;transition:width .3s}
  .tr-next{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;padding:12px 14px;border-radius:14px;border:1px solid var(--accent,#6547da);margin-bottom:14px}
  .tr-go{background:var(--accent,#6547da);color:#fff;text-decoration:none;font-weight:700;border-radius:10px;padding:8px 14px;font-size:13.5px}
  .tr-list{list-style:none;margin:0;padding:0;counter-reset:s}
  .tr-step{display:flex;align-items:center;gap:12px;padding:10px 12px;border:1px solid var(--line,#e5e1f4);border-radius:12px;margin-bottom:8px;text-decoration:none;color:inherit}
  .tr-step:hover{border-color:var(--accent,#6547da)}
  .tr-n{flex:none;width:30px;height:30px;border-radius:50%;display:grid;place-items:center;font-size:13px;font-weight:700;background:var(--accent-soft,rgba(101,71,218,.14))}
  .tr-step.is-done .tr-n{background:var(--teal,#177d75);color:#fff}
  .tr-step.is-next{border-color:var(--accent,#6547da);box-shadow:0 0 0 1px var(--accent,#6547da) inset}
  .tr-t{flex:1;min-width:0} .tr-t b{display:block;font-size:14px} .tr-t span{font-size:12px;opacity:.75}
  .tr-st{font-size:12px;font-weight:700;white-space:nowrap}`;
  document.head.appendChild(style);

  function render() {
    const tabs = CLASSES.map((n) => {
      const t = track(n), d = t.filter((l) => done.has(rel(l.h))).length;
      return `<button type="button" class="tr-tab" data-c="${n}" aria-pressed="${cls === n}">Class ${n}<small>${d} / ${t.length} done</small></button>`;
    }).join("");
    let body = `<p class="tr-head" style="margin:0 0 6px">Pick a class to follow its lessons in order, easiest first. A lesson counts as done when you score 60% or more on its quiz.</p>`;
    if (cls) {
      const t = track(cls), d = t.filter((l) => done.has(rel(l.h))).length;
      const next = t.find((l) => !done.has(rel(l.h)));
      const pct = t.length ? Math.round((d / t.length) * 100) : 0;
      body = `<div class="tr-bar" role="progressbar" aria-label="Class ${cls} progress" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><i style="width:${pct}%"></i></div>
        ${next ? `<div class="tr-next"><div><b>Next up: ${esc(next.t)}</b><br><span style="font-size:12.5px;opacity:.8">${esc(next.s)} · ${esc(levelLabel(next.m[2]))}</span></div><a class="tr-go" href="${esc(rel(next.h))}">${seen.has(rel(next.h)) ? "Continue" : "Start"} →</a></div>` : `<div class="tr-next"><b>Class ${cls} track complete 🎉</b><a class="tr-go" href="exams.html">Try an exam</a></div>`}
        <ol class="tr-list">${t.map((l, i) => {
          const h = rel(l.h), isDone = done.has(h), isNext = next && next.h === l.h;
          return `<li><a class="tr-step${isDone ? " is-done" : ""}${isNext ? " is-next" : ""}" href="${esc(h)}"><span class="tr-n" aria-hidden="true">${isDone ? "✓" : i + 1}</span><span class="tr-t"><b>${esc(l.t)}</b><span>${esc(l.s)} · ${esc(levelLabel(l.m[2]))}</span></span><span class="tr-st">${isDone ? "Done" : isNext ? "Up next" : seen.has(h) ? "In progress" : ""}</span></a></li>`;
        }).join("")}</ol>`;
    }
    host.innerHTML = `<div class="tr-wrap"><div class="tr-head"><h2>Class tracks</h2><p>A guided path for Class 8, 9 or 10</p></div><div class="tr-tabs" role="group" aria-label="Choose a class">${tabs}</div>${body}</div>`;
    host.querySelectorAll(".tr-tab").forEach((b) => b.addEventListener("click", () => {
      cls = cls === Number(b.dataset.c) ? 0 : Number(b.dataset.c);
      const q = new URLSearchParams(location.search); cls ? q.set("track", cls) : q.delete("track");
      try { history.replaceState(null, "", location.pathname + (q.toString() ? "?" + q : "")); } catch (e) {}
      render();
    }));
  }

  async function load() {
    if (L) {
      try {
        const s = await L.get();
        done = new Set(s.lessonProgress.filter((p) => p.status === "completed").map((p) => L.relHref(p.href).replace(/^pages\//, "")));
        seen = new Set(s.lessonProgress.map((p) => L.relHref(p.href).replace(/^pages\//, "")));
      } catch (e) { /* show the track without progress */ }
    }
    render();
  }
  window.addEventListener("curio-learning-updated", load);
  render(); load();
})();
