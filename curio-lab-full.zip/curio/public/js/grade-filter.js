// Curio Lab — grade & difficulty filter for subject hubs.
// Reads window.CurioMeta (js/lesson-meta.js). Adds badges to every topic card,
// a filter bar above the roadmap, URL sharing (?grade=9-10&level=2) and remembers the last choice.
(function () {
  const META = window.CurioMeta;
  if (!META) return;
  const STORE = "curio.gf.v1";

  const bandById = Object.fromEntries(META.bands.map((b) => [b.id, b]));
  const levelById = Object.fromEntries(META.levels.map((l) => [String(l.id), l]));

  const keyFromHref = (href) => {
    const m = (href || "").match(/([a-z-]+\/[a-z0-9-]+)\.html/i);
    return m ? m[1].toLowerCase() : null;
  };
  const overlaps = (m, band) => m[0] <= band.max && m[1] >= band.min;
  const lessonMatches = (m, st) =>
    (!st.grade || overlaps(m, bandById[st.grade])) && (!st.level || m[2] === Number(st.level));

  function readState() {
    let st = { grade: "", level: "" };
    try { Object.assign(st, JSON.parse(localStorage.getItem(STORE) || "{}")); } catch (e) {}
    const q = new URLSearchParams(location.search);
    if (q.has("grade") || q.has("level")) st = { grade: q.get("grade") || "", level: q.get("level") || "" };
    if (!bandById[st.grade]) st.grade = "";
    if (!levelById[st.level]) st.level = "";
    return st;
  }
  function saveState(st) {
    try { localStorage.setItem(STORE, JSON.stringify(st)); } catch (e) {}
    const q = new URLSearchParams(location.search);
    st.grade ? q.set("grade", st.grade) : q.delete("grade");
    st.level ? q.set("level", st.level) : q.delete("level");
    const s = q.toString();
    try { history.replaceState(null, "", location.pathname + (s ? "?" + s : "") + location.hash); } catch (e) {}
  }

  const gradeText = (min, max) => (min === max ? `Grade ${min}` : max >= 13 ? `Grades ${min}+` : `Grades ${min}–${max}`);

  function pillGroup(label, items, current, onPick) {
    const row = document.createElement("div");
    row.className = "gf-row";
    row.setAttribute("role", "group");
    row.setAttribute("aria-label", label);
    row.innerHTML = `<span class="gf-label">${label}</span><div class="gf-pills"></div>`;
    const box = row.querySelector(".gf-pills");
    const all = [{ id: "", label: "All" }].concat(items);
    all.forEach((it) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "gf-pill";
      b.dataset.id = String(it.id);
      b.textContent = it.short || it.label;
      b.setAttribute("aria-pressed", String(String(it.id) === String(current)));
      b.addEventListener("click", () => onPick(String(it.id)));
      box.appendChild(b);
    });
    return row;
  }

  document.addEventListener("DOMContentLoaded", () => {
    const track = document.querySelector(".roadmap-track");
    if (!track) return;
    const nodes = Array.from(track.querySelectorAll(".topic-node"));

    // 1) Collect lessons per card + add badges
    const info = nodes.map((node) => {
      const links = Array.from(node.querySelectorAll("a[href]")).concat(node.matches("a[href]") ? [node] : []);
      const lessons = links.map((a) => ({ a, m: META.lessons[keyFromHref(a.getAttribute("href"))] })).filter((x) => x.m);
      if (lessons.length) {
        const min = Math.min(...lessons.map((x) => x.m[0]));
        const max = Math.max(...lessons.map((x) => x.m[1]));
        const lo = Math.min(...lessons.map((x) => x.m[2]));
        const hi = Math.max(...lessons.map((x) => x.m[2]));
        const badges = document.createElement("div");
        badges.className = "gf-badges";
        const lv = lo === hi ? levelById[lo].label : `${levelById[lo].label}–${levelById[hi].label}`;
        badges.innerHTML = `<span class="gf-badge">${gradeText(min, max)}</span><span class="gf-badge lv-${hi}">${lv}</span>`;
        const h3 = node.querySelector("h3");
        if (h3) node.insertBefore(badges, h3);
      }
      return { node, lessons };
    });

    // 2) Build the bar
    const st = readState();
    const bar = document.createElement("div");
    bar.className = "gf-bar";
    bar.setAttribute("role", "region");
    bar.setAttribute("aria-label", "Filter topics by grade and level");
    const foot = document.createElement("div");
    foot.className = "gf-foot";
    foot.innerHTML = `<span class="gf-count" aria-live="polite"></span><button type="button" class="gf-reset" hidden>Clear filters</button>`;
    const count = foot.querySelector(".gf-count");
    const reset = foot.querySelector(".gf-reset");
    const empty = document.createElement("div");
    empty.className = "gf-empty";
    empty.hidden = true;
    empty.textContent = "No topics match these filters yet — try a different grade or level.";

    let gradeRow, levelRow;
    const sync = (row, val) => row.querySelectorAll(".gf-pill").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.id === val)));

    function apply() {
      const active = !!(st.grade || st.level);
      track.classList.toggle("is-filtering", active);
      let shown = 0, total = 0;
      info.forEach(({ node, lessons }) => {
        const isLesson = lessons.length > 0;
        if (isLesson) total++;
        let visible = true;
        if (active) visible = isLesson && lessons.some((x) => lessonMatches(x.m, st));
        node.classList.toggle("gf-hide", !visible);
        if (visible && isLesson) shown++;
        lessons.forEach((x) => x.a !== node && x.a.classList.toggle("gf-dim", active && !lessonMatches(x.m, st)));
      });
      count.textContent = active ? `Showing ${shown} of ${total} topics` : `${total} topics`;
      reset.hidden = !active;
      empty.hidden = !(active && shown === 0);
      sync(gradeRow, st.grade);
      sync(levelRow, st.level);
      saveState(st);
    }

    gradeRow = pillGroup("Grade", META.bands, st.grade, (v) => { st.grade = v; apply(); });
    levelRow = pillGroup("Level", META.levels, st.level, (v) => { st.level = v; apply(); });
    reset.addEventListener("click", () => { st.grade = ""; st.level = ""; apply(); });

    bar.append(gradeRow, levelRow, foot);
    track.parentNode.insertBefore(bar, track);
    track.parentNode.insertBefore(empty, track.nextSibling);
    apply();
  });
})();
