// Curio Lab — text helpers for the practice tools.
// Pure functions (no DOM, no storage) so they can be unit-tested in Node:
//   answer matching with typo tolerance, "blank out the key word" cloze building,
//   keyword extraction for Explain It, and masking a term inside its own definition.
(function (root) {
  "use strict";

  const STOP = new Set(("a about above after again all also am an and any are as at be because been before being below between both but by can could did do does doing down during each few for from further had has have having he her here hers him his how i if in into is it its itself just me more most my no nor not now of off on once only or other our out over own same she should so some such than that the their them then there these they this those through to too under until up us very was we were what when where which while who whom why will with would you your usually often called known based makes make made using used use uses may might many much like within without across along among around become becomes being between certain commonly especially generally mainly typically often sometimes usually something another process thing things refers refer amount type types form forms kind way ways part parts called named example examples such including include includes").split(/\s+/));

  const EMOJI_LEAD = /^(?:[\p{Extended_Pictographic}\p{Regional_Indicator}️‍\s])+/u;
  const bare = (t) => String(t == null ? "" : t).replace(EMOJI_LEAD, "").trim();

  // lower-case, no accents, no punctuation, single spaces, no leading article
  function norm(s) {
    return String(s == null ? "" : s)
      .normalize("NFD").replace(/[̀-ͯ]/g, "")
      .toLowerCase()
      .replace(/&/g, " and ")
      .replace(/[’‘`']/g, "")
      .replace(/(\d),(?=\d{3}\b)/g, "$1")             // 20,000 -> 20000
      .replace(/[^a-z0-9Ͱ-Ͽ.\s]/g, " ")      // keep digits, greek letters (θ) and decimal points
      .replace(/(?<![0-9])\.|\.(?![0-9])/g, " ")      // drop full stops that are not decimal points
      .replace(/\s+/g, " ").trim()
      .replace(/^(the|a|an) /, "");
  }

  function levenshtein(a, b) {
    if (a === b) return 0;
    if (!a.length) return b.length;
    if (!b.length) return a.length;
    let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) {
      const cur = [i];
      for (let j = 1; j <= b.length; j++) {
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      }
      prev = cur;
    }
    return prev[b.length];
  }

  const tolerance = (len) => (len <= 4 ? 0 : len <= 8 ? 1 : len <= 14 ? 2 : 3);
  const singular = (s) => s.replace(/(?<=[a-z]{3})(ies)$/, "y").replace(/(?<=[a-z]{3})(es|s)$/, "");

  // Every way a learner might reasonably write a card's term.
  //   "Endoplasmic Reticulum (ER)"  -> endoplasmic reticulum | er
  //   "Doppelgänger / Double"       -> doppelganger | double
  //   "Sine (sin θ)"                -> sine | sin θ
  function termVariants(term) {
    const raw = bare(term);
    const out = new Set();
    const add = (s) => { const n = norm(s); if (n) out.add(n); };
    add(raw);
    const main = raw.replace(/\s*\([^)]*\)/g, "").trim();
    add(main);
    (raw.match(/\(([^)]*)\)/g) || []).forEach((p) => add(p.slice(1, -1)));
    main.split(/\s+\/\s+|\s+or\s+/i).forEach(add);
    return [...out];
  }

  // -> { ok, close, answer } ; ok = accepted (exact or within typo tolerance), close = accepted but misspelt
  function check(input, variants) {
    const n = norm(input);
    if (!n) return { ok: false, close: false, empty: true };
    for (const v of variants) {
      if (n === v) return { ok: true, close: false, answer: v };
    }
    for (const v of variants) {
      if (singular(n) === singular(v)) return { ok: true, close: false, answer: v };
    }
    let best = null;
    for (const v of variants) {
      const d = levenshtein(n, v);
      if (d <= tolerance(v.length) && (best === null || d < best.d)) best = { d, v };
    }
    if (best) return { ok: true, close: true, answer: best.v };
    return { ok: false, close: false };
  }

  const tokens = (s) => (norm(s).match(/[a-z0-9Ͱ-Ͽ][a-z0-9Ͱ-Ͽ.-]*/g) || []).map((t) => t.replace(/[.-]+$/, ""));
  const stemOf = (w) => w.slice(0, Math.min(w.length, 6));

  // Hide the term (and close relatives) inside its own definition so it can't give the answer away.
  function maskTerm(def, term) {
    let out = String(def);
    tokens(bare(term)).filter((t) => t.length >= 4 && !STOP.has(t)).forEach((t) => {
      const stem = t.slice(0, Math.max(4, t.length - 2)).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      out = out.replace(new RegExp("\\b" + stem + "[a-z]*", "gi"), "_____");
    });
    return out;
  }

  // Document frequency of every content word across a pool of definitions (for "how key is this word?").
  function buildIdf(defs) {
    const df = Object.create(null);
    defs.forEach((d) => { new Set(tokens(d)).forEach((w) => { df[w] = (df[w] || 0) + 1; }); });
    const N = Math.max(1, defs.length);
    return (w) => Math.log((N + 1) / (1 + (df[w] || 0)));
  }

  const isNumber = (w) => /^\d[\d.]*$/.test(w);

  function rankWords(def, term, idf) {
    const termStems = new Set(tokens(bare(term)).map(stemOf));
    const seen = new Set();
    const list = [];
    const re = /\d[\d,]*(?:\.\d+)?|[A-Za-z][A-Za-z'’-]*[A-Za-z]/g;
    let m;
    while ((m = re.exec(def))) {
      const surface = m[0].replace(/['’]s$/i, "");
      const w = norm(surface);
      if (!w || seen.has(w)) continue;
      const num = isNumber(w);
      if (!num && (w.length < 5 || STOP.has(w))) continue;
      if (num && w.replace(/\./g, "").length < 2) continue;      // lone digits make poor blanks
      if (!num && termStems.has(stemOf(w))) continue;            // the term is shown, so it is not a useful blank
      seen.add(w);
      let score = (num ? 3.2 : idf(w)) * Math.min(w.length, 10);
      // Nouns and names make the best blanks; verbs/adverbs/adjectives and hyphenated words are ambiguous to type.
      if (!num && /(?:ing|ly|ed|ive|ful|ous)$/.test(w)) score *= 0.5;
      if (/-/.test(surface)) score *= 0.45;
      if (!num && m.index > 0 && /^[A-Z]/.test(surface) && !/[.!?]\s*$/.test(def.slice(0, m.index))) score *= 1.4;
      list.push({ surface, w, index: m.index, score, num });
    }
    return list.sort((a, b) => b.score - a.score);
  }

  // One key word blanked out of a definition. Returns null when no good blank exists.
  function buildCloze(def, term, idf, pick) {
    const ranked = rankWords(def, term, idf);
    if (!ranked.length) return null;
    const top = ranked.slice(0, Math.min(3, ranked.length));
    const chosen = top[Math.min(top.length - 1, Math.floor((pick == null ? 0 : pick) * top.length))];
    return {
      before: def.slice(0, chosen.index),
      after: def.slice(chosen.index + chosen.surface.length),
      answer: chosen.surface,
      variants: [chosen.w],
      length: chosen.surface.length,
      hint: chosen.surface[0],
    };
  }

  // Cloze answers are single words, so inflections ("reflected" for "reflect") count as close.
  function checkWord(input, answer) {
    const v = norm(answer);
    const r = check(input, [v]);
    if (r.ok) return r;
    const n = norm(input);
    if (n && v && Math.min(n.length, v.length) >= 5 && n.slice(0, 5) === v.slice(0, 5) && Math.abs(n.length - v.length) <= 3) return { ok: true, close: true, answer: v };
    return { ok: false, close: false };
  }

  // The handful of words a good answer to "explain this term" should contain.
  function keywords(def, term, idf, max) {
    const out = [];
    const seen = new Set();
    rankWords(def, term, idf).forEach((r) => {
      if (r.num) return;
      const s = stemOf(r.w);
      if (seen.has(s)) return;
      seen.add(s);
      out.push({ word: r.surface.toLowerCase(), stem: s });
    });
    return out.slice(0, max || 5);
  }

  function coverage(answer, kws) {
    const text = " " + norm(answer) + " ";
    const hit = kws.map((k) => ({ ...k, found: text.indexOf(" " + k.stem) !== -1 }));
    return { hit, found: hit.filter((h) => h.found).length, total: kws.length };
  }

  const api = { norm, levenshtein, termVariants, check, checkWord, maskTerm, buildIdf, buildCloze, keywords, coverage, bare, STOP };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.CurioPracticeText = api;
})(typeof window !== "undefined" ? window : globalThis);
