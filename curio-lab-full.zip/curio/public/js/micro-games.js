// Curio Lab — Advanced Game-Fi Micro-Learning System
//
// Two embeddable mini-games, both driven entirely by JSON blocks placed
// inline in lesson content (works inside about-block paragraphs, extension
// customHtml, or hand-authored static pages — anywhere the DOM ends up with
// these markers, before or after window.onLessonContentReady fires):
//
//   SORT GAME
//   <div class="microgame-sort" data-microgame-sort="mg1"></div>
//   <script type="application/json" data-microgame-config="mg1">
//     { "title": "Order the reaction steps", "items": [
//         { "id": "1", "label": "Reactants collide" },
//         { "id": "2", "label": "Activation energy is absorbed" },
//         { "id": "3", "label": "Bonds break, transition state forms" },
//         { "id": "4", "label": "New bonds form into products" } ],
//       "correctOrder": ["1","2","3","4"] }
//   <\/script>
//
//   TERM MATCHER
//   <div class="microgame-match" data-microgame-match="mg2"></div>
//   <script type="application/json" data-microgame-config="mg2">
//     { "title": "Match the command to its function", "pairs": [
//         { "term": "for", "def": "Repeats a block a fixed number of times" },
//         { "term": "if", "def": "Runs a block only when a condition is true" } ] }
//   <\/script>
//
// Wins/streaks call window.CurioToast.show(...) when present, and increment
// a persistent streak counter shared across every mini-game on the site.
(function () {
  "use strict";

  const STYLE_ID = "curio-microgames-styles";
  const STREAK_KEY = "curiolab-microgame-streak";

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .microgame-shell {
        border: 1px solid var(--color-line);
        border-radius: var(--radius-md, 12px);
        background: var(--color-surface);
        box-shadow: var(--shadow-card);
        padding: 1.1rem 1.2rem 1.3rem;
        margin: 1rem 0;
      }
      .microgame-title { font-family: var(--font-display); font-size: 1.05rem; margin: 0 0 0.15rem; }
      .microgame-sub { color: var(--color-ink-soft); font-size: 0.82rem; margin: 0 0 0.9rem; }

      /* ---- Sort game ---- */
      .mg-sort-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 8px; }
      .mg-sort-item {
        display: flex; align-items: center; gap: 10px;
        padding: 0.65rem 0.8rem; border-radius: var(--radius-sm, 8px);
        background: var(--color-bg-alt); border: 1.5px solid var(--color-line);
        cursor: grab; user-select: none; touch-action: none;
        transition: box-shadow 160ms var(--ease-standard, ease), border-color 160ms, transform 160ms;
        font-size: 0.92rem;
      }
      .mg-sort-item:active { cursor: grabbing; }
      .mg-sort-item.dragging { box-shadow: var(--shadow-lift); border-color: var(--accent); z-index: 5; opacity: 0.95; }
      .mg-sort-item .mg-handle { color: var(--color-ink-soft); font-size: 1rem; line-height: 1; }
      .mg-sort-item.correct { border-color: var(--color-moss); background: color-mix(in srgb, var(--color-moss) 12%, var(--color-surface)); }
      .mg-sort-item.incorrect { border-color: var(--color-coral); background: color-mix(in srgb, var(--color-coral) 12%, var(--color-surface)); }
      .mg-sort-item.placeholder { opacity: 0.35; border-style: dashed; }
      .mg-actions { display: flex; gap: 0.6rem; margin-top: 1rem; align-items: center; flex-wrap: wrap; }
      .mg-btn {
        border: 1px solid var(--color-line-strong); background: var(--color-bg);
        color: var(--color-ink); padding: 0.5rem 1rem; border-radius: 999px;
        font-size: 0.82rem; cursor: pointer; font-weight: 600;
        transition: transform 140ms, border-color 140ms;
      }
      .mg-btn:hover { border-color: var(--accent); transform: translateY(-1px); }
      .mg-btn.primary { background: var(--accent); color: var(--color-surface); border-color: transparent; }
      .mg-feedback { font-size: 0.85rem; font-weight: 600; }
      .mg-feedback.win { color: var(--color-moss); }
      .mg-feedback.lose { color: var(--color-coral); }

      /* ---- Match game ---- */
      .mg-match-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0.6rem 1rem; }
      @media (max-width: 560px) { .mg-match-grid { grid-template-columns: 1fr; } }
      .mg-card {
        padding: 0.7rem 0.85rem; border-radius: var(--radius-sm, 8px);
        border: 1.5px solid var(--color-line); background: var(--color-bg-alt);
        cursor: pointer; font-size: 0.88rem; text-align: left;
        transition: border-color 140ms, transform 140ms, background 140ms;
      }
      .mg-card:hover { border-color: var(--accent); }
      .mg-card.selected { border-color: var(--accent); box-shadow: 0 0 0 2px color-mix(in srgb, var(--accent) 30%, transparent); }
      .mg-card.matched { border-color: var(--color-moss); background: color-mix(in srgb, var(--color-moss) 14%, var(--color-surface)); opacity: 0.7; cursor: default; }
      .mg-card.shake { animation: mg-shake 350ms; border-color: var(--color-coral); }
      @keyframes mg-shake {
        10%, 90% { transform: translateX(-2px); } 20%, 80% { transform: translateX(3px); }
        30%, 50%, 70% { transform: translateX(-5px); } 40%, 60% { transform: translateX(5px); }
      }
      .mg-streak-pill {
        display: inline-flex; align-items: center; gap: 4px;
        font-family: var(--font-mono); font-size: 0.76rem;
        background: var(--color-bg-alt); border-radius: 999px; padding: 0.2rem 0.6rem;
        color: var(--color-ink-soft);
      }
      @media (prefers-reduced-motion: reduce) {
        .mg-sort-item, .mg-card, .mg-btn { transition: none; }
      }
    `;
    document.head.appendChild(style);
  }

  function escapeHtml(str) {
    return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  // --- Shared streak tracker, feeds the global toast + achievements ------
  function readStreak() {
    try { return JSON.parse(localStorage.getItem(STREAK_KEY)) || { current: 0, best: 0 }; }
    catch (e) { return { current: 0, best: 0 }; }
  }
  function writeStreak(s) { localStorage.setItem(STREAK_KEY, JSON.stringify(s)); }

  function registerWin(gameLabel) {
    const s = readStreak();
    s.current += 1;
    s.best = Math.max(s.best, s.current);
    writeStreak(s);
    if (window.CurioToast) {
      if (s.current > 0 && s.current % 5 === 0) {
        window.CurioToast.show(`🔥 ${s.current}-win streak across mini-games!`, { type: "trophy", icon: "🔥", duration: 5000 });
      } else {
        window.CurioToast.show(`Nice — ${gameLabel} solved!`, { icon: "🎮" });
      }
    }
    if (window.CurioAchievements && typeof window.CurioAchievements.notifyMicrogameWin === "function") {
      window.CurioAchievements.notifyMicrogameWin(s.current);
    }
    return s;
  }
  function registerLoss() {
    const s = readStreak();
    s.current = 0;
    writeStreak(s);
    return s;
  }

  function streakPillHtml() {
    const s = readStreak();
    return `<span class="mg-streak-pill">🔥 <span data-mg-streak-val>${s.current}</span> streak · best ${s.best}</span>`;
  }

  // --- Drag-and-drop sort game -------------------------------------------
  // Pointer-events based (not native HTML5 DnD) so it works identically on
  // touch and mouse without the flakiness of dragstart/dragover on mobile.
  function buildSortGame(container, config) {
    const items = shuffle(config.items || []);
    const correctOrder = config.correctOrder || (config.items || []).map((i) => i.id);

    container.classList.add("microgame-shell", "microgame-sort-shell");
    container.innerHTML = `
      <p class="microgame-title">🧩 ${escapeHtml(config.title || "Put it in order")}</p>
      <p class="microgame-sub">Drag the cards into the correct sequence, then check your answer. ${streakPillHtml()}</p>
      <ol class="mg-sort-list" data-mg-sort-list></ol>
      <div class="mg-actions">
        <button type="button" class="mg-btn primary" data-mg-check>Check order</button>
        <button type="button" class="mg-btn" data-mg-shuffle>Shuffle again</button>
        <span class="mg-feedback" data-mg-feedback></span>
      </div>`;

    const list = container.querySelector("[data-mg-sort-list]");
    const feedback = container.querySelector("[data-mg-feedback]");

    function renderItems(order) {
      list.innerHTML = "";
      order.forEach((item) => {
        const li = document.createElement("li");
        li.className = "mg-sort-item";
        li.dataset.id = item.id;
        li.innerHTML = `<span class="mg-handle">⠿</span><span>${escapeHtml(item.label)}</span>`;
        list.appendChild(li);
      });
    }
    renderItems(items);

    let dragEl = null;
    let placeholder = null;

    list.addEventListener("pointerdown", (ev) => {
      const item = ev.target.closest(".mg-sort-item");
      if (!item) return;
      window.CurioSound && window.CurioSound.play("flip");
      dragEl = item;
      dragEl.setPointerCapture(ev.pointerId);
      dragEl.classList.add("dragging");
      placeholder = document.createElement("li");
      placeholder.className = "mg-sort-item placeholder";
      placeholder.style.height = `${dragEl.offsetHeight}px`;
      dragEl.after(placeholder);
      dragEl.style.position = "fixed";
      dragEl.style.width = `${dragEl.offsetWidth}px`;
      dragEl.style.zIndex = "50";
      moveDrag(ev);
    });

    function moveDrag(ev) {
      if (!dragEl) return;
      const rect = list.getBoundingClientRect();
      dragEl.style.left = `${Math.min(Math.max(ev.clientX - dragEl.offsetWidth / 2, rect.left), rect.right - dragEl.offsetWidth)}px`;
      dragEl.style.top = `${ev.clientY - dragEl.offsetHeight / 2}px`;

      const siblings = [...list.querySelectorAll(".mg-sort-item:not(.dragging)")];
      const after = siblings.find((sib) => {
        const r = sib.getBoundingClientRect();
        return ev.clientY < r.top + r.height / 2;
      });
      if (after) list.insertBefore(placeholder, after);
      else list.appendChild(placeholder);
    }

    list.addEventListener("pointermove", moveDrag);

    function endDrag() {
      if (!dragEl) return;
      dragEl.style.position = "";
      dragEl.style.left = "";
      dragEl.style.top = "";
      dragEl.style.width = "";
      dragEl.style.zIndex = "";
      dragEl.classList.remove("dragging");
      placeholder.replaceWith(dragEl);
      placeholder = null;
      dragEl = null;
    }
    list.addEventListener("pointerup", endDrag);
    list.addEventListener("pointercancel", endDrag);

    container.querySelector("[data-mg-shuffle]").addEventListener("click", () => {
      renderItems(shuffle(config.items || []));
      feedback.textContent = "";
      feedback.className = "mg-feedback";
    });

    container.querySelector("[data-mg-check]").addEventListener("click", () => {
      const current = [...list.children].map((li) => li.dataset.id);
      let allCorrect = true;
      current.forEach((id, i) => {
        const li = list.children[i];
        const isRight = id === correctOrder[i];
        li.classList.remove("correct", "incorrect");
        li.classList.add(isRight ? "correct" : "incorrect");
        if (!isRight) allCorrect = false;
      });
      if (allCorrect) {
        feedback.textContent = "✅ Perfect order!";
        feedback.className = "mg-feedback win";
        window.CurioSound && window.CurioSound.play("matchCorrect");
        const s = registerWin(config.title || "sort game");
        updateStreakPill(container, s);
      } else {
        feedback.textContent = "Not quite — re-check the highlighted cards.";
        feedback.className = "mg-feedback lose";
        window.CurioSound && window.CurioSound.play("matchIncorrect");
        const s = registerLoss();
        updateStreakPill(container, s);
      }
    });
  }

  function updateStreakPill(container, s) {
    const el = container.querySelector("[data-mg-streak-val]");
    if (el) el.textContent = s.current;
  }

  // --- Term matcher --------------------------------------------------------
  function buildMatchGame(container, config) {
    const pairs = config.pairs || [];
    const termCards = shuffle(pairs.map((p, i) => ({ kind: "term", text: p.term, pairIndex: i })));
    const defCards = shuffle(pairs.map((p, i) => ({ kind: "def", text: p.def, pairIndex: i })));

    container.classList.add("microgame-shell", "microgame-match-shell");
    container.innerHTML = `
      <p class="microgame-title">🃏 ${escapeHtml(config.title || "Match the pairs")}</p>
      <p class="microgame-sub">Select a term, then its matching definition. ${streakPillHtml()}</p>
      <div class="mg-match-grid">
        <div class="mg-match-col" data-mg-terms></div>
        <div class="mg-match-col" data-mg-defs></div>
      </div>
      <div class="mg-actions">
        <span class="mg-feedback" data-mg-feedback></span>
      </div>`;

    const termsCol = container.querySelector("[data-mg-terms]");
    const defsCol = container.querySelector("[data-mg-defs]");
    const feedback = container.querySelector("[data-mg-feedback]");

    function makeCard(card) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "mg-card";
      btn.textContent = card.text;
      btn.dataset.pairIndex = card.pairIndex;
      btn.dataset.kind = card.kind;
      return btn;
    }
    termCards.forEach((c) => termsCol.appendChild(makeCard(c)));
    defCards.forEach((c) => defsCol.appendChild(makeCard(c)));

    let selectedTerm = null;
    let matchedCount = 0;
    let mistakesThisRound = 0;

    function handleClick(ev) {
      const btn = ev.target.closest(".mg-card");
      if (!btn || btn.classList.contains("matched")) return;
      const kind = btn.dataset.kind;

      if (kind === "term") {
        termsCol.querySelectorAll(".mg-card").forEach((c) => c.classList.remove("selected"));
        btn.classList.add("selected");
        window.CurioSound && window.CurioSound.play("flip");
        selectedTerm = btn;
        return;
      }
      if (kind === "def" && selectedTerm) {
        const isMatch = selectedTerm.dataset.pairIndex === btn.dataset.pairIndex;
        if (isMatch) {
          selectedTerm.classList.remove("selected");
          selectedTerm.classList.add("matched");
          btn.classList.add("matched");
          window.CurioSound && window.CurioSound.play("matchCorrect");
          selectedTerm = null;
          matchedCount += 1;
          if (matchedCount === pairs.length) {
            const perfect = mistakesThisRound === 0;
            feedback.textContent = perfect ? "✅ Perfect match — no mistakes!" : `✅ All matched (${mistakesThisRound} miss${mistakesThisRound === 1 ? "" : "es"}).`;
            feedback.className = "mg-feedback win";
            const s = registerWin(config.title || "term matcher");
            updateStreakPill(container, s);
          }
        } else {
          btn.classList.add("shake");
          selectedTerm.classList.add("shake");
          window.CurioSound && window.CurioSound.play("matchIncorrect");
          mistakesThisRound += 1;
          setTimeout(() => {
            btn.classList.remove("shake");
            selectedTerm && selectedTerm.classList.remove("shake", "selected");
            selectedTerm = null;
          }, 350);
        }
      }
    }
    termsCol.addEventListener("click", handleClick);
    defsCol.addEventListener("click", handleClick);
  }

  function initAll() {
    document.querySelectorAll("[data-microgame-sort]").forEach((container) => {
      if (container.dataset.mgInitialized) return;
      const id = container.getAttribute("data-microgame-sort");
      const cfgScript = document.querySelector(`script[data-microgame-config="${CSS.escape(id)}"]`);
      if (!cfgScript) return;
      let config;
      try { config = JSON.parse(cfgScript.textContent); } catch (err) {
        console.error("[micro-games] invalid sort config", id, err);
        return;
      }
      container.dataset.mgInitialized = "true";
      injectStyles();
      buildSortGame(container, config);
    });

    document.querySelectorAll("[data-microgame-match]").forEach((container) => {
      if (container.dataset.mgInitialized) return;
      const id = container.getAttribute("data-microgame-match");
      const cfgScript = document.querySelector(`script[data-microgame-config="${CSS.escape(id)}"]`);
      if (!cfgScript) return;
      let config;
      try { config = JSON.parse(cfgScript.textContent); } catch (err) {
        console.error("[micro-games] invalid match config", id, err);
        return;
      }
      container.dataset.mgInitialized = "true";
      injectStyles();
      buildMatchGame(container, config);
    });
  }

  window.CurioMicroGames = {
    init: initAll,
    getStreak: readStreak,
  };

  if (window.onLessonContentReady) {
    window.onLessonContentReady(initAll);
  } else if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initAll, { once: true });
  } else {
    initAll();
  }
})();
