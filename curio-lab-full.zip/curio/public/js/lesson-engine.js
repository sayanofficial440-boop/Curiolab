// Curio Lab — Dynamic Lesson Engine
//
// Replaces one hand-written HTML file per lesson with a single template
// (pages/lesson.html) plus one small JSON file per lesson under
// data/lessons/<subject>/<slug>.json. This is the piece that makes the
// platform scale: adding a lesson becomes "add a JSON file", not "hand-author
// 400 lines of HTML and remember to wire up nine <script> tags correctly."
//
// WHY PER-LESSON JSON FILES INSTEAD OF ONE GIANT PAYLOAD:
// A single "all lessons" JSON blob would mean every visitor downloads every
// subject's content just to read one lesson — the opposite of scaling to
// millions of users. Splitting by lesson means: each file is tiny and cached
// independently by the CDN/browser, a typo in one lesson can't break every
// other lesson's build, and lessons can be added/edited without touching a
// shared file (no merge conflicts between content authors).
//
// WHY ZERO CLS:
// pages/lesson.html ships a skeleton with the same approximate footprint as
// the real hero/tabs/panel. We only ever *replace* content, never insert
// blocks above content the user may already be reading, and every
// interactive canvas re-uses the same fixed aspect-ratio boxes the static
// pages already used (see css/lesson.css .model-canvas).
(function () {
  "use strict";

  const params = new URLSearchParams(window.location.search);
  const subject = params.get("subject");
  const lessonSlug = params.get("lesson");
  const root = document.getElementById("lesson-root");
  const backLinkWrap = document.getElementById("lesson-back-link");

  if (!subject || !lessonSlug) {
    renderFatalError("This lesson link is missing ?subject= and ?lesson= parameters.");
    return;
  }

  const JSON_URL = `../data/lessons/${encodeURIComponent(subject)}/${encodeURIComponent(lessonSlug)}.json`;

  fetch(JSON_URL)
    .then((res) => {
      if (!res.ok) throw new Error(`Lesson not found (HTTP ${res.status})`);
      return res.json();
    })
    .then((lesson) => renderLesson(lesson))
    .catch((err) => renderFatalError(err.message));

  // ---------------------------------------------------------------------
  // Rendering
  // ---------------------------------------------------------------------

  function renderLesson(lesson) {
    document.title = `${lesson.meta.title} — Curio Lab ${lesson.meta.subjectLabel}`;
    document.body.style.setProperty("--accent", `var(${lesson.meta.accentVar || "--color-teal"})`);
    markActiveSubjectNav(lesson.meta.subject);

    root.innerHTML = buildHeroAndTabs(lesson);
    const panelsWrap = document.createElement("div");
    panelsWrap.className = "wrap";
    panelsWrap.id = "lesson-panels";
    root.appendChild(panelsWrap);

    const coreOrder = ["about", "video", "audio", "cards", "slides", "quiz"];
    const extByPanelId = new Map((lesson.extensions || []).map((e) => [e.panelId, e]));

    (lesson.tabs || []).forEach((tab) => {
      let panelEl;
      if (coreOrder.includes(tab.id)) {
        panelEl = buildCorePanel(tab.id, lesson);
      } else if (extByPanelId.has(tab.id)) {
        panelEl = buildExtensionPanel(extByPanelId.get(tab.id));
      }
      if (panelEl) panelsWrap.appendChild(panelEl);
    });

    if (backLinkWrap) {
      backLinkWrap.innerHTML = `<a class="back-home" href="${escapeAttr(lesson.meta.subjectIndexHref || "#")}">&larr; Back to ${escapeHtml(lesson.meta.subjectLabel || "")}</a>`;
    }

    populateCoach(lesson);
    loadExtensionScripts(lesson).finally(() => {
      // Every module below this point is patched to call
      // window.onLessonContentReady(...) — this is the one call that fires
      // all of them, in registration order, exactly once.
      window.dispatchLessonReady();
    });
  }

  function buildHeroAndTabs(lesson) {
    const crumb = (lesson.meta.breadcrumb || [])
      .map((c, i, arr) => (i === arr.length - 1 ? escapeHtml(c) : `<a href="${escapeAttr(lesson.meta.subjectIndexHref || "#")}">${escapeHtml(c)}</a>`))
      .join(" / ");

    const tabsHtml = (lesson.tabs || [])
      .map(
        (t, i) =>
          `<button class="mode-tab${i === 0 ? " active" : ""}" data-tab="${escapeAttr(t.id)}" type="button">${t.icon || ""} ${escapeHtml(t.label)}</button>`
      )
      .join("");

    return `
      <section class="lesson-hero">
        <div class="wrap">
          <p class="crumb">${crumb}</p>
          <div class="lesson-hero-top">
            <div>
              <h1>${escapeHtml(lesson.meta.title)}</h1>
              <p>${escapeHtml(lesson.meta.summary || "")}</p>
              <div class="score-badge" data-score-badge>🏆 No attempts yet — take the quiz to start your scoreboard.</div>
            </div>
            <div class="timer-widget">
              <p class="eyebrow">Smart Study Timer</p>
              <div class="timer-display" data-timer-display>25:00</div>
              <div class="timer-controls">
                <button class="timer-btn" data-timer-start type="button">Start</button>
                <button class="timer-btn" data-timer-reset type="button">Reset</button>
              </div>
              <div class="timer-modes">
                <button data-timer-mode="focus" class="active" type="button">Focus 25</button>
                <button data-timer-mode="short" type="button">Break 5</button>
                <button data-timer-mode="long" type="button">Long 15</button>
              </div>
            </div>
          </div>
          <nav class="mode-tabs" aria-label="Study modes">${tabsHtml}</nav>
        </div>
      </section>`;
  }

  function buildCorePanel(id, lesson) {
    const section = document.createElement("section");
    section.className = "mode-panel";
    section.dataset.panel = id;

    if (id === "about") {
      section.innerHTML = `<div class="about-grid">${(lesson.about?.blocks || []).map(renderAboutBlock).join("")}</div>`;
    } else if (id === "video") {
      const v = lesson.video || {};
      section.innerHTML = `
        <div class="video-frame">
          <iframe src="https://www.youtube-nocookie.com/embed/${escapeAttr(v.youtubeId)}" title="${escapeAttr(v.title || lesson.meta.title)}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe>
        </div>
        <p class="video-caption">${escapeHtml(v.caption || "")}</p>
        ${v.transcript ? `<div data-video-transcript>${String(v.transcript).split(/\n{2,}|\n/).filter(Boolean).map((l) => `<p>${escapeHtml(l)}</p>`).join("")}</div>` : ""}`;
    } else if (id === "audio") {
      section.innerHTML = `
        <div class="tts-panel">
          <div class="tts-controls">
            <button class="tts-play" data-tts-play type="button" aria-label="Play">▶</button>
            <div class="tts-rate">
              <span>Speed</span>
              <input type="range" min="0.6" max="1.6" step="0.1" value="1" data-tts-rate />
              <span data-tts-rate-label>1.0×</span>
            </div>
          </div>
          <p class="tts-text" data-tts-text>${escapeHtml(lesson.audio?.text || "")}</p>
        </div>`;
    } else if (id === "cards") {
      section.innerHTML = `
        <div class="cards-wrap">
          <div class="flashcard" data-flashcard>
            <div class="flashcard-inner">
              <div class="flashcard-face flashcard-front" data-card-front></div>
              <div class="flashcard-face flashcard-back" data-card-back></div>
            </div>
          </div>
          <div class="card-nav">
            <button data-card-prev type="button">← Prev</button>
            <span data-card-counter>1 / ${(lesson.cards || []).length}</span>
            <button data-card-next type="button">Next →</button>
          </div>
          <p style="font-size:0.82rem; color:var(--color-ink-soft);">Tap the card to flip it.</p>
        </div>
        <script type="application/json" data-card-deck>${JSON.stringify(lesson.cards || [])}<\/script>`;
    } else if (id === "slides") {
      section.innerHTML = `
        <div class="slide-frame" data-slide-frame>
          <p class="slide-eyebrow" data-slide-eyebrow>Slide 1 of ${(lesson.slides || []).length}</p>
          <h3 data-slide-title>—</h3>
          <p data-slide-body>—</p>
          <div class="slide-controls">
            <button class="timer-btn" data-slide-prev type="button">← Prev</button>
            <div class="slide-dots" data-slide-dots></div>
            <button class="timer-btn" data-slide-next type="button">Next →</button>
          </div>
        </div>
        <script type="application/json" data-slide-deck>${JSON.stringify(lesson.slides || [])}<\/script>`;
    } else if (id === "quiz") {
      section.innerHTML = `
        <div class="quiz-shell" data-quiz data-quiz-lesson="${escapeAttr(lesson.meta.title)}" data-quiz-subject="${escapeAttr(lesson.meta.subjectLabel)}">
          <div data-quiz-body>
            <p class="quiz-progress" data-quiz-progress>Question 1 of ${(lesson.quiz || []).length}</p>
            <p class="quiz-q" data-quiz-question>—</p>
            <div class="quiz-options" data-quiz-options></div>
            <button class="quiz-next" data-quiz-next type="button">Next question →</button>
          </div>
          <div class="quiz-result" data-quiz-result style="display:none;"></div>
        </div>
        <script type="application/json" data-quiz-data>${JSON.stringify(lesson.quiz || [])}<\/script>`;
    }
    return section;
  }

  function renderAboutBlock(block) {
    const paras = (block.paragraphs || []).map((p) => `<p>${p}</p>`).join("");
    const list = block.list ? `<ul>${block.list.map((li) => `<li>${li}</li>`).join("")}</ul>` : "";
    const parasAfter = (block.paragraphsAfterList || []).map((p) => `<p>${p}</p>`).join("");
    const listAfter = block.listAfter ? `<ul>${block.listAfter.map((li) => `<li>${li}</li>`).join("")}</ul>` : "";
    const facts = block.facts ? `<div class="about-facts">${block.facts.map((f) => `<span>${escapeHtml(f)}</span>`).join("")}</div>` : "";
    return `<div class="about-block"><h3>${escapeHtml(block.heading)}</h3>${paras}${list}${parasAfter}${listAfter}${facts}</div>`;
  }

  // Extension panels (model3d / projectile3d / graph2d / diagram) keep their
  // bespoke rendering logic in their own JS files rather than being forced
  // through the generic schema above — a hand-tuned 3D scene or force-graph
  // canvas doesn't gain anything from being "generic," and trying to model
  // every possible interactive visualization as JSON would make the schema
  // fragile. The engine's job here is just: build the right container +
  // controls, load the right script, and hand it lesson-specific config
  // through data-* attributes, the same contract the module already expects.
  function buildExtensionPanel(ext) {
    const section = document.createElement("section");
    section.className = "mode-panel";
    section.dataset.panel = ext.panelId;

    if (ext.type === "model3d") {
      const c = ext.config || {};
      section.innerHTML = `
        <div class="model-panel">
          <div class="model-canvas" data-model-canvas></div>
          <div class="model-controls">
            <label>Applied force
              <input type="range" min="${c.forceMin ?? 0}" max="${c.forceMax ?? 100}" value="${c.forceDefault ?? 40}" data-model-force />
              <span data-model-force-label>${c.forceDefault ?? 40} N</span>
            </label>
          </div>
          <p class="model-hint">${escapeHtml(ext.hint || "")}</p>
        </div>`;
    } else if (ext.type === "projectile3d") {
      const c = ext.config || {};
      section.innerHTML = `
        <div class="model-panel">
          <div class="model-canvas" data-projectile-canvas></div>
          <div class="model-controls">
            <label>Launch angle
              <input type="range" min="${c.angleMin ?? 10}" max="${c.angleMax ?? 80}" value="${c.angleDefault ?? 45}" data-projectile-angle />
              <span data-projectile-angle-label>${c.angleDefault ?? 45}°</span>
            </label>
            <label>Launch speed
              <input type="range" min="${c.speedMin ?? 5}" max="${c.speedMax ?? 25}" value="${c.speedDefault ?? 14}" data-projectile-speed />
              <span data-projectile-speed-label>${c.speedDefault ?? 14} m/s</span>
            </label>
            <button class="code-run" data-projectile-launch type="button">🚀 Launch</button>
          </div>
          <p class="model-readout" data-projectile-readout>—</p>
          <p class="model-hint">${escapeHtml(ext.hint || "")}</p>
        </div>`;
    } else if (ext.type === "graph2d") {
      const c = ext.config || {};
      section.innerHTML = `
        <div class="model-panel">
          <div class="model-canvas" data-force-graph-canvas></div>
          <div class="model-controls">
            <label>Object mass
              <input type="range" min="${c.massMin ?? 1}" max="${c.massMax ?? 10}" step="1" value="${c.massDefault ?? 2}" data-force-graph-mass />
              <span data-force-graph-mass-label>${c.massDefault ?? 2} kg</span>
            </label>
          </div>
          <p class="model-readout" data-force-graph-readout>—</p>
          <p class="model-hint">${escapeHtml(ext.hint || "")}</p>
        </div>`;
    } else if (ext.type === "diagram") {
      section.innerHTML = buildDiagramPanel(ext);
    } else if (ext.customHtml) {
      // Deliberate escape hatch for a one-off visualization that doesn't fit
      // any known extension type yet — used sparingly, never as the default.
      section.innerHTML = ext.customHtml;
    }
    return section;
  }

  // Fully data-driven free-body-diagram renderer: arrows + labels come
  // entirely from JSON, so a new diagram lesson never needs a line of code.
  function buildDiagramPanel(ext) {
    const d = ext.diagram || {};
    const arrows = (d.arrows || [])
      .map((a) => {
        const dx = a.x2 - a.x1;
        const dy = a.y2 - a.y1;
        const len = Math.hypot(dx, dy) || 1;
        const ux = dx / len;
        const uy = dy / len;
        // Arrowhead as a small triangle at the endpoint, perpendicular to the shaft.
        const headLen = 13;
        const px = -uy;
        const py = ux;
        const tipX = a.x2, tipY = a.y2;
        const baseX = a.x2 - ux * headLen, baseY = a.y2 - uy * headLen;
        const p1x = baseX + px * 6, p1y = baseY + py * 6;
        const p2x = baseX - px * 6, p2y = baseY - py * 6;
        const attrs = `data-annot data-device="${escapeAttr(a.device)}" data-note="${escapeAttr(a.note)}"`;
        return `
          <line ${attrs} x1="${a.x1}" y1="${a.y1}" x2="${baseX}" y2="${baseY}" stroke="${escapeAttr(a.color)}" stroke-width="4" style="cursor:pointer;"/>
          <polygon ${attrs} points="${tipX},${tipY} ${p1x},${p1y} ${p2x},${p2y}" fill="${escapeAttr(a.color)}" style="cursor:pointer;"/>`;
      })
      .join("");

    return `
      <div class="reader-layout">
        <div class="model-panel" style="background: var(--color-surface);">
          <svg viewBox="${escapeAttr(d.viewBox || "0 0 300 260")}" style="width:100%; height:auto; display:block;">
            ${d.ground ? `<line x1="${d.ground.x1}" y1="${d.ground.y1}" x2="${d.ground.x2}" y2="${d.ground.y2}" stroke="var(--color-line-strong)" stroke-width="2"/>` : ""}
            ${d.object ? `<rect x="${d.object.x}" y="${d.object.y}" width="${d.object.width}" height="${d.object.height}" fill="${escapeAttr(d.object.fill)}" stroke="var(--color-ink)" stroke-width="2"/>` : ""}
            ${arrows}
          </svg>
          <p class="model-hint">${escapeHtml(ext.hint || "")}</p>
        </div>
        <div class="analysis-card" data-analysis-card>
          <p class="analysis-hint">Click an arrow on the diagram to see the force explained here.</p>
        </div>
      </div>`;
  }

  function populateCoach(lesson) {
    const panel = document.querySelector("[data-coach-panel]");
    const responsesEl = document.querySelector("[data-coach-responses]");
    if (panel) {
      panel.dataset.coachTopic = lesson.coach?.topic || lesson.meta.title;
      // Read by js/ai-coach.js's buildLessonContext() so the AI Coach payload
      // carries real subject/difficulty without the student typing anything.
      panel.dataset.coachSubject = lesson.meta.subjectLabel || lesson.meta.subject || "";
      panel.dataset.coachDifficulty = lesson.meta.difficulty || "";
    }
    if (responsesEl) responsesEl.textContent = JSON.stringify(lesson.coach?.presetResponses || []);
  }

  function markActiveSubjectNav(subjectSlug) {
    document.querySelectorAll("[data-subject-link]").forEach((a) => {
      a.toggleAttribute("aria-current", a.dataset.subjectLink === subjectSlug);
      if (a.dataset.subjectLink === subjectSlug) a.setAttribute("aria-current", "page");
    });
  }

  // ---------------------------------------------------------------------
  // Extension script loading (only fetched for lessons that actually use
  // three.js / the 2D graph module — most lessons don't, so most visitors
  // never pay for that bundle).
  // ---------------------------------------------------------------------

  const loadedScripts = new Set();

  function loadScriptOnce(src) {
    if (loadedScripts.has(src) || document.querySelector(`script[src="${src}"]`)) {
      return Promise.resolve();
    }
    loadedScripts.add(src);
    return new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = src;
      s.onload = () => resolve();
      s.onerror = () => reject(new Error(`Failed to load ${src}`));
      document.body.appendChild(s);
    });
  }

  function loadExtensionScripts(lesson) {
    const exts = lesson.extensions || [];
    const needsThree = exts.some((e) => (e.requires || []).includes("three"));
    const chain = needsThree
      ? loadScriptOnce("https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js")
      : Promise.resolve();

    return chain.then(() => Promise.all(exts.filter((e) => e.script).map((e) => loadScriptOnce(`../${e.script}`))));
  }

  // ---------------------------------------------------------------------
  // Utilities
  // ---------------------------------------------------------------------

  function escapeHtml(str) {
    return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  // Note: About-block paragraphs/lists deliberately do NOT go through
  // escapeHtml — they contain trusted, author-written markup like <strong>
  // from our own JSON files in data/lessons/, not user input. Everything
  // that could ever contain a value typed by an end user (titles used in
  // attributes, device labels, hint text) is escaped.
  function escapeAttr(str) {
    return escapeHtml(str);
  }

  function renderFatalError(message) {
    root.innerHTML = `
      <section class="lesson-hero">
        <div class="wrap">
          <p class="crumb">Curio Lab</p>
          <h1>Lesson unavailable</h1>
          <p>${escapeHtml(message)}</p>
          <a class="back-home" href="../index.html">&larr; Back to home</a>
        </div>
      </section>`;
  }
})();
