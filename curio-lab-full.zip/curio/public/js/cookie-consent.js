/* Curio Lab — cookie & privacy consent (GDPR / ePrivacy)
 *
 * What it does
 *  - Shows a banner on first visit with equally prominent "Accept all", "Reject optional" and "Choose" buttons.
 *  - Stores the choice in localStorage ("curio.consent.v1") and asks again after 12 months or when CONSENT_VERSION changes.
 *  - Gates optional categories. Today that is: "media" (embedded YouTube videos). "analytics" exists as a switch
 *    for the future, but is only shown when window.CURIO_CONSENT_CONFIG = { analytics: true } is set before this script,
 *    because the site currently ships no analytics.
 *  - Any element with [data-cookie-settings] re-opens the preferences dialog (the footer has one).
 *  - Honors the browser's Global Privacy Control signal: optional categories stay off until the visitor opts in.
 *  - Provides "download my data" and "erase my data" helpers (GDPR access / portability / erasure) for the privacy page.
 *
 * Public API:  window.CurioConsent = { get(), has(category), open(), onChange(fn), exportData(), eraseData() }
 * Gate your own script:  CurioConsent.onChange(c => { if (c.analytics) loadAnalytics(); });
 */
(function () {
  "use strict";
  var KEY = "curio.consent.v1";
  var CONSENT_VERSION = 1;
  var MAX_AGE_MS = 365 * 24 * 3600 * 1000;
  var cfg = window.CURIO_CONSENT_CONFIG || {};
  var script = document.currentScript;
  var ROOT = script && script.src ? script.src.replace(/js\/cookie-consent\.js.*$/, "") : "/";
  var listeners = [];
  var gpc = !!(navigator.globalPrivacyControl);

  function read() {
    try {
      var raw = localStorage.getItem(KEY);
      if (!raw) return null;
      var c = JSON.parse(raw);
      if (!c || c.v !== CONSENT_VERSION || !c.ts || Date.now() - c.ts > MAX_AGE_MS) return null;
      return c;
    } catch (e) { return null; }
  }
  function write(choices) {
    var c = { v: CONSENT_VERSION, ts: Date.now(), media: !!choices.media, analytics: !!choices.analytics };
    try { localStorage.setItem(KEY, JSON.stringify(c)); } catch (e) { /* private mode: choice lasts for this page only */ memory = c; }
    memory = c;
    applyMedia();
    listeners.forEach(function (fn) { try { fn(api.get()); } catch (e) {} });
    document.dispatchEvent(new CustomEvent("curio:consent", { detail: api.get() }));
  }
  var memory = null;
  function current() { return memory || read(); }

  var api = {
    get: function () { var c = current(); return { essential: true, media: !!(c && c.media) && !(window.CurioAge && !window.CurioAge.allowed("media")), analytics: !!(c && c.analytics), decided: !!c }; },
    has: function (cat) { return cat === "essential" ? true : !!api.get()[cat]; },
    open: function () { openDialog(); },
    onChange: function (fn) { listeners.push(fn); if (current()) fn(api.get()); },
    exportData: exportData,
    eraseData: eraseData
  };
  window.CurioConsent = api;

  /* ---------------- gate embedded YouTube ---------------- */
  var YT = /^https?:\/\/(www\.)?youtube(-nocookie)?\.com\//i;
  function gateIframe(f) {
    if (!f || f.__gated || !f.getAttribute) return;
    var src = f.getAttribute("src") || "";
    if (!YT.test(src)) return;
    if (api.has("media")) return;
    f.__gated = true;
    injectCss(); // returning visitors never open the banner, so make sure the placeholder is styled
    f.setAttribute("data-consent-src", src);
    f.removeAttribute("src");
    var ph = document.createElement("div");
    ph.className = "cc-embed";
    ph.innerHTML =
      '<p><strong>Video from YouTube</strong></p>' +
      '<p>Playing this video connects your browser to YouTube (Google), which may set cookies. We only load it if you allow it.</p>' +
      '<div class="cc-row"><button type="button" class="cc-btn cc-primary" data-once>Load this video</button>' +
      '<button type="button" class="cc-btn" data-always>Always allow videos</button></div>';
    ph.querySelector("[data-once]").addEventListener("click", function () { release(f, ph); });
    ph.querySelector("[data-always]").addEventListener("click", function () { var c = api.get(); write({ media: true, analytics: c.analytics }); });
    f.parentNode.insertBefore(ph, f);
    f.__ph = ph;
    f.style.display = "none";
    // A fixed 16:9 frame (.video-frame, overflow:hidden) is shorter than the placeholder on phones and clips its buttons.
    // Let the frame grow while the placeholder is showing; release() restores it.
    var fr = f.parentNode;
    if (fr && fr.classList && fr.classList.contains("video-frame")) { fr.classList.add("cc-gated"); f.__frame = fr; }
  }
  function release(f, ph) {
    var s = f.getAttribute("data-consent-src");
    if (s) f.setAttribute("src", s);
    f.style.display = "";
    f.__gated = false;
    if (f.__frame) { f.__frame.classList.remove("cc-gated"); f.__frame = null; }
    if (ph && ph.parentNode) ph.parentNode.removeChild(ph);
    f.__ph = null;
  }
  function applyMedia() {
    var list = document.querySelectorAll("iframe[data-consent-src]");
    for (var i = 0; i < list.length; i++) {
      if (api.has("media")) release(list[i], list[i].__ph);
    }
    scanIframes();
  }
  function scanIframes(root) {
    var list = (root || document).querySelectorAll ? (root || document).querySelectorAll("iframe") : [];
    for (var i = 0; i < list.length; i++) gateIframe(list[i]);
  }
  try {
    new MutationObserver(function (recs) {
      recs.forEach(function (r) {
        r.addedNodes.forEach(function (n) {
          if (n.nodeType !== 1) return;
          if (n.tagName === "IFRAME") gateIframe(n); else scanIframes(n);
        });
      });
    }).observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) {}

  /* ---------------- GDPR helpers ---------------- */
  function exportData() {
    var out = { exportedAt: new Date().toISOString(), site: location.origin, localStorage: {} };
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i), v = localStorage.getItem(k);
        try { out.localStorage[k] = JSON.parse(v); } catch (e) { out.localStorage[k] = v; }
      }
    } catch (e) { out.error = "Local storage is not available in this browser."; }
    var blob = new Blob([JSON.stringify(out, null, 2)], { type: "application/json" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "curio-lab-my-data.json";
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
    return Object.keys(out.localStorage).length;
  }
  function eraseData() {
    try { localStorage.clear(); } catch (e) {}
    try { sessionStorage.clear(); } catch (e) {}
    memory = null;
    var jobs = [];
    try { if (window.caches) jobs.push(caches.keys().then(function (ks) { return Promise.all(ks.map(function (k) { return caches.delete(k); })); })); } catch (e) {}
    try { if (navigator.serviceWorker) jobs.push(navigator.serviceWorker.getRegistrations().then(function (rs) { return Promise.all(rs.map(function (r) { return r.unregister(); })); })); } catch (e) {}
    try { if (window.indexedDB && indexedDB.databases) jobs.push(indexedDB.databases().then(function (ds) { ds.forEach(function (d) { if (d.name) indexedDB.deleteDatabase(d.name); }); })); } catch (e) {}
    return Promise.all(jobs).catch(function () {});
  }

  /* ---------------- UI ---------------- */
  var css =
    ".cc-banner,.cc-modal,.cc-embed{font-family:var(--font-body,Inter,system-ui,sans-serif);color:var(--color-ink,#16181C)}" +
    ".cc-banner{position:fixed;left:12px;right:12px;bottom:12px;z-index:2147483000;max-width:760px;margin:0 auto;background:var(--color-surface,#fff);border:1px solid var(--color-line-strong,#D7D5CF);border-radius:16px;padding:18px 20px;box-shadow:0 20px 50px -18px rgba(0,0,0,.45)}" +
    ".cc-banner h2{margin:0 0 6px;font-size:1.05rem}.cc-banner p{margin:0 0 12px;font-size:.92rem;line-height:1.55;color:var(--color-ink-soft,#5B5F68)}" +
    ".cc-banner a,.cc-modal a{color:var(--accent,#0F7A6E)}" +
    ".cc-row{display:flex;flex-wrap:wrap;gap:8px}" +
    ".cc-btn{font:inherit;font-size:.9rem;font-weight:600;padding:.6rem 1rem;border-radius:10px;border:1px solid var(--color-line-strong,#D7D5CF);background:var(--color-surface,#fff);color:var(--color-ink,#16181C);cursor:pointer}" +
    ".cc-btn:hover{background:var(--color-bg-alt,#EEECE6)}" +
    ".cc-primary{background:var(--color-navy,#12213B);border-color:var(--color-navy,#12213B);color:#fff}.cc-primary:hover{filter:brightness(1.15);background:var(--color-navy,#12213B)}" +
    ".cc-btn:focus-visible,.cc-switch input:focus-visible+span{outline:3px solid var(--accent,#0F7A6E);outline-offset:2px}" +
    ".cc-overlay{position:fixed;inset:0;z-index:2147483001;background:rgba(10,15,25,.55);display:flex;align-items:center;justify-content:center;padding:14px}" +
    ".cc-modal{background:var(--color-surface,#fff);border-radius:18px;max-width:560px;width:100%;max-height:90vh;overflow:auto;padding:22px;border:1px solid var(--color-line-strong,#D7D5CF)}" +
    ".cc-modal h2{margin:0 0 6px}.cc-modal>p{margin:0 0 14px;color:var(--color-ink-soft,#5B5F68);font-size:.92rem;line-height:1.55}" +
    ".cc-cat{display:flex;gap:14px;justify-content:space-between;align-items:flex-start;padding:14px 0;border-top:1px solid var(--color-line,#E8E6E0)}" +
    ".cc-cat h3{margin:0 0 3px;font-size:.98rem}.cc-cat p{margin:0;font-size:.86rem;line-height:1.5;color:var(--color-ink-soft,#5B5F68)}" +
    ".cc-switch{position:relative;flex:none;width:46px;height:26px}.cc-switch input{position:absolute;inset:0;opacity:0;cursor:pointer;margin:0;width:100%;height:100%}" +
    ".cc-switch span{position:absolute;inset:0;border-radius:99px;background:var(--color-line-strong,#D7D5CF);transition:background .15s}" +
    ".cc-switch span::after{content:'';position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:#fff;transition:transform .15s}" +
    ".cc-switch input:checked+span{background:var(--accent,#0F7A6E)}.cc-switch input:checked+span::after{transform:translateX(20px)}" +
    ".cc-switch input:disabled{cursor:not-allowed}.cc-switch input:disabled+span{opacity:.6}" +
    ".cc-modal .cc-row{margin-top:16px;justify-content:flex-end}" +
    ".cc-embed{border:1px dashed var(--color-line-strong,#D7D5CF);background:var(--color-bg-alt,#EEECE6);border-radius:14px;padding:22px;text-align:center;margin:8px 0}" +
    ".video-frame.cc-gated{aspect-ratio:auto;height:auto;overflow:visible}.video-frame.cc-gated .cc-embed{margin:0;border-radius:inherit}" +
    ".cc-embed p{margin:0 0 8px;font-size:.92rem;color:var(--color-ink-soft,#5B5F68)}.cc-embed .cc-row{justify-content:center;margin-top:10px}" +
    "@media (prefers-reduced-motion:reduce){.cc-switch span,.cc-switch span::after{transition:none}}";

  function injectCss() {
    if (document.getElementById("cc-style")) return;
    var s = document.createElement("style"); s.id = "cc-style"; s.textContent = css;
    (document.head || document.documentElement).appendChild(s);
  }
  function el(html) { var d = document.createElement("div"); d.innerHTML = html.trim(); return d.firstChild; }

  var banner = null, dialog = null, lastFocus = null;
  function showBanner() {
    if (banner || current()) return;
    injectCss();
    banner = el(
      '<div class="cc-banner" role="region" aria-labelledby="cc-t" aria-live="polite">' +
        '<h2 id="cc-t">Your privacy, your choice</h2>' +
        '<p>Curio Lab keeps your progress on your own device and has no ads or trackers. We only ask before loading optional extras such as embedded YouTube videos. ' +
        'Read our <a href="' + ROOT + 'pages/cookies.html">Cookie Policy</a> and <a href="' + ROOT + 'pages/privacy.html">Privacy notice</a>.</p>' +
        '<div class="cc-row">' +
          '<button type="button" class="cc-btn cc-primary" data-a="all">Accept all</button>' +
          '<button type="button" class="cc-btn cc-primary" data-a="none">Reject optional</button>' +
          '<button type="button" class="cc-btn" data-a="choose">Choose…</button>' +
        '</div></div>');
    banner.addEventListener("click", function (e) {
      var a = e.target && e.target.getAttribute && e.target.getAttribute("data-a");
      if (!a) return;
      if (a === "all") { write({ media: true, analytics: !!cfg.analytics }); hideBanner(); }
      else if (a === "none") { write({ media: false, analytics: false }); hideBanner(); }
      else openDialog();
    });
    document.body.appendChild(banner);
  }
  function hideBanner() { if (banner && banner.parentNode) banner.parentNode.removeChild(banner); banner = null; }

  function openDialog() {
    if (dialog) return;
    injectCss();
    lastFocus = document.activeElement;
    var c = api.get();
    var analyticsRow = cfg.analytics ?
      '<div class="cc-cat"><div><h3>Analytics</h3><p>Anonymous usage statistics that help us improve lessons.</p></div>' +
      '<label class="cc-switch"><input type="checkbox" id="cc-an" aria-label="Analytics"' + (c.analytics ? " checked" : "") + '><span></span></label></div>' : "";
    dialog = el(
      '<div class="cc-overlay"><div class="cc-modal" role="dialog" aria-modal="true" aria-labelledby="cc-dt">' +
        '<h2 id="cc-dt">Privacy preferences</h2>' +
        '<p>Choose which optional features may run. You can change this at any time from “Cookie settings” in the footer.' +
        (gpc ? ' Your browser sends a Global Privacy Control signal, so optional features start switched off.' : '') + '</p>' +
        '<div class="cc-cat"><div><h3>Essential</h3><p>Saves your progress, scores, theme and language on this device, and keeps you signed in. The site can’t work without it, so it is always on.</p></div>' +
          '<label class="cc-switch"><input type="checkbox" checked disabled aria-label="Essential, always on"><span></span></label></div>' +
        '<div class="cc-cat"><div><h3>Embedded videos (YouTube)</h3><p>Lets lesson videos load from YouTube’s privacy-enhanced player. YouTube (Google) may receive your IP address and set cookies once a video plays.</p></div>' +
          '<label class="cc-switch"><input type="checkbox" id="cc-me" aria-label="Embedded videos"' + (c.media ? " checked" : "") + '><span></span></label></div>' +
        analyticsRow +
        '<div class="cc-row"><button type="button" class="cc-btn" data-a="none">Reject optional</button>' +
        '<button type="button" class="cc-btn" data-a="all">Accept all</button>' +
        '<button type="button" class="cc-btn cc-primary" data-a="save">Save choices</button></div>' +
      '</div></div>');
    dialog.addEventListener("click", function (e) {
      if (e.target === dialog) return closeDialog();
      var a = e.target && e.target.getAttribute && e.target.getAttribute("data-a");
      if (!a) return;
      var media = dialog.querySelector("#cc-me").checked, an = dialog.querySelector("#cc-an");
      if (a === "all") { media = true; an = !!cfg.analytics; }
      else if (a === "none") { media = false; an = false; }
      else an = an ? an.checked : false;
      write({ media: media, analytics: an });
      hideBanner(); closeDialog();
    });
    dialog.addEventListener("keydown", function (e) {
      if (e.key === "Escape") return closeDialog();
      if (e.key !== "Tab") return;
      var f = dialog.querySelectorAll("button,input:not([disabled]),a[href]");
      if (!f.length) return;
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
    document.body.appendChild(dialog);
    var first = dialog.querySelector("#cc-me"); if (first) first.focus();
  }
  function closeDialog() {
    if (dialog && dialog.parentNode) dialog.parentNode.removeChild(dialog);
    dialog = null;
    if (lastFocus && lastFocus.focus) { try { lastFocus.focus(); } catch (e) {} }
  }

  document.addEventListener("click", function (e) {
    var t = e.target && e.target.closest ? e.target.closest("[data-cookie-settings]") : null;
    if (t) { e.preventDefault(); openDialog(); }
  });

  function boot() { scanIframes(); showBanner(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
