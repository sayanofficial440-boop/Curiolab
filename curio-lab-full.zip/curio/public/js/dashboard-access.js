// Keep the learning workspace behind the sign-in step in both live and demo modes.
// CurioAuth reads the browser-only session; this file handles route transition.
async function protectDashboard() {
  // Opened directly from storage (file://): no server/session exists, so preview it instead of redirecting.
  if (window.location.protocol === "file:") { document.body.classList.remove("auth-pending"); return; }
  const redirectToLogin = () => window.location.replace("pages/login.html?next=dashboard");

  try {
    const user = window.CurioAuth ? await window.CurioAuth.getCurrentUser() : null;
    if (!user) {
      redirectToLogin();
      return;
    }

    const initials = (user.name || "Learner")
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((part) => part[0])
      .join("")
      .toUpperCase();

    document.querySelectorAll("[data-user-name]").forEach((el) => { el.textContent = user.name || "Learner"; });
    document.querySelectorAll("[data-user-initials]").forEach((el) => { el.textContent = initials; });
    document.body.classList.remove("auth-pending");
  } catch (error) {
    redirectToLogin();
  }
}
// Wait until the page has finished loading before checking the local session.
if (document.readyState === "complete") protectDashboard();
else window.addEventListener("load", protectDashboard);
