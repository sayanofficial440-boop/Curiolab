/* Profile page extras for children's accounts: parent-approval status, a way to (re)send the request,
   and an account delete that also forgets the approval record on this device. Adults see nothing from this file. */
(function () {
  "use strict";
  document.addEventListener("DOMContentLoaded", async function () {
    if (!window.CurioAuth || !window.CurioAge) return;
    var user = await window.CurioAuth.getCurrentUser();
    if (!user || !user.child) return;
    var host = document.querySelector("[data-pf-delete-account]");
    var anchor = host && (host.closest(".pf-card, .pf-section, section, div") || host.parentElement);
    if (!anchor || !anchor.parentNode) return;
    await window.CurioAge.refresh();
    var status = window.CurioAge.consent();

    var card = document.createElement("div");
    card.className = anchor.className; card.setAttribute("data-child-card", "");
    card.style.marginBottom = "var(--space-3, 1rem)";
    var msg = {
      granted: "✅ A parent has approved this account. Certificates, reminders and videos are available.",
      pending: "⏳ Waiting for a parent to approve. We emailed them a private link. Lessons and quizzes work meanwhile.",
      unverified: "No parent has been asked yet. Certificates, reminders and videos stay off until one approves.",
      declined: "A parent declined. Lessons and quizzes still work; certificates, reminders and videos stay off.",
      gone: "This account was deleted by a parent."
    };
    card.innerHTML = "<h3 style='margin:0 0 .4rem'>Parent approval</h3><p data-cc-msg style='margin:0 0 .6rem'></p>";
    card.querySelector("[data-cc-msg]").textContent = msg[status] || msg.unverified;
    if (status !== "granted") {
      var f = document.createElement("form");
      f.innerHTML = "<label style='display:block;font-size:.85rem;margin-bottom:.25rem' for='cc-mail'>Parent or guardian's email</label>" +
        "<div style='display:flex;gap:.5rem;flex-wrap:wrap'><input id='cc-mail' type='email' required autocomplete='off' style='flex:1;min-width:14rem;min-height:44px;padding:0 .75rem' />" +
        "<button type='submit' class='pf-btn' style='min-height:44px'>" + (status === "pending" ? "Send the email again" : "Ask a parent") + "</button></div>" +
        "<p data-cc-note role='status' aria-live='polite' style='font-size:.82rem;margin:.4rem 0 0'></p>";
      f.addEventListener("submit", async function (e) {
        e.preventDefault();
        var note = f.querySelector("[data-cc-note]");
        try {
          var r = await window.CurioAuth.resendParentConsent(f.querySelector("#cc-mail").value);
          f.querySelector("#cc-mail").value = "";
          note.textContent = r.delivery === "email" ? "Sent. Ask them to check their inbox." : "The request was saved but this site can't send email yet, so nobody could be asked.";
        } catch (err) { note.textContent = err.message; }
      });
      card.appendChild(f);
    }
    anchor.parentNode.insertBefore(card, anchor);

    // Child delete: replace the button so the generic handler (which only knows adults) doesn't run.
    var fresh = host.cloneNode(true); host.parentNode.replaceChild(fresh, host);
    fresh.disabled = false; fresh.textContent = "Delete account";
    var armed = false;
    fresh.addEventListener("click", async function () {
      if (!armed) { armed = true; fresh.textContent = "Click again to confirm"; setTimeout(function () { armed = false; fresh.textContent = "Delete account"; }, 4000); return; }
      try {
        var accounts = JSON.parse(localStorage.getItem("curiolab-local-accounts")) || {};
        delete accounts[user.email]; localStorage.setItem("curiolab-local-accounts", JSON.stringify(accounts));
        localStorage.removeItem("curio.child.v1");
      } catch (e) {}
      await window.CurioAuth.logout();
      location.href = "../index.html";
    });
  });
})();
