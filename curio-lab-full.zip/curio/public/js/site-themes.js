(function () {
  "use strict";
  // This is the single source of truth for the global, non-landing-page
  // appearance.  Do not also set the legacy `data-theme` attribute here:
  // several older stylesheets interpret it as a different theme system and
  // can overwrite the palette selected in this switcher.
  var KEY = "curiolab-site-theme-v2";
  // bg/surface/ink/accent/accent2 drive the miniature preview in the picker.
  var THEMES = [
    { id: "studio", name: "Studio", note: "Warm editorial peach", dark: false, bg: "#ffe9d8", surface: "#fffaf3", ink: "#3a2418", accent: "#e8683f", accent2: "#2f9e8f", gradient: "linear-gradient(135deg,#fff3e6,#ffd2b3 60%,#ffb48a)" },
    { id: "sakura", name: "Sakura", note: "Soft cherry blossom", dark: false, bg: "#ffd9e8", surface: "#fffafc", ink: "#3d1f2f", accent: "#e0457b", accent2: "#4a9a95", gradient: "linear-gradient(135deg,#fffafc,#ffd0e2 60%,#ff9fc4)" },
    { id: "bloom", name: "Orchid", note: "Refined violet energy", dark: false, bg: "#ecd2f2", surface: "#fff8fe", ink: "#2f1f4a", accent: "#7359c7", accent2: "#d36aa8", gradient: "linear-gradient(135deg,#fff3fb,#e4c6ee 55%,#b9a2ec)" },
    { id: "lavender", name: "Lavender", note: "Calm creative focus", dark: false, bg: "#e1d7fa", surface: "#fdfbff", ink: "#32234d", accent: "#7354b8", accent2: "#448078", gradient: "linear-gradient(135deg,#fcfaff,#dcd0f7 55%,#c0aaeb)" },
    { id: "coral", name: "Coral", note: "Bright modern optimism", dark: false, bg: "#ffd9d0", surface: "#fffaf8", ink: "#492926", accent: "#e65d4f", accent2: "#3d8580", gradient: "linear-gradient(135deg,#fffaf7,#ffd4c8 55%,#ff9f90)" },
    { id: "ember", name: "Ember", note: "Confident warm contrast", dark: false, bg: "#ffd6c5", surface: "#fffaf7", ink: "#48231e", accent: "#c33a2c", accent2: "#bd6d25", gradient: "linear-gradient(135deg,#fffaf5,#ffcdb8 55%,#f2937a)" },
    { id: "atelier", name: "Atelier", note: "Earthy executive finish", dark: false, bg: "#ecd1ae", surface: "#fff9ef", ink: "#3b2a1c", accent: "#a84c35", accent2: "#5c7f6b", gradient: "linear-gradient(135deg,#fff6e8,#e8cba5 55%,#c98d6b)" },
    { id: "sandstone", name: "Sandstone", note: "Soft timeless warmth", dark: false, bg: "#ead8af", surface: "#fffdf7", ink: "#473622", accent: "#9a6737", accent2: "#4f837a", gradient: "linear-gradient(135deg,#fffdf3,#ecd7ad 55%,#d1a870)" },
    { id: "moss", name: "Moss", note: "Grounded natural balance", dark: false, bg: "#dce9c7", surface: "#fbfff6", ink: "#2b4126", accent: "#48733f", accent2: "#b9822a", gradient: "linear-gradient(135deg,#fbfff4,#d7e8bc 55%,#a9cf84)" },
    { id: "alpine", name: "Alpine", note: "Crisp mountain clarity", dark: false, bg: "#cce9e8", surface: "#f8ffff", ink: "#163b42", accent: "#167c92", accent2: "#c78331", gradient: "linear-gradient(135deg,#f7ffff,#c9ebe9 55%,#8fcad3)" },
    { id: "tide", name: "Tide", note: "Clear blue workday", dark: false, bg: "#bfeef1", surface: "#f4feff", ink: "#0f3548", accent: "#2197c8", accent2: "#ff9d73", gradient: "linear-gradient(135deg,#edfaff,#b8ecef 55%,#6cc3e0)" },
    { id: "arctic", name: "Arctic", note: "Clean cool precision", dark: false, bg: "#d3e8f8", surface: "#fbfdff", ink: "#203d59", accent: "#377bb6", accent2: "#3e8694", gradient: "linear-gradient(135deg,#faffff,#d2e6f7 55%,#9cc7ea)" },
    { id: "prism", name: "Prism", note: "Vibrant balanced spectrum", dark: false, bg: "#d0eee4", surface: "#fcfffe", ink: "#203d4b", accent: "#5865d8", accent2: "#278d8a", gradient: "linear-gradient(135deg,#f9fffd,#cfeee1 50%,#a6b3f0)" },
    { id: "nocturne", name: "Nocturne", note: "Deep blue focus mode", dark: true, bg: "#0a2142", surface: "#12365c", ink: "#e6f3ff", accent: "#23b8ae", accent2: "#7cc4ff", gradient: "linear-gradient(135deg,#061630,#0f3a63 60%,#146a78)" },
    { id: "sapphire", name: "Sapphire", note: "Elegant blue authority", dark: true, bg: "#0b1e43", surface: "#16346a", ink: "#e8f2ff", accent: "#4e9ffc", accent2: "#f0b957", gradient: "linear-gradient(135deg,#06142e,#12356e 60%,#2a6bd0)" },
    { id: "aurora", name: "Aurora", note: "Northern lights glow", dark: true, bg: "#0b2330", surface: "#133646", ink: "#e6fbf5", accent: "#3ddbb0", accent2: "#7c5cff", gradient: "linear-gradient(135deg,#06121a,#0c3a3e 50%,#4a3bb0)" },
    { id: "velvet", name: "Velvet", note: "Rich plum refinement", dark: true, bg: "#3b2245", surface: "#4b2b58", ink: "#faeefa", accent: "#d680b8", accent2: "#edbd66", gradient: "linear-gradient(135deg,#211128,#522a62 55%,#a24f93)" },
    { id: "dusk", name: "Dusk", note: "Violet sky, ember horizon", dark: true, bg: "#2a1745", surface: "#3a2060", ink: "#fff1ea", accent: "#ff7a59", accent2: "#ff6f91", gradient: "linear-gradient(135deg,#170d2a,#3a1d5e 50%,#e0613f)" },
    { id: "graphite", name: "Graphite", note: "Steel and gold contrast", dark: true, bg: "#1c2530", surface: "#2a3948", ink: "#eef2f6", accent: "#d5a83d", accent2: "#6fa3c9", gradient: "linear-gradient(135deg,#10161d,#2b3b4b 55%,#6b5a2c)" }
  ];
  var root = document.documentElement;

  function savedTheme() {
    try { var value = localStorage.getItem(KEY); return THEMES.some(function (theme) { return theme.id === value; }) ? value : null; }
    catch (error) { return null; }
  }
  function preferredTheme() {
    return savedTheme() || (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "nocturne" : "studio");
  }
  function isTheme(id) {
    return THEMES.some(function (theme) { return theme.id === id; });
  }
  function setTheme(id, persist) {
    // Suspend every colour transition for this frame so nothing lags behind the switch.
    root.classList.add("curio-theme-instant");
    requestAnimationFrame(function () { requestAnimationFrame(function () { root.classList.remove("curio-theme-instant"); }); });
    root.setAttribute("data-site-theme", id);
    root.removeAttribute("data-theme");
    if (persist) { try { localStorage.setItem(KEY, id); } catch (error) {} }
    document.querySelectorAll("[data-curio-theme]").forEach(function (button) {
      button.setAttribute("aria-checked", String(button.getAttribute("data-curio-theme") === id));
    });
    var active = THEMES.find(function (theme) { return theme.id === id; });
    var trigger = document.querySelector(".curio-theme-trigger");
    if (trigger && active) trigger.setAttribute("aria-label", "Change theme. Current theme: " + active.name);
    var meta = document.querySelector('meta[name="theme-color"]');
    if (!meta) { meta = document.createElement("meta"); meta.name = "theme-color"; document.head.appendChild(meta); }
    if (active) meta.content = active.bg;
    document.dispatchEvent(new CustomEvent("curiolab:themechange", { detail: { theme: id } }));
  }
  // Applied instantly: no transition, so the colours change the moment you tap.
  function applyTheme(id, persist) {
    if (!isTheme(id)) id = preferredTheme();
    setTheme(id, persist);
  }

  applyTheme(preferredTheme(), false);
  // Small public API so other scripts (e.g. the profile page) can use the same
  // theme system instead of setting the legacy `data-theme` attribute.
  window.CurioSiteThemes = {
    list: THEMES,
    current: function () { return root.getAttribute("data-site-theme") || preferredTheme(); },
    apply: function (id, origin) { applyTheme(id, true, origin); }
  };

  function build() {
    if (document.querySelector(".curio-theme-studio")) return;
    var studio = document.createElement("div");
    studio.className = "curio-theme-studio";
    studio.setAttribute("data-open", "false");
    function choice(theme) {
      return '<button class="curio-theme-choice" type="button" role="radio" data-curio-theme="' + theme.id + '" aria-checked="false" aria-label="' + theme.name + ' — ' + theme.note + '">' +
        '<span class="curio-theme-swatch" aria-hidden="true" style="--p-grad:' + theme.gradient + ';--p-bg:' + theme.bg + ';--p-surface:' + theme.surface + ';--p-ink:' + theme.ink + ';--p-accent:' + theme.accent + ';--p-accent2:' + theme.accent2 + '">' +
        '<i class="ps-card"></i><i class="ps-line"></i><i class="ps-line s"></i><i class="ps-bar"></i><i class="ps-orb"></i><i class="ps-dot"></i></span>' +
        '<span class="curio-theme-meta"><span class="curio-theme-name">' + theme.name + '</span><span class="curio-theme-note">' + theme.note + '</span></span>' +
        '<span class="curio-theme-check" aria-hidden="true">✓</span></button>';
    }
    function group(label, dark) {
      return '<p class="curio-theme-group">' + label + '</p><div class="curio-theme-grid" role="radiogroup" aria-label="' + label + ' themes">' + THEMES.filter(function (t) { return t.dark === dark; }).map(choice).join("") + '</div>';
    }
    studio.innerHTML = '<button class="curio-theme-trigger" type="button" aria-haspopup="dialog" aria-expanded="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="13.5" cy="6.5" r="1"/><circle cx="17.5" cy="10.5" r="1"/><circle cx="8.5" cy="7.5" r="1"/><path d="M12 3a9 9 0 1 0 0 18h1.5a2 2 0 0 0 0-4H12a1.5 1.5 0 0 1 0-3h2a7 7 0 0 0-2-11Z"/></svg></button>' +
      '<section class="curio-theme-panel" role="dialog" aria-modal="false" aria-label="Choose website theme"><div class="curio-theme-head"><div><p class="curio-theme-kicker">' + THEMES.length + ' themes</p><h2 class="curio-theme-title">Make it yours</h2></div><button class="curio-theme-close" type="button" aria-label="Close theme switcher">×</button></div>' +
      '<div class="curio-theme-scroll">' + group("Light", false) + group("Dark", true) + '</div><p class="curio-theme-foot">Your choice follows you across every CurioLab page.</p></section>';
    document.body.appendChild(studio);
    // The global Curio Assistant is also a bottom-right fixed control. Keep
    // this switcher above it whenever that launcher is present.
    function syncDock() {
      studio.classList.toggle("curio-theme-above-assistant", !!document.querySelector(".gcoach-launcher"));
      var bar = document.querySelector(".curio-bottom-bar");
      var showing = !!bar && getComputedStyle(bar).display !== "none";
      studio.classList.toggle("curio-theme-docked", showing);
    }
    syncDock();
    new MutationObserver(syncDock).observe(document.body, { childList: true });
    window.addEventListener("resize", syncDock);
    window.addEventListener("load", syncDock);
    var trigger = studio.querySelector(".curio-theme-trigger");
    var close = studio.querySelector(".curio-theme-close");
    function setOpen(open) {
      studio.setAttribute("data-open", String(open));
      trigger.setAttribute("aria-expanded", String(open));
      if (open) setTimeout(function () { var current = studio.querySelector('[aria-checked="true"]'); if (current) current.focus(); }, 0);
    }
    trigger.addEventListener("click", function () { setOpen(studio.getAttribute("data-open") !== "true"); });
    close.addEventListener("click", function () { setOpen(false); trigger.focus(); });
    studio.querySelectorAll("[data-curio-theme]").forEach(function (button) {
      button.addEventListener("click", function (event) {
        var r = button.getBoundingClientRect();
        applyTheme(button.getAttribute("data-curio-theme"), true, { x: event.clientX || r.left + r.width / 2, y: event.clientY || r.top + r.height / 2 });
      });
    });
    document.addEventListener("click", function (event) { if (!studio.contains(event.target)) setOpen(false); });
    document.addEventListener("keydown", function (event) { if (event.key === "Escape" && studio.getAttribute("data-open") === "true") { setOpen(false); trigger.focus(); } });
    applyTheme(root.getAttribute("data-site-theme") || preferredTheme(), false);
  }
  // Keep separate open tabs in sync as well as preserving the choice when a
  // visitor navigates to another page.
  window.addEventListener("storage", function (event) {
    if (event.key === KEY && isTheme(event.newValue)) applyTheme(event.newValue, false);
  });
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", build, { once: true });
  else build();
})();
