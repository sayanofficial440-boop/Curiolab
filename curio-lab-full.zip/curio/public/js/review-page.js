// Curio Lab — Mistake Notebook page: spaced-review session, notebook list, schedule.
(function () {
  "use strict";
  const R = window.CurioReview;
  const root = document.querySelector("[data-review-app]");
  if (!R || !root) return;

  const $ = (s, el) => (el || root).querySelector(s);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const lessonUrl = (href) => (href ? "../" + href : "#");
  const shuffled = (a) => { const x = [...a]; for (let i = x.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [x[i], x[j]] = [x[j], x[i]]; } return x; };

  let queue = [], total = 0, doneCount = 0, current = null, answered = false, started = false;

  // ---------- stats ----------
  function renderStats() {
    const s = R.stats();
    $("[data-s-due]").textContent = s.due;
    $("[data-s-total]").textContent = s.total;
    $("[data-s-mastered]").textContent = s.mastered;
    $("[data-s-today]").textContent = s.reviewedToday;
    $("[data-s-due]").closest(".st-stat").classList.toggle("hot", s.due > 0);
    return s;
  }

  // ---------- review ----------
  function startSession(early) {
    queue = (early === true ? R.all().sort((a, b) => a.due - b.due) : R.due()).map((x) => x.id);
    total = queue.length; doneCount = 0; started = true;
    nextCard();
  }

  function renderIdle() {
    const s = R.stats(), box = $("[data-review-box]");
    if (!s.total) {
      box.innerHTML = `<div class="st-empty"><span class="big">📓</span><b>Your notebook is empty — a good sign.</b><p>When you get a quiz question wrong it lands here automatically and returns on a spaced schedule until you truly know it.</p><a href="physics.html">Take a lesson quiz →</a></div>`;
      return;
    }
    if (!s.due) {
      const next = R.all().map((x) => x.due).sort((a, b) => a - b)[0];
      const mins = Math.max(1, Math.round((next - Date.now()) / 60000));
      const when = mins < 90 ? "in " + mins + " min" : mins < 2880 ? "in " + Math.round(mins / 60) + " h" : "in " + Math.round(mins / 1440) + " days";
      box.innerHTML = `<div class="rv-done"><div style="font-size:2.2rem">🎉</div><h2>Nothing due right now</h2><p>${s.total} question${s.total === 1 ? "" : "s"} in your notebook. Next review ${when}.</p><button class="st-btn" type="button" data-early>Practice early anyway</button></div>`;
      $("[data-early]").addEventListener("click", () => startSession(true));
      return;
    }
    box.innerHTML = `<div class="rv-done"><div style="font-size:2.2rem">🧠</div><h2>${s.due} question${s.due === 1 ? "" : "s"} due for review</h2><p>Answer from memory. Missed ones come back in 10 minutes; ones you know get pushed further out.</p><button class="st-btn primary" type="button" data-start>Start review</button></div>`;
    $("[data-start]").addEventListener("click", () => startSession());
  }

  function nextCard() {
    const box = $("[data-review-box]");
    while (queue.length) {
      const item = R.all().find((x) => x.id === queue[0]);
      if (item) { current = item; break; }
      queue.shift();
    }
    if (!queue.length || !current) {
      started = false; current = null;
      const s = R.stats();
      box.innerHTML = `<div class="rv-done"><div style="font-size:2.2rem">✅</div><h2>Review complete</h2><p>${doneCount} question${doneCount === 1 ? "" : "s"} reviewed${s.due ? ` · ${s.due} more due again soon` : ""}.</p><button class="st-btn" type="button" data-again>${s.due ? "Review again" : "Back to notebook"}</button></div>`;
      $("[data-again]").addEventListener("click", () => (s.due ? startSession() : selectTab("notebook")));
      renderStats(); return;
    }
    answered = false;
    const pct = total ? Math.round((doneCount / total) * 100) : 0;
    const opts = shuffled(current.options);
    box.innerHTML = `
      <div class="rv-meta"><span>${esc(current.subject || "")} · ${esc(current.lesson)}</span><span>${doneCount} / ${total} done · ${queue.length} left</span></div>
      <div class="rv-bar" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><i style="width:${pct}%"></i></div>
      <p class="rv-q">${esc(current.q)}</p>
      <div class="rv-opts" data-opts>${opts.map((o, i) => `<button type="button" class="st-opt" data-opt="${esc(o)}"><kbd>${i + 1}</kbd><span>${esc(o)}</span></button>`).join("")}</div>
      <div data-after></div>`;
    box.querySelectorAll("[data-opt]").forEach((b) => b.addEventListener("click", () => answer(b.getAttribute("data-opt"))));
  }

  function answer(choice) {
    if (answered || !current) return;
    answered = true;
    const ok = choice === current.correct, box = $("[data-review-box]");
    box.querySelectorAll("[data-opt]").forEach((b) => {
      b.disabled = true;
      const v = b.getAttribute("data-opt");
      if (v === current.correct) b.classList.add("correct"); else if (v === choice) b.classList.add("wrong");
    });
    const after = $("[data-after]");
    const from = `<p class="rv-from">Review the lesson: <a href="${esc(lessonUrl(current.href))}">${esc(current.lesson)}</a></p>`;
    if (!ok) {
      R.grade(current.id, 1);
      const id = current.id;
      queue.shift(); queue.push(id); // see it again later this session
      after.innerHTML = `<div class="rv-feedback">Not quite — the answer is <b>${esc(current.correct)}</b>. It will come back in about 10 minutes.</div>${from}<div style="margin-top:14px"><button class="st-btn primary" type="button" data-next>Continue</button></div>`;
      $("[data-next]").addEventListener("click", nextCard);
      $("[data-next]").focus();
    } else {
      const pv = R.preview(current);
      after.innerHTML = `<div class="rv-feedback">Correct! How easy was that?</div>
        <div class="rv-grade">
          <button class="st-btn" type="button" data-g="3">Hard<small>${R.fmtInterval(pv[3])}</small></button>
          <button class="st-btn primary" type="button" data-g="4">Good<small>${R.fmtInterval(pv[4])}</small></button>
          <button class="st-btn" type="button" data-g="5">Easy<small>${R.fmtInterval(pv[5])}</small></button>
        </div>${from}`;
      after.querySelectorAll("[data-g]").forEach((b) => b.addEventListener("click", () => {
        R.grade(current.id, Number(b.getAttribute("data-g")));
        queue.shift(); doneCount += 1; nextCard();
      }));
    }
    renderStats();
  }

  document.addEventListener("keydown", (e) => {
    if (!started || e.ctrlKey || e.metaKey || e.altKey || /input|textarea|select/i.test(e.target.tagName)) return;
    if (!answered && /^[1-9]$/.test(e.key)) { const b = root.querySelectorAll("[data-opt]")[Number(e.key) - 1]; if (b) b.click(); }
    else if (answered) {
      const g = root.querySelector("[data-g]") ? { 1: "3", 2: "4", 3: "5" }[e.key] : null;
      if (g) { const b = root.querySelector('[data-g="' + g + '"]'); if (b) b.click(); }
      else if (e.key === "Enter") { const n = root.querySelector("[data-next]"); if (n) n.click(); }
    }
  });

  // ---------- notebook ----------
  function renderNotebook() {
    const items = R.all(), list = $("[data-nb-list]"), subjSel = $("[data-nb-subject]");
    const subjects = [...new Set(items.map((x) => x.subject || "Other"))].sort();
    const keep = subjSel.value;
    subjSel.innerHTML = `<option value="">All subjects</option>` + subjects.map((s) => `<option${s === keep ? " selected" : ""}>${esc(s)}</option>`).join("");
    const q = $("[data-nb-search]").value.trim().toLowerCase(), sub = subjSel.value, mode = $("[data-nb-filter]").value, now = Date.now();
    const shown = items.filter((x) =>
      (!sub || (x.subject || "Other") === sub) &&
      (!q || (x.q + " " + x.lesson + " " + x.correct).toLowerCase().includes(q)) &&
      (mode === "all" || (mode === "due" && x.due <= now) || (mode === "mastered" && x.interval >= R.MASTERED_AT) || (mode === "learning" && x.interval < R.MASTERED_AT))
    ).sort((a, b) => a.due - b.due);
    $("[data-nb-clear]").hidden = !items.length;
    if (!items.length) { list.innerHTML = `<div class="st-empty"><span class="big">📓</span>No mistakes saved yet. Wrong quiz answers appear here automatically.</div>`; return; }
    if (!shown.length) { list.innerHTML = `<div class="st-empty">No questions match these filters.</div>`; return; }
    list.innerHTML = shown.map((x) => {
      const isDue = x.due <= now, days = Math.max(0, Math.ceil((x.due - now) / 86400000));
      const status = x.interval >= R.MASTERED_AT ? "Mastered" : isDue ? "Due now" : "Next review in " + (days <= 1 ? "≤1 day" : days + " days");
      return `<article class="nb-item">
        <h3>${esc(x.q)}</h3>
        <div class="nb-row">Correct answer: <b class="good">${esc(x.correct)}</b></div>
        ${x.picked ? `<div class="nb-row">You answered: <span class="bad">${esc(x.picked)}</span></div>` : ""}
        <div class="nb-foot"><span><span class="nb-chip${isDue ? " due" : ""}">${esc(status)}</span><a href="${esc(lessonUrl(x.href))}">${esc(x.subject || "")} · ${esc(x.lesson)}</a></span>
        <span>Missed ${x.misses || 1}× <button class="st-btn ghost" type="button" data-del="${esc(x.id)}" aria-label="Remove from notebook">Remove</button></span></div>
      </article>`;
    }).join("");
    list.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => R.remove(b.getAttribute("data-del"))));
  }

  // ---------- schedule ----------
  function renderSchedule() {
    const s = R.stats(), el = $("[data-schedule]");
    if (!s.total) { el.innerHTML = `<div class="st-empty">Your review schedule will appear once you have saved questions.</div>`; return; }
    const names = ["Now", "Tomorrow"], d = new Date(), max = Math.max(1, ...s.upcoming);
    const label = (i) => { if (i < 2) return names[i]; const x = new Date(d); x.setDate(d.getDate() + i); return i === 6 ? "6+ d" : x.toLocaleDateString(undefined, { weekday: "short" }); };
    const subs = Object.entries(s.bySubject).sort((a, b) => b[1].total - a[1].total);
    el.innerHTML = `<p style="margin:0 0 6px;font-weight:600">Reviews coming up</p>
      <div class="sc-bars">${s.upcoming.map((n, i) => `<div><b>${n}</b><i style="height:${Math.round((n / max) * 100)}%"></i><span>${label(i)}</span></div>`).join("")}</div>
      <div class="sc-sub">${subs.map(([n, v]) => `<div><span>${esc(n)}</span><span>${v.total} saved${v.due ? ` · <b style="color:var(--color-coral)">${v.due} due</b>` : ""}</span></div>`).join("")}</div>`;
  }

  // ---------- tabs ----------
  function selectTab(name) {
    root.querySelectorAll("[data-tab]").forEach((t) => t.setAttribute("aria-selected", String(t.dataset.tab === name)));
    root.querySelectorAll("[data-panel]").forEach((p) => { p.hidden = p.dataset.panel !== name; });
    try { history.replaceState(null, "", "#" + name); } catch (_) { /* ignore */ }
  }
  root.querySelectorAll("[data-tab]").forEach((t) => t.addEventListener("click", () => selectTab(t.dataset.tab)));
  ["[data-nb-search]", "[data-nb-subject]", "[data-nb-filter]"].forEach((s) => $(s).addEventListener("input", renderNotebook));
  $("[data-nb-clear]").addEventListener("click", () => { if (confirm("Remove every question from your Mistake Notebook? This can't be undone.")) R.clearAll(); });

  function refresh() { renderStats(); renderNotebook(); renderSchedule(); if (!started) renderIdle(); }
  window.addEventListener("curio-review-updated", refresh);
  refresh();
  const h = location.hash.slice(1);
  selectTab(["review", "notebook", "schedule"].includes(h) ? h : "review");
})();
