/* Curio Lab — shareable lesson links.
 *
 *  - Adds a "Share" button to every lesson hero: native share sheet where the browser has one, otherwise copy link,
 *    WhatsApp, Telegram, X and email. The links are plain URLs (no third-party widgets or trackers are loaded).
 *  - The shared address is the page's canonical URL, so previews (title, description, image) come from the
 *    static tags written by scripts/build-seo.mjs. Nothing about the sender is added to the link.
 *  - Study-mode deep links: /pages/physics/force.html#quiz opens the Quiz tab; the address bar follows the tab.
 *  - Child accounts (see js/age-gate.js) only get "Copy link" and the device share sheet, no social network buttons.
 *
 *  Also exposes window.CurioShare.open({ url, title, text }) for other pages (e.g. certificate verification links).
 */
(function () {
  "use strict";

  function canonicalUrl() {
    var l = document.querySelector('link[rel="canonical"]');
    var href = l && l.href;
    // Placeholder / mismatching hosts (local preview, staging): share the address that actually works right now.
    try {
      var u = new URL(href);
      if (/\.example$/.test(u.hostname) || (location.hostname && u.hostname !== location.hostname && /^(localhost|127\.|192\.168\.|10\.)/.test(location.hostname))) return location.origin + location.pathname;
      return u.origin + u.pathname;
    } catch (e) { return location.origin + location.pathname; }
  }
  function isChild() { try { return !!(window.CurioAge && window.CurioAge.isChild()); } catch (e) { return false; } }
  function clip(text) { try { return navigator.clipboard.writeText(text); } catch (e) { return Promise.reject(e); } }
  function copyFallback(text) {
    var t = document.createElement("textarea"); t.value = text; t.setAttribute("readonly", ""); t.style.position = "fixed"; t.style.opacity = "0";
    document.body.appendChild(t); t.select(); var ok = false; try { ok = document.execCommand("copy"); } catch (e) {} document.body.removeChild(t); return ok;
  }
  function toast(msg) {
    if (window.CurioToast && window.CurioToast.show) window.CurioToast.show(msg, { icon: "🔗", duration: 2500 });
    else { var live = document.getElementById("share-live"); if (live) live.textContent = msg; }
  }
  function copy(text) {
    return clip(text).then(function () { toast("Link copied"); }, function () { toast(copyFallback(text) ? "Link copied" : "Copy failed - select the address bar instead"); });
  }

  var CSS = ".cl-share{position:relative;display:inline-block;margin-top:.6rem}" +
    ".cl-share-btn{display:inline-flex;align-items:center;gap:.45rem;min-height:44px;padding:0 1rem;border:1px solid var(--color-line-strong,#cfc9b8);border-radius:999px;background:var(--color-surface,#fff);color:var(--color-ink,#1b1b18);font:600 .9rem/1 inherit;cursor:pointer}" +
    ".cl-share-btn:hover,.cl-share-btn[aria-expanded=true]{border-color:var(--accent,#2a9d8f)}" +
    ".cl-share-menu{position:absolute;z-index:60;left:0;top:calc(100% + 6px);min-width:240px;padding:.4rem;border:1px solid var(--color-line-strong,#cfc9b8);border-radius:14px;background:var(--color-surface,#fff);box-shadow:0 12px 32px rgba(0,0,0,.18)}" +
    ".cl-share-menu[hidden]{display:none}" +
    ".cl-share-menu a,.cl-share-menu button{display:flex;width:100%;align-items:center;gap:.6rem;min-height:44px;padding:0 .8rem;border:0;border-radius:10px;background:none;color:var(--color-ink,#1b1b18);font:500 .92rem/1 inherit;text-align:left;text-decoration:none;cursor:pointer}" +
    ".cl-share-menu a:hover,.cl-share-menu button:hover,.cl-share-menu a:focus-visible,.cl-share-menu button:focus-visible{background:var(--color-line,#ece7d8);outline:none}" +
    ".cl-share-menu hr{border:0;border-top:1px solid var(--color-line,#ece7d8);margin:.3rem 0}" +
    ".cl-share-url{padding:.3rem .8rem .5rem;font:500 .74rem/1.3 ui-monospace,monospace;color:var(--color-ink-soft,#5c594e);word-break:break-all}";

  function buildMenu(opts) {
    var url = opts.url, title = opts.title, text = opts.text || title;
    var child = isChild();
    var items = [];
    if (navigator.share) items.push({ label: "Share…", icon: "📤", run: function () { navigator.share({ title: title, text: text, url: url }).catch(function () {}); } });
    items.push({ label: "Copy link", icon: "🔗", run: function () { copy(url); } });
    if (opts.tabUrl && opts.tabUrl !== url) items.push({ label: "Copy link to this tab", icon: "📌", run: function () { copy(opts.tabUrl); } });
    if (!child) {
      var enc = encodeURIComponent, full = enc(text + " " + (opts.tabUrl || url));
      items.push({ hr: true });
      items.push({ label: "WhatsApp", icon: "💬", href: "https://wa.me/?text=" + full });
      items.push({ label: "Telegram", icon: "✈️", href: "https://t.me/share/url?url=" + enc(opts.tabUrl || url) + "&text=" + enc(text) });
      items.push({ label: "X (Twitter)", icon: "𝕏", href: "https://twitter.com/intent/tweet?text=" + enc(text) + "&url=" + enc(opts.tabUrl || url) });
      items.push({ label: "Email", icon: "✉️", href: "mailto:?subject=" + enc(title) + "&body=" + full });
    }
    return items;
  }

  function mount(host, opts) {
    var wrap = document.createElement("div"); wrap.className = "cl-share";
    var btn = document.createElement("button"); btn.type = "button"; btn.className = "cl-share-btn";
    btn.setAttribute("aria-haspopup", "menu"); btn.setAttribute("aria-expanded", "false");
    btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/></svg><span>Share</span>';
    var menu = document.createElement("div"); menu.className = "cl-share-menu"; menu.setAttribute("role", "menu"); menu.hidden = true;
    var live = document.createElement("span"); live.id = "share-live"; live.setAttribute("role", "status"); live.style.cssText = "position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)";
    wrap.appendChild(btn); wrap.appendChild(menu); wrap.appendChild(live); host.appendChild(wrap);

    function render() {
      var o = typeof opts === "function" ? opts() : opts;
      menu.innerHTML = "";
      buildMenu(o).forEach(function (it) {
        if (it.hr) { menu.appendChild(document.createElement("hr")); return; }
        var el = document.createElement(it.href ? "a" : "button");
        el.setAttribute("role", "menuitem");
        if (it.href) { el.href = it.href; el.target = "_blank"; el.rel = "noopener noreferrer"; } else el.type = "button";
        el.innerHTML = '<span aria-hidden="true">' + it.icon + "</span><span></span>"; el.lastChild.textContent = it.label;
        el.addEventListener("click", function () { if (it.run) it.run(); close(); });
        menu.appendChild(el);
      });
      var u = document.createElement("div"); u.className = "cl-share-url"; u.textContent = (o.tabUrl || o.url).replace(/^https?:\/\//, ""); menu.appendChild(u);
    }
    function open() { render(); menu.hidden = false; menu.style.left = "0px";
      var r = menu.getBoundingClientRect(), vw = document.documentElement.clientWidth;   // keep the menu on screen on phones
      if (r.right > vw - 8) menu.style.left = -(r.right - (vw - 8)) + "px";
      if (r.left < 8 && r.right <= vw - 8) menu.style.left = (8 - r.left) + "px"; btn.setAttribute("aria-expanded", "true"); var f = menu.querySelector("a,button"); if (f) f.focus(); }
    function close() { menu.hidden = true; btn.setAttribute("aria-expanded", "false"); }
    btn.addEventListener("click", function () { menu.hidden ? open() : close(); });
    document.addEventListener("click", function (e) { if (!wrap.contains(e.target)) close(); });
    wrap.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { close(); btn.focus(); }
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        var els = [].slice.call(menu.querySelectorAll("a,button")), i = els.indexOf(document.activeElement);
        if (!els.length || menu.hidden) return; e.preventDefault();
        els[(i + (e.key === "ArrowDown" ? 1 : -1) + els.length) % els.length].focus();
      }
    });
    return wrap;
  }

  var api = window.CurioShare = { open: null, mount: mount, canonicalUrl: canonicalUrl, copy: copy };
  if (!document.getElementById("cl-share-css")) { var st = document.createElement("style"); st.id = "cl-share-css"; st.textContent = CSS; (document.head || document.documentElement).appendChild(st); }

  /* ---------- lesson pages ---------- */
  function lessonInit() {
    var hero = document.querySelector(".lesson-hero h1");
    if (!hero || document.querySelector(".cl-share")) return;
    var host = hero.parentElement;
    var badge = host.querySelector(".score-badge");
    var title = document.title.replace(/\s*\|\s*Curio Lab\s*$/, "");
    var holder = document.createElement("div");
    badge ? badge.insertAdjacentElement("afterend", holder) : host.appendChild(holder);
    var currentTab = null;
    mount(holder, function () {
      var url = canonicalUrl();
      return { url: url, tabUrl: currentTab && currentTab !== "about" ? url + "#" + currentTab : url, title: title, text: "Check out this lesson on Curio Lab: " + hero.textContent.trim() };
    });

    // lesson-tabs.js has already run (it registered first), so the first tab is active by now.
    var active = document.querySelector("[data-tab].active");
    currentTab = active ? active.dataset.tab : null;
    window.addEventListener("curiolab:tab-shown", function (e) {
      var name = e.detail && e.detail.name;
      if (!name) return;
      currentTab = name;
      try { history.replaceState(null, "", name === "about" ? location.pathname + location.search : "#" + name); } catch (err) {}
    });
    var wanted = (location.hash || "").replace(/^#/, "");
    if (wanted && wanted !== currentTab) {
      var t = document.querySelector('[data-tab="' + CSS_escape(wanted) + '"]');
      if (t) t.click();
    }
  }
  function CSS_escape(s) { return window.CSS && CSS.escape ? CSS.escape(s) : s.replace(/[^\w-]/g, ""); }

  if (typeof window.onLessonContentReady === "function") window.onLessonContentReady(lessonInit);
  else if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", lessonInit); else lessonInit();
})();
