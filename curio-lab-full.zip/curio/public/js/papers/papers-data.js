// Curio Lab — exam-style practice papers WITH full solutions (original questions, not reproductions of any board paper).
// Add a paper by pushing one object onto window.CurioPapers. Section types: mcq | fib | tf | vsa | sa | la | cbq.
//  mcq: { q, options[], correct:<index>, why }     fib: { q, answers:[accepted...], why }     tf: { q, answer:true|false, why }
//  vsa/sa/la: { q, model, points:[[text, marks], ...] }   (marks per question = sum of its points)
//  cbq: { passage, subs:[{ q, model, points:[[text, marks]...] }] }
(function () {
  const W = (q, model, points) => ({ q, model, points });
  window.CurioPapers = (window.CurioPapers || []).concat([
  { id: "phy-set-a", subject: "Physics", title: "Physics Practice Paper A", level: "Grades 9–10 style", minutes: 45, sections: [
    { name: "Section A", type: "mcq", label: "Multiple choice (1 mark each)", questions: [
      { q: "The SI unit of force is the", options: ["newton", "dyne", "joule", "watt"], correct: 0, why: "Force = mass × acceleration, so 1 N = 1 kg·m/s²." },
      { q: "“A body stays at rest or in uniform motion unless an external force acts” is", options: ["Newton’s first law", "Newton’s second law", "Newton’s third law", "the law of gravitation"], correct: 0, why: "That statement is the law of inertia, Newton’s first law." },
      { q: "Work done when a 10 N force moves an object 3 m along the force is", options: ["3 J", "13 J", "30 J", "0.3 J"], correct: 2, why: "W = F × s = 10 × 3 = 30 J." },
      { q: "A conductor has 12 V across it and carries 3 A. Its resistance is", options: ["36 Ω", "4 Ω", "0.25 Ω", "9 Ω"], correct: 1, why: "R = V / I = 12 / 3 = 4 Ω." } ] },
    { name: "Section B", type: "fib", label: "Fill in the blanks (1 mark each)", questions: [
      { q: "The rate of doing work is called ______.", answers: ["power"], why: "P = W / t, measured in watts." },
      { q: "The mirror used as a car’s rear-view mirror is a ______ mirror.", answers: ["convex"], why: "A convex mirror gives an upright image and a wide field of view." } ] },
    { name: "Section C", type: "tf", label: "True or false (1 mark each)", questions: [
      { q: "Mass and weight of a body are the same thing.", answer: false, why: "Mass is the amount of matter (kg); weight is the gravitational force on it (N)." },
      { q: "The kinetic energy of a body depends on its speed.", answer: true, why: "KE = ½mv², so it grows with the square of speed." } ] },
    { name: "Section D", type: "vsa", label: "Very short answer (2 marks each)", questions: [
      W("State Newton’s second law of motion.", "The rate of change of momentum of a body is directly proportional to the applied force and takes place in the direction of the force. For constant mass this gives F = ma.", [["Correct statement (rate of change of momentum ∝ force)", 1], ["F = ma for constant mass", 1]]),
      W("Define one joule of work.", "One joule is the work done when a force of 1 newton displaces a body by 1 metre in the direction of the force (1 J = 1 N·m).", [["Definition with 1 N and 1 m in the direction of force", 1], ["1 J = 1 N·m", 1]]) ] },
    { name: "Section E", type: "sa", label: "Short answer (3 marks each)", questions: [
      W("A 2 kg ball moves at 5 m/s. Find its kinetic energy and its momentum.", "KE = ½mv² = ½ × 2 × 5² = 25 J. Momentum p = mv = 2 × 5 = 10 kg·m/s.", [["Writes KE = ½mv² and substitutes", 1], ["KE = 25 J", 1], ["p = mv = 10 kg·m/s", 1]]),
      W("Resistors of 2 Ω, 3 Ω and 6 Ω are connected in parallel. Find the equivalent resistance.", "1/R = 1/2 + 1/3 + 1/6 = 3/6 + 2/6 + 1/6 = 1, so R = 1 Ω.", [["Parallel formula 1/R = 1/R₁ + 1/R₂ + 1/R₃", 1], ["Correct sum = 1", 1], ["R = 1 Ω with unit", 1]]) ] },
    { name: "Section F", type: "la", label: "Long answer (5 marks)", questions: [
      W("A car of mass 1000 kg accelerates uniformly from rest to 20 m/s in 10 s. Find (a) the acceleration, (b) the net force, (c) the work done, (d) the average power.", "(a) a = (v − u)/t = 20/10 = 2 m/s². (b) F = ma = 1000 × 2 = 2000 N. (c) Distance s = ½at² = ½ × 2 × 100 = 100 m, so W = F × s = 200 000 J (check: ½mv² = ½ × 1000 × 400 = 200 000 J). (d) P = W/t = 200 000 / 10 = 20 000 W = 20 kW.", [["(a) a = 2 m/s²", 1], ["(b) F = 2000 N", 1], ["(c) method: distance or ½mv²", 1], ["(c) W = 200 000 J", 1], ["(d) P = 20 kW", 1]]) ] },
    { name: "Section G", type: "cbq", label: "Case-based question (4 marks)", questions: [
      { passage: "A student connects a 6 V battery, a 2 Ω resistor and a 4 Ω resistor in series, with an ammeter and a switch.", subs: [
        W("(a) Find the total resistance.", "R = 2 + 4 = 6 Ω (series resistances add).", [["6 Ω", 1]]),
        W("(b) Find the current in the circuit.", "I = V/R = 6/6 = 1 A.", [["1 A", 1]]),
        W("(c) Find the potential difference across the 4 Ω resistor.", "V = IR = 1 × 4 = 4 V.", [["4 V", 1]]),
        W("(d) The 4 Ω resistor is replaced by a 1 Ω resistor. How does the current change?", "Total R = 3 Ω, so I = 6/3 = 2 A. The current doubles because the total resistance falls.", [["Says the current increases (to 2 A) because total resistance falls", 1]]) ] } ] } ] },
  { id: "mth-set-a", subject: "Mathematics", title: "Mathematics Practice Paper A", level: "Grades 8–10 style", minutes: 45, sections: [
    { name: "Section A", type: "mcq", label: "Multiple choice (1 mark each)", questions: [
      { q: "The value of √144 is", options: ["10", "12", "14", "16"], correct: 1, why: "12 × 12 = 144." },
      { q: "The solution of x + 7 = 12 is", options: ["4", "5", "19", "−5"], correct: 1, why: "Subtract 7 from both sides: x = 5." },
      { q: "The sum of the angles of a triangle is", options: ["90°", "180°", "270°", "360°"], correct: 1, why: "Angle sum property of a triangle." },
      { q: "The slope of the line y = 3x + 2 is", options: ["2", "3", "1/3", "5"], correct: 1, why: "In y = mx + c the slope is m = 3." } ] },
    { name: "Section B", type: "fib", label: "Fill in the blanks (1 mark each)", questions: [
      { q: "The area of a circle of radius r is ______.", answers: ["πr²", "pi r^2", "πr^2", "pi*r^2", "pi r2", "pi r squared"], why: "Area = π × r × r." },
      { q: "A number that cannot be written as p/q is called ______.", answers: ["irrational", "an irrational number", "irrational number"], why: "For example √2 and π are irrational." } ] },
    { name: "Section C", type: "tf", label: "True or false (1 mark each)", questions: [
      { q: "Every square is a rhombus.", answer: true, why: "A square has four equal sides, which is what makes a rhombus." },
      { q: "The probability of an event can be greater than 1.", answer: false, why: "Probability always lies between 0 and 1 inclusive." } ] },
    { name: "Section D", type: "vsa", label: "Very short answer (2 marks each)", questions: [
      W("Find the HCF of 12 and 18.", "12 = 2² × 3 and 18 = 2 × 3². Common factors with lowest powers: 2 × 3 = 6. HCF = 6.", [["Prime factorisation (or listing factors)", 1], ["HCF = 6", 1]]),
      W("Solve 3x − 5 = 10.", "3x = 10 + 5 = 15, so x = 5.", [["Moves −5 across: 3x = 15", 1], ["x = 5", 1]]) ] },
    { name: "Section E", type: "sa", label: "Short answer (3 marks each)", questions: [
      W("Factorise x² − 5x + 6.", "Find two numbers with product 6 and sum −5: −2 and −3. x² − 2x − 3x + 6 = x(x − 2) − 3(x − 2) = (x − 2)(x − 3).", [["Identifies −2 and −3 (product 6, sum −5)", 1], ["Splits the middle term and groups", 1], ["(x − 2)(x − 3)", 1]]),
      W("A rectangle is 12 cm long and 5 cm wide. Find its area and perimeter.", "Area = 12 × 5 = 60 cm². Perimeter = 2(12 + 5) = 34 cm.", [["Area formula and 60", 1], ["Perimeter = 2(l + b) = 34", 1], ["Correct units (cm², cm)", 1]]) ] },
    { name: "Section F", type: "la", label: "Long answer (5 marks)", questions: [
      W("Solve by elimination and verify: 2x + y = 11 and x − y = 1.", "Add the equations: 3x = 12, so x = 4. From x − y = 1: y = 4 − 1 = 3. Check: 2(4) + 3 = 11 ✓ and 4 − 3 = 1 ✓.", [["Chooses to add so y cancels", 1], ["3x = 12", 1], ["x = 4", 1], ["y = 3", 1], ["Verifies in both equations", 1]]) ] },
    { name: "Section G", type: "cbq", label: "Case-based question (4 marks)", questions: [
      { passage: "A rectangular garden is 15 m long and 8 m wide. A path 1 m wide runs all the way around the outside of the garden.", subs: [
        W("(a) Find the area of the garden.", "15 × 8 = 120 m².", [["120 m²", 1]]),
        W("(b) Find the length and width of the garden plus path.", "The path adds 1 m on each side: 17 m × 10 m.", [["17 m by 10 m", 1]]),
        W("(c) Find the area of the path.", "Outer area 17 × 10 = 170 m². Path = 170 − 120 = 50 m².", [["50 m²", 1]]),
        W("(d) Paving costs ₹40 per m². Find the cost of paving the path.", "50 × 40 = ₹2000.", [["₹2000", 1]]) ] } ] } ] }
  ]);
})();
