// Curio Lab — course bar on lesson pages: "Step 3 of 10 · Physics path", previous/next links, and a gentle
// heads-up when the lesson before this one in the path hasn't been passed yet. Never blocks the lesson.
(function () {
  "use strict";
  const C = window.CurioCourses, P = window.CurioCoursePath, L = window.CurioLearning;
  if (!C || !L || document.querySelector(".course-bar")) return;
  const here = location.pathname.replace(/^.*?(pages\/)/, "$1");
  const course = C.find((c) => c.lessons.some((l) => l.h === here));
  if (!course) return;
  const root = location.pathname.replace(/pages\/.*$/, "");
  const i = course.lessons.findIndex((l) => l.h === here), prev = course.lessons[i - 1], next = course.lessons[i + 1];
  const bar = document.createElement("nav"); bar.className = "course-bar"; bar.setAttribute("aria-label", "Course path");
  const link = (l, t) => `<a href="${root}${l.h}">${t}</a>`;
  const paint = (prog) => {
    const nx = window.CurioNext ? window.CurioNext.recommend(prog) : null;
    const nxLink = nx && nx.lesson.h !== here ? `<a class="cb-next" href="${root}${nx.lesson.h}" title="${nx.reason.replace(/"/g, "&quot;")}">Next for you: ${nx.lesson.t}</a>` : "";
    const passed = (prog || []).some((p) => prev && P.rel(p.href) === prev.h && p.status === "completed");
    bar.innerHTML = `<span><b>${course.title}</b> · lesson ${i + 1} of ${course.lessons.length}</span>` +
      (prev && !passed ? `<span class="warn">Recommended first: ${prev.t}</span>` : "") + nxLink + `<span class="sp"></span>` +
      (prev ? link(prev, "← " + prev.t) : "") + (next ? link(next, next.t + " →") : "") + `<a href="${root}pages/courses.html?c=${course.id}">All lessons</a>`;
  };
  paint([]); document.body.insertBefore(bar, document.body.firstChild);
  L.get().then((s) => paint(s.lessonProgress)).catch(() => {});
})();
