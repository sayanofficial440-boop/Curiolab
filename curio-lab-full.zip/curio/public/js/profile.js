// Curio Lab — Profile / Account Hub
// Reads the same localStorage data every other tool page already writes
// (curiolab-scores, curiolab-theme, curiolab-sound, curiolab-todos,
// curiolab-chat-*) and window.CurioAuth / window.CurioAchievements for
// identity + trophies. Purely additive — never assumes a backend exists,
// and every destructive action lives behind an explicit confirm step.
(function () {
  "use strict";

  const SCORES_KEY = "curiolab-scores";
  const PREFS_KEY = "curiolab-profile-prefs"; // { avatarColor, bio }
  const SOUND_KEY = "curiolab-sound";

  const AVATAR_COLORS = ["#12213B", "#D68C1F", "#2E8E80", "#C94A38", "#5F7A34", "#7C5CBF"];

  function getScores() {
    try { return JSON.parse(localStorage.getItem(SCORES_KEY)) || []; } catch (e) { return []; }
  }
  function getPrefs() {
    try { return JSON.parse(localStorage.getItem(PREFS_KEY)) || {}; } catch (e) { return {}; }
  }
  function savePrefs(p) { localStorage.setItem(PREFS_KEY, JSON.stringify(p)); }

  function initials(name) {
    if (!name) return "?";
    return name.trim().split(/\s+/).slice(0, 2).map((w) => w[0].toUpperCase()).join("");
  }

  document.addEventListener("DOMContentLoaded", async () => {
    const guestEl = document.querySelector("[data-pf-guest]");
    const heroEl = document.querySelector("[data-pf-hero]");
    const bodyEl = document.querySelector("[data-pf-body]");
    if (!guestEl || !heroEl || !bodyEl) return;

    const user = window.CurioAuth ? await window.CurioAuth.getCurrentUser() : null;

    if (!user) {
      guestEl.style.display = "block";
      heroEl.style.display = "none";
      bodyEl.style.display = "none";
      return;
    }

    guestEl.style.display = "none";
    heroEl.style.display = "flex";
    bodyEl.style.display = "block";

    const prefs = getPrefs();

    /* ---------------- Hero: identity ---------------- */
    const avatarEl = document.querySelector("[data-pf-avatar]");
    const nameEl = document.querySelector("[data-pf-name]");
    const modeEl = document.querySelector("[data-pf-mode]");
    const bioEl = document.querySelector("[data-pf-bio]");

    function applyAvatarColor(color) {
      document.documentElement.style.setProperty("--pf-avatar", color);
      if (avatarEl) avatarEl.style.setProperty("--pf-avatar", color);
    }

    if (avatarEl) avatarEl.textContent = initials(user.name);
    if (nameEl) nameEl.textContent = user.name || "Curious Learner";
    document.querySelectorAll("[data-pf-email]").forEach((el) => { el.textContent = user.child ? "Child account (no email stored)" : (user.email || ""); });
    if (modeEl) {
      const isDemo = user.mode === "demo";
      modeEl.textContent = isDemo ? "Demo account" : "Live account";
      modeEl.classList.toggle("is-demo", isDemo);
    }
    if (bioEl) bioEl.textContent = prefs.bio || "";
    applyAvatarColor(prefs.avatarColor || "#12213B");

    // Avatar color picker
    const swatchWrap = document.querySelector("[data-pf-avatar-picker]");
    if (swatchWrap) {
      swatchWrap.innerHTML = AVATAR_COLORS.map((c) => `<button type="button" class="pf-avatar-swatch${(prefs.avatarColor || "#12213B") === c ? " is-active" : ""}" style="background:${c};" data-color="${c}" aria-label="Avatar color"></button>`).join("");
      swatchWrap.querySelectorAll("[data-color]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const color = btn.dataset.color;
          const p = getPrefs();
          p.avatarColor = color;
          savePrefs(p);
          applyAvatarColor(color);
          swatchWrap.querySelectorAll(".pf-avatar-swatch").forEach((b) => b.classList.toggle("is-active", b === btn));
        });
      });
    }

    // Display name / bio form (cosmetic — layered over the auth identity,
    // doesn't touch the account record itself since there's no backend
    // endpoint for that yet)
    const form = document.querySelector("[data-pf-form]");
    if (form) {
      const nameInput = form.querySelector("[data-pf-name-input]");
      const bioInput = form.querySelector("[data-pf-bio-input]");
      if (nameInput) nameInput.value = prefs.displayName || user.name || "";
      if (bioInput) bioInput.value = prefs.bio || "";
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const p = getPrefs();
        p.displayName = nameInput ? nameInput.value.trim() : "";
        p.bio = bioInput ? bioInput.value.trim() : "";
        savePrefs(p);
        if (nameEl) nameEl.textContent = p.displayName || user.name || "Curious Learner";
        if (avatarEl) avatarEl.textContent = initials(p.displayName || user.name);
        if (bioEl) bioEl.textContent = p.bio || "";
        const note = form.querySelector("[data-pf-saved]");
        if (note) {
          note.classList.add("is-visible");
          setTimeout(() => note.classList.remove("is-visible"), 2200);
        }
        if (window.CurioToast) window.CurioToast.show("Profile updated", { icon: "✨" });
      });
    }

    /* ---------------- Account & security panel ---------------- */
    const providerEl = document.querySelector("[data-pf-provider]");
    if (providerEl) {
      const provider = user.provider || "email";
      const labelMap = { email: "📧 Email & password", google: "🔵 Google", github: "⚫ GitHub", apple: "🍎 Apple" };
      providerEl.textContent = labelMap[provider] || provider;
    }

    const logoutBtn = document.querySelector("[data-pf-logout]");
    if (logoutBtn) {
      logoutBtn.addEventListener("click", async () => {
        await window.CurioAuth.logout();
        window.location.href = "../index.html";
      });
    }

    /* ---------------- Stats strip ---------------- */
    // Keep the account hub aligned with the same event stream that powers the
    // dashboard. Older standalone quiz records remain a fallback for people
    // returning from a previous version of the app.
    const learning = window.CurioLearning ? await window.CurioLearning.get() : null;
    const activityScores = (learning?.events || []).filter((event) => event.type === "quiz" && event.total).map((event) => ({
      lesson: event.lesson, subject: event.subject, score: event.score, total: event.total, date: event.at,
    }));
    const scores = activityScores.length ? activityScores : getScores();
    const statLessons = document.querySelector("[data-pf-stat-lessons]");
    const statAttempts = document.querySelector("[data-pf-stat-attempts]");
    const statAvg = document.querySelector("[data-pf-stat-avg]");
    const statStreak = document.querySelector("[data-pf-stat-streak]");

    const uniqueLessons = new Set([
      ...scores.map((s) => `${s.subject || ""}:${s.lesson}`),
      ...(learning?.lessonProgress || []).map((item) => `${item.subject || ""}:${item.title}`),
    ]).size;
    const avgPct = scores.length ? Math.round((scores.reduce((sum, s) => sum + s.score / s.total, 0) / scores.length) * 100) : 0;
    const dayMs = 86400000;
    const uniqueDayNums = [...new Set(scores.map((s) => Math.floor(new Date(s.date).getTime() / dayMs)))].sort((a, b) => a - b);
    let bestStreak = uniqueDayNums.length ? 1 : 0;
    let running = 1;
    for (let i = 1; i < uniqueDayNums.length; i++) {
      running = uniqueDayNums[i] === uniqueDayNums[i - 1] + 1 ? running + 1 : 1;
      if (running > bestStreak) bestStreak = running;
    }

    if (statLessons) statLessons.textContent = uniqueLessons;
    if (statAttempts) statAttempts.textContent = scores.length;
    if (statAvg) statAvg.textContent = scores.length ? `${avgPct}%` : "—";
    if (statStreak) statStreak.textContent = bestStreak;

    /* ---------------- Subject mastery (compact) ---------------- */
    const SUBJECTS = [
      { name: "Physics", accent: "var(--color-teal)" },
      { name: "Chemistry", accent: "var(--color-amber)" },
      { name: "Biology", accent: "var(--color-coral)" },
      { name: "Mathematics", accent: "var(--color-amber)" },
      { name: "English", accent: "var(--color-coral)" },
      { name: "History", accent: "var(--color-navy)" },
      { name: "Geography", accent: "var(--color-moss)" },
      { name: "Computer Science", accent: "var(--color-navy)" },
    ];
    const masteryEl = document.querySelector("[data-pf-mastery]");
    if (masteryEl) {
      const bySubject = {};
      scores.forEach((s) => { (bySubject[s.subject] = bySubject[s.subject] || []).push(s.score / s.total); });
      const rows = SUBJECTS.filter((s) => bySubject[s.name]).map((s) => {
        const pcts = bySubject[s.name];
        const avg = Math.round((pcts.reduce((a, b) => a + b, 0) / pcts.length) * 100);
        return { ...s, avg, attempts: pcts.length };
      }).sort((a, b) => b.avg - a.avg);

      masteryEl.innerHTML = rows.length ? rows.map((s) => `
        <div class="pf-mastery-row">
          <span>${s.name}</span>
          <span>${s.avg}% · ${s.attempts}×</span>
          <span class="pf-mastery-track" style="--pm-accent:${s.accent};"><span class="pf-mastery-fill" style="--pm-pct:${s.avg}%;"></span></span>
        </div>
      `).join("") : `<p class="pf-badge-empty" style="text-align:left; padding-left:0;">No quiz attempts yet — <a href="scoreboard.html" style="color:var(--accent);">visit Progress</a> to get started.</p>`;
    }

    /* ---------------- Badges (reuses CurioAchievements) ---------------- */
    const badgeGrid = document.querySelector("[data-pf-badges]");
    if (badgeGrid && window.CurioAchievements) {
      const all = window.CurioAchievements.earned();
      const earnedCount = all.filter((t) => t.earned).length;
      const countEl = document.querySelector("[data-pf-badge-count]");
      if (countEl) countEl.textContent = `${earnedCount} of ${all.length} earned`;
      badgeGrid.innerHTML = all.map((t) => `
        <div class="pf-badge${t.earned ? " earned" : ""}" title="${t.desc}">
          <span class="icon">${t.icon}</span>
          <span class="name">${t.name}</span>
        </div>
      `).join("");
    }

    /* ---------------- Preferences: theme grid ---------------- */
    const themeGrid = document.querySelector("[data-pf-theme-grid]");
    if (themeGrid && window.CurioSiteThemes) {
      const ST = window.CurioSiteThemes;
      const swatch = (g) => { const c = g.match(/#[0-9a-fA-F]{3,8}/g) || []; return { a: c[0] || "#ccc", b: c[c.length - 1] || "#888" }; };
      const paint = () => {
        const cur = ST.current();
        themeGrid.querySelectorAll(".pf-theme-option").forEach((b) => b.classList.toggle("is-active", b.dataset.themeId === cur));
        const labelEl = document.querySelector("[data-theme-label]");
        const t = ST.list.find((x) => x.id === cur);
        if (labelEl && t) labelEl.textContent = t.name;
      };
      themeGrid.innerHTML = ST.list.map((t) => { const c = swatch(t.gradient); return `
        <button type="button" class="pf-theme-option" data-theme-id="${t.id}" style="--sa:${c.a}; --sb:${c.b};">
          <span class="pf-theme-swatch-preview"></span>
          <span class="pf-theme-name">${t.name}</span>
        </button>
      `; }).join("");
      themeGrid.querySelectorAll("[data-theme-id]").forEach((btn) => {
        btn.addEventListener("click", () => {
          ST.apply(btn.dataset.themeId);
          const t = ST.list.find((x) => x.id === btn.dataset.themeId);
          if (window.CurioToast && t) window.CurioToast.show(`Theme set to ${t.name}`, { icon: "\u2713" });
        });
      });
      document.addEventListener("curiolab:themechange", paint);
      paint();
    }

    /* ---------------- Preferences: sound toggle ---------------- */
    const soundSwitch = document.querySelector("[data-pf-sound-switch]");
    if (soundSwitch) {
      const isOn = localStorage.getItem(SOUND_KEY) !== "off";
      soundSwitch.classList.toggle("is-on", isOn);
      soundSwitch.addEventListener("click", () => {
        const nowOn = !soundSwitch.classList.contains("is-on");
        soundSwitch.classList.toggle("is-on", nowOn);
        localStorage.setItem(SOUND_KEY, nowOn ? "on" : "off");
        const headerToggle = document.querySelector("[data-sound-toggle]");
        if (headerToggle) headerToggle.setAttribute("aria-pressed", String(nowOn));
      });
    }

    /* ---------------- Danger zone ---------------- */
    function armButton(btn, confirmLabel, action) {
      let armed = false;
      const original = btn.textContent;
      btn.addEventListener("click", () => {
        if (!armed) {
          armed = true;
          btn.textContent = confirmLabel;
          btn.classList.add("is-confirm");
          setTimeout(() => { armed = false; btn.textContent = original; btn.classList.remove("is-confirm"); }, 3500);
          return;
        }
        armed = false;
        btn.textContent = original;
        btn.classList.remove("is-confirm");
        action();
      });
    }

    const resetProgressBtn = document.querySelector("[data-pf-reset-progress]");
    if (resetProgressBtn) {
      armButton(resetProgressBtn, "Click to confirm", () => {
        localStorage.removeItem(SCORES_KEY);
        localStorage.removeItem("curiolab-trophies-seen");
        localStorage.removeItem("curiolab-exam-log");
        Object.keys(localStorage).filter((k) => k.indexOf("curiolab-exam-v1:") === 0).forEach((k) => localStorage.removeItem(k));
        if (window.CurioToast) window.CurioToast.show("Quiz progress & trophies reset", { icon: "🗑️" });
        setTimeout(() => window.location.reload(), 900);
      });
    }

    const clearChatBtn = document.querySelector("[data-pf-clear-chat]");
    if (clearChatBtn) {
      armButton(clearChatBtn, "Click to confirm", () => {
        Object.keys(localStorage).filter((k) => k.startsWith("curiolab-chat-")).forEach((k) => localStorage.removeItem(k));
        if (window.CurioToast) window.CurioToast.show("AI Coach chat history cleared", { icon: "🧹" });
      });
    }

    const clearTodoBtn = document.querySelector("[data-pf-clear-todo]");
    if (clearTodoBtn) {
      armButton(clearTodoBtn, "Click to confirm", () => {
        localStorage.removeItem("curiolab-todos");
        if (window.CurioToast) window.CurioToast.show("To-Do list cleared", { icon: "🧹" });
      });
    }

    const deleteAccountBtn = document.querySelector("[data-pf-delete-account]");
    if (deleteAccountBtn) {
      if (user.mode === "demo") {
        armButton(deleteAccountBtn, "Click to confirm", async () => {
          try {
            const accounts = JSON.parse(localStorage.getItem("curiolab-local-accounts")) || {};
            delete accounts[(user.email || "").toLowerCase().trim()];
            localStorage.setItem("curiolab-local-accounts", JSON.stringify(accounts));
          } catch (e) { /* ignore */ }
          await window.CurioAuth.logout();
          window.location.href = "../index.html";
        });
      } else {
        deleteAccountBtn.disabled = true;
        deleteAccountBtn.textContent = "Contact support";
        deleteAccountBtn.title = "Account deletion for live accounts isn't wired up in this build — see Contact Us.";
        deleteAccountBtn.addEventListener("click", () => { window.location.href = "contact.html"; });
        deleteAccountBtn.disabled = false;
      }
    }
  });
})();
