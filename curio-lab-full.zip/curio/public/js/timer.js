// Curio Lab — Smart Study Timer
window.onLessonContentReady(() => {
  const display = document.querySelector("[data-timer-display]");
  if (!display) return;

  const MODES = { focus: 25 * 60, short: 5 * 60, long: 15 * 60 };
  let mode = "focus";
  let secondsLeft = MODES[mode];
  let running = false;
  let intervalId = null;

  const startBtn = document.querySelector("[data-timer-start]");
  const resetBtn = document.querySelector("[data-timer-reset]");
  const modeButtons = document.querySelectorAll("[data-timer-mode]");

  function render() {
    const m = Math.floor(secondsLeft / 60).toString().padStart(2, "0");
    const s = Math.floor(secondsLeft % 60).toString().padStart(2, "0");
    display.textContent = `${m}:${s}`;
    if (startBtn) startBtn.textContent = running ? "Pause" : "Start";
  }

  function tick() {
    if (secondsLeft <= 0) {
      clearInterval(intervalId);
      running = false;
      render();
      document.querySelector(".timer-widget")?.classList.add("is-done");
      if (window.Notification && Notification.permission === "granted") {
        new Notification("Curio Lab", { body: "Session complete — take a short break." });
      }
      return;
    }
    secondsLeft -= 1;
    render();
  }

  startBtn?.addEventListener("click", () => {
    running = !running;
    if (running) {
      document.querySelector(".timer-widget")?.classList.remove("is-done");
      intervalId = setInterval(tick, 1000);
    } else {
      clearInterval(intervalId);
    }
    render();
  });

  resetBtn?.addEventListener("click", () => {
    clearInterval(intervalId);
    running = false;
    secondsLeft = MODES[mode];
    document.querySelector(".timer-widget")?.classList.remove("is-done");
    render();
  });

  modeButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      mode = btn.dataset.timerMode;
      modeButtons.forEach((b) => b.classList.toggle("active", b === btn));
      clearInterval(intervalId);
      running = false;
      secondsLeft = MODES[mode];
      document.querySelector(".timer-widget")?.classList.remove("is-done");
      render();
    });
  });

  render();
});
