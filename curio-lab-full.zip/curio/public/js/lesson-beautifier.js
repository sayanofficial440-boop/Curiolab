// Curio Lab — Lesson Beautifier
//
// Two independent pieces, both config-driven via the same JSON-script-tag
// convention already used by js/educational-arcade.js and
// js/diagram-engine.js, so lesson authors only need to learn one pattern
// across the whole site:
//
// 1) "About This Topic" panel
//      <div class="lesson-about" data-lesson-about></div>
//      <script type="application/json" data-lesson-about-config>
//        { "summary": "...", "estimatedMinutes": 12,
//          "prerequisites": ["Basic algebra"],
//          "realWorldUses": ["Game physics engines", "Robotics"] }
//      <\/script>
//
// 2) Chart renderer (multiple per lesson, keyed like the arcade engine)
//      <div class="lesson-chart" data-lesson-chart="c1"></div>
//      <script type="application/json" data-lesson-chart-config="c1">
//        { "type": "line", "title": "World Population", "yLabel": "Billions",
//          "labels": ["1950","1990","2023"],
//          "series": [{ "name": "Population", "data": [2.5, 5.3, 8.1], "color": "--color-teal" }] }
//      <\/script>
//
// The chart renderer is intentionally a small dependency-free <canvas>
// implementation rather than pulling in the Chart.js CDN bundle — that
// matches a decision js/diagram-engine.js already made and documents in its
// own header comment (no render-blocking network fetch, no version drift,
// and it can read --color-* custom properties directly to stay in sync with
// js/theme.js and js/theme-sync.js's palettes, including re-rendering itself
// automatically when the user switches theme — something a generic charting
// library would need extra glue code for anyway).
(function () {
  "use strict";

  const STYLE_ID = "curio-lesson-beautifier-styles";
  const REDUCE_MOTION = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .lesson-about-panel {
        border: 1px solid var(--color-line); border-radius: var(--radius-md, 12px);
        background: linear-gradient(135deg, var(--color-bg-alt), var(--color-surface));
        padding: 1.1rem 1.3rem; margin: 1rem 0 1.4rem; overflow: hidden;
        max-height: 600px; opacity: 1; transition: max-height 420ms ease, opacity 420ms ease, padding 420ms ease;
      }
      .lesson-about-panel.collapsed { max-height: 0; opacity: 0; padding-top: 0; padding-bottom: 0; border-width: 0; margin: 0.4rem 0; }
      .lesson-about-head { display: flex; justify-content: space-between; align-items: center; gap: 0.8rem; cursor: pointer; }
      .lesson-about-head h4 { font-family: var(--font-display); font-size: 1.05rem; margin: 0; display: flex; align-items: center; gap: 0.5rem; }
      .lesson-about-time {
        font-family: var(--font-mono); font-size: 0.74rem; color: var(--color-ink-soft);
        border: 1px solid var(--color-line-strong); border-radius: 999px; padding: 0.2rem 0.65rem; white-space: nowrap;
      }
      .lesson-about-toggle { background: none; border: none; color: var(--color-ink-soft); font-size: 0.85rem; cursor: pointer; transition: transform 220ms ease; }
      .lesson-about-toggle.open { transform: rotate(180deg); }
      .lesson-about-summary { color: var(--color-ink-soft); font-size: 0.9rem; margin: 0.6rem 0 0.9rem; line-height: 1.55; }
      .lesson-about-cols { display: grid; grid-template-columns: 1fr 1fr; gap: 1.2rem; }
      @media (max-width: 640px) { .lesson-about-cols { grid-template-columns: 1fr; } }
      .lesson-about-cols h5 { font-family: var(--font-mono); font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.05em; color: var(--color-ink-soft); margin: 0 0 0.5rem; }
      .lesson-about-chips { display: flex; flex-wrap: wrap; gap: 0.4rem; }
      .lesson-about-chips span {
        font-size: 0.8rem; background: var(--color-surface); border: 1px solid var(--color-line-strong);
        border-radius: 999px; padding: 0.25rem 0.7rem;
      }
      .lesson-about-uses { margin: 0; padding-left: 1.1rem; font-size: 0.86rem; color: var(--color-ink); line-height: 1.6; }
      @media (prefers-reduced-motion: reduce) { .lesson-about-panel, .lesson-about-toggle { transition: none; } }

      .lesson-chart-shell {
        border: 1px solid var(--color-line); border-radius: var(--radius-md, 12px);
        background: var(--color-surface); box-shadow: var(--shadow-card); padding: 1.1rem 1.2rem 0.8rem; margin: 1rem 0;
      }
      .lesson-chart-title { font-family: var(--font-display); font-size: 1rem; margin: 0 0 0.7rem; }
      .lesson-chart-canvas-wrap { width: 100%; }
      .lesson-chart-canvas-wrap canvas { display: block; width: 100%; height: auto; }
      .lesson-chart-legend { display: flex; flex-wrap: wrap; gap: 0.9rem; margin: 0.6rem 0 0.3rem; font-size: 0.78rem; color: var(--color-ink-soft); }
      .lesson-chart-legend span { display: inline-flex; align-items: center; gap: 0.35rem; }
      .lesson-chart-legend i { width: 10px; height: 10px; border-radius: 3px; display: inline-block; }
    `;
    document.head.appendChild(style);
  }

  // --- About panel ---------------------------------------------------------
  function buildAboutPanel() {
    const mount = document.querySelector("[data-lesson-about]");
    const cfgScript = document.querySelector("[data-lesson-about-config]");
    if (!mount || !cfgScript || mount.dataset.aboutInitialized) return;
    let config;
    try { config = JSON.parse(cfgScript.textContent); } catch (err) {
      console.error("[lesson-beautifier] invalid about-panel config", err);
      return;
    }
    mount.dataset.aboutInitialized = "true";

    const prereqs = Array.isArray(config.prerequisites) ? config.prerequisites : [];
    const uses = Array.isArray(config.realWorldUses) ? config.realWorldUses : [];
    const minutes = Number(config.estimatedMinutes) > 0 ? Math.round(Number(config.estimatedMinutes)) : null;

    mount.className = "lesson-about-panel";
    mount.innerHTML = `
      <div class="lesson-about-head" data-about-toggle-trigger role="button" tabindex="0" aria-expanded="true">
        <h4>ℹ️ About this topic</h4>
        <div style="display:flex; align-items:center; gap:0.6rem;">
          ${minutes ? `<span class="lesson-about-time">⏱ ~${minutes} min</span>` : ""}
          <button type="button" class="lesson-about-toggle open" data-about-toggle aria-label="Collapse">▾</button>
        </div>
      </div>
      <div data-about-body>
        ${config.summary ? `<p class="lesson-about-summary">${escapeHtml(config.summary)}</p>` : ""}
        <div class="lesson-about-cols">
          ${prereqs.length ? `
            <div>
              <h5>Prerequisites</h5>
              <div class="lesson-about-chips">${prereqs.map((p) => `<span>${escapeHtml(p)}</span>`).join("")}</div>
            </div>` : ""}
          ${uses.length ? `
            <div>
              <h5>Where this shows up</h5>
              <ul class="lesson-about-uses">${uses.map((u) => `<li>${escapeHtml(u)}</li>`).join("")}</ul>
            </div>` : ""}
        </div>
      </div>
    `;

    const toggleBtn = mount.querySelector("[data-about-toggle]");
    const triggerRow = mount.querySelector("[data-about-toggle-trigger]");
    function toggle() {
      const collapsed = mount.classList.toggle("collapsed");
      toggleBtn.classList.toggle("open", !collapsed);
      triggerRow.setAttribute("aria-expanded", String(!collapsed));
    }
    triggerRow.addEventListener("click", toggle);
    triggerRow.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(); } });

    if (!REDUCE_MOTION) {
      mount.style.maxHeight = "0px";
      mount.style.opacity = "0";
      requestAnimationFrame(() => {
        mount.style.maxHeight = "";
        mount.style.opacity = "";
      });
    }
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = String(str);
    return div.innerHTML;
  }

  // --- Chart renderer --------------------------------------------------------
  function cssVar(name, fallback) {
    const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return v || fallback;
  }
  function resolveColor(value, fallback) {
    if (!value) return fallback;
    return value.startsWith("--") ? cssVar(value, fallback) : value;
  }

  const DEFAULT_PALETTE = ["--color-teal", "--color-coral", "--color-amber", "--color-moss", "--color-navy"];

  function buildChart(container, config, id) {
    const type = config.type === "bar" ? "bar" : "line";
    const labels = Array.isArray(config.labels) ? config.labels : [];
    const series = Array.isArray(config.series) && config.series.length ? config.series : [{ name: "Series", data: [] }];

    container.innerHTML = `
      <div class="lesson-chart-shell">
        ${config.title ? `<h4 class="lesson-chart-title">${escapeHtml(config.title)}</h4>` : ""}
        <div class="lesson-chart-canvas-wrap" data-chart-wrap><canvas data-chart-canvas></canvas></div>
        <div class="lesson-chart-legend" data-chart-legend></div>
      </div>
    `;
    const wrap = container.querySelector("[data-chart-wrap]");
    const canvas = container.querySelector("[data-chart-canvas]");
    const legend = container.querySelector("[data-chart-legend]");
    const ctx = canvas.getContext("2d");

    const seriesColors = series.map((s, i) => resolveColor(s.color, cssVar(DEFAULT_PALETTE[i % DEFAULT_PALETTE.length], "#2E8E80")));
    legend.innerHTML = series.map((s, i) => `<span><i style="background:${seriesColors[i]}"></i>${escapeHtml(s.name || `Series ${i + 1}`)}</span>`).join("");

    const DPR = Math.min(window.devicePixelRatio || 1, 2);
    const CSS_HEIGHT = 260;
    const PAD = { top: 18, right: 16, bottom: 30, left: 44 };

    function draw() {
      const cssWidth = wrap.clientWidth || 480;
      canvas.width = Math.round(cssWidth * DPR);
      canvas.height = Math.round(CSS_HEIGHT * DPR);
      canvas.style.height = CSS_HEIGHT + "px";
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      ctx.clearRect(0, 0, cssWidth, CSS_HEIGHT);

      const ink = cssVar("--color-ink", "#1B1B18");
      const inkSoft = cssVar("--color-ink-soft", "#6B6B63");
      const line = cssVar("--color-line", "rgba(0,0,0,0.1)");

      const allValues = series.flatMap((s) => (Array.isArray(s.data) ? s.data : []).map(Number)).filter((n) => !Number.isNaN(n));
      const maxVal = allValues.length ? Math.max(...allValues, 0) : 1;
      const minVal = Math.min(0, allValues.length ? Math.min(...allValues) : 0);
      const plotW = cssWidth - PAD.left - PAD.right;
      const plotH = CSS_HEIGHT - PAD.top - PAD.bottom;

      function yFor(v) {
        if (maxVal === minVal) return PAD.top + plotH;
        return PAD.top + plotH - ((v - minVal) / (maxVal - minVal)) * plotH;
      }
      function xFor(i, count) {
        if (count <= 1) return PAD.left + plotW / 2;
        return PAD.left + (i / (count - 1)) * plotW;
      }

      // Gridlines + y-axis labels (4 ticks)
      ctx.strokeStyle = line;
      ctx.fillStyle = inkSoft;
      ctx.font = "11px 'JetBrains Mono', monospace";
      ctx.textAlign = "right";
      ctx.textBaseline = "middle";
      const ticks = 4;
      for (let t = 0; t <= ticks; t++) {
        const v = minVal + ((maxVal - minVal) * t) / ticks;
        const y = yFor(v);
        ctx.beginPath();
        ctx.moveTo(PAD.left, y);
        ctx.lineTo(cssWidth - PAD.right, y);
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.fillText(formatTick(v), PAD.left - 8, y);
      }

      // X labels
      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      const maxLabels = Math.max(2, Math.floor(plotW / 60));
      const labelStep = Math.max(1, Math.ceil(labels.length / maxLabels));
      labels.forEach((lab, i) => {
        if (i % labelStep !== 0 && i !== labels.length - 1) return;
        ctx.fillText(String(lab), xFor(i, labels.length), CSS_HEIGHT - PAD.bottom + 8);
      });

      // Series
      series.forEach((s, si) => {
        const data = (Array.isArray(s.data) ? s.data : []).map(Number);
        const color = seriesColors[si];
        if (type === "bar") {
          const groupW = plotW / Math.max(1, data.length);
          const barW = Math.max(4, (groupW / series.length) * 0.7);
          data.forEach((v, i) => {
            const x = PAD.left + i * groupW + (groupW / series.length) * si + (groupW / series.length - barW) / 2;
            const y = yFor(v);
            ctx.fillStyle = color;
            ctx.fillRect(x, y, barW, yFor(minVal) - y);
          });
        } else {
          ctx.strokeStyle = color;
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          data.forEach((v, i) => {
            const x = xFor(i, data.length);
            const y = yFor(v);
            if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
          });
          ctx.stroke();
          ctx.fillStyle = color;
          data.forEach((v, i) => {
            const x = xFor(i, data.length);
            const y = yFor(v);
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, Math.PI * 2);
            ctx.fill();
          });
        }
      });

      // Axis line
      ctx.strokeStyle = ink;
      ctx.globalAlpha = 0.5;
      ctx.beginPath();
      ctx.moveTo(PAD.left, yFor(minVal));
      ctx.lineTo(cssWidth - PAD.right, yFor(minVal));
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    function formatTick(v) {
      if (Math.abs(v) >= 1000) return (v / 1000).toFixed(1).replace(/\.0$/, "") + "k";
      return Number.isInteger(v) ? String(v) : v.toFixed(1);
    }

    draw();
    const resizeObserver = new ResizeObserver(() => draw());
    resizeObserver.observe(wrap);

    // Re-render on theme change — theme.js/theme-sync.js/theme-engine.js all
    // work by setting CSS custom properties on <html>, so watching that
    // element's style attribute is a single hook that stays correct no
    // matter which of the three theme systems just fired.
    const themeObserver = new MutationObserver(() => draw());
    themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["style", "data-theme"] });
  }

  function initCharts() {
    document.querySelectorAll("[data-lesson-chart]").forEach((container) => {
      if (container.dataset.chartInitialized) return;
      const id = container.getAttribute("data-lesson-chart");
      const cfgScript = document.querySelector(`script[data-lesson-chart-config="${CSS.escape(id)}"]`);
      if (!cfgScript) return;
      let config;
      try { config = JSON.parse(cfgScript.textContent); } catch (err) {
        console.error("[lesson-beautifier] invalid chart config", id, err);
        return;
      }
      container.dataset.chartInitialized = "true";
      buildChart(container, config, id);
    });
  }

  function initAll() {
    injectStyles();
    buildAboutPanel();
    initCharts();
  }

  window.CurioLessonBeautifier = { init: initAll };

  if (window.onLessonContentReady) {
    window.onLessonContentReady(initAll);
  } else if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initAll, { once: true });
  } else {
    initAll();
  }
})();
