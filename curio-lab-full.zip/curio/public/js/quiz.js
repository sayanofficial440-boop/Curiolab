// Curio Lab — Quiz engine + score saving (feeds js/scoreboard.js)
(function () {
  const SCORES_KEY = "curiolab-scores";

  function saveScore(entry) {
    let all = [];
    try { all = JSON.parse(localStorage.getItem(SCORES_KEY)) || []; } catch (e) { all = []; }
    all.push(entry);
    localStorage.setItem(SCORES_KEY, JSON.stringify(all));
  }

  window.CurioScoreboard = { saveScore, key: SCORES_KEY };

  window.onLessonContentReady(() => {
    const shell = document.querySelector("[data-quiz]");
    if (!shell) return;

    let pool = [];
    try { pool = JSON.parse(document.querySelector("[data-quiz-data]").textContent); } catch (e) { pool = []; }

    const SESSION_LENGTH = Math.min(10, pool.length);
    const TOTAL = SESSION_LENGTH;
    let questions = [];

    function shuffled(arr) {
      const a = [...arr];
      for (let k = a.length - 1; k > 0; k--) {
        const j = Math.floor(Math.random() * (k + 1));
        [a[k], a[j]] = [a[j], a[k]];
      }
      return a;
    }

    // Pick a random subset of the question bank, and shuffle each question's
    // own answer options too, so both the set and the order are different
    // every attempt.
    function buildSession() {
      questions = shuffled(pool).slice(0, SESSION_LENGTH).map(prepare);
    }
    function prepare(q) {
      const order = shuffled(q.options.map((_, idx) => idx));
      return {
        q: q.q,
        options: order.map((idx) => q.options[idx]),
        correct: order.indexOf(q.correct),
        d: q.d === 1 || q.d === 3 ? q.d : 2,
        src: q,
      };
    }

    // Adaptive difficulty: start at Medium. Two right answers in a row move up a level,
    // a wrong answer moves down one. The next question is drawn from the pool at that level
    // (nearest level if it has run out), never repeating one already asked this session.
    const ADAPT_KEY = "curio.adaptive";
    const tagged = new Set(pool.map((q) => q.d)).size > 1;   // needs difficulty tags to adapt
    let adaptive = tagged && localStorage.getItem(ADAPT_KEY) !== "0";
    let level = 2, rightRun = 0;
    function pickNext() {
      const asked = new Set(questions.map((x) => x.src));
      const free = pool.filter((q) => !asked.has(q));
      if (!free.length) return null;
      const dOf = (q) => (q.d === 1 || q.d === 3 ? q.d : 2);
      const best = free.slice().sort((a, b) => Math.abs(dOf(a) - level) - Math.abs(dOf(b) - level) || Math.random() - 0.5)[0];
      return prepare(best);
    }
    // Community (opt-in): the server grades the attempt, so a joined learner's leaderboard XP can't be set from the browser.
    const CM = (() => {
      let cur = null;
      const lessonId = (location.pathname.match(/\/pages\/([^/]+\/[^/]+?)\.html$/) || [])[1];
      function key() {
        try { const u = JSON.parse(localStorage.getItem("curiolab-local-session")); if (!u || u.child || !u.email) return null;
          const s = JSON.parse(localStorage.getItem("curio.community.v1:" + String(u.email).toLowerCase())); return s && s.key; } catch (_) { return null; }
      }
      const call = (path, body) => fetch("/api/community/attempt/" + path, { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + key() }, body: JSON.stringify(body) }).then((r) => (r.ok ? r.json() : null)).catch(() => null);
      return {
        reset() { cur = null; },
        begin() { if (cur || !lessonId || !key()) return; cur = { id: null, answers: [] }; const mine = cur; call("start", { lesson: lessonId }).then((j) => { mine.id = j && j.attempt; }); },
        answer(srcQ, picked) { if (cur) { const k = pool.indexOf(srcQ); if (k >= 0) cur.answers.push({ i: k, p: picked }); } },
        finish() {
          const mine = cur; cur = null;
          if (!mine || !mine.id) return;
          call("finish", { attempt: mine.id, answers: mine.answers }).then((j) => {
            if (!j || !window.CurioToast) return;
            window.CurioToast.show(`+${j.xp_gained} community XP`, { icon: "🌍" });
            (j.new_badges || []).forEach((b, n) => setTimeout(() => window.CurioToast.show(`Community badge: ${b.name}`, { type: "trophy", icon: b.icon, duration: 5000 }), 900 + n * 600));
          });
        },
      };
    })();
    function startSession() {
      CM.reset();
      level = 2; rightRun = 0;
      if (adaptive) { questions = []; const first = pickNext(); if (first) questions.push(first); }
      else buildSession();
    }
    startSession();

    const LEVELS = { 1: "Easy", 2: "Medium", 3: "Hard" };
    const lessonName = shell.dataset.quizLesson || "Lesson";
    const subjectName = shell.dataset.quizSubject || "Subject";

    // This records a resume point only. It never inflates XP or completion;
    // those are earned when the learner actually submits a quiz below.
    if (window.CurioLearning) {
      window.CurioLearning.recordLessonVisit({
        title: lessonName,
        subject: subjectName,
        href: window.location.pathname + window.location.search,
      });
    }

    const progressEl = shell.querySelector("[data-quiz-progress]");
    const qEl = shell.querySelector("[data-quiz-question]");
    const optsEl = shell.querySelector("[data-quiz-options]");
    const nextBtn = shell.querySelector("[data-quiz-next]");
    const resultEl = shell.querySelector("[data-quiz-result]");
    const badgeEl = document.querySelector("[data-score-badge]");

    // Streak badge, injected once above the question.
    const streakEl = document.createElement("div");
    streakEl.className = "quiz-streak";
    qEl?.insertAdjacentElement("beforebegin", streakEl);

    if (tagged) {
      const bar = document.createElement("label");
      bar.className = "quiz-adaptive";
      bar.style.cssText = "display:flex;align-items:center;gap:8px;font-size:13px;margin:0 0 10px;cursor:pointer";
      bar.innerHTML = `<input type="checkbox" ${adaptive ? "checked" : ""}> <span>Adaptive difficulty <small style="opacity:.7">— questions get harder as you get them right</small></span>`;
      bar.querySelector("input").addEventListener("change", (e) => {
        adaptive = e.target.checked;
        try { localStorage.setItem(ADAPT_KEY, adaptive ? "1" : "0"); } catch (_) { /* ignore */ }
        startSession(); i = 0; correctCount = 0; streak = 0;
        shell.querySelector("[data-quiz-body]").style.display = "block"; resultEl.style.display = "none";
        renderQuestion();
      });
      shell.querySelector("[data-quiz-body]").insertAdjacentElement("beforebegin", bar);
    }

    let i = 0;
    let correctCount = 0;
    let streak = 0;
    let answered = false;

    function renderStreak() {
      if (streak >= 2) {
        streakEl.textContent = `🔥 ${streak} in a row`;
        streakEl.classList.add("show");
      } else {
        streakEl.classList.remove("show");
      }
    }

    // Mistake Notebook: wrong answers are saved for spaced review; a right answer
    // to a question that is already due in the notebook counts as a successful review.
    function recordForReview(q, pickedIdx, isCorrect) {
      const R = window.CurioReview;
      if (!R) return;
      try {
        const base = { q: q.q, lesson: lessonName, subject: subjectName, href: window.location.pathname };
        if (!isCorrect) {
          R.addMistake({ ...base, options: q.options, correct: q.options[q.correct], picked: q.options[pickedIdx] });
          if (window.CurioToast && !recordForReview.told) {
            recordForReview.told = true;
            window.CurioToast.show("Saved to your Mistake Notebook — it will come back for review.", { icon: "📓" });
          }
        } else {
          const id = R.idFor(lessonName, q.q);
          const hit = R.due().find((x) => x.id === id);
          if (hit) R.grade(id, 4);
        }
      } catch (_) { /* review is best-effort; never break the quiz */ }
    }

    function renderQuestion() {
      if (i === 0) CM.begin();
      answered = false;
      resultEl.style.display = "none";
      shell.querySelector("[data-quiz-body]").style.display = "block";
      progressEl.textContent = `Question ${i + 1} of ${TOTAL}` + (adaptive ? ` · ${LEVELS[questions[i].d]}` : "");
      qEl.textContent = questions[i].q;
      optsEl.innerHTML = "";
      nextBtn.classList.remove("show");
      renderStreak();

      questions[i].options.forEach((opt, idx) => {
        const btn = document.createElement("button");
        btn.className = "quiz-option";
        btn.textContent = opt;
        btn.addEventListener("click", () => {
          if (answered) return;
          answered = true;
          const isCorrect = idx === questions[i].correct;
          CM.answer(questions[i].src, questions[i].options[idx]);
          if (isCorrect) { correctCount += 1; streak += 1; rightRun += 1; if (rightRun >= 2 && level < 3) { level += 1; rightRun = 0; } }
          else { streak = 0; rightRun = 0; if (level > 1) level -= 1; }
          recordForReview(questions[i], idx, isCorrect);
          renderStreak();
          [...optsEl.children].forEach((c, ci) => {
            c.disabled = true;
            if (ci === questions[i].correct) c.classList.add("correct");
            else if (ci === idx) c.classList.add("wrong");
          });
          btn.classList.add(isCorrect ? "pop" : "shake");
          nextBtn.classList.add("show");
          nextBtn.textContent = i === TOTAL - 1 ? "See results" : "Next question →";
        });
        optsEl.appendChild(btn);
      });
    }

    function renderResult() {
      shell.querySelector("[data-quiz-body]").style.display = "none";
      resultEl.style.display = "block";
      const pct = Math.round((correctCount / TOTAL) * 100);
      const R = 52;
      const circ = 2 * Math.PI * R;
      resultEl.innerHTML = `
        <p class="eyebrow">Quiz complete</p>
        <div class="quiz-score-ring-wrap">
          <svg viewBox="0 0 130 130">
            <circle class="quiz-ring-track" cx="65" cy="65" r="${R}" fill="none" stroke-width="8"/>
            <circle class="quiz-ring-bar" cx="65" cy="65" r="${R}" fill="none" stroke-width="8"
              stroke-dasharray="${circ}" stroke-dashoffset="${circ}" transform="rotate(-90 65 65)"/>
          </svg>
          <div class="score-big" data-target="${correctCount}" data-total="${TOTAL}">0/${TOTAL}</div>
        </div>
        <p style="color:var(--color-ink-soft); margin-top:0.5rem;">${
          correctCount === TOTAL ? "Perfect score — nicely done." :
          correctCount / TOTAL >= 0.6 ? "Solid work. Review the ones you missed." :
          "Good first attempt — try the lesson again and re-take it."
        }</p>
        <button class="timer-btn" data-quiz-retry style="margin-top:1rem;">Retake quiz</button>
      `;
      resultEl.querySelector("[data-quiz-retry]").addEventListener("click", () => {
        startSession();
        i = 0; correctCount = 0; streak = 0; renderQuestion();
      });

      // Animate the ring + count-up score together.
      const ringBar = resultEl.querySelector(".quiz-ring-bar");
      const scoreBig = resultEl.querySelector(".score-big");
      requestAnimationFrame(() => {
        const offset = circ - (pct / 100) * circ;
        ringBar.style.transition = "stroke-dashoffset 0.9s cubic-bezier(0.22, 1, 0.36, 1)";
        ringBar.style.strokeDashoffset = String(offset);
      });
      if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
        const dur = 700;
        const start = performance.now();
        (function frame(now) {
          const p = Math.min((now - start) / dur, 1);
          scoreBig.textContent = `${Math.round(correctCount * p)}/${TOTAL}`;
          if (p < 1) requestAnimationFrame(frame);
        })(start);
      } else {
        scoreBig.textContent = `${correctCount}/${TOTAL}`;
      }
      if (window.CurioConfetti) window.CurioConfetti.burst(correctCount === TOTAL);

      const attempt = {
        lesson: lessonName,
        subject: subjectName,
        score: correctCount,
        total: TOTAL,
        date: new Date().toISOString(),
      };
      saveScore(attempt);
      CM.finish();
      // The legacy score list still powers older pages; this separate,
      // account-scoped record is the source for the smart dashboard.
      if (window.CurioLearning) window.CurioLearning.recordQuiz({
        ...attempt,
        href: window.location.pathname + window.location.search,
      });
      updateBadge();
      notifyResult();
      notifyNewTrophies();
    }

    function notifyResult() {
      if (!window.CurioToast) return;
      const pct = Math.round((correctCount / TOTAL) * 100);
      if (pct === 100) window.CurioToast.show(`Perfect score on ${lessonName}! 🎉`, { type: "trophy", icon: "🏆", duration: 5000 });
      else window.CurioToast.show(`Quiz complete — ${correctCount}/${TOTAL} on ${lessonName}`, { icon: "✅" });
    }

    function notifyNewTrophies() {
      if (!window.CurioToast || !window.CurioAchievements) return;
      const SEEN_KEY = "curiolab-trophies-seen";
      let seen = [];
      try { seen = JSON.parse(localStorage.getItem(SEEN_KEY)) || []; } catch (e) { seen = []; }
      const current = window.CurioAchievements.earned().filter((t) => t.earned);
      const newlyEarned = current.filter((t) => !seen.includes(t.id));
      newlyEarned.forEach((t, i) => {
        setTimeout(() => {
          window.CurioToast.show(`Trophy unlocked: ${t.name}`, { type: "trophy", icon: t.icon, duration: 5000 });
        }, i * 600 + 800);
      });
      localStorage.setItem(SEEN_KEY, JSON.stringify(current.map((t) => t.id)));
    }

    function updateBadge() {
      if (!badgeEl) return;
      let all = [];
      try { all = JSON.parse(localStorage.getItem(SCORES_KEY)) || []; } catch (e) { all = []; }
      const mine = all.filter((s) => s.lesson === lessonName);
      const best = mine.reduce((m, s) => Math.max(m, s.score / s.total), 0);
      badgeEl.innerHTML = `🏆 Best score on this lesson: <strong>${Math.round(best * 100)}%</strong> · ${mine.length} attempt${mine.length === 1 ? "" : "s"}`;
      badgeEl.classList.remove("pop");
      void badgeEl.offsetWidth;
      badgeEl.classList.add("pop");
    }

    nextBtn.addEventListener("click", () => {
      if (i < TOTAL - 1) {
        if (adaptive && questions.length <= i + 1) { const nq = pickNext(); if (nq) questions.push(nq); }
        i += 1; renderQuestion();
      }
      else { renderResult(); }
    });

    if (questions.length) renderQuestion();
    updateBadge();
  });
})();
