// Curio Lab — Community: live study rooms with a shared Pomodoro timer (the "Rooms" tab) and the moderator notices banner.
// Talks to backend/rooms.py and backend/moderation.py. The SERVER owns the clock: every poll says what time the server thinks it is,
// so everybody in a room sees the same seconds. This file only draws the countdown from `ends_at - server_now`.
(function () {
  "use strict";
  const SUBJECTS = ["Physics", "Chemistry", "Biology", "Mathematics", "English", "History", "Geography", "Computer Science"];
  const PRESETS = [["Classic", 25, 5, 15, 4], ["Deep work", 50, 10, 20, 3], ["Short bursts", 15, 3, 10, 4]];
  const PHASE = { idle: "Ready", focus: "Focus", break: "Short break", long: "Long break" };
  const mmss = (s) => { s = Math.max(0, Math.ceil(s)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; };
  const SOUND_KEY = "curio.rooms.sound";
  const reduced = () => window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // ================================================================== rooms
  function rooms(el, ctx) {
    const { CC, toast } = ctx, { esc, avatar } = CC;
    const baseTitle = document.title;
    let root = null, room = null, offset = 0, hasOffset = false, since = null, inflight = false, pollT = null, tickT = null;
    let prevKey = null, lastNudge = 0, legend = null, hostToolsFor = null, soundOn = false, actx = null, sig = "", booted = false;
    const onVis = () => { if (!document.hidden && alive()) refresh(); };
    try { soundOn = localStorage.getItem(SOUND_KEY) === "1"; } catch (_) {}

    const stop = () => { clearTimeout(pollT); clearInterval(tickT); pollT = tickT = null; document.title = baseTitle; document.removeEventListener("visibilitychange", onVis); };
    const alive = () => root && root.isConnected;
    const R = (path, body, method) => CC.api("/rooms" + path, body === undefined ? (method ? { method } : {}) : { body, method });

    function beep(kind) {
      if (!soundOn) return;
      try {
        actx = actx || new (window.AudioContext || window.webkitAudioContext)();
        const t = actx.currentTime;
        [[660, 0], [880, 0.2]].forEach(([f, d]) => {
          const o = actx.createOscillator(), g = actx.createGain();
          o.type = "sine"; o.frequency.value = kind === "focus" ? f : f * 0.75;
          g.gain.setValueAtTime(0.0001, t + d); g.gain.exponentialRampToValueAtTime(0.18, t + d + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.4);
          o.connect(g); g.connect(actx.destination); o.start(t + d); o.stop(t + d + 0.45);
        });
      } catch (_) { /* no audio: the screen still changes */ }
    }

    // ---------------------------------------------------------------- lobby
    async function lobby() {
      stop(); room = null; since = null; hasOffset = false; prevKey = null; hostToolsFor = null; sig = "";
      el.innerHTML = `<p class="cm-hint">Loading…</p>`;
      let j;
      try { j = await CC.api("/rooms"); } catch (e) { el.innerHTML = `<p class="cm-err">${esc(e.message)}</p>`; return; }
      root = el;
      if (j.current) return enter(j.current);
      const L = j.limits, muted = j.muted_until && j.muted_until > Date.now() / 1000;
      el.innerHTML = `<div class="rm-intro cm-card"><h3>Study with others, quietly</h3>
          <p class="cm-hint">Open a room, share the code, and start a timer everyone sees at the same moment. There is no chat: you just see who's studying, what they're working on, and you can cheer each other on.</p></div>
        ${muted ? `<p class="cm-err" role="alert">A moderator has paused your posting for now, so you can join rooms but not open one. See your messages at the top of this page.</p>` : ""}
        ${j.group_rooms.length ? `<h3 class="cm-h"><span>Live in your groups</span></h3><ul class="cm-s-cards">${j.group_rooms.map((g) => `<li class="cm-card"><div class="cm-s-top"><strong>${esc(g.name)}</strong><span class="cm-chip">${esc(g.group.name)}</span></div>
          <p class="cm-hint"><span class="rm-live" aria-hidden="true"></span>${g.here} studying now · ${esc(PHASE[g.phase] || "Ready")}</p><button type="button" class="cm-btn cm-sm cm-primary" data-enter="${esc(g.id)}">Join</button></li>`).join("")}</ul>` : ""}
        <div class="cm-s-grid">
          <form class="cm-card cm-s-form" data-join novalidate><h3>Join with a code</h3><label class="cm-sr" for="rm-code">Room code</label>
            <div class="cm-inline"><input id="rm-code" name="code" placeholder="ABCD-EFGH" autocomplete="off" autocapitalize="characters" maxlength="12" translate="no" /><button class="cm-btn cm-primary" type="submit">Join</button></div>
            <p class="cm-hint">Rooms are private. There's no list to browse: the person who opened the room shares the code. Everyone in the room can see each other's name and avatar.</p><p class="cm-err" data-jerr role="alert"></p></form>
          <form class="cm-card cm-s-form" data-new novalidate><h3>Open a room</h3>
            <label class="cm-sr" for="rm-name">Room name</label><input id="rm-name" name="name" placeholder="Room name (e.g. Quiet physics hour)" maxlength="40" ${muted ? "disabled" : ""} />
            <div class="rm-presets" role="group" aria-label="Timer presets">${PRESETS.map((p, i) => `<button type="button" class="cm-btn cm-sm" data-preset="${i}">${p[0]} <small>${p[1]}/${p[2]}</small></button>`).join("")}</div>
            <div class="cm-row"><label>Focus (minutes)<input name="focus" type="number" inputmode="numeric" min="${L.focus[0]}" max="${L.focus[1]}" value="${L.focus[2]}" /></label><label>Short break<input name="short" type="number" inputmode="numeric" min="${L.short[0]}" max="${L.short[1]}" value="${L.short[2]}" /></label></div>
            <div class="cm-row"><label>Long break<input name="long" type="number" inputmode="numeric" min="${L.long[0]}" max="${L.long[1]}" value="${L.long[2]}" /></label><label>Blocks before a long break<input name="rounds" type="number" inputmode="numeric" min="${L.rounds[0]}" max="${L.rounds[1]}" value="${L.rounds[2]}" /></label></div>
            <div class="cm-row"><label>Subject<select name="subject"><option value="">Any subject</option>${j.subjects.map((s) => `<option>${esc(s)}</option>`).join("")}</select></label>
              <label>Open it for a group<select name="group"><option value="">Nobody: invite by code</option>${j.groups.map((g) => `<option value="${esc(g.id)}">${esc(g.name)}</option>`).join("")}</select></label></div>
            <button class="cm-btn cm-primary" type="submit" ${muted ? "disabled" : ""}>Open room</button><p class="cm-err" data-nerr role="alert"></p></form></div>`;
      el.querySelectorAll("[data-enter]").forEach((b) => b.addEventListener("click", async () => { try { enter((await R("/join", { room: b.dataset.enter })).room); } catch (e) { toast(e.message, { icon: "⚠️" }); lobby(); } }));
      const f1 = el.querySelector("[data-join]");
      f1.addEventListener("submit", async (ev) => { ev.preventDefault(); const er = f1.querySelector("[data-jerr]"); er.textContent = ""; try { enter((await R("/join", { code: f1.code.value })).room); } catch (e) { er.textContent = e.message; } });
      const f2 = el.querySelector("[data-new]");
      f2.querySelectorAll("[data-preset]").forEach((b) => b.addEventListener("click", () => { const p = PRESETS[+b.dataset.preset]; f2.elements.focus.value = p[1]; f2.elements.short.value = p[2]; f2.elements.long.value = p[3]; f2.elements.rounds.value = p[4]; }));
      f2.addEventListener("submit", async (ev) => {
        ev.preventDefault(); const er = f2.querySelector("[data-nerr]"); er.textContent = "";
        try { const r = await R("/create", { name: f2.elements.name.value, subject: f2.elements.subject.value, group: f2.elements.group.value || undefined, focus: +f2.elements.focus.value, break: +f2.elements.short.value, long: +f2.elements.long.value, rounds: +f2.elements.rounds.value }); toast("Room open", { icon: "📚" }); enter(r.room); }
        catch (e) { er.textContent = e.message; }
      });
    }

    // ---------------------------------------------------------------- inside a room
    function enter(r) {
      stop(); room = r; root = document.createElement("div"); root.className = "rm-room"; root.setAttribute("aria-live", "off");
      el.innerHTML = ""; el.appendChild(root);
      since = null; hasOffset = false; prevKey = null; hostToolsFor = null; sig = ""; booted = false;
      root.innerHTML = `<button type="button" class="cm-link" data-leave-quick>← Leave room</button>
        <div class="cm-card rm-head"><div class="cm-s-top"><h3 data-name></h3><span class="cm-chip" data-subject hidden></span></div><p class="cm-hint" data-meta></p>
          <p class="cm-s-invite">Room code <code translate="no" data-code></code> <button type="button" class="cm-btn cm-sm" data-copy>Copy</button></p></div>
        <div class="cm-card rm-timer is-idle" data-timerbox>
          <div class="rm-ring" role="timer" aria-label="Shared timer"><svg viewBox="0 0 120 120" aria-hidden="true"><circle class="rm-track" cx="60" cy="60" r="52"></circle><circle class="rm-arc" cx="60" cy="60" r="52" data-arc></circle></svg>
            <div class="rm-clock"><strong data-time>0:00</strong><span data-phase>Ready</span></div></div>
          <ol class="rm-dots" data-dots aria-label="Focus blocks in this round"></ol>
          <p class="cm-hint rm-sub" data-sub></p>
          <div class="rm-controls" data-controls></div>
          <label class="rm-sound"><input type="checkbox" data-sound ${soundOn ? "checked" : ""} /> <span>Play a sound when the timer changes</span></label>
          <p class="cm-sr" role="status" aria-live="polite" data-say></p></div>
        <div class="cm-card rm-me"><h3>What are you working on?</h3><div class="cm-row"><label>I'm<select data-task></select></label><label>Subject<select data-subj><option value="">Any subject</option>${SUBJECTS.map((s) => `<option>${s}</option>`).join("")}</select></label></div></div>
        <div class="cm-card rm-cheers"><h3>Cheer the room on</h3><div class="rm-cheer-row" data-cheers></div><div class="rm-float" aria-hidden="true" data-float></div></div>
        <h3 class="cm-h"><span>In the room</span> <small data-count></small></h3><ul class="cm-rows rm-members" data-members></ul>
        <div data-hosttools></div>
        <div class="cm-btns cm-s-foot"><button type="button" class="cm-btn" data-leave>Leave room</button><button type="button" class="cm-btn" data-reportroom hidden>Report room</button></div>
        <p class="cm-err" data-err role="alert"></p>`;
      bind();
      apply(r, true);
      tickT = setInterval(tick, 250);
      schedule(1200);
    }

    const $ = (s) => root.querySelector(s);
    const id = () => room.id;
    const secsLeft = () => {
      const t = room.timer;
      if (t.phase === "idle") return t.focus * 60;
      if (t.paused) return t.left;
      return Math.max(0, t.ends_at - (Date.now() / 1000 + offset));
    };

    function schedule(ms) {
      clearTimeout(pollT);
      pollT = setTimeout(async () => { if (!alive()) return stop(); await refresh(); if (alive()) schedule(document.hidden ? 20000 : 5000); }, ms == null ? 5000 : ms);
    }
    async function refresh() {
      if (inflight || !alive()) return;
      inflight = true;
      try { const j = await CC.api(`/rooms/${encodeURIComponent(id())}/state` + (since != null ? `?since=${since}` : "")); if (alive()) apply(j.room); $("[data-err]") && ($("[data-err]").textContent = ""); }
      catch (e) {
        if (!alive()) return;
        if (e.status === 404 || e.status === 410) return gone(e.message);
        if (e.status !== 429 && $("[data-err]")) $("[data-err]").textContent = e.offline ? "Reconnecting… your timer keeps running." : e.message;
      } finally { inflight = false; }
    }
    function gone(msg) {
      stop();
      root.innerHTML = `<div class="cm-card cm-s-result"><h2>This room has closed</h2><p class="cm-hint">${esc(msg || "Rooms close when nobody has been in them for a while.")}</p><div class="cm-btns"><button type="button" class="cm-btn cm-primary" data-home>Back to rooms</button></div></div>`;
      root.querySelector("[data-home]").addEventListener("click", lobby);
    }

    // ---------------------------------------------------------------- painting
    function apply(r, first) {
      room = r;
      const srv = r.now - Date.now() / 1000;
      offset = hasOffset ? offset * 0.7 + srv * 0.3 : srv; hasOffset = true;
      legend = r.reacts_legend || (r.reacts && !Array.isArray(r.reacts) ? r.reacts : null) || legend;
      if (r.last_react != null && Array.isArray(r.reacts)) { if (since != null) r.reacts.forEach(floatReact); since = r.last_react; }
      $("[data-name]").textContent = r.name;
      const sj = $("[data-subject]"); sj.hidden = !r.subject; sj.textContent = r.subject || "";
      $("[data-meta]").textContent = (r.group ? `For the group “${r.group.name}” · ` : "") + `up to ${r.limit} people${r.locked ? " · locked" : ""}`;
      $("[data-code]").textContent = r.invite || "";
      const t = r.timer, key = t.phase + "|" + t.total + "|" + t.paused;
      const box = $("[data-timerbox]"); box.className = "cm-card rm-timer is-" + t.phase + (t.paused ? " is-paused" : "");
      $("[data-phase]").textContent = t.paused ? PHASE[t.phase] + " · paused" : PHASE[t.phase];
      $("[data-sub]").textContent = t.phase === "idle" ? `${t.focus} min focus · ${t.short} min break · a ${t.long} min break after every ${t.rounds} blocks` : `${t.total} focus block${t.total === 1 ? "" : "s"} done together today`;
      $("[data-dots]").innerHTML = Array.from({ length: t.rounds }, (_, i) => `<li class="${i < t.cycle ? "is-done" : (i === t.cycle && t.phase === "focus" ? "is-now" : "")}"><span class="cm-sr">${i < t.cycle ? "done" : "to do"}</span></li>`).join("");
      if (prevKey != null && key !== prevKey) {
        const prev = prevKey.split("|");           // [phase, total, paused]
        let msg = "", change = false;
        if (t.phase === "idle" && prev[0] !== "idle") msg = "The host stopped the timer.";
        else if (t.paused && prev[2] !== "true") msg = "The host paused the timer.";
        else if (!t.paused && prev[2] === "true" && prev[0] === t.phase) msg = "The timer is running again.";
        else if (prev[0] !== t.phase) { change = true; msg = prev[0] === "idle" ? "Focus time. Let's go." : t.phase === "focus" ? "Break's over. Focus time." : t.phase === "long" ? "Focus block done. Long break: you've earned it." : "Focus block done. Time for a break."; }
        if (msg) say(msg);
        if (change) { beep(t.phase); toast(msg, { icon: t.phase === "focus" ? "🍅" : "☕" }); }
      }
      prevKey = key;
      paintControls(); paintMembers(); paintMe(first || !booted); paintHost();
      $("[data-reportroom]").hidden = r.role === "owner";
      booted = true; tick();
    }
    function say(m) { const s = $("[data-say]"); if (s) { s.textContent = ""; setTimeout(() => { s.textContent = m; }, 50); } }

    function paintControls() {
      const t = room.timer, host = room.role === "owner", c = $("[data-controls]");
      const b = (a, label, cls) => `<button type="button" class="cm-btn ${cls || ""}" data-act="${a}">${label}</button>`;
      const html = !host ? `<p class="cm-hint">The host controls the timer. It runs for everyone at the same moment.</p>`
        : t.phase === "idle" ? b("start", "▶ Start focus", "cm-primary")
        : (t.paused ? b("resume", "▶ Resume", "cm-primary") : b("pause", "⏸ Pause")) + b("skip", "⏭ Skip") + b("reset", "⏹ Stop");
      if (c.dataset.sig !== html) { c.dataset.sig = html; c.innerHTML = html; }
    }
    function paintMembers() {
      const s = JSON.stringify(room.members) + room.role;
      $("[data-count]").textContent = `(${room.members.filter((m) => m.here).length} here)`;
      if (s === sig) return; sig = s;
      $("[data-members]").innerHTML = room.members.map((m) => `<li class="${m.you ? "is-me" : ""} ${m.here ? "" : "is-away"}">${avatar(m.name, m.avatar)}
        <span class="cm-name">${m.link ? `<a href="${esc(CC.profileUrl(m.handle))}">${esc(m.name)}</a>` : esc(m.name)}<small translate="no">@${esc(m.handle)}${m.role === "owner" ? " · host" : ""}</small>
          <small class="rm-doing">${m.here ? (esc([m.task, m.subject].filter(Boolean).join(" · ")) || "&nbsp;") : "Away"}</small></span>
        <span class="cm-pts"><span translate="no">${m.blocks}</span><small>blocks</small></span>
        <span class="cm-btns">${!m.you && room.role === "owner" ? `<button type="button" class="cm-btn cm-sm" data-kick="${esc(m.handle)}" aria-label="Remove ${esc(m.name)}">Remove</button>` : ""}${!m.you ? `<button type="button" class="cm-btn cm-sm" data-reportp="${esc(m.handle)}" aria-label="Report ${esc(m.name)}">Report</button>` : ""}</span></li>`).join("");
    }
    function paintMe(force) {
      const task = $("[data-task]"), mine = room.members.find((m) => m.you) || {};
      if (!task.options.length) task.innerHTML = `<option value="">choosing…</option>` + (room.tasks || []).map((x) => `<option>${esc(x)}</option>`).join("");
      if (force) { task.value = mine.task || ""; $("[data-subj]").value = mine.subject || ""; }
      const ch = $("[data-cheers]");
      if (!ch.children.length) ch.innerHTML = Object.entries(legend || {}).map(([k, e]) => `<button type="button" class="cm-btn rm-cheer" data-react="${esc(k)}" aria-label="Cheer: ${esc(k)}"><span aria-hidden="true">${e}</span></button>`).join("");
    }
    function paintHost() {
      const host = room.role === "owner", h = $("[data-hosttools]");
      if (!host) { h.innerHTML = ""; hostToolsFor = null; return; }
      const idle = room.timer.phase === "idle", k = room.id + "|" + idle;
      if (hostToolsFor !== k) {
        hostToolsFor = k;
        const t = room.timer;
        h.innerHTML = `<details class="cm-card rm-host"><summary>Host tools</summary>
          <form class="cm-s-form" data-settings novalidate><label>Room name<input name="name" maxlength="40" value="${esc(room.name)}" /></label>
            <div class="cm-row"><label>Focus (minutes)<input name="focus" type="number" min="10" max="90" value="${t.focus}" ${idle ? "" : "disabled"} /></label><label>Short break<input name="short" type="number" min="3" max="20" value="${t.short}" ${idle ? "" : "disabled"} /></label></div>
            <div class="cm-row"><label>Long break<input name="long" type="number" min="10" max="45" value="${t.long}" ${idle ? "" : "disabled"} /></label><label>Blocks before a long break<input name="rounds" type="number" min="2" max="8" value="${t.rounds}" ${idle ? "" : "disabled"} /></label></div>
            ${idle ? "" : `<p class="cm-hint">Timer lengths can only change while the timer is stopped.</p>`}
            <label>Subject<select name="subject"><option value="">Any subject</option>${SUBJECTS.map((s) => `<option ${s === room.subject ? "selected" : ""}>${s}</option>`).join("")}</select></label>
            <div class="cm-btns"><button class="cm-btn cm-primary" type="submit">Save</button></div><p class="cm-err" data-serr role="alert"></p></form>
          <div class="cm-btns rm-hostbtns"><button type="button" class="cm-btn cm-sm" data-lock></button><button type="button" class="cm-btn cm-sm" data-rotate>New code</button><button type="button" class="cm-btn cm-sm" data-close>Close room for everyone</button></div></details>`;
      }
      const lk = h.querySelector("[data-lock]"); if (lk) lk.textContent = room.locked ? "Unlock room" : "Lock room (no new people)";
    }

    function tick() {
      if (!room) return;
      if (!alive()) return stop();                       // the learner switched tabs: the panel was replaced
      const t = room.timer, left = secsLeft(), len = t.phase === "idle" ? t.focus * 60 : t.length;
      $("[data-time]").textContent = mmss(left);
      const arc = $("[data-arc]"), C = 2 * Math.PI * 52;
      arc.style.strokeDasharray = C; arc.style.strokeDashoffset = t.phase === "idle" ? 0 : C * (1 - Math.max(0, Math.min(1, left / Math.max(1, len))));
      document.title = t.phase === "idle" ? baseTitle : `${mmss(left)} · ${PHASE[t.phase]} — Curio Lab`;
      // our copy of the clock says the phase just ended: ask the server what comes next (at most once every 1.5 s)
      if (t.phase !== "idle" && !t.paused && left <= 0 && Date.now() - lastNudge > 1500) { lastNudge = Date.now(); refresh(); }
    }

    function floatReact(x) {
      const box = root && root.querySelector("[data-float]"); if (!box) return;
      const s = document.createElement("span"); s.className = "rm-bubble"; s.style.left = 8 + Math.random() * 80 + "%"; s.textContent = x.emoji;
      s.title = x.you ? "You" : x.name; box.appendChild(s); setTimeout(() => s.remove(), reduced() ? 1400 : 2600);
    }

    // ---------------------------------------------------------------- actions (one delegated handler: the lists re-render)
    async function report(what, send) {
      if (!window.CurioReport) { toast("The report form didn't load. Refresh the page and try again.", { icon: "⚠️" }); return false; }
      return window.CurioReport.open({ what, onSend: send });
    }
    function bind() {
      root.addEventListener("click", async (ev) => {
        const t = ev.target.closest("button"); if (!t) return;
        const err = (e) => toast(e.message, { icon: "⚠️" });
        try {
          if (t.dataset.leaveQuick !== undefined || t.dataset.leave !== undefined) { await R(`/${encodeURIComponent(id())}/leave`, {}); toast("You left the room", { icon: "👋" }); return lobby(); }
          if (t.dataset.copy !== undefined) { try { await navigator.clipboard.writeText(room.invite); toast("Code copied", { icon: "📋" }); } catch (_) { toast(room.invite, { icon: "📋" }); } return; }
          if (t.dataset.act) { apply((await R(`/${encodeURIComponent(id())}/control`, { action: t.dataset.act })).room); return; }
          if (t.dataset.react) { await R(`/${encodeURIComponent(id())}/react`, { kind: t.dataset.react }); floatReact({ emoji: (legend && legend[t.dataset.react]) || "👏", you: true }); return; }
          if (t.dataset.kick) { if (!confirm("Remove this person from the room? They won't be able to come back.")) return; await R(`/${encodeURIComponent(id())}/kick`, { handle: t.dataset.kick }); return refresh(); }
          if (t.dataset.reportp) { const h = t.dataset.reportp; const sent = await report("profile", (x) => CC.api("/report", { body: { handle: h, category: x.category, reason: x.reason } })); if (sent) { toast(`Thanks. @${h} is hidden from you now.`, { icon: "🚩" }); refresh(); } return; }
          if (t.dataset.reportroom !== undefined) { const sent = await report("room", (x) => R(`/${encodeURIComponent(id())}/report`, { category: x.category, reason: x.reason })); if (sent) toast("Thanks, we'll take a look", { icon: "🚩" }); return; }
          if (t.dataset.lock !== undefined) { await R(`/${encodeURIComponent(id())}/lock`, { locked: !room.locked }); return refresh(); }
          if (t.dataset.rotate !== undefined) { if (!confirm("Make a new room code? The old one stops working.")) return; apply((await R(`/${encodeURIComponent(id())}/rotate`, {})).room); toast("New code", { icon: "🔑" }); return; }
          if (t.dataset.close !== undefined) { if (!confirm("Close this room for everyone?")) return; await R(`/${encodeURIComponent(id())}`, undefined, "DELETE"); toast("Room closed", { icon: "🗑️" }); return lobby(); }
        } catch (e) { if (e.status === 404 || e.status === 410) gone(e.message); else err(e); }
      });
      root.addEventListener("change", async (ev) => {
        const t = ev.target;
        if (t.matches("[data-task],[data-subj]")) { try { await R(`/${encodeURIComponent(id())}/me`, { task: $("[data-task]").value, subject: $("[data-subj]").value }); refresh(); } catch (e) { toast(e.message, { icon: "⚠️" }); } }
        if (t.matches("[data-sound]")) { soundOn = t.checked; try { localStorage.setItem(SOUND_KEY, soundOn ? "1" : "0"); } catch (_) {} if (soundOn) beep("focus"); }
      });
      root.addEventListener("submit", async (ev) => {
        const f = ev.target.closest("[data-settings]"); if (!f) return; ev.preventDefault();
        const body = { name: f.elements.name.value, subject: f.elements.subject.value };
        if (!f.elements.focus.disabled) Object.assign(body, { focus: +f.elements.focus.value, break: +f.elements.short.value, long: +f.elements.long.value, rounds: +f.elements.rounds.value });
        try { hostToolsFor = null; apply((await R(`/${encodeURIComponent(id())}/settings`, body)).room); toast("Saved", { icon: "✅" }); }
        catch (e) { f.querySelector("[data-serr]").textContent = e.message; }
      });
      document.addEventListener("visibilitychange", onVis);
    }

    lobby();
  }

  // ================================================================== moderator notices (banner at the top of the Community page)
  async function notices(el, ctx) {
    const { CC } = ctx, { esc } = CC;
    if (!ctx.count && !(ctx.muted_until && ctx.muted_until > Date.now() / 1000)) { el.innerHTML = ""; return; }
    const until = ctx.muted_until && ctx.muted_until > Date.now() / 1000 ? new Date(ctx.muted_until * 1000).toLocaleString() : "";
    el.innerHTML = `<div class="cm-card cm-notices"><p><strong>${ctx.count ? `You have ${ctx.count} new message${ctx.count === 1 ? "" : "s"} from the moderators.` : "Posting is paused."}</strong>${until ? ` <span class="cm-hint">Posting is paused until ${esc(until)}. You can still read, vote and study.</span>` : ""}</p>
      <button type="button" class="cm-btn cm-sm" data-read>Read</button><div data-list></div></div>`;
    const btn = el.querySelector("[data-read]");
    btn.addEventListener("click", async () => {
      const list = el.querySelector("[data-list]");
      if (list.innerHTML) { list.innerHTML = ""; btn.textContent = "Read"; return; }
      try {
        const j = await CC.api("/notices");
        list.innerHTML = `<ul class="cm-notice-list">${j.notices.map((n) => `<li class="${n.seen ? "" : "is-new"}"><span>${esc(n.text)}</span> <small>${esc(new Date(n.created_at * 1000).toLocaleDateString())}</small></li>`).join("") || "<li>No messages.</li>"}</ul><button type="button" class="cm-btn cm-sm" data-seen>Mark all as read</button>`;
        btn.textContent = "Hide";
        const sb = list.querySelector("[data-seen]"); sb && sb.addEventListener("click", async () => { await CC.api("/notices/seen", { body: {} }); el.innerHTML = ""; });
      } catch (e) { list.innerHTML = `<p class="cm-err">${esc(e.message)}</p>`; }
    });
  }

  window.CurioSocial = Object.assign(window.CurioSocial || {}, { rooms, notices });
})();
