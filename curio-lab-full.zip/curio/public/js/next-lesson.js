// Curio Lab — "Next for you": recommends the next lesson from the learner's weak spots.
//
// Weakness per lesson = questions still open in the Mistake Notebook (not yet mastered) plus a
// failed or low quiz score. The weakest lesson that sits in a course path (js/courses-data.js) decides:
//   1. foundation - a lesson shortly before it in the path that hasn't been passed yet
//   2. review     - the weak lesson itself, when its quiz isn't passed (60%+)
//   3. next       - the following lesson in the path, when the weak one is passed but mistakes remain
// Returns null when nothing is weak, so callers keep their normal suggestions.
// Everything is computed from what the learner actually did; nothing is sample data.
(function () {
  "use strict";
  if (window.CurioNext) return;
  const REACH = 2; // how many lessons before a weak one are checked for a missing foundation
  const rel = (h) => { const m = String(h || "").split("#")[0].split("?")[0].match(/pages\/.+$/); return m ? m[0] : ""; };
  const plural = (n, w) => n + " " + w + (n === 1 ? "" : "s");

  function openMistakes() {
    const R = window.CurioReview, out = {};
    if (!R || typeof R.all !== "function") return out;
    const mastered = R.MASTERED_AT || 21;
    R.all().forEach((x) => { const h = rel(x.href); if (h && !(x.interval >= mastered)) out[h] = (out[h] || 0) + 1; });
    return out;
  }

  // progress: CurioLearning lessonProgress (or any list of { href, best, status })
  function recommend(progress) {
    const C = window.CurioCourses;
    if (!Array.isArray(C) || !C.length) return null;
    const by = {};
    (progress || []).forEach((p) => { const h = rel(p.href); if (h) by[h] = p; });
    const miss = openMistakes();
    const passed = (h) => !!by[h] && by[h].status === "completed";

    let top = null;
    C.forEach((course) => course.lessons.forEach((l, i) => {
      const p = by[l.h], m = miss[l.h] || 0;
      let s = m;
      if (p && p.best != null) s += p.best < 60 ? 2 + (60 - p.best) / 20 : p.best < 75 ? 0.75 : 0;
      if (s >= 1 && (!top || s > top.s)) top = { course, i, l, s };
    }));
    if (!top) return null;

    const { course, i, l } = top, p = by[l.h], m = miss[l.h] || 0;
    const facts = [m ? plural(m, "missed question") : "", p && p.best != null ? "best quiz " + p.best + "%" : ""].filter(Boolean).join(", ");
    const out = (lesson, kind, short, reason) => ({
      kind, tag: "NEXT",
      lesson: { h: lesson.h, t: lesson.t, subject: course.subject },
      weak: { h: l.h, t: l.t, misses: m, best: p ? p.best : null },
      short, reason,
    });

    for (let j = Math.max(0, i - REACH); j < i; j++) {
      const f = course.lessons[j];
      if (!passed(f.h)) {
        return out(f, "foundation", course.subject + " · builds the base for " + l.t + " (" + facts + ")",
          l.t + " is a weak spot (" + facts + "), and " + f.t + ", which comes before it in the " + course.title + ", isn't passed yet. Start there.");
      }
    }
    if (!passed(l.h)) {
      return out(l, "review", course.subject + " · weak spot: " + facts + " · 60% completes it",
        l.t + " is your weakest lesson (" + facts + "). Reach 60% on its quiz to complete it.");
    }
    const next = course.lessons.slice(i + 1).find((x) => !passed(x.h));
    if (next) {
      return out(next, "next", course.subject + " · next in the path · " + plural(m, "open mistake") + " in " + l.t,
        l.t + " still has " + plural(m, "open mistake") + " in the Mistake Notebook. Clear them, then continue with " + next.t + ".");
    }
    return out(l, "review", course.subject + " · " + plural(m, "open mistake") + " left to clear",
      "You've finished the " + course.title + ". Clear the " + plural(m, "open mistake") + " in " + l.t + " to lock it in.");
  }

  window.CurioNext = { recommend, rel };
})();
