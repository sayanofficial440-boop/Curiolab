// Curio Lab — Toast notifications
(function () {
  let stack;
  function ensureStack() {
    if (stack) return stack;
    stack = document.createElement("div");
    stack.className = "toast-stack";
    document.body.appendChild(stack);
    return stack;
  }

  function show(message, opts = {}) {
    const { type = "info", icon = "✅", duration = 4000 } = opts;
    const s = ensureStack();
    const el = document.createElement("div");
    el.className = `toast ${type}`;
    el.innerHTML = `<span class="toast-icon">${icon}</span><span>${message}</span>`;
    s.appendChild(el);
    setTimeout(() => {
      el.classList.add("leaving");
      setTimeout(() => el.remove(), 220);
    }, duration);
  }

  window.CurioToast = { show };
})();
