/* Parent page: talks to /api/coppa/consent/<token>. The token comes from the emailed link (?t=...), is sent only to
   this site's own server, and is removed from the address bar after loading so it isn't left in history or screenshots. */
(function () {
  "use strict";
  var root = document.querySelector("[data-parent-root]");
  var token = new URLSearchParams(location.search).get("t") || "";
  try { history.replaceState(null, "", location.pathname); } catch (e) {}
  function esc(s) { var d = document.createElement("div"); d.textContent = s == null ? "" : String(s); return d.innerHTML; }
  function date(ts) { return ts ? new Date(ts * 1000).toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" }) : ""; }
  function api(path, opts) {
    return fetch("/api/coppa/consent/" + encodeURIComponent(token) + path, opts || {}).then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { ok: r.ok, status: r.status, j: j }; }); });
  }
  function msg(html) { root.innerHTML = html; }
  if (!token) { msg("<p>This page needs the private link from the email we sent you. If you can't find it, the child can ask for a new one when they sign up again.</p>"); return; }

  function list(a) { return "<ul style='list-style:disc;padding-left:1.3rem;margin:.4rem 0 1rem'>" + a.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul>"; }
  function render(i) {
    var h = "<h2 style='margin-top:0'>Account for “" + esc(i.nickname) + "”</h2>";
    h += "<h3>What we collect</h3>" + list(i.collected) + "<h3>What we don't</h3>" + list(i.not_collected);
    if (i.status === "pending") {
      h += "<p>Do you give permission for this child to have a Curio Lab account? Declining deletes your email address from our records straight away.</p>" +
        "<div style='display:flex;gap:.6rem;flex-wrap:wrap'><button class='cl-submit-btn' data-act='approve' type='button'><span class='btn-label'>Yes, approve</span></button>" +
        "<button class='cl-submit-btn' data-act='decline' type='button' style='background:transparent;color:inherit;border:1px solid currentColor'><span class='btn-label'>No, decline</span></button></div>";
    } else if (i.status === "granted") {
      h += "<p><strong>Approved</strong> on " + esc(date(i.decided_at)) + ". You can change your mind at any time.</p>";
      if (i.certificates && i.certificates.length) h += "<h3>Certificates</h3>" + list(i.certificates.map(function (c) { return c.tier + " (" + c.code + ")"; }));
      h += "<div style='display:flex;gap:.6rem;flex-wrap:wrap'><button class='cl-submit-btn' data-act='export' type='button'><span class='btn-label'>Download data (JSON)</span></button>" +
        "<button class='cl-submit-btn' data-act='delete' type='button' style='background:transparent;color:inherit;border:1px solid currentColor'><span class='btn-label'>Delete account and data</span></button></div>" +
        "<p><small>Quiz progress is stored in your child's browser, not on our server. Clear it from that browser's site settings or the child's Profile page.</small></p>";
    } else if (i.status === "declined") {
      h += "<p>You declined on " + esc(date(i.decided_at)) + ". Your email address has been removed from our records.</p>";
    }
    h += "<p><small>Questions" + (i.contact ? ": <a href='mailto:" + esc(i.contact) + "'>" + esc(i.contact) + "</a>" : "? Use the contact page") + ". Operator: " + esc(i.controller) + ". <a href='privacy.html#children'>Children's privacy</a></small></p>";
    msg(h);
    root.querySelectorAll("[data-act]").forEach(function (b) { b.addEventListener("click", function () { act(b.dataset.act); }); });
  }
  function act(a) {
    if (a === "export") { location.href = "/api/coppa/consent/" + encodeURIComponent(token) + "/export"; return; }
    if (a === "delete" && !confirm("Delete this account and everything linked to it? This can't be undone.")) return;
    var req = a === "delete" ? api("/delete", { method: "POST" }) : api("/decision", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ decision: a }) });
    req.then(function (r) {
      if (!r.ok) { msg("<p role='alert'>" + esc(r.j.error || "Something went wrong.") + "</p>"); return; }
      if (a === "delete") { msg("<p>Done. The account, its certificates and your email address have been deleted. The sign-in on your child's device stops working the next time it connects.</p>"); return; }
      // keep the token for this session only (not in the URL) so the parent can see the result
      api("").then(function (x) { x.ok ? render(x.j) : msg("<p>Thank you. " + (a === "approve" ? "A confirmation email with the same private link is on its way." : "Your email address has been removed.") + "</p>"); });
    });
  }
  api("").then(function (r) { r.ok ? render(r.j) : msg("<p role='alert'>" + esc(r.j.error || "This link isn't valid.") + "</p>"); })
    .catch(function () { msg("<p role='alert'>We couldn't reach the server. Please try again later.</p>"); });
})();
