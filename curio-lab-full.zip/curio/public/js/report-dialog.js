// Curio Lab — one report dialog for everything a learner can report (profiles, lesson posts, study groups, study rooms).
// Replaces the browser's prompt() box: pick what's wrong, optionally add a note, send. Nothing is sent until they press Report.
//   CurioReport.open({ what: "post", onSend: async ({ category, reason }) => {...} })  ->  resolves true when sent, false when cancelled.
// The category list comes from the server (GET /api/community/report-options) so it can change in one place; this copy is the fallback.
(function () {
  "use strict";
  if (window.CurioReport) return;
  const FALLBACK = [
    ["spam", "Spam or advertising"], ["bullying", "Bullying, hate or threats"], ["inappropriate", "Not suitable for school"],
    ["personal", "Shares personal details"], ["selfharm", "Someone may need help"], ["wrong", "Wrong or misleading"], ["other", "Something else"],
  ];
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const CSS = `.rp-overlay{position:fixed;inset:0;z-index:100000;display:grid;place-items:center;padding:1rem;background:rgba(10,14,24,.55)}
.rp-dialog{width:min(30rem,100%);max-height:calc(100vh - 2rem);overflow:auto;background:var(--color-surface,#fff);color:var(--color-ink,#12213B);border:1px solid var(--color-line-strong,#c9d1dd);border-radius:var(--radius-md,14px);box-shadow:0 20px 60px rgba(0,0,0,.35);padding:1.2rem 1.3rem;font-family:inherit}
.rp-dialog h2{margin:0 0 .3rem;font-size:1.15rem;font-family:var(--font-display,inherit)}
.rp-note,.rp-help{margin:.2rem 0 .8rem;font-size:.88rem;line-height:1.5;color:var(--color-ink-soft,#55627a)}
.rp-dialog fieldset{border:0;padding:0;margin:0 0 .8rem;display:grid;gap:.4rem}
.rp-opt{display:flex;gap:.65rem;align-items:center;min-height:44px;padding:.35rem .7rem;border:1px solid var(--color-line,#dde3ec);border-radius:10px;cursor:pointer}
.rp-opt:has(input:checked){border-color:var(--color-teal,#2a9d8f);background:var(--color-bg-alt,#f2f5f9)}
.rp-opt input{width:1.1rem;height:1.1rem;accent-color:var(--color-teal,#2a9d8f)}
.rp-more{display:grid;gap:.3rem;font-size:.9rem;font-weight:600}.rp-more small{font-weight:400;color:var(--color-ink-soft,#55627a)}
.rp-more textarea{width:100%;box-sizing:border-box;padding:.55rem .7rem;border:1px solid var(--color-line-strong,#c9d1dd);border-radius:10px;background:var(--color-bg,#fff);color:inherit;font:inherit;resize:vertical}
.rp-err{color:var(--color-coral,#d64545);font-size:.9rem;min-height:0;margin:.2rem 0}.rp-err:empty{display:none}
.rp-actions{display:flex;gap:.6rem;justify-content:flex-end;margin-top:.6rem}
.rp-btn{min-height:44px;padding:.5rem 1.2rem;border-radius:999px;border:1px solid var(--color-line-strong,#c9d1dd);background:var(--color-surface,#fff);color:inherit;font:inherit;font-weight:600;cursor:pointer}
.rp-btn:hover:not(:disabled){border-color:var(--color-ink,#12213B)}.rp-btn:disabled{opacity:.5;cursor:not-allowed}
.rp-primary{background:var(--solid-bg,var(--color-navy,#12213B));color:var(--solid-ink,#fff);border-color:var(--solid-bg,var(--color-navy,#12213B))}
.rp-sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
.rp-btn:focus-visible,.rp-opt:focus-within,.rp-more textarea:focus-visible{outline:3px solid var(--color-teal,#2a9d8f);outline-offset:2px}`;
  function styles() { if (document.getElementById("rp-style")) return; const st = document.createElement("style"); st.id = "rp-style"; st.textContent = CSS; document.head.appendChild(st); }
  let cached = null;
  async function categories() {
    if (cached) return cached;
    try {
      const r = await fetch("/api/community/report-options", { headers: { Accept: "application/json" } });
      if (r.ok && (r.headers.get("content-type") || "").includes("json")) { const j = await r.json(); if (j.categories && j.categories.length) return (cached = j.categories.map((c) => [c.id, c.label])); }
    } catch (_) { /* offline: use the built-in list */ }
    return (cached = FALLBACK);
  }
  const HELP = "If someone is in danger right now, tell a parent, a teacher or another adult you trust straight away.";
  const NOTE = { post: "It's hidden from you straight away. A moderator will look at it.", profile: "This profile is hidden from you straight away. A moderator will look at it.", group: "A moderator will look at it. Your report is private.", room: "A moderator will look at it. Your report is private." };

  function open(opts) {
    opts = opts || {};
    return new Promise(async (resolve) => {
      styles();
      const cats = await categories();
      const prev = document.activeElement;
      const wrap = document.createElement("div");
      wrap.className = "rp-overlay";
      wrap.innerHTML = `<div class="rp-dialog" role="dialog" aria-modal="true" aria-labelledby="rp-title">
        <h2 id="rp-title">Report this ${esc(opts.what || "content")}</h2>
        <p class="rp-note">${esc(NOTE[opts.what] || NOTE.group)}</p>
        <form novalidate>
          <fieldset><legend class="rp-sr">What is wrong?</legend>
            ${cats.map(([id, label], i) => `<label class="rp-opt"><input type="radio" name="category" value="${esc(id)}" /><span>${esc(label)}</span></label>`).join("")}
          </fieldset>
          <label class="rp-more"><span>Anything else a moderator should know? <small>(optional)</small></span><textarea name="reason" rows="2" maxlength="300"></textarea></label>
          <p class="rp-help">${esc(HELP)}</p>
          <p class="rp-err" role="alert"></p>
          <div class="rp-actions"><button type="button" class="rp-btn" data-cancel>Cancel</button><button type="submit" class="rp-btn rp-primary">Report</button></div>
        </form></div>`;
      document.body.appendChild(wrap);
      const dlg = wrap.querySelector(".rp-dialog"), form = wrap.querySelector("form"), er = wrap.querySelector(".rp-err");
      const close = (v) => { document.removeEventListener("keydown", onKey, true); wrap.remove(); try { prev && prev.focus && prev.focus(); } catch (_) {} resolve(v); };
      function onKey(ev) {
        if (ev.key === "Escape") { ev.preventDefault(); close(false); return; }
        if (ev.key !== "Tab") return;
        const f = [...dlg.querySelectorAll("input,textarea,button")].filter((x) => !x.disabled);
        const first = f[0], last = f[f.length - 1];
        if (ev.shiftKey && document.activeElement === first) { ev.preventDefault(); last.focus(); }
        else if (!ev.shiftKey && document.activeElement === last) { ev.preventDefault(); first.focus(); }
      }
      document.addEventListener("keydown", onKey, true);
      wrap.addEventListener("mousedown", (ev) => { if (ev.target === wrap) close(false); });
      wrap.querySelector("[data-cancel]").addEventListener("click", () => close(false));
      form.addEventListener("submit", async (ev) => {
        ev.preventDefault(); er.textContent = "";
        const c = form.querySelector("input[name=category]:checked");
        if (!c) { er.textContent = "Please choose what is wrong."; return; }
        const btn = form.querySelector(".rp-primary"); btn.disabled = true;
        try { await opts.onSend({ category: c.value, reason: form.reason.value.trim() }); close(true); }
        catch (e) { btn.disabled = false; er.textContent = e && e.message ? e.message : "That didn't work. Please try again."; }
      });
      form.querySelector("input[name=category]").focus();
    });
  }
  window.CurioReport = { open, categories };
})();
