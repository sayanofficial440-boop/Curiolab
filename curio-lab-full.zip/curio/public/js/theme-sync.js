// Curio Lab — Premium palette sync
//
// This sits ALONGSIDE js/theme.js (owns the 8 base light/dark themes toggled
// via [data-theme]) and js/theme-engine.js (owns the per-subject immersion
// veil). It does not touch either — instead it adds a *third*, independent
// tier: named premium palettes (Pastel Mint, Crimson Sunrise, Cyberpunk
// Matrix, Warm Amber, Cream Pearl) that override the same --color-* /
// --theme-swatch-* variables theme.js's base themes already define, and
// persists the choice server-side (backend/models.py) when the user is
// logged in, so it follows them across devices — mirroring the
// live/demo-mode fallback pattern js/auth.js already uses.
//
// Load order: theme.js, then this file, then theme-engine.js (order doesn't
// actually matter for correctness — all three only ever touch CSS custom
// properties on :root — but this keeps DOM injection predictable).
window.CurioThemeSync = (function () {
  "use strict";

  const BACKEND_URL = "";
  const LOCAL_KEY = "curiolab-premium-palette";
  const STYLE_ID = "curio-premium-palette-fade";
  const FADE_MS = 420;

  // Client-side mirror of backend/models.py's PALETTES. Kept in sync with
  // the server's version, but the frontend never trusts its own copy for
  // anything security-relevant — saving still round-trips through the
  // server's whitelist/regex validation in models.sanitize_custom_vars.
  const PALETTES = {
    "pastel-mint": {
      label: "Pastel Mint",
      vars: {
        "--color-bg": "#EAF6F0", "--color-bg-alt": "#DCEEE4", "--color-surface": "#F6FBF8",
        "--color-ink": "#1C3B30", "--color-ink-soft": "#4F7566",
        "--color-line": "rgba(28,59,48,0.14)", "--color-line-strong": "rgba(28,59,48,0.28)",
        "--color-navy": "#2E5C4C", "--color-amber": "#C98A3B", "--color-teal": "#3FA37E",
        "--color-coral": "#D97B62", "--color-moss": "#6FA35A",
        "--theme-swatch-a": "#EAF6F0", "--theme-swatch-b": "#3FA37E",
      },
    },
    "crimson-sunrise": {
      label: "Crimson Sunrise",
      vars: {
        "--color-bg": "#FFF3EC", "--color-bg-alt": "#FCE3D6", "--color-surface": "#FFFAF6",
        "--color-ink": "#3B1A12", "--color-ink-soft": "#7A4433",
        "--color-line": "rgba(59,26,18,0.14)", "--color-line-strong": "rgba(59,26,18,0.28)",
        "--color-navy": "#6B1E1A", "--color-amber": "#E0862E", "--color-teal": "#B5453A",
        "--color-coral": "#FF5E3A", "--color-moss": "#A34E2E",
        "--theme-swatch-a": "#FFF3EC", "--theme-swatch-b": "#FF5E3A",
      },
    },
    "cyberpunk-matrix": {
      label: "Cyberpunk Matrix",
      vars: {
        "--color-bg": "#05070A", "--color-bg-alt": "#0B0F14", "--color-surface": "#0D1218",
        "--color-ink": "#D6FFEA", "--color-ink-soft": "#7FE8B0",
        "--color-line": "rgba(214,255,234,0.14)", "--color-line-strong": "rgba(214,255,234,0.28)",
        "--color-navy": "#39FF9E", "--color-amber": "#FFD23F", "--color-teal": "#00E5FF",
        "--color-coral": "#FF2E6C", "--color-moss": "#39FF9E",
        "--theme-swatch-a": "#05070A", "--theme-swatch-b": "#39FF9E",
      },
    },
    "warm-amber": {
      label: "Warm Amber",
      vars: {
        "--color-bg": "#FFF6E9", "--color-bg-alt": "#FCEBD0", "--color-surface": "#FFFBF3",
        "--color-ink": "#3A2A12", "--color-ink-soft": "#7A6540",
        "--color-line": "rgba(58,42,18,0.14)", "--color-line-strong": "rgba(58,42,18,0.28)",
        "--color-navy": "#6B4A1E", "--color-amber": "#E0932A", "--color-teal": "#8A7A3E",
        "--color-coral": "#C9713A", "--color-moss": "#9C7A2E",
        "--theme-swatch-a": "#FFF6E9", "--theme-swatch-b": "#E0932A",
      },
    },
    "cream-pearl": {
      label: "Cream Pearl",
      vars: {
        "--color-bg": "#FAF7F0", "--color-bg-alt": "#F1ECE0", "--color-surface": "#FFFDF9",
        "--color-ink": "#2B2A26", "--color-ink-soft": "#6B695F",
        "--color-line": "rgba(43,42,38,0.12)", "--color-line-strong": "rgba(43,42,38,0.24)",
        "--color-navy": "#4A5568", "--color-amber": "#C9A24A", "--color-teal": "#7FA69A",
        "--color-coral": "#C98A7A", "--color-moss": "#9CA37A",
        "--theme-swatch-a": "#FAF7F0", "--theme-swatch-b": "#C9A24A",
      },
    },
    "ocean-breeze": {
      label: "Ocean Breeze",
      vars: {
        "--color-bg": "#EAF4FB", "--color-bg-alt": "#D8E9F5", "--color-surface": "#F5FAFD",
        "--color-ink": "#0F2A3D", "--color-ink-soft": "#3F6B85",
        "--color-line": "rgba(15,42,61,0.14)", "--color-line-strong": "rgba(15,42,61,0.28)",
        "--color-navy": "#1F4E68", "--color-amber": "#D9A441", "--color-teal": "#2E9AB5",
        "--color-coral": "#E0806B", "--color-moss": "#5B9A8B",
        "--theme-swatch-a": "#EAF4FB", "--theme-swatch-b": "#2E9AB5",
      },
    },
    "royal-violet": {
      label: "Royal Violet",
      vars: {
        "--color-bg": "#120B1F", "--color-bg-alt": "#1B1230", "--color-surface": "#180F28",
        "--color-ink": "#EDE3FF", "--color-ink-soft": "#B79FE0",
        "--color-line": "rgba(237,227,255,0.14)", "--color-line-strong": "rgba(237,227,255,0.28)",
        "--color-navy": "#8B5CF6", "--color-amber": "#F0B94D", "--color-teal": "#7C6FEA",
        "--color-coral": "#E0578C", "--color-moss": "#8B5CF6",
        "--theme-swatch-a": "#120B1F", "--theme-swatch-b": "#8B5CF6",
      },
    },
    "sunset-coral": {
      label: "Sunset Coral",
      vars: {
        "--color-bg": "#FFF0EC", "--color-bg-alt": "#FCDCD2", "--color-surface": "#FFF8F5",
        "--color-ink": "#401E17", "--color-ink-soft": "#7A4B3E",
        "--color-line": "rgba(64,30,23,0.14)", "--color-line-strong": "rgba(64,30,23,0.28)",
        "--color-navy": "#6B2E24", "--color-amber": "#E0982E", "--color-teal": "#C7745C",
        "--color-coral": "#FF6F52", "--color-moss": "#B5713E",
        "--theme-swatch-a": "#FFF0EC", "--theme-swatch-b": "#FF6F52",
      },
    },
    "midnight-gold": {
      label: "Midnight Gold",
      vars: {
        "--color-bg": "#0D0D10", "--color-bg-alt": "#161619", "--color-surface": "#18181C",
        "--color-ink": "#F5EFE0", "--color-ink-soft": "#B8AE94",
        "--color-line": "rgba(245,239,224,0.14)", "--color-line-strong": "rgba(245,239,224,0.28)",
        "--color-navy": "#D4AF37", "--color-amber": "#D4AF37", "--color-teal": "#8C9C8C",
        "--color-coral": "#C97A4A", "--color-moss": "#9C8C4E",
        "--theme-swatch-a": "#0D0D10", "--theme-swatch-b": "#D4AF37",
      },
    },
    "lavender-dream": {
      label: "Lavender Dream",
      vars: {
        "--color-bg": "#F3EEFB", "--color-bg-alt": "#E7DEF5", "--color-surface": "#FAF7FD",
        "--color-ink": "#2E2440", "--color-ink-soft": "#6B5D8A",
        "--color-line": "rgba(46,36,64,0.13)", "--color-line-strong": "rgba(46,36,64,0.26)",
        "--color-navy": "#6A4FA0", "--color-amber": "#D9A25C", "--color-teal": "#7C9AD9",
        "--color-coral": "#C97BB0", "--color-moss": "#8C7BD9",
        "--theme-swatch-a": "#F3EEFB", "--theme-swatch-b": "#8C7BD9",
      },
    },
    "arctic-frost": {
      label: "Arctic Frost",
      vars: {
        "--color-bg": "#EEF3F6", "--color-bg-alt": "#DCE7ED", "--color-surface": "#F8FBFC",
        "--color-ink": "#1A2933", "--color-ink-soft": "#4E6673",
        "--color-line": "rgba(26,41,51,0.12)", "--color-line-strong": "rgba(26,41,51,0.24)",
        "--color-navy": "#3B6E8C", "--color-amber": "#C9A24A", "--color-teal": "#5FA8C7",
        "--color-coral": "#C77E6E", "--color-moss": "#7A9C8E",
        "--theme-swatch-a": "#EEF3F6", "--theme-swatch-b": "#5FA8C7",
      },
    },
    "forest-emerald": {
      label: "Forest Emerald",
      vars: {
        "--color-bg": "#07140F", "--color-bg-alt": "#0C1E16", "--color-surface": "#0E2219",
        "--color-ink": "#DFF7EA", "--color-ink-soft": "#8FC7A8",
        "--color-line": "rgba(223,247,234,0.14)", "--color-line-strong": "rgba(223,247,234,0.28)",
        "--color-navy": "#2FBE7A", "--color-amber": "#E0B24A", "--color-teal": "#22A87C",
        "--color-coral": "#E0785E", "--color-moss": "#4FBE6A",
        "--theme-swatch-a": "#07140F", "--theme-swatch-b": "#2FBE7A",
      },
    },
    "peach-fizz": {
      label: "Peach Fizz",
      vars: {
        "--color-bg": "#FFF1E8", "--color-bg-alt": "#FCE1D0", "--color-surface": "#FFF8F2",
        "--color-ink": "#402A1C", "--color-ink-soft": "#8A6A52",
        "--color-line": "rgba(64,42,28,0.13)", "--color-line-strong": "rgba(64,42,28,0.26)",
        "--color-navy": "#8A5A3E", "--color-amber": "#E0983D", "--color-teal": "#C77E7A",
        "--color-coral": "#FF8C6B", "--color-moss": "#C79A6B",
        "--theme-swatch-a": "#FFF1E8", "--theme-swatch-b": "#FF8C6B",
      },
    },
  };

  function injectFadeStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    // Only color-ish properties transition — layout properties are never
    // touched by a palette swap, so there's no reflow, only a repaint.
    style.textContent = `
      html, body, .card, .sidebar, .nav, button, .btn, [data-theme-option],
      input, textarea, select {
        transition: background-color ${FADE_MS}ms ease, color ${FADE_MS}ms ease,
                    border-color ${FADE_MS}ms ease, box-shadow ${FADE_MS}ms ease;
      }
      .premium-palette-option.active { outline: 2px solid var(--color-teal); outline-offset: 2px; }
      @media (prefers-reduced-motion: reduce) {
        html, body, .card, .sidebar, .nav, button, .btn, [data-theme-option],
        input, textarea, select { transition: none; }
      }
    `;
    document.head.appendChild(style);
  }

  function applyVars(vars) {
    const root = document.documentElement;
    Object.entries(vars).forEach(([key, value]) => root.style.setProperty(key, value));
  }

  function clearVars(paletteId) {
    const palette = PALETTES[paletteId];
    if (!palette) return;
    const root = document.documentElement;
    Object.keys(palette.vars).forEach((key) => root.style.removeProperty(key));
  }

  let backendAvailableCache = null;
  async function backendAvailable() {
    if (backendAvailableCache !== null) return backendAvailableCache;
    try {
      const controller = new AbortController();
      const t = setTimeout(() => controller.abort(), 1200);
      const res = await fetch(`${BACKEND_URL}/api/theme/palettes`, { credentials: "include", signal: controller.signal });
      clearTimeout(t);
      backendAvailableCache = res.ok;
    } catch (e) {
      backendAvailableCache = false;
    }
    return backendAvailableCache;
  }

  function getLocalChoice() {
    try { return JSON.parse(localStorage.getItem(LOCAL_KEY)); } catch (e) { return null; }
  }
  function setLocalChoice(paletteId) {
    localStorage.setItem(LOCAL_KEY, JSON.stringify({ palette_id: paletteId }));
  }

  let currentPaletteId = null;

  function applyPalette(paletteId, { persist = true } = {}) {
    injectFadeStyle();
    if (currentPaletteId && currentPaletteId !== paletteId) clearVars(currentPaletteId);

    if (!paletteId || paletteId === "none") {
      currentPaletteId = null;
      updateActiveMarkers(null);
      if (persist) persistChoice(null);
      return;
    }

    const palette = PALETTES[paletteId];
    if (!palette) return;
    applyVars(palette.vars);
    currentPaletteId = paletteId;
    updateActiveMarkers(paletteId);
    if (persist) persistChoice(paletteId);
  }

  async function persistChoice(paletteId) {
    setLocalChoice(paletteId);
    if (!(await backendAvailable())) return; // guest or offline — localStorage is enough
    try {
      await fetch(`${BACKEND_URL}/api/theme/me`, {
        method: "PUT",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ palette_id: paletteId }),
      });
    } catch (e) {
      // Non-fatal — the palette is already applied and cached locally;
      // it just won't have followed the user to another device this time.
    }
  }

  function updateActiveMarkers(paletteId) {
    document.querySelectorAll("[data-premium-palette]").forEach((el) => {
      const isNoneEntry = el.dataset.premiumPalette === "none";
      el.classList.toggle("active", isNoneEntry ? !paletteId : el.dataset.premiumPalette === paletteId);
    });
  }

  function buildPickerEntries() {
    const dropdown = document.querySelector(".theme-dropdown");
    if (!dropdown || dropdown.querySelector("[data-premium-palette]")) return;

    const divider = document.createElement("div");
    divider.className = "theme-dropdown-divider";
    divider.setAttribute("role", "separator");
    dropdown.appendChild(divider);

    const label = document.createElement("div");
    label.className = "theme-dropdown-label";
    label.textContent = "Premium Palettes";
    dropdown.appendChild(label);

    // No explicit "None" entry here — picking a premium palette is meant
    // to apply immediately, same as picking a base theme above. Dropping
    // back to a base theme's own colors happens by picking a base theme
    // (see theme.js, which calls applyPalette(null) for you).
    Object.entries(PALETTES).forEach(([id, palette]) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "theme-option premium-palette-option";
      btn.setAttribute("data-premium-palette", id);
      btn.style.setProperty("--sa", palette.vars["--theme-swatch-a"]);
      btn.style.setProperty("--sb", palette.vars["--theme-swatch-b"]);
      btn.innerHTML = `<span class="theme-swatch"></span><span>${palette.label}</span>`;
      btn.addEventListener("click", () => {
        applyPalette(id);
        dropdown.classList.remove("open");
      });
      dropdown.appendChild(btn);
    });
  }

  async function init() {
    injectFadeStyle();
    buildPickerEntries();

    // Logged-in users: server's saved choice wins (keeps devices in sync).
    // Guests / offline: fall back to whatever was last applied locally.
    let initial = null;
    if (await backendAvailable()) {
      try {
        const res = await fetch(`${BACKEND_URL}/api/theme/me`, { credentials: "include" });
        const data = await res.json();
        if (data.theme && data.theme.palette_id) initial = data.theme.palette_id;
      } catch (e) { /* fall through to local */ }
    }
    if (!initial) {
      const local = getLocalChoice();
      if (local && local.palette_id) initial = local.palette_id;
    }
    if (initial) applyPalette(initial, { persist: false });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }

  return { applyPalette, palettes: PALETTES };
})();
