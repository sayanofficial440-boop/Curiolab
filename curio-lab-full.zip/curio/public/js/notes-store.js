// Curio Lab — lesson bookmarks and personal notes (per account, on this device).
(function () {
  "use strict";
  if (window.CurioNotes) return;
  const KEY_PREFIX = "curiolab-notes-v1:";
  const SESSION_KEY = "curiolab-local-session";
  const safeParse = (v, f) => { try { const x = JSON.parse(v); return x == null ? f : x; } catch (_) { return f; } };

  function accountKey() {
    const u = safeParse(localStorage.getItem(SESSION_KEY), null);
    if (u && u.id) return "id:" + u.id;
    if (u && u.email) return "email:" + String(u.email).toLowerCase();
    return "guest";
  }
  const key = () => KEY_PREFIX + accountKey();

  function relHref(href) {
    let p = String(href || "").split("#")[0].split("?")[0];
    try { p = decodeURIComponent(p); } catch (_) { /* keep raw */ }
    const i = p.lastIndexOf("/pages/");
    if (i >= 0) return p.slice(i + 1);
    return p.indexOf("pages/") === 0 ? p : p.replace(/^\/+/, "");
  }

  function readAll() { const d = safeParse(localStorage.getItem(key()), {}); return d && typeof d === "object" && !Array.isArray(d) ? d : {}; }
  function writeAll(d) {
    try { localStorage.setItem(key(), JSON.stringify(d)); } catch (_) { return false; }
    window.dispatchEvent(new CustomEvent("curio-notes-updated"));
    return true;
  }

  function get(href) { return readAll()[relHref(href)] || null; }

  // meta: { title, subject }. patch: { note?, bookmarked? }. Empty records are dropped.
  function set(href, meta, patch) {
    const all = readAll(), k = relHref(href), now = new Date().toISOString();
    const cur = all[k] || { href: k, title: meta.title, subject: meta.subject, note: "", bookmarked: false, bookmarkedAt: null, updatedAt: now };
    cur.title = meta.title || cur.title; cur.subject = meta.subject || cur.subject;
    if (patch.note !== undefined) { cur.note = String(patch.note).slice(0, 20000); cur.updatedAt = now; }
    if (patch.bookmarked !== undefined && patch.bookmarked !== cur.bookmarked) { cur.bookmarked = !!patch.bookmarked; cur.bookmarkedAt = cur.bookmarked ? now : null; }
    if (!cur.note.trim() && !cur.bookmarked) delete all[k]; else all[k] = cur;
    return writeAll(all);
  }

  const list = () => Object.values(readAll()).sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)));
  function remove(href) { const all = readAll(); delete all[relHref(href)]; writeAll(all); }
  const counts = () => { const l = list(); return { bookmarks: l.filter((x) => x.bookmarked).length, notes: l.filter((x) => x.note && x.note.trim()).length }; };

  window.CurioNotes = { get, set, list, remove, counts, relHref };
  window.addEventListener("storage", (e) => { if (e.key && e.key.indexOf(KEY_PREFIX) === 0) window.dispatchEvent(new CustomEvent("curio-notes-updated")); });
})();
