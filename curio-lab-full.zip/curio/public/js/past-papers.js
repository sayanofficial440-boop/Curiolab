// Curio Lab — Past Papers: sit an exam-style paper (MCQ, fill-blank, true/false auto-marked; VSA/SA/LA/CBQ
// self-marked against the model answer and marking points). Attempts are kept per account on this device.
(function () {
  "use strict";
  const host = document.querySelector("[data-papers]"), PAPERS = window.CurioPapers || [];
  if (!host) return;
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const norm = (s) => String(s).toLowerCase().replace(/[\s.]+/g, " ").trim();
  const acct = () => { try { const u = JSON.parse(localStorage.getItem("curiolab-local-session")); return u && (u.id || u.email) ? String(u.id || u.email).toLowerCase() : "guest"; } catch (_) { return "guest"; } };
  const KEY = () => "curiolab-papers-v1:" + acct();
  const load = () => { try { return JSON.parse(localStorage.getItem(KEY())) || {}; } catch (_) { return {}; } };
  const store = (d) => { try { localStorage.setItem(KEY(), JSON.stringify(d)); } catch (_) { /* full */ } };
  const ptsMarks = (pts) => pts.reduce((n, p) => n + p[1], 0);

  // Flatten a paper into marked items.
  function flatten(p) {
    const items = [];
    p.sections.forEach((s, si) => s.questions.forEach((q, qi) => {
      const k = si + "." + qi;
      if (s.type === "cbq") q.subs.forEach((u, ui) => items.push({ k: k + "." + ui, si, type: "cbq", passage: ui ? null : q.passage, q: u.q, model: u.model, points: u.points, marks: ptsMarks(u.points) }));
      else if (s.type === "mcq") items.push({ k, si, type: "mcq", q: q.q, options: q.options, correct: q.correct, why: q.why, marks: 1 });
      else if (s.type === "fib") items.push({ k, si, type: "fib", q: q.q, answers: q.answers, why: q.why, marks: 1 });
      else if (s.type === "tf") items.push({ k, si, type: "tf", q: q.q, answer: q.answer, why: q.why, marks: 1 });
      else items.push({ k, si, type: s.type, q: q.q, model: q.model, points: q.points, marks: ptsMarks(q.points) });
    }));
    return items;
  }
  const total = (p) => flatten(p).reduce((n, i) => n + i.marks, 0);
  const objective = (i, a) => i.type === "mcq" ? a === i.correct : i.type === "fib" ? !!a && i.answers.some((x) => norm(x) === norm(a)) : i.type === "tf" ? a === i.answer : null;

  let paper = null, items = [], ans = {}, ticks = {}, mode = "list", left = 0, timer = null;

  function list() {
    const done = load();
    host.innerHTML = `<div class="pp-grid">${PAPERS.map((p) => { const a = done[p.id]; return `<article class="pp-card"><small>${esc(p.subject)} · ${esc(p.level)}</small><h3>${esc(p.title)}</h3><p>${total(p)} marks · ${p.minutes} min · ${p.sections.map((s) => s.type.toUpperCase()).filter((v, i, r) => r.indexOf(v) === i).join(", ")}</p>${a ? `<p class="pp-best">Last score ${a.score}/${a.total}</p>` : ""}<button type="button" class="pp-btn" data-start="${p.id}">${a ? "Sit again" : "Start paper"}</button>${a ? `<button type="button" class="pp-btn ghost" data-review="${p.id}">View solutions</button>` : `<button type="button" class="pp-btn ghost" data-peek="${p.id}">Solutions only</button>`}</article>`; }).join("")}</div>
      <p class="pp-note">These are original exam-style papers written for practice. Add your own in <code>js/papers/papers-data.js</code>.</p>`;
  }

  function qHtml(i, review) {
    const a = ans[i.k], head = `<div class="pp-q"><div class="pp-qh"><span>${esc(i.q)}</span><em>${i.marks} mark${i.marks > 1 ? "s" : ""}</em></div>`;
    if (!review) {
      if (i.type === "mcq") return head + i.options.map((o, n) => `<label class="pp-opt"><input type="radio" name="q${i.k}" data-k="${i.k}" value="${n}" ${a === n ? "checked" : ""}> ${esc(o)}</label>`).join("") + "</div>";
      if (i.type === "tf") return head + [true, false].map((v) => `<label class="pp-opt"><input type="radio" name="q${i.k}" data-k="${i.k}" value="${v}" ${a === v ? "checked" : ""}> ${v ? "True" : "False"}</label>`).join("") + "</div>";
      if (i.type === "fib") return head + `<input class="pp-in" data-k="${i.k}" value="${esc(a || "")}" placeholder="Your answer" autocomplete="off"></div>`;
      return head + `<textarea class="pp-in" rows="${i.type === "la" ? 7 : i.type === "sa" ? 4 : 2}" data-k="${i.k}" placeholder="Write your answer…">${esc(a || "")}</textarea></div>`;
    }
    const ok = objective(i, a);
    if (ok !== null) {
      const given = a == null || a === "" ? "—" : i.type === "mcq" ? i.options[a] : i.type === "tf" ? (a ? "True" : "False") : a;
      const right = i.type === "mcq" ? i.options[i.correct] : i.type === "tf" ? (i.answer ? "True" : "False") : i.answers[0];
      return head + `<p class="pp-res ${ok ? "good" : "bad"}">${ok ? "✓ Correct" : "✗ Your answer: " + esc(given)} ${ok ? "" : "· Correct: <b>" + esc(right) + "</b>"}</p><p class="pp-why">${esc(i.why || "")}</p></div>`;
    }
    return head + `<div class="pp-mine"><b>Your answer</b><p>${a ? esc(a).replace(/\n/g, "<br>") : "<i>Not answered</i>"}</p></div><div class="pp-model"><b>Model answer</b><p>${esc(i.model)}</p><b>Mark yourself</b>${i.points.map((p, n) => `<label class="pp-opt"><input type="checkbox" data-tick="${i.k}:${n}" ${ticks[i.k + ":" + n] ? "checked" : ""}> ${esc(p[0])} <em>(${p[1]})</em></label>`).join("")}</div></div>`;
  }
  const secHead = (i, prev) => (!prev || prev.si !== i.si) ? `<h3 class="pp-sec">${esc(paper.sections[i.si].name)} <small>${esc(paper.sections[i.si].label)}</small></h3>` : "";
  const cbqHead = (i) => i.passage ? `<blockquote class="pp-pass">${esc(i.passage)}</blockquote>` : "";
  const body = (review) => items.map((i, n) => secHead(i, items[n - 1]) + cbqHead(i) + qHtml(i, review)).join("");

  function score() {
    let s = 0; items.forEach((i) => { const ok = objective(i, ans[i.k]); if (ok !== null) s += ok ? i.marks : 0; else i.points.forEach((p, n) => { if (ticks[i.k + ":" + n]) s += p[1]; }); });
    return s;
  }
  function save() { const d = load(); d[paper.id] = { score: score(), total: total(paper), at: new Date().toISOString() }; store(d); }

  function sit(id) {
    paper = PAPERS.find((p) => p.id === id); items = flatten(paper); ans = {}; ticks = {}; mode = "sit"; left = paper.minutes * 60;
    clearInterval(timer); timer = setInterval(() => { left -= 1; const t = host.querySelector("[data-clock]"); if (t) t.textContent = fmt(left); if (left <= 0) submit(); }, 1000);
    host.innerHTML = `<div class="pp-bar"><b>${esc(paper.title)}</b><span class="pp-clock" data-clock>${fmt(left)}</span><button class="pp-btn" type="button" data-submit>Submit</button></div>${body(false)}<button class="pp-btn" type="button" data-submit>Submit paper</button>`;
  }
  const fmt = (s) => Math.floor(Math.max(0, s) / 60) + ":" + String(Math.max(0, s) % 60).padStart(2, "0");
  function submit() { clearInterval(timer); mode = "review"; save(); showReview(); }
  function showReview(peek) {
    const sc = score(), tot = total(paper), objMax = items.filter((i) => objective(i, null) !== null).reduce((n, i) => n + i.marks, 0);
    host.innerHTML = `<div class="pp-bar"><b>${esc(paper.title)}</b><span class="pp-clock" data-score>${peek ? "Solutions" : sc + " / " + tot}</span><button class="pp-btn ghost" type="button" data-back>All papers</button></div>` +
      (peek ? "" : `<p class="pp-note">Objective questions are marked for you (${items.filter((i) => objective(i, null) !== null).reduce((n, i) => n + (objective(i, ans[i.k]) ? i.marks : 0), 0)}/${objMax}). For written answers, compare with the model answer and tick each marking point you earned — your total updates as you go.</p>`) + body(true);
    if (peek) host.querySelectorAll(".pp-mine").forEach((n) => n.remove());
  }
  function review(id, peek) { paper = PAPERS.find((p) => p.id === id); items = flatten(paper); if (peek) { ans = {}; ticks = {}; } mode = "review"; showReview(peek); }

  host.addEventListener("click", (e) => {
    const t = e.target.closest("button"); if (!t) return;
    if (t.dataset.start) sit(t.dataset.start); else if (t.dataset.peek) review(t.dataset.peek, true); else if (t.dataset.review) review(t.dataset.review, true);
    else if (t.hasAttribute("data-submit")) { if (confirm("Submit your paper now?")) submit(); } else if (t.hasAttribute("data-back")) { mode = "list"; list(); }
  });
  host.addEventListener("input", (e) => { const k = e.target.dataset.k; if (k) ans[k] = e.target.type === "radio" ? (e.target.value === "true" ? true : e.target.value === "false" ? false : +e.target.value) : e.target.value; });
  host.addEventListener("change", (e) => {
    const k = e.target.dataset.k; if (k && e.target.type === "radio") ans[k] = e.target.value === "true" ? true : e.target.value === "false" ? false : +e.target.value;
    if (e.target.dataset.tick) { ticks[e.target.dataset.tick] = e.target.checked; save(); const s = host.querySelector("[data-score]"); if (s) s.textContent = score() + " / " + total(paper); }
  });
  window.addEventListener("beforeunload", (e) => { if (mode === "sit") { e.preventDefault(); e.returnValue = ""; } });
  list();
})();
