// Curio Lab — captions and transcripts for media.
//  • Lesson videos (YouTube): captions are requested by default (and in the learner's language when
//    YouTube has a track for it); under every video there is a "Captions & transcript" section with
//    the route to YouTube's full transcript, the lesson as text, and — when a lesson supplies one —
//    its own transcript (put it in an element marked data-video-transcript inside the video panel,
//    or in `video.transcript` of a dynamic lesson).
//  • Audio (read-aloud) mode: the transcript is always on screen, the sentence being spoken is
//    highlighted as live captions, and it can be downloaded as a .txt file.
//  • Any <video>/<audio> added later is checked for a captions track.
(function () {
  "use strict";
  const A = window.CurioA11y;
  if (!A || window.CurioA11yMedia) return;
  const P = window.CurioA11yPanel, T = (k) => (P && P.t ? P.t(k) : k);
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const css = document.createElement("style"); css.id = "a11y-media-css";
  css.textContent = `
  .a11y-tr{margin:12px 0 0;border:1.5px solid var(--color-line-strong,#9aa5b1);border-radius:14px;background:var(--color-surface,#fff);color:var(--color-ink,#16202a);font-size:.95rem}
  .a11y-tr>summary{cursor:pointer;padding:12px 16px;font-weight:700;min-height:44px;display:flex;align-items:center;gap:8px}
  .a11y-tr[open]>summary{border-bottom:1px solid var(--color-line,#dde)}
  .a11y-tr .a11y-tr-in{padding:12px 16px 16px;display:grid;gap:10px}
  .a11y-tr p{margin:0;line-height:1.6}
  .a11y-tr .a11y-tr-body{max-height:22rem;overflow:auto;padding:12px;border:1px solid var(--color-line,#dde);border-radius:10px;line-height:1.7}
  .a11y-tr .a11y-tr-btn,.a11y-dl{appearance:none;font:inherit;font-weight:600;min-height:44px;padding:8px 14px;border-radius:10px;border:1.5px solid var(--color-line-strong,#9aa5b1);background:var(--color-surface,#fff);color:inherit;cursor:pointer;justify-self:start;text-decoration:none;display:inline-flex;align-items:center}
  .a11y-tr a{color:var(--accent,#1b6f87);font-weight:600}
  [data-tts-text] [data-s]{border-radius:4px;transition:background .15s}
  [data-tts-text] [data-s].a11y-say{background:var(--accent-soft,rgba(27,111,135,.22));box-shadow:0 0 0 3px var(--accent-soft,rgba(27,111,135,.22))}
  .a11y-tr-h{margin:14px 0 6px;font-size:1rem;font-weight:700}
  .a11y-dl{margin-top:10px}`;
  document.head.appendChild(css);

  const YT = /(?:youtube(?:-nocookie)?\.com\/embed\/)([\w-]{6,})/i;
  const HL = { zh: "zh-CN", "zh-TW": "zh-TW", he: "iw" };
  const lang = () => { const c = (window.CurioLang && window.CurioLang.get()) || document.documentElement.lang || "en"; return HL[c] || c; };

  /* ---------- 1. YouTube captions ---------- */
  function captionUrl(src) {
    let u; try { u = new URL(src, location.href); } catch (_) { return src; }
    const on = A.get().captions !== false;
    if (on) u.searchParams.set("cc_load_policy", "1"); else u.searchParams.delete("cc_load_policy");
    const l = lang();
    if (l !== "en") { u.searchParams.set("hl", l); u.searchParams.set("cc_lang_pref", l); } else { u.searchParams.set("hl", "en"); u.searchParams.delete("cc_lang_pref"); }
    u.searchParams.set("playsinline", "1"); u.searchParams.set("rel", "0");
    return u.toString();
  }
  function ytIframes() { return $$("iframe").filter((f) => YT.test(f.getAttribute("src") || f.getAttribute("data-consent-src") || "")); }
  function updateCaptions(f) {
    // consent-gated frames keep their address in data-consent-src until the learner allows the video
    const gated = !f.getAttribute("src") && f.getAttribute("data-consent-src");
    const cur = gated ? f.getAttribute("data-consent-src") : f.getAttribute("src");
    const next = captionUrl(cur);
    if (next === cur) return;
    if (gated) f.setAttribute("data-consent-src", next); else f.setAttribute("src", next);
  }

  /* ---------- 2. Transcript section under each video ---------- */
  function addTranscript(f) {
    if (f.__trDone) return; f.__trDone = true;
    const m = (f.getAttribute("src") || f.getAttribute("data-consent-src") || "").match(YT); if (!m) return;
    const host = f.closest(".video-frame") || f.parentElement, panel = f.closest("[data-panel]") || host.parentElement || document;
    const anchor = (host && host.parentElement) ? host : f;
    const author = $("[data-video-transcript]", panel);
    const d = document.createElement("details"); d.className = "a11y-tr"; d.setAttribute("data-a11y-tr", "");
    const watch = "https://www.youtube.com/watch?v=" + encodeURIComponent(m[1]);
    d.innerHTML = `<summary>${esc(T("Captions & transcript"))}</summary><div class="a11y-tr-in">
      <p>${esc(T("Captions are switched on by default. Use the captions button in the video to change their language. You can turn this default off in Accessibility settings."))}</p>
      <p><a href="${esc(watch)}" target="_blank" rel="noopener noreferrer">${esc(T("Open this video on YouTube for the full transcript"))}<span class="a11y-sr"> (${esc(T("opens in a new tab"))})</span></a> — ${esc(T("choose more, then Show transcript"))}.</p>
      <div data-tr-slot></div>
      <button type="button" class="a11y-tr-btn" data-readtext>${esc(T("Read this lesson as text instead"))}</button></div>`;
    if (author) {
      const body = document.createElement("div"); body.className = "a11y-tr-body"; body.tabIndex = 0; body.setAttribute("role", "region"); body.setAttribute("aria-label", T("Transcript"));
      while (author.firstChild) body.appendChild(author.firstChild);
      author.remove(); $("[data-tr-slot]", d).replaceWith(body); d.open = false;
    } else $("[data-tr-slot]", d).remove();
    $("[data-readtext]", d).addEventListener("click", () => {
      const about = $('[data-tab="about"]'); if (about) { about.click(); about.focus(); }
      const a = $('[data-panel="about"]'); if (a) { a.setAttribute("tabindex", "-1"); a.scrollIntoView({ block: "start" }); a.focus({ preventScroll: true }); }
    });
    // placed after the caption line of the video if there is one, otherwise right after the frame
    const cap = anchor.nextElementSibling && anchor.nextElementSibling.matches(".video-caption") ? anchor.nextElementSibling : anchor;
    cap.after(d);
  }

  /* ---------- 3. Audio (read-aloud) transcript, live captions and download ---------- */
  function setupAudio() {
    const tx = $("[data-tts-text]"); if (!tx || tx.__a11y) return; tx.__a11y = true;
    const text = tx.textContent.trim(); if (!text) return;
    tx.setAttribute("role", "region"); tx.setAttribute("aria-label", T("Transcript"));
    // wrap sentences (textContent stays identical, so the speech engine reads the same text)
    const parts = text.match(/[^.!?।]+[.!?।]*\s*/g) || [text];
    tx.textContent = "";
    let pos = 0; const spans = parts.map((p) => { const s = document.createElement("span"); s.setAttribute("data-s", ""); s.dataset.at = String(pos); s.textContent = p; pos += p.length; tx.appendChild(s); return s; });
    const btn = $("[data-tts-play]");
    if (btn) { btn.setAttribute("aria-pressed", "false"); btn.setAttribute("aria-label", T("Play audio")); }
    const rate = $("[data-tts-rate]"); if (rate && !rate.getAttribute("aria-label")) rate.setAttribute("aria-label", T("Reading speed"));
    const say = (i) => { spans.forEach((s, k) => s.classList.toggle("a11y-say", k === i)); };
    document.addEventListener("curio:tts-boundary", (e) => {
      const c = e.detail.charIndex; let i = 0; while (i + 1 < spans.length && Number(spans[i + 1].dataset.at) <= c) i++;
      say(i); const r = spans[i].getBoundingClientRect(), v = window.innerHeight; if (r.top < 0 || r.bottom > v) spans[i].scrollIntoView({ block: "center" });
    });
    document.addEventListener("curio:tts-state", (e) => {
      if (btn) { btn.setAttribute("aria-pressed", String(!!e.detail.speaking)); btn.setAttribute("aria-label", T(e.detail.speaking ? "Stop audio" : "Play audio")); }
      if (!e.detail.speaking) say(-1);
    });
    const dl = document.createElement("button"); dl.type = "button"; dl.className = "a11y-dl"; dl.textContent = T("Download transcript");
    dl.addEventListener("click", () => {
      const title = ($("h1") || {}).textContent || document.title;
      const blob = new Blob([title.trim() + "\n\n" + text + "\n"], { type: "text/plain;charset=utf-8" });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = (title.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "transcript") + "-transcript.txt";
      document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
      A.announce(T("Transcript downloaded"));
    });
    (tx.closest(".tts-panel") || tx.parentElement).appendChild(dl);
  }

  /* ---------- 4. Any native <video>/<audio> must carry a captions track ---------- */
  function checkNative() {
    $$("video,audio").forEach((m) => {
      if (m.__a11y) return; m.__a11y = true;
      if (!m.hasAttribute("controls")) m.setAttribute("controls", "");
      const hasTrack = $$("track", m).some((t) => /captions|subtitles/.test(t.kind || t.getAttribute("kind") || ""));
      if (!hasTrack) {
        if (window.console) console.warn("[a11y-media] no captions track on", m.currentSrc || m.src || m);
        const n = document.createElement("p"); n.className = "a11y-tr-h"; n.textContent = T("Captions are not available for this media yet. Ask us for a transcript from the Contact page.");
        m.after(n);
      }
    });
  }

  function run() { ytIframes().forEach((f) => { updateCaptions(f); addTranscript(f); }); setupAudio(); checkNative(); }
  run();
  let timer = null; new MutationObserver(() => { clearTimeout(timer); timer = setTimeout(run, 200); }).observe(document.body, { childList: true, subtree: true });
  A.onChange(() => ytIframes().forEach(updateCaptions));
  document.addEventListener("curio:langchange", () => setTimeout(() => ytIframes().forEach(updateCaptions), 200));
  window.CurioA11yMedia = { run };
})();
