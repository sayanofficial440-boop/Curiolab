// Curio Lab — Practice hub (pages/practice.html).
// Three tabs: Overview (streak, accuracy, what's due), Practice (the five recall modes across any
// subject or lesson), Problems (jump into a Problem Lab topic). All state lives in practice-store.js.
(function () {
  "use strict";
  const root = document.querySelector("[data-practice-hub]");
  const S = window.CurioPracticeStore, P = window.CurioPractice, bank = window.CURIO_BANK && window.CURIO_BANK.recall;
  if (!root || !S || !P) return;
  const TABS = [["overview", "Overview"], ["practice", "Practice"], ["problems", "Problems"]];
  let tab = (location.hash || "#overview").slice(1), engine = null;
  if (!TABS.some((t) => t[0] === tab)) tab = "overview";
  const scope = { subject: "", lesson: "", focus: "all" };

  root.classList.add("px-wrap");
  root.innerHTML = `<div class="px-tabs" role="tablist">${TABS.map(([id, l]) => `<button class="px-tab" role="tab" data-tab="${id}">${l}</button>`).join("")}</div><div data-body></div>`;
  const body = root.querySelector("[data-body]");

  function overview() {
    const s = S.stats(), max = Math.max(1, ...s.week.map((d) => d.a)), day = (d) => d.toLocaleDateString(undefined, { weekday: "short" }).slice(0, 2);
    const card = (h, big, sub) => `<div class="px-card"><h3>${h}</h3><b class="big">${big}</b><p>${sub}</p></div>`;
    body.innerHTML = `<div class="px-grid">
      ${card("Streak", s.streak + (s.streak === 1 ? " day" : " days"), s.todayAnswered ? "You've practised today." : "Practise today to keep it alive.")}
      ${card("Today", s.todayAnswered, s.todayAnswered ? s.todayCorrect + " correct" : "questions answered")}
      ${card("Accuracy", s.accuracy == null ? "–" : s.accuracy + "%", s.totalAnswered + " answered in total")}
      ${card("Due for review", s.due, s.weak + " weak spot" + (s.weak === 1 ? "" : "s"))}
      <div class="px-card" style="grid-column:1/-1"><h3>Last 7 days</h3><div class="px-week">${s.week.map((d) => `<div><i style="height:${Math.round((d.a / max) * 100)}%" title="${d.a} answered"></i>${day(d.date)}</div>`).join("")}</div></div></div>
      <div class="pr-actions"><button class="pr-btn primary" data-go="practice">Start practising</button><a class="pr-btn" href="problem-lab.html">Open the Problem Lab</a></div>`;
  }

  function practice() {
    const subs = bank ? bank.subjects : [];
    body.innerHTML = `<div class="px-scope">
      <div class="px-scoperow"><label for="px-s">Subject</label><select id="px-s" data-s><option value="">All subjects</option>${subs.map((x) => `<option value="${x.k}">${x.l}</option>`).join("")}</select></div>
      <div class="px-scoperow"><label for="px-l">Lesson</label><select id="px-l" data-l></select></div>
      <div class="px-scoperow"><label for="px-f">Focus</label><select id="px-f" data-f><option value="all">Everything</option><option value="weak">Weak spots only</option><option value="due">Due for review</option></select><span class="px-count" data-count></span></div></div><div data-engine></div>`;
    const sS = body.querySelector("[data-s]"), sL = body.querySelector("[data-l]"), sF = body.querySelector("[data-f]");
    function lessons() { sL.innerHTML = '<option value="">All lessons</option>' + (bank ? bank.lessons.filter((l) => !scope.subject || subs[l.s].k === scope.subject).map((l) => `<option value="${l.k}">${l.t}</option>`).join("") : ""); sL.value = scope.lesson; }
    function items() {
      let it = P.itemsFromBank({ subject: scope.subject, lessonKey: scope.lesson });
      if (scope.focus === "weak") { const w = new Set(S.weakIds()); it = it.filter((i) => w.has(i.id)); }
      if (scope.focus === "due") { const d = new Set(S.queueFor(it.map((i) => i.id)).due); it = it.filter((i) => d.has(i.id)); }
      return it;
    }
    function refresh() { const it = items(); body.querySelector("[data-count]").textContent = it.length + " item" + (it.length === 1 ? "" : "s"); const host = body.querySelector("[data-engine]"); if (engine) { engine.setItems(it); } else engine = P.mount(host, { items: it }); }
    sS.value = scope.subject; sF.value = scope.focus; lessons(); engine = null; refresh();
    sS.onchange = () => { scope.subject = sS.value; scope.lesson = ""; lessons(); refresh(); };
    sL.onchange = () => { scope.lesson = sL.value; refresh(); };
    sF.onchange = () => { scope.focus = sF.value; refresh(); };
  }

  function problems() {
    const gens = window.CurioProblemLab ? window.CurioProblemLab.GENS : [], ps = S.problemStats(); let html = "", cur = "";
    gens.forEach((g) => {
      if (g.s !== cur) { if (cur) html += "</div>"; cur = g.s; html += `<h3 style="margin:18px 0 8px;font:700 1.05rem var(--font-display)">${g.s}</h3><div class="px-grid">`; }
      const st = ps[g.id], acc = st && st.a ? Math.round((100 * st.c) / st.a) : null;
      html += `<a class="px-card" href="problem-lab.html?g=${g.id}" style="text-decoration:none;color:inherit"><h3>${g.t}</h3><p>${st && st.a ? st.c + " of " + st.a + " correct" : "Not tried yet"}</p>${acc == null ? "" : `<span class="pl-meter" style="margin-top:8px"><i style="width:${acc}%"></i></span>`}</a>`;
    });
    body.innerHTML = (html ? html + "</div>" : '<p class="pr-note">Problem Lab topics could not be loaded.</p>');
  }

  function show(t) {
    tab = t; if (engine) { engine.destroy(); engine = null; }
    root.querySelectorAll(".px-tab").forEach((b) => b.setAttribute("aria-selected", b.dataset.tab === t));
    history.replaceState(null, "", "#" + t);
    ({ overview, practice, problems })[t]();
  }
  root.addEventListener("click", (e) => { const b = e.target.closest("[data-tab],[data-go]"); if (b) show(b.dataset.tab || b.dataset.go); });
  window.addEventListener("curio-practice-updated", () => { if (tab === "overview") overview(); });
  show(tab);
})();
