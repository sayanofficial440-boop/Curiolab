// Curio Lab — Exam Center.
// Choose a paper (100/80/40/20 marks, weekly, monthly, weak-spot, subject, custom or
// random), read the instructions, sit it against a real clock with a question navigator,
// resume it later, and get a full analysis plus a readiness view. State lives in
// js/exam-store.js; this file is the interface.
(function () {
  "use strict";
  const root = document.querySelector("[data-xc-app]");
  if (!root) return;
  const X = window.CurioExam, L = window.CurioLearning;
  const CAT = window.CurioCatalog || { subjects: [], lessons: [] };
  const BANK = window.CURIO_BANK && window.CURIO_BANK.exams && window.CURIO_BANK.exams.q;
  const $ = (s, el) => (el || root).querySelector(s);
  const $$ = (s, el) => [...(el || root).querySelectorAll(s)];
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const shuffled = (a) => { const x = [...a]; for (let i = x.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [x[i], x[j]] = [x[j], x[i]]; } return x; };
  const plural = (n, w) => n + " " + w + (n === 1 ? "" : "s");
  const num = (n) => (Math.round(n * 100) / 100).toString();
  const hrefFor = (s, t) => { const l = CAT.lessons.find((x) => x.s === s && x.t === t); return l ? l.h : ""; };
  const isExamEvent = (e) => /^(Exam Center|Mock test)/.test(e.lesson || "") || e.subject === "Exam";

  if (!X || !BANK || BANK.length < 20) {
    root.innerHTML = '<div class="st-card st-empty"><span class="big">⚠️</span>The question bank could not be loaded. Refresh the page and try again.</div>';
    return;
  }

  const bankSubjects = [...new Set(BANK.map((q) => q.subject))];
  const SUBJECTS = [...CAT.subjects.map((s) => s.name).filter((n) => bankSubjects.includes(n)), ...bankSubjects.filter((n) => !CAT.subjects.some((s) => s.name === n)).sort()];
  const PRESET = (id) => X.PRESETS.find((p) => p.id === id);
  const STANDARD = ["full100", "board80", "mid40", "test20", "subject", "custom", "random"]; // titles carry the mark total

  const stages = { home: $("[data-stage=home]"), brief: $("[data-stage=brief]"), run: $("[data-stage=run]"), result: $("[data-stage=result]") };
  function show(name) {
    Object.keys(stages).forEach((k) => { stages[k].hidden = k !== name; });
    document.body.classList.toggle("xc-running", name === "run");
    window.scrollTo({ top: 0 });
  }

  let learn = null;        // CurioLearning snapshot
  let tab = "start";
  let cfg = null;          // paper being configured
  let session = null;      // paper being sat
  let timerId = null, lastTick = 0, ticks = 0, warned = new Set();

  // =========================================================== small UI helpers
  function modal({ title, body, actions }) {
    return new Promise((resolve) => {
      const back = document.createElement("div");
      back.className = "xc-modal-back";
      back.innerHTML = `<div class="xc-modal" role="dialog" aria-modal="true" aria-labelledby="xc-m-t"><h3 id="xc-m-t">${esc(title)}</h3><div class="xc-m-body">${body}</div><div class="xc-m-act">${actions.map((a, i) => `<button type="button" class="st-btn${a.primary ? " primary" : ""}" data-v="${i}">${esc(a.label)}</button>`).join("")}</div></div>`;
      const prev = document.activeElement;
      const done = (v) => { back.remove(); document.removeEventListener("keydown", onKey, true); if (prev && prev.focus) prev.focus(); resolve(v); };
      const onKey = (e) => { if (e.key === "Escape") { e.stopPropagation(); done(null); } };
      back.addEventListener("click", (e) => { const b = e.target.closest("[data-v]"); if (b) done(actions[Number(b.dataset.v)].value); else if (e.target === back) done(null); });
      document.addEventListener("keydown", onKey, true);
      document.body.appendChild(back);
      const first = back.querySelector(".primary") || back.querySelector("button"); if (first) first.focus();
    });
  }
  const modalOpen = () => !!document.querySelector(".xc-modal-back");
  const toast = (msg, opts) => { if (window.CurioToast) window.CurioToast.show(msg, opts); };

  function ring(pct, size, label) {
    const r = 52, c = 2 * Math.PI * r;
    return `<svg viewBox="0 0 130 130" width="${size}" height="${size}" role="img" aria-label="${esc(label)}"><circle cx="65" cy="65" r="${r}" fill="none" stroke="var(--color-line)" stroke-width="9"/><circle cx="65" cy="65" r="${r}" fill="none" stroke="var(--accent,var(--color-teal))" stroke-width="9" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c - (c * Math.max(0, Math.min(100, pct))) / 100}" transform="rotate(-90 65 65)"/><text x="65" y="73" text-anchor="middle" font-size="28" font-weight="700" fill="currentColor">${pct == null ? "—" : pct + "%"}</text></svg>`;
  }
  // trend line of exam percentages (with optional target line)
  function trendChart(points, target) {
    if (points.length < 2) return `<p class="rp-none">Sit at least two exams to see your trend.</p>`;
    const W = 320, H = 110, pad = 18, n = points.length;
    const x = (i) => pad + (i * (W - pad * 2)) / (n - 1), y = (v) => H - pad - (v / 100) * (H - pad * 2);
    const line = points.map((p, i) => `${x(i).toFixed(1)},${y(p.pct).toFixed(1)}`).join(" ");
    const grid = [0, 50, 100].map((v) => `<line x1="${pad}" x2="${W - pad}" y1="${y(v)}" y2="${y(v)}" stroke="var(--color-line)" stroke-width="1"/><text x="2" y="${y(v) + 3}" font-size="8" fill="var(--color-ink-soft)">${v}</text>`).join("");
    const tl = target ? `<line x1="${pad}" x2="${W - pad}" y1="${y(target)}" y2="${y(target)}" stroke="var(--color-coral,#e8563a)" stroke-width="1" stroke-dasharray="4 3"/><text x="${W - pad}" y="${y(target) - 3}" text-anchor="end" font-size="8" fill="var(--color-coral,#e8563a)">target ${target}%</text>` : "";
    const dots = points.map((p, i) => `<circle cx="${x(i).toFixed(1)}" cy="${y(p.pct).toFixed(1)}" r="3.2" fill="var(--accent,var(--color-teal))"><title>${esc(p.title)} — ${p.pct}%</title></circle>`).join("");
    return `<svg class="xc-trend" viewBox="0 0 ${W} ${H}" role="img" aria-label="Exam scores over time: ${points.map((p) => p.pct + "%").join(", ")}">${grid}${tl}<polyline points="${line}" fill="none" stroke="var(--accent,var(--color-teal))" stroke-width="2" stroke-linejoin="round"/>${dots}</svg>`;
  }

  // =========================================================== data helpers
  const studiedSet = () => {
    const set = new Set(); if (!learn) return set;
    const rel = L ? L.relHref : (h) => h;
    CAT.lessons.forEach((l) => {
      const v = learn.visits.some((x) => rel(x.href) === l.h);
      const e = learn.events.some((x) => !isExamEvent(x) && ((x.href && rel(x.href) === l.h) || (x.subject === l.s && x.lesson === l.t)));
      if (v || e) set.add(l.s + "|" + l.t);
    });
    return set;
  };

  function newCfg(id, extra) {
    const p = PRESET(id), s = X.settings();
    const c = { preset: id, subjects: new Set(SUBJECTS), subject: SUBJECTS[0], studied: false, perQ: p.perQ, n: p.n, mins: p.mins, neg: s.neg || 0, strict: !!s.strict, minsTouched: false };
    if (id === "custom") { c.n = 25; c.perQ = 1; c.mins = 28; }
    if (id === "random") roll(c);
    return Object.assign(c, extra || {});
  }
  function roll(c) {
    const schemes = [[10, 1, 10], [20, 1, 20], [30, 1, 33], [20, 2, 25], [30, 2, 40], [40, 1, 45], [40, 2, 50], [50, 1, 55]];
    const [n, perQ, mins] = schemes[Math.floor(Math.random() * schemes.length)];
    const k = Math.min(SUBJECTS.length, 2 + Math.floor(Math.random() * (SUBJECTS.length - 1)));
    c.n = n; c.perQ = perQ; c.mins = mins; c.subjects = new Set(shuffled(SUBJECTS).slice(0, k));
  }
  function poolFor(c) {
    const subs = c.preset === "subject" ? new Set([c.subject]) : c.preset === "weak" ? new Set(SUBJECTS) : c.subjects;
    let pool = BANK.filter((q) => subs.has(q.subject));
    if (c.studied && c.preset !== "weak") { const set = studiedSet(); if (set.size) pool = pool.filter((q) => set.has(q.subject + "|" + q.lesson)); }
    return pool;
  }
  function plan(c) {
    const pool = poolFor(c);
    const n = Math.max(0, Math.min(c.n, pool.length));
    return { pool, n, short: n < c.n, maxMarks: n * c.perQ, mins: c.n ? Math.max(1, Math.round((c.mins * n) / c.n)) : c.mins };
  }
  const titleFor = (c, maxMarks) => {
    const p = PRESET(c.preset);
    if (c.preset === "subject") return `${c.subject} Paper · ${maxMarks} marks`;
    return STANDARD.includes(c.preset) ? `${p.label} · ${maxMarks} marks` : p.label;
  };

  // round-robin across subjects, and across lessons inside each subject
  function pickBalanced(pool, n, skip) {
    const bySub = {};
    shuffled(pool).forEach((q) => { if (skip && skip.has(q)) return; const s = (bySub[q.subject] = bySub[q.subject] || {}); (s[q.lesson || ""] = s[q.lesson || ""] || []).push(q); });
    const order = shuffled(Object.keys(bySub).map((k) => ({ groups: shuffled(Object.values(bySub[k])), i: 0 })));
    const out = []; let si = 0;
    while (out.length < n && order.some((s) => s.groups.some((g) => g.length))) {
      const s = order[si++ % order.length];
      for (let t = 0; t < s.groups.length; t++) {
        const g = s.groups[(s.i + t) % s.groups.length];
        if (g.length) { out.push(g.pop()); s.i = (s.i + t + 1) % s.groups.length; break; }
      }
    }
    return out;
  }
  function pickWeak(pool, n) {
    const out = new Set();
    const missed = new Set(window.CurioReview ? window.CurioReview.all().map((m) => m.q) : []);
    shuffled(pool.filter((q) => missed.has(q.q))).slice(0, Math.ceil(n * 0.4)).forEach((q) => out.add(q));
    const keys = new Set(X.weakKeys(learn));
    if (keys.size) pickBalanced(pool.filter((q) => keys.has(q.subject + "|" + q.lesson) && !out.has(q)), n - out.size).forEach((q) => { if (out.size < n) out.add(q); });
    if (out.size < n) pickBalanced(pool, n - out.size, out).forEach((q) => { if (out.size < n) out.add(q); });
    return [...out];
  }

  function buildSession(c) {
    const p = plan(c);
    const picked = c.preset === "weak" ? pickWeak(p.pool, p.n) : pickBalanced(p.pool, p.n);
    const order = (q) => { const i = SUBJECTS.indexOf(q.subject); return i < 0 ? 99 : i; };
    const multi = new Set(picked.map((q) => q.subject)).size > 1;
    const sorted = multi ? shuffled(picked).sort((a, b) => order(a) - order(b)) : shuffled(picked);
    const letters = {}; let li = 0;
    const qs = sorted.map((q) => {
      let section = "";
      if (multi) { if (!(q.subject in letters)) letters[q.subject] = String.fromCharCode(65 + li++); section = `Section ${letters[q.subject]} · ${q.subject}`; }
      const ord = shuffled(q.options.map((_, i) => i));
      return { q: q.q, subject: q.subject, lesson: q.lesson || "", section, options: ord.map((i) => q.options[i]), correct: ord.indexOf(q.correct), picked: null, first: null, flagged: false, visited: false, secs: 0, changes: 0 };
    });
    const subs = [...new Set(qs.map((q) => q.subject))];
    return {
      id: "x" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      kind: c.preset, title: titleFor(c, qs.length * c.perQ), scope: subs.length > 3 ? subs.length + " subjects" : subs.join(", "),
      maxMarks: qs.length * c.perQ, perQ: c.perQ, neg: c.neg, strict: c.strict, allowed: p.mins * 60,
      elapsed: 0, since: Date.now(), paused: false, i: 0, qs, startedAt: Date.now(),
    };
  }

  // A short paper made only of the questions missed (wrong or blank) in a finished attempt.
  function buildRedo(a) {
    const missed = (a.qs || []).filter((q) => q.picked !== q.correct);
    const qs = shuffled(missed).map((q) => {
      const ord = shuffled(q.options.map((_, i) => i));
      return { q: q.q, subject: q.subject, lesson: q.lesson || "", section: "", options: ord.map((i) => q.options[i]), correct: ord.indexOf(q.correct), picked: null, first: null, flagged: false, visited: false, secs: 0, changes: 0 };
    });
    const subs = [...new Set(qs.map((q) => q.subject))];
    return {
      id: "x" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), kind: "redo",
      title: `Mistake Redo · ${qs.length} marks`, scope: subs.length > 3 ? subs.length + " subjects" : subs.join(", "),
      maxMarks: qs.length, perQ: 1, neg: 0, strict: false, allowed: Math.max(5, Math.ceil(qs.length * 1.2)) * 60,
      elapsed: 0, since: Date.now(), paused: false, i: 0, qs, startedAt: Date.now(),
    };
  }
  async function startRedo(id) {
    const a = X.attempt(id); if (!a || !a.qs) return;
    if (X.active() && !(await modal({ title: "Replace the exam in progress?", body: "<p>You already have a paper in progress. Starting this one discards it without marking.</p>", actions: [{ label: "Keep the old one", value: false }, { label: "Start redo", value: true, primary: true }] }))) return;
    const s = buildRedo(a); if (!s.qs.length) return;
    X.saveActive(s); runSession(s);
  }

  // =========================================================== hero stats + resume banner
  function renderStats() {
    const el = $("[data-xc-stats]", document); if (!el) return;
    const st = X.stats(), rd = X.readiness(learn);
    const cards = [[st.count, "Exams taken"], [st.best == null ? "—" : st.best + "%", "Best score"], [st.avg == null ? "—" : st.avg + "%", "Average score"], [rd.overall == null ? "—" : rd.overall + "%", "Exam readiness"]];
    el.innerHTML = cards.map(([v, l]) => `<div class="stat-card"><div class="num">${v}</div><div class="label">${l}</div></div>`).join("");
  }
  function renderResume() {
    const host = $("[data-xc-resume]");
    const s = X.active();
    if (!s || session) { host.hidden = true; host.innerHTML = ""; return; }
    const m = X.summary(s);
    host.hidden = false;
    host.innerHTML = `<div class="xc-resume"><div class="xc-rs-ic" aria-hidden="true">⏳</div><div class="xc-rs-tx"><strong>${m.expired ? "Time ran out on your paper" : "Exam in progress"}: ${esc(m.title)}</strong><span>${m.answered}/${m.n} answered${m.flagged ? " · " + m.flagged + " flagged" : ""} · ${m.expired ? "the clock ran out while you were away" : X.fmtClock(m.left) + " left"}${m.strict && !m.expired ? " · strict clock is still running" : ""}</span></div>
      <div class="xc-rs-act"><button class="st-btn primary" type="button" data-resume>${m.expired ? "See my result" : "Resume exam"}</button><button class="st-btn" type="button" data-discard>Discard</button></div></div>`;
  }

  // =========================================================== home (start / readiness / history)
  function renderHome() {
    renderResume(); renderStats();
    const tabs = [["start", "Start an exam"], ["readiness", "Readiness"], ["history", "History"]];
    $("[data-xc-tabs]").innerHTML = tabs.map(([id, label]) => `<button class="st-tab" type="button" role="tab" id="xc-tab-${id}" aria-selected="${tab === id}" aria-controls="xc-panel" data-tab="${id}">${label}</button>`).join("");
    const panel = $("[data-xc-panel]");
    panel.setAttribute("aria-labelledby", "xc-tab-" + tab);
    if (tab === "start") renderStart(panel); else if (tab === "readiness") renderReadiness(panel); else renderHistory(panel);
  }

  function presetMeta(p) {
    if (p.id === "custom") return "You decide";
    if (p.id === "random") return "Surprise length & subjects";
    if (p.id === "subject") return "One subject · 20–100 Qs";
    if (p.id === "weak") return `${p.marks} marks · ${p.n} Qs · ${p.mins} min`;
    return `${p.marks} marks · ${p.n} Qs · ${p.mins >= 60 ? num(p.mins / 60) + " h" : p.mins + " min"}`;
  }

  function renderStart(panel) {
    const rd = X.readiness(learn), next = PRESET(rd.next.id);
    panel.innerHTML = `
      <div class="xc-rec"><div class="xc-rec-ic" aria-hidden="true">${next.icon}</div><div class="xc-rec-tx"><b>Recommended: ${esc(next.label)}</b><span>${esc(rd.next.why)}</span></div><button class="st-btn primary" type="button" data-pick-preset="${next.id}">Set up</button></div>
      <h2 class="xc-h">Choose your paper</h2>
      <div class="xc-presets" role="radiogroup" aria-label="Exam type">${X.PRESETS.map((p) => `<button type="button" class="xc-preset${cfg && cfg.preset === p.id ? " on" : ""}" role="radio" aria-checked="${!!(cfg && cfg.preset === p.id)}" data-pick-preset="${p.id}"><span class="xc-pi" aria-hidden="true">${p.icon}</span><span class="xc-pt">${esc(p.label)}</span><span class="xc-pm">${esc(presetMeta(p))}</span><span class="xc-pb">${esc(p.blurb)}</span></button>`).join("")}</div>
      <div data-xc-config>${cfg ? "" : '<p class="xc-hint">Pick a paper above to set it up. Timed papers save your progress automatically so you can resume them later.</p>'}</div>`;
    if (cfg) renderConfig();
  }

  function renderConfig() {
    const host = $("[data-xc-config]"); if (!host || !cfg) return;
    const c = cfg, p = PRESET(c.preset);
    const chips = (items, on, attr, multi) => items.map(([v, label]) => `<button type="button" class="mk-chip" aria-pressed="${on(v)}" ${attr}="${esc(v)}">${esc(label)}</button>`).join("");
    const scope = c.preset === "subject"
      ? `<div class="xc-row"><div class="mk-label"><span>Subject</span></div><div class="mk-chips">${chips(SUBJECTS.map((s) => [s, s]), (v) => c.subject === v, "data-subject")}</div></div>`
      : c.preset === "weak"
        ? `<p class="xc-note">${X.weakKeys(learn).length || (window.CurioReview && window.CurioReview.stats().total) ? "Built from your lowest-scoring lessons and the questions in your Mistake Notebook, topped up with a balanced mix." : "You have no weak spots on record yet, so this drill will be a balanced mix. Take a few exams first and it will aim at what you miss."}</p>`
        : `<div class="xc-row"><div class="mk-label"><span>Subjects</span><button class="st-btn ghost" type="button" data-all>Select / clear all</button></div><div class="mk-chips">${chips(SUBJECTS.map((s) => [s, s]), (v) => c.subjects.has(v), "data-subj")}</div></div>`;
    const length = c.preset === "subject"
      ? `<div class="xc-row"><div class="mk-label"><span>Length</span></div><div class="mk-chips">${chips([20, 40, 60, 100].map((n) => [n, n + " questions"]), (v) => c.n === Number(v), "data-len")}</div></div>`
      : c.preset === "custom"
        ? `<div class="xc-row"><div class="mk-label"><span>Paper size</span></div><div class="xc-fields">
            <label class="xc-field">Questions<input type="number" inputmode="numeric" min="5" max="150" value="${c.n}" data-f="n"></label>
            <label class="xc-field">Marks per question<select data-f="perQ">${[1, 2, 3, 4, 5].map((v) => `<option value="${v}"${c.perQ === v ? " selected" : ""}>${v}</option>`).join("")}</select></label>
            <label class="xc-field">Time (minutes)<input type="number" inputmode="numeric" min="5" max="240" value="${c.mins}" data-f="mins"></label></div></div>`
        : c.preset === "random"
          ? `<div class="xc-row"><div class="mk-label"><span>Your random paper</span><button class="st-btn" type="button" data-reroll>🎲 Roll again</button></div><p class="xc-note" data-xc-rolled></p></div>`
          : "";
    host.innerHTML = `<div class="st-card xc-config">
      <div class="xc-cfg-head"><span class="xc-pi" aria-hidden="true">${p.icon}</span><div><h3 class="mk-h" style="margin:0">${esc(p.label)}</h3><small>${esc(p.blurb)}</small></div></div>
      ${scope}${length}
      <div class="xc-row"><div class="mk-label"><span>Marking</span></div><div class="mk-chips">${chips(X.NEG.map((n, i) => [i, n.label]), (v) => Math.abs(X.NEG[v].v - c.neg) < 0.001, "data-neg")}</div></div>
      <div class="xc-row"><div class="mk-label"><span>Clock</span></div><div class="mk-chips">${chips([["relaxed", "Relaxed — pause any time"], ["strict", "Strict — the clock never stops"]], (v) => (v === "strict") === c.strict, "data-mode")}</div></div>
      ${c.preset === "weak" ? "" : `<label class="xc-check"><input type="checkbox" data-studied ${c.studied ? "checked" : ""}> Only lessons I've opened or taken a quiz in</label>`}
      <div class="mk-start"><b data-xc-sum></b><button class="st-btn primary" type="button" data-brief>Continue →</button></div></div>`;
    renderSummary();
  }

  function renderSummary() {
    if (!cfg) return;
    const c = cfg, p = plan(c), sum = $("[data-xc-sum]"), btn = $("[data-brief]");
    if (!sum) return;
    const rolled = $("[data-xc-rolled]");
    if (rolled) rolled.textContent = `${plural(c.n, "question")} · ${c.n * c.perQ} marks · ${c.mins} min · ${c.subjects.size} subject${c.subjects.size === 1 ? "" : "s"}: ${[...c.subjects].join(", ")}`;
    if (!p.pool.length) { sum.textContent = c.preset === "subject" || c.studied ? "No questions match — widen your choices." : "Choose at least one subject"; btn.disabled = true; return; }
    btn.disabled = c.n < 1;
    const neg = X.NEG.find((n) => Math.abs(n.v - c.neg) < 0.001).label.toLowerCase();
    sum.innerHTML = `${plural(p.n, "question")} × ${plural(c.perQ, "mark")} = <u>${p.maxMarks} marks</u> · ${p.mins} min${p.short ? ` <span class="xc-warn">(only ${p.pool.length} questions match)</span>` : ""}<small>${esc(neg)} · ${c.strict ? "strict clock" : "relaxed clock"}</small>`;
  }

  // =========================================================== instructions
  function renderBrief() {
    const c = cfg, p = plan(c), neg = X.NEG.find((n) => Math.abs(n.v - c.neg) < 0.001);
    const rules = [
      `This paper has <b>${plural(p.n, "question")}</b>, each worth <b>${plural(c.perQ, "mark")}</b> — <b>${p.maxMarks} marks</b> in total.`,
      c.neg ? `<b>Negative marking:</b> a wrong answer costs ${num(c.perQ * c.neg)} mark${c.perQ * c.neg === 1 ? "" : "s"}. An unanswered question costs nothing.` : `There is no negative marking — never leave a question blank.`,
      `You have <b>${p.mins} minutes</b>. The clock starts when you press Begin and the paper submits itself when time is up.`,
      c.strict ? `<b>Strict clock:</b> there is no pause, and time keeps running even if you close the tab.` : `<b>Relaxed clock:</b> you can pause any time, and closing the tab pauses the clock so you can resume later.`,
      `Move around freely with the question navigator. <b>Flag</b> a question to come back to it; you can change any answer until you submit.`,
      `Your progress is saved automatically. No hints and no feedback until you submit.`,
    ];
    stages.brief.innerHTML = `<div class="st-card xc-brief"><p class="eyebrow">Instructions</p><h2>${esc(titleFor(c, p.maxMarks))}</h2>
      <div class="xc-facts"><div><b>${p.n}</b><span>Questions</span></div><div><b>${p.maxMarks}</b><span>Total marks</span></div><div><b>${p.mins}</b><span>Minutes</span></div><div><b>${c.neg ? "−" + num(c.perQ * c.neg) : "None"}</b><span>Per wrong answer</span></div></div>
      <ol class="xc-rules">${rules.map((r) => `<li>${r}</li>`).join("")}</ol>
      <div class="xc-legend" aria-label="Navigator key"><span><i class="xc-n ans">1</i> Answered</span><span><i class="xc-n vis">2</i> Seen, not answered</span><span><i class="xc-n flg">3</i> Flagged</span><span><i class="xc-n">4</i> Not visited</span></div>
      <p class="rp-note">Keys: 1–4 or A–D choose · ← → move · F flag · C clear · U next unanswered</p>
      <div class="mk-start"><button class="st-btn" type="button" data-back>← Change paper</button><button class="st-btn primary" type="button" data-begin>Begin exam</button></div></div>`;
    show("brief");
    $("[data-begin]").focus();
  }

  // =========================================================== running the exam
  function persist() { if (session) X.saveActive(session); }
  const usedNow = () => X.usedSecs(session);
  const leftNow = () => Math.max(0, session.allowed - usedNow());

  function runSession(s) {
    session = s; warned = new Set(); lastTick = Date.now(); ticks = 0;
    const left0 = leftNow();
    [300, 60].concat([Math.round(s.allowed * 0.25)]).forEach((t) => { if (t < s.allowed && left0 <= t) warned.add(t); });
    s.qs[s.i].visited = true;
    stages.run.innerHTML = `
      <div class="xc-top"><div class="xc-top-l"><b data-r-title></b><small data-r-prog></small></div>
        <div class="xc-clock" data-r-clock role="timer" aria-live="off">00:00</div>
        <div class="xc-top-r"><button class="st-btn" type="button" data-act="pause" data-r-pausebtn>⏸ Pause</button><button class="st-btn primary" type="button" data-act="submit">Submit</button></div></div>
      <div class="xc-timebar" aria-hidden="true"><i data-r-timebar></i></div>
      <div class="xc-paused" data-r-paused hidden><span class="big" aria-hidden="true">⏸</span><h3>Exam paused</h3><p>Your clock is stopped and the questions are hidden.</p><button class="st-btn primary" type="button" data-act="resume">Resume exam</button></div>
      <div class="xc-grid" data-r-grid>
        <section class="st-card xc-qcard"><div class="xc-qmeta"><span class="xc-tag" data-r-sec></span><span class="xc-tag mk" data-r-marks></span></div>
          <h2 class="xc-q" data-r-q tabindex="-1" id="xc-q"></h2>
          <div class="xc-opts" role="radiogroup" aria-labelledby="xc-q" data-r-opts></div>
          <div class="xc-ctl"><button class="st-btn" type="button" data-act="prev">← Previous</button><button class="st-btn" type="button" data-act="clear">Clear answer</button><button class="st-btn" type="button" data-act="flag" aria-pressed="false">⚑ Flag</button><button class="st-btn primary" type="button" data-act="next">Save &amp; next →</button></div></section>
        <aside class="st-card xc-nav"><details data-r-navdet open><summary>Question navigator</summary><div class="xc-counts" data-r-counts></div><div data-r-nav></div>
          <div class="xc-jumps"><button class="st-btn" type="button" data-act="nextun">Next unanswered</button><button class="st-btn" type="button" data-act="nextfl">Next flagged</button></div>
          <div class="xc-legend"><span><i class="xc-n ans">·</i> Answered</span><span><i class="xc-n vis">·</i> Seen</span><span><i class="xc-n flg">·</i> Flagged</span></div></details></aside></div>
      <div class="xc-sronly" role="status" aria-live="polite" data-r-live></div>`;
    if (window.matchMedia && window.matchMedia("(max-width: 760px)").matches) $("[data-r-navdet]").open = false;
    $("[data-r-title]").textContent = s.title;
    $("[data-r-pausebtn]").hidden = !!s.strict;
    show("run");
    if (s.paused) { s.paused = false; s.since = Date.now(); } // opening the paper starts/resumes the clock
    persist();
    renderQ(); tick();
    clearInterval(timerId); timerId = setInterval(tick, 1000);
    window.addEventListener("beforeunload", onBeforeUnload);
    window.addEventListener("pagehide", onPageHide);
    document.addEventListener("keydown", onKey);
    renderResume();
  }
  function stopRun() {
    clearInterval(timerId); timerId = null;
    window.removeEventListener("beforeunload", onBeforeUnload);
    window.removeEventListener("pagehide", onPageHide);
    document.removeEventListener("keydown", onKey);
  }
  const onBeforeUnload = (e) => { if (session) { e.preventDefault(); e.returnValue = ""; } };
  function onPageHide() {
    if (!session) return;
    if (!session.strict && !session.paused) { session.elapsed = usedNow(); session.since = null; session.paused = true; }
    persist();
  }

  function tick() {
    if (!session || session.paused) return;
    const now = Date.now(), dt = Math.min(5, (now - lastTick) / 1000); lastTick = now;
    session.qs[session.i].secs += dt;
    const left = leftNow();
    const clock = $("[data-r-clock]");
    clock.textContent = X.fmtClock(left);
    clock.classList.toggle("low", left <= Math.max(30, session.allowed * 0.1));
    $("[data-r-timebar]").style.width = Math.max(0, (left / session.allowed) * 100) + "%";
    [300, 60, Math.round(session.allowed * 0.25)].forEach((t) => {
      if (t >= session.allowed || warned.has(t) || left > t) return;
      warned.add(t);
      const msg = t === 60 ? "1 minute left" : t === 300 ? "5 minutes left" : Math.round((t / session.allowed) * 100) + "% of the time left";
      $("[data-r-live]").textContent = msg; toast(msg, { icon: "⏱️", duration: 3500 });
    });
    if (++ticks % 5 === 0) persist();
    if (left <= 0) finish(true);
  }

  function renderQ() {
    const s = session, q = s.qs[s.i], n = s.qs.length;
    q.visited = true;
    $("[data-r-sec]").textContent = `Question ${s.i + 1} of ${n}${q.section ? " · " + q.section : ""}`;
    $("[data-r-marks]").textContent = `${plural(s.perQ, "mark")}${s.neg ? " · −" + num(s.perQ * s.neg) + " if wrong" : ""}`;
    $("[data-r-q]").textContent = q.q;
    $("[data-r-opts]").innerHTML = q.options.map((o, i) => `<button type="button" class="xc-opt${q.picked === i ? " picked" : ""}" role="radio" aria-checked="${q.picked === i}" data-pick="${i}"><kbd>${"ABCD"[i] || i + 1}</kbd><span>${esc(o)}</span></button>`).join("");
    const f = $("[data-act=flag]"); f.setAttribute("aria-pressed", String(q.flagged)); f.textContent = q.flagged ? "🚩 Flagged" : "⚑ Flag";
    $("[data-act=prev]").disabled = s.i === 0;
    $("[data-act=clear]").disabled = q.picked == null;
    $("[data-act=next]").textContent = s.i === n - 1 ? "Review & submit" : "Save & next →";
    renderNav();
  }
  function renderNav() {
    const s = session, qs = s.qs;
    const ans = qs.filter((q) => q.picked != null).length, flg = qs.filter((q) => q.flagged).length;
    const seen = qs.filter((q) => q.visited && q.picked == null).length, fresh = qs.filter((q) => !q.visited).length;
    $("[data-r-prog]").textContent = `${ans}/${qs.length} answered`;
    $("[data-r-counts]").innerHTML = `<span><b>${ans}</b> answered</span><span><b>${seen}</b> seen</span><span><b>${fresh}</b> new</span><span><b>${flg}</b> flagged</span>`;
    let html = "", cur = null;
    qs.forEach((q, i) => {
      if (q.section !== cur) { if (cur !== null) html += "</div>"; cur = q.section; html += (q.section ? `<div class="xc-sec">${esc(q.section)}</div>` : "") + '<div class="xc-navgrid">'; }
      const cls = ["xc-n", i === s.i ? "cur" : "", q.picked != null ? "ans" : q.visited ? "vis" : "", q.flagged ? "flg" : ""].filter(Boolean).join(" ");
      html += `<button type="button" class="${cls}" data-go="${i}" aria-label="Question ${i + 1}${q.picked != null ? ", answered" : q.visited ? ", seen, not answered" : ", not visited"}${q.flagged ? ", flagged" : ""}"${i === s.i ? ' aria-current="true"' : ""}>${i + 1}</button>`;
    });
    $("[data-r-nav]").innerHTML = html + "</div>";
    $("[data-act=nextun]").disabled = ans === qs.length;
    $("[data-act=nextfl]").disabled = flg === 0;
  }
  function jumpTo(test) {
    const n = session.qs.length;
    for (let k = 1; k <= n; k++) { const i = (session.i + k) % n; if (test(session.qs[i])) { go(i); return; } }
  }
  function go(i) {
    if (i < 0 || i >= session.qs.length) return;
    session.i = i; persist(); renderQ();
    const q = $("[data-r-q]"); if (q) q.focus({ preventScroll: true });
  }
  function pick(i) {
    const q = session.qs[session.i]; if (i < 0 || i >= q.options.length) return;
    if (q.first == null) q.first = i; else if (q.picked !== i && q.picked != null) q.changes += 1;
    q.picked = i; persist(); renderQ();
  }
  function toggleFlag() { const q = session.qs[session.i]; q.flagged = !q.flagged; persist(); renderQ(); }
  function clearAnswer() { const q = session.qs[session.i]; if (q.picked == null) return; q.picked = null; persist(); renderQ(); }

  function pause() {
    if (!session || session.paused || session.strict) return;
    session.elapsed = usedNow(); session.since = null; session.paused = true; persist();
    $("[data-r-paused]").hidden = false; $("[data-r-grid]").hidden = true;
    $("[data-r-live]").textContent = "Exam paused";
    const b = $("[data-act=resume]"); if (b) b.focus();
  }
  function resume() {
    if (!session || !session.paused) return;
    session.paused = false; session.since = Date.now(); lastTick = Date.now(); persist();
    $("[data-r-paused]").hidden = true; $("[data-r-grid]").hidden = false;
    $("[data-r-live]").textContent = "Exam resumed"; renderQ();
  }

  async function confirmSubmit() {
    if (!session) return;
    const qs = session.qs, un = qs.filter((q) => q.picked == null).length, fl = qs.filter((q) => q.flagged).length;
    const warn = un || fl;
    const v = await modal({
      title: "Submit your paper?",
      body: `<p>${plural(qs.length - un, "question")} answered${un ? `, <b>${un} left blank</b>` : ""}${fl ? `, <b>${fl} flagged</b>` : ""}. You have <b>${X.fmtClock(leftNow())}</b> left.</p>${warn ? "<p>You can still go back and change answers before you submit.</p>" : "<p>Once you submit, the paper is marked and you can't change your answers.</p>"}`,
      actions: [{ label: "Keep working", value: "stay" }].concat(un ? [{ label: "Go to first blank", value: "blank" }] : []).concat(fl ? [{ label: "Go to flagged", value: "flag" }] : []).concat([{ label: "Submit now", value: "submit", primary: true }]),
    });
    if (v === "submit") finish(false);
    else if (v === "blank") go(qs.findIndex((q) => q.picked == null));
    else if (v === "flag") go(qs.findIndex((q) => q.flagged));
  }

  function onKey(e) {
    if (!session || stages.run.hidden || session.paused || modalOpen() || e.ctrlKey || e.metaKey || e.altKey || /input|textarea|select/i.test(e.target.tagName)) return;
    const k = e.key.toLowerCase();
    if (/^[1-9]$/.test(k)) pick(Number(k) - 1);
    else if (/^[a-d]$/.test(k)) pick(k.charCodeAt(0) - 97);
    else if (k === "arrowright" || k === "n") { if (session.i < session.qs.length - 1) go(session.i + 1); }
    else if (k === "arrowleft" || k === "p") go(session.i - 1);
    else if (k === "f") toggleFlag();
    else if (k === "c") clearAnswer();
    else if (k === "u") jumpTo((q) => q.picked == null);
  }

  stages.run.addEventListener("click", (e) => {
    if (!session) return;
    const b = e.target.closest("button"); if (!b) return;
    if (b.dataset.pick != null) pick(Number(b.dataset.pick));
    else if (b.dataset.go != null) go(Number(b.dataset.go));
    else if (b.dataset.act === "prev") go(session.i - 1);
    else if (b.dataset.act === "next") { if (session.i < session.qs.length - 1) go(session.i + 1); else confirmSubmit(); }
    else if (b.dataset.act === "flag") toggleFlag();
    else if (b.dataset.act === "clear") clearAnswer();
    else if (b.dataset.act === "submit") confirmSubmit();
    else if (b.dataset.act === "nextun") jumpTo((q) => q.picked == null);
    else if (b.dataset.act === "nextfl") jumpTo((q) => q.flagged);
    else if (b.dataset.act === "pause") pause();
    else if (b.dataset.act === "resume") resume();
  });

  function finish(timedOut) {
    if (!session) return;
    const s = session; session = null; stopRun();
    if (document.querySelector(".xc-modal-back")) document.querySelector(".xc-modal-back").remove();
    const { attempt, saved } = X.finalize(s, timedOut);
    renderResult(attempt, { saved, timedOut, fresh: true });
    if (window.CurioConfetti && attempt.pct >= 80) window.CurioConfetti.burst(attempt.pct === 100);
    announceTrophies();
  }
  function announceTrophies() {
    if (!window.CurioToast || !window.CurioAchievements) return;
    const KEY = "curiolab-trophies-seen";
    let seen = []; try { seen = JSON.parse(localStorage.getItem(KEY)) || []; } catch (_) { seen = []; }
    const cur = window.CurioAchievements.earned().filter((t) => t.earned);
    cur.filter((t) => !seen.includes(t.id)).forEach((t, i) => setTimeout(() => window.CurioToast.show(`Trophy unlocked: ${t.name}`, { type: "trophy", icon: t.icon, duration: 5000 }), i * 600 + 900));
    try { localStorage.setItem(KEY, JSON.stringify(cur.map((t) => t.id))); } catch (_) { /* ignore */ }
  }

  // =========================================================== result analysis
  function insights(a) {
    const out = [], qs = a.qs || [], per = a.secsAllowed / a.n;
    if (a.timedOut && a.skipped) out.push(["⏱️", `Time ran out with ${plural(a.skipped, "question")} unanswered. Next time, give hard questions a quick flag and come back — about ${X.fmtDur(per)} per question is the budget.`]);
    const subs = Object.entries(a.subjects).filter(([, v]) => v.n >= 3).map(([name, v]) => ({ name, acc: Math.round((v.c / v.n) * 100), lost: round1(v.max - v.marks) }));
    if (subs.length > 1) {
      const w = [...subs].sort((x, y) => x.acc - y.acc)[0], b = [...subs].sort((x, y) => y.acc - x.acc)[0];
      if (w.acc < 70) out.push(["🎯", `Weakest section: <b>${esc(w.name)}</b> at ${w.acc}% — ${num(w.lost)} of your lost marks came from there.${b.name !== w.name ? ` Strongest: ${esc(b.name)} (${b.acc}%).` : ""}`]);
      else out.push(["💪", `Strong across the board — your lowest section was ${esc(w.name)} at ${w.acc}%.`]);
    }
    if (qs.length) {
      const guess = qs.filter((q) => q.picked != null && q.picked !== q.correct && q.secs <= Math.max(5, per * 0.25)).length;
      if (guess >= 2) out.push(["⚡", `${guess} answers were wrong after only a few seconds each — likely rushed guesses. Reading the options twice would have saved marks.`]);
      const slow = [...qs].map((q, i) => ({ i, secs: q.secs })).sort((x, y) => y.secs - x.secs)[0];
      if (slow && slow.secs >= Math.max(60, per * 3)) out.push(["🐢", `Question ${slow.i + 1} took ${X.fmtDur(slow.secs)} — ${Math.round(slow.secs / per)}× the time budget. Flag long questions and return to them.`]);
    }
    if (a.negMarks > 0) out.push(["➖", `Negative marking cost you <b>${num(a.negMarks)} marks</b> (${plural(a.wrong, "wrong answer")}). When two options are still in play, a guess can pay; when none are, leave it blank.`]);
    const ch = a.changedRight + a.changedWrong;
    if (ch >= 2) out.push(["✏️", a.changedWrong > a.changedRight ? `You changed ${ch} answers and ${a.changedWrong} of those switches made things worse — trust your first instinct unless you spot a clear mistake.` : `Re-thinking paid off: ${a.changedRight} of ${ch} changed answers turned into correct ones.`]);
    if (!a.timedOut && a.skipped) out.push(["○", `${plural(a.skipped, "question")} left unanswered${a.neg ? " — fine under negative marking if you were unsure" : " — with no negative marking, always make a guess"}.`]);
    if (!a.timedOut && a.secsUsed < a.secsAllowed * 0.6 && a.wrong + a.skipped > 0) out.push(["🕒", `You finished with ${X.fmtDur(a.secsAllowed - a.secsUsed)} to spare. Use leftover time to re-check flagged questions.`]);
    return out.slice(0, 4);
  }
  const round1 = (n) => Math.round(n * 10) / 10;

  function renderResult(a, opts) {
    opts = opts || {};
    const g = X.grade(a.pct), prev = X.prevOfKind(a), qs = a.qs || [];
    const best = X.bestOfKind(a), isBest = a.kind !== "redo" && opts.fresh && a.pct > best && X.attempts().filter((x) => x.kind === a.kind).length > 1;
    const delta = prev ? a.pct - prev.pct : null;
    const avgQ = a.n ? a.secsUsed / a.n : 0;
    const ins = insights(a);
    const subjRows = Object.entries(a.subjects).sort((x, y) => x[1].c / x[1].n - y[1].c / y[1].n).map(([name, v]) => {
      const p = Math.round((v.c / v.n) * 100);
      return `<div class="xc-subj"><span class="xc-sn">${esc(name)}</span><div class="mk-meter" role="img" aria-label="${esc(name)} accuracy ${p} percent"><i style="width:${p}%"></i></div><b>${num(v.marks)}/${v.max}</b><small>${p}% · ${X.fmtDur(v.n ? v.secs / v.n : 0)}/Q</small></div>`;
    }).join("");
    const weak = a.lessons.filter((l) => l.c / l.n < 0.6).sort((x, y) => x.c / x.n - y.c / y.n).slice(0, 6);
    const maxSecs = Math.max(1, ...qs.map((q) => q.secs));
    const avgLine = qs.length ? (avgQ / maxSecs) * 100 : 0;
    const chart = qs.length ? `<div class="xc-chart-wrap"><div class="xc-chart" role="img" aria-label="Time spent on each question; green is correct, red is wrong, grey is unanswered">${qs.map((q, i) => { const st = q.picked == null ? "skip" : q.picked === q.correct ? "ok" : "bad"; return `<i class="xc-bar ${st}" style="height:${Math.max(4, (q.secs / maxSecs) * 100)}%" title="Q${i + 1}: ${X.fmtDur(q.secs)} — ${st === "ok" ? "correct" : st === "bad" ? "wrong" : "unanswered"}"></i>`; }).join("")}<span class="xc-avg" style="bottom:${avgLine}%"><em>avg ${X.fmtDur(avgQ)}</em></span></div></div><div class="xc-legend"><span><i class="xc-dot ok"></i>Correct</span><span><i class="xc-dot bad"></i>Wrong</span><span><i class="xc-dot skip"></i>Unanswered</span></div>` : "";
    const slowest = [...qs].map((q, i) => ({ q, i })).sort((x, y) => y.q.secs - x.q.secs).slice(0, 3);
    const slowHtml = slowest.length ? `<div class="xc-slow"><b>Slowest questions</b>${slowest.map(({ q, i }) => `<button type="button" class="xc-link" data-rv-jump="${i}">Q${i + 1} · ${X.fmtDur(q.secs)} · ${q.picked === q.correct ? "✓" : q.picked == null ? "○" : "✗"}</button>`).join("")}</div>` : "";

    stages.result.innerHTML = `
      <h2 class="rp-print-title">Curio Lab — ${esc(a.title)} · ${new Date(a.at).toLocaleDateString(undefined, { day: "numeric", month: "long", year: "numeric" })}</h2>
      <div class="st-card xc-score">${ring(a.pct, 140, "Score " + a.pct + " percent")}
        <div class="xc-score-tx"><p class="eyebrow">${esc(a.title)}${a.legacy ? "" : " · " + new Date(a.at).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}</p>
          <h2>${num(a.marks)} <small>/ ${a.maxMarks} marks</small></h2>
          <p class="xc-grade"><b>${g.short}</b> ${esc(g.label)}${isBest ? ' <span class="xc-badge">🏅 New personal best</span>' : ""}${delta != null ? ` <span class="xc-delta ${delta >= 0 ? "up" : "down"}">${delta >= 0 ? "▲" : "▼"} ${Math.abs(delta)} pts vs last ${esc(prev.title.split(" · ")[0])}</span>` : ""}</p>
          <div class="xc-chips"><span class="xc-chip ok">✔ ${a.correct} correct</span><span class="xc-chip bad">✖ ${a.wrong} wrong</span><span class="xc-chip">○ ${a.skipped} unanswered</span>${a.negMarks ? `<span class="xc-chip bad">−${num(a.negMarks)} negative</span>` : ""}<span class="xc-chip">⏱ ${X.fmtDur(a.secsUsed)} of ${X.fmtDur(a.secsAllowed)}${a.timedOut ? " (time up)" : ""}</span></div>
          ${opts.fresh ? (opts.saved ? `<p class="rp-note"><a href="review.html">📓 ${plural(opts.saved, "missed question")} added to your Mistake Notebook →</a></p>` : `<p class="rp-note">🎉 Nothing to add to your Mistake Notebook.</p>`) : ""}
          <div class="mk-actions">${qs.length && a.wrong + a.skipped > 0 ? `<button class="st-btn primary" type="button" data-redo="${esc(a.id)}">🔁 Retake my ${a.wrong + a.skipped} missed question${a.wrong + a.skipped === 1 ? "" : "s"}</button>` : ""}<button class="st-btn${qs.length && a.wrong + a.skipped > 0 ? "" : " primary"}" type="button" data-again="${a.kind === "redo" ? "test20" : esc(a.kind)}">${a.kind === "redo" ? "Sit a fresh paper" : "Sit another paper like this"}</button><button class="st-btn" type="button" data-to="readiness">See my readiness</button>${qs.length ? '<button class="st-btn" type="button" data-print>🖨 Save as PDF</button>' : ""}<button class="st-btn ghost" type="button" data-to="start">Exam Center</button></div></div></div>
      ${ins.length ? `<div class="st-card xc-ins"><h3 class="mk-h">What the numbers say</h3>${ins.map(([i, t]) => `<p><span aria-hidden="true">${i}</span><span>${t}</span></p>`).join("")}</div>` : ""}
      <div class="st-card xc-sec-card"><h3 class="mk-h">By subject</h3><p class="rp-note">Marks scored, accuracy and average time per question.</p>${subjRows}</div>
      ${qs.length ? `<div class="st-card xc-sec-card"><h3 class="mk-h">Time analysis</h3><p class="rp-note">Each bar is a question; its height is the time you spent. Average: ${X.fmtDur(avgQ)} per question against a budget of ${X.fmtDur(a.secsAllowed / a.n)}.</p>${chart}${slowHtml}</div>` : ""}
      ${weak.length ? `<div class="st-card xc-sec-card"><h3 class="mk-h">Lessons to revise</h3>${weak.map((l) => { const h = hrefFor(l.subject, l.lesson); return `<div class="mk-hist"><span>${h ? `<a href="../${esc(h)}">${esc(l.lesson)}</a>` : esc(l.lesson)} · ${esc(l.subject)}</span><b>${l.c}/${l.n}</b></div>`; }).join("")}</div>` : ""}
      ${qs.length ? `<div class="st-card xc-sec-card" data-rv><div class="mk-rhead"><h3 class="mk-h" style="margin:0">Answer review</h3></div><div class="mk-chips xc-rv-f" data-rv-filters role="group" aria-label="Filter questions"></div><div class="nb-list" data-rv-list style="margin-top:12px"></div></div>` : `<div class="st-card xc-sec-card"><p class="rp-none">Question-by-question review isn't kept for exams taken with the older Exams page, or for the oldest attempts.</p></div>`}`;
    show("result");
    if (qs.length) wireReview(a);
  }

  function wireReview(a) {
    const qs = a.qs, per = a.secsAllowed / a.n;
    const filters = [["wrong", "Wrong", (q) => q.picked != null && q.picked !== q.correct], ["skip", "Unanswered", (q) => q.picked == null], ["flag", "Flagged", (q) => q.flagged], ["slow", "Slow", (q) => q.secs > Math.max(30, per * 2)], ["all", "All", () => true]];
    let f = qs.some(filters[0][2]) ? "wrong" : "all", shown = 15;
    const list = $("[data-rv-list]"), bar = $("[data-rv-filters]");
    function draw() {
      const def = filters.find((x) => x[0] === f);
      const items = qs.map((q, i) => ({ q, i })).filter((x) => def[2](x.q));
      bar.innerHTML = filters.map(([id, label, fn]) => `<button type="button" class="mk-chip" aria-pressed="${f === id}" data-rv-f="${id}">${label} (${qs.filter(fn).length})</button>`).join("");
      list.innerHTML = items.length ? items.slice(0, shown).map(({ q, i }) => {
        const st = q.picked == null ? "skip" : q.picked === q.correct ? "ok" : "bad";
        return `<article class="nb-item xc-ritem" id="xc-rv-${i}"><h3><span class="xc-rs ${st}">${st === "ok" ? "✔" : st === "bad" ? "✖" : "○"}</span> ${i + 1}. ${esc(q.q)}</h3>
          <div class="xc-ropts">${q.options.map((o, k) => `<div class="xc-ropt${k === q.correct ? " correct" : ""}${k === q.picked && k !== q.correct ? " wrong" : ""}"><b>${"ABCD"[k] || k + 1}</b><span>${esc(o)}</span>${k === q.correct ? '<em>correct</em>' : k === q.picked ? "<em>your answer</em>" : ""}</div>`).join("")}</div>
          <div class="nb-foot"><span>${esc(q.subject)}${q.lesson ? " · " + esc(q.lesson) : ""}</span><span>⏱ ${X.fmtDur(q.secs)}${q.flagged ? " · 🚩 flagged" : ""}${q.changes ? " · changed " + plural(q.changes, "time") : ""}${q.picked == null ? " · not answered" : ""}</span></div></article>`;
      }).join("") + (items.length > shown ? `<button type="button" class="st-btn" data-rv-more>Show ${Math.min(15, items.length - shown)} more</button>` : "") : `<div class="st-empty">Nothing here — nice.</div>`;
    }
    draw();
    const card = $("[data-rv]");
    card.addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      if (b.dataset.rvF) { f = b.dataset.rvF; shown = 15; draw(); }
      else if (b.hasAttribute("data-rv-more")) { shown += 15; draw(); }
    });
    rvApi = { printAll() { f = qs.some(filters[0][2]) ? "wrong" : "all"; shown = 9999; draw(); }, jump(i) { f = "all"; shown = Math.max(shown, i + 1); draw(); const el = document.getElementById("xc-rv-" + i); if (el) el.scrollIntoView({ behavior: "smooth", block: "center" }); } };
  }
  let rvApi = null;
  stages.result.addEventListener("click", (e) => {
    const b = e.target.closest("[data-rv-jump]");
    if (b && rvApi) rvApi.jump(Number(b.dataset.rvJump));
  });


  // Day-by-day plan toward the target / exam date, built only from real weak spots, due reviews and recent papers.
  function studyPlan(rd, set) {
    if (rd.overall == null) return null;
    const left = set.examDate ? Math.ceil((new Date(set.examDate + "T23:59:59") - Date.now()) / 86400000) : null;
    const horizon = left != null && left >= 1 ? Math.min(left, 14) : 7;
    const days = Array.from({ length: horizon }, (_, i) => ({ i, items: [] }));
    const R = window.CurioReview ? window.CurioReview.stats() : null;
    if (R && R.due) days[0].items.push({ icon: "🧠", text: `Clear ${plural(R.due, "due review question")}`, href: "review.html" });
    if (R && R.total) for (let i = R.due ? 2 : 1; i < horizon; i += 2) days[i].items.push({ icon: "🧠", text: "10-minute Mistake Notebook review", href: "review.html" });
    const weak = rd.weak.slice(0, horizon >= 7 ? 6 : 3);
    weak.forEach((w, k) => {
      const d = Math.min(horizon - 1, Math.floor((k * horizon) / Math.max(1, weak.length)));
      days[d].items.push({ icon: "📖", text: `Revise ${w.lesson} (${w.subject}, ${w.acc}%) then retake its quiz`, href: w.href ? "../" + w.href : "" });
    });
    const weakestSubj = rd.subjects.filter((s) => s.value != null).sort((a, b) => a.value - b.value)[0];
    const paperDays = horizon <= 3 ? [Math.min(1, horizon - 1)] : [];
    if (horizon > 3) for (let i = 2; i < horizon; i += 3) paperDays.push(i);
    paperDays.forEach((d, k) => {
      const last = k === paperDays.length - 1;
      let it;
      if (last && left != null) it = rd.overall >= 65 ? { id: "board80", text: "Full board paper — simulate the real thing" } : { id: "test20", text: "Class test — check how the revision landed" };
      else if (k === 0 && rd.weak.length >= 2) it = { id: "weak", text: "Weak-spot drill on your lowest lessons" };
      else if (weakestSubj && k % 2 === 0) it = { id: "subject", subject: weakestSubj.name, text: `${weakestSubj.name} subject paper (20 questions)` };
      else it = { id: "mid40", text: "Mid-term paper — mixed subjects" };
      days[d].items.push({ icon: "📝", text: it.text, preset: it.id, subject: it.subject });
    });
    days.forEach((d) => { if (!d.items.length) d.items.push({ icon: "☕", text: "Light day — skim your notes or play a learning game" }); });
    return { horizon, left, days };
  }
  function planHtml(pl) {
    if (!pl) return "";
    const label = (i) => (i === 0 ? "Today" : i === 1 ? "Tomorrow" : new Date(Date.now() + i * 864e5).toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short" }));
    const item = (it) => it.preset ? `<button type="button" class="xc-pi-btn" ${it.subject ? `data-practise="${esc(it.subject)}"` : `data-pick-preset="${it.preset}"`}><span aria-hidden="true">${it.icon}</span><span>${esc(it.text)}</span></button>` : it.href ? `<a class="xc-pi-btn" href="${esc(it.href)}"><span aria-hidden="true">${it.icon}</span><span>${esc(it.text)}</span></a>` : `<div class="xc-pi-btn static"><span aria-hidden="true">${it.icon}</span><span>${esc(it.text)}</span></div>`;
    return `<section class="st-card" style="margin-top:14px"><h3 class="mk-h">Your ${pl.horizon}-day plan</h3><p class="rp-note">${pl.left != null && pl.left >= 1 ? `Counting down to your exam in ${plural(pl.left, "day")}${pl.left > 14 ? " — showing the next 14" : ""}.` : "A week of focused practice. Set an exam date above to plan toward it."} Built from your weak lessons, due reviews and recent papers; it changes as your results do.</p><div class="xc-plan">${pl.days.map((d) => `<div class="xc-day"><b>${label(d.i)}</b>${d.items.map(item).join("")}</div>`).join("")}</div></section>`;
  }

  // =========================================================== readiness
  function renderReadiness(panel) {
    const rd = X.readiness(learn), set = X.settings(), next = PRESET(rd.next.id);
    const bandClass = (b) => "xc-band-" + b.id;
    const days = set.examDate ? Math.ceil((new Date(set.examDate + "T23:59:59") - Date.now()) / 86400000) : null;
    let goal = "";
    if (rd.overall == null) goal = "Take an exam or finish a few lesson quizzes and your readiness estimate appears here.";
    else {
      const gap = set.target - rd.overall;
      goal = gap <= 0 ? `You're at or above your ${set.target}% target. 🎯 Keep it there with a paper every week.` : `You're ${gap} point${gap === 1 ? "" : "s"} below your ${set.target}% target.`;
      if (days != null) goal += days > 0 ? ` ${plural(days, "day")} until your exam — aim for about ${plural(Math.max(1, Math.ceil(days / 4)), "practice paper")} and clear your due reviews.` : days === 0 ? " Your exam is today — good luck!" : " Your exam date has passed; set a new one to keep a countdown.";
    }
    const rows = rd.subjects.map((s) => `<div class="xc-rrow"><div class="xc-rname"><b>${esc(s.name)}</b><small>${s.examAcc != null ? "Exams " + s.examAcc + "%" : "No exam data"} · ${s.practice != null ? "Quizzes " + s.practice + "%" : "No quiz data"} · ${s.explored}/${s.total} lessons${s.due ? " · " + s.due + " due" : ""}</small></div>
      <div class="mk-meter" role="img" aria-label="${esc(s.name)} readiness ${s.value == null ? "unknown" : s.value + " percent"}"><i style="width:${s.value || 0}%"></i></div>
      <span class="xc-bandchip ${bandClass(s.band)}">${s.value == null ? "—" : s.value + "%"} · ${esc(s.band.label)}</span><button class="st-btn" type="button" data-practise="${esc(s.name)}">Practise</button></div>`).join("");
    const weakRows = rd.weak.slice(0, 6).map((w) => `<div class="mk-hist"><span>${w.href ? `<a href="../${esc(w.href)}">${esc(w.lesson)}</a>` : esc(w.lesson)} · ${esc(w.subject)}${w.mistakes ? ` · ${plural(w.mistakes, "missed question")}` : ""}</span><b>${w.acc}%</b></div>`).join("");
    panel.innerHTML = `
      <div class="st-card xc-rd-top"><div class="xc-gauge">${ring(rd.overall, 150, "Overall readiness " + (rd.overall == null ? "unknown" : rd.overall + " percent"))}<span class="xc-bandchip ${bandClass(rd.band)}">${esc(rd.band.label)}</span></div>
        <div class="xc-rd-tx"><p class="eyebrow">Exam readiness</p><h2>${rd.overall == null ? "Not enough data yet" : rd.overall + "% ready"}</h2>
          ${rd.range ? `<p>On a full paper today you'd likely score about <b>${rd.range[0]}–${rd.range[1]}%</b>. <span class="xc-conf ${rd.confidence}">${rd.confidence} confidence</span></p>` : ""}
          <p class="rp-note">${rd.overall == null ? "" : `Based on ${rd.evidence} question${rd.evidence === 1 ? "" : "s"} across ${rd.subjectsWithData} of ${rd.subjects.length} subjects. `}${esc(goal)}</p>
          <div class="xc-target"><label>Target score <input type="number" min="30" max="100" value="${set.target}" data-target aria-label="Target score percent"> %</label><label>Exam date <input type="date" value="${esc(set.examDate)}" data-examdate></label>${set.examDate ? '<button class="st-btn ghost" type="button" data-cleardate>Clear date</button>' : ""}</div></div></div>
      <div class="rp-two" style="margin-top:14px"><section class="st-card"><h3 class="mk-h">Exam score trend</h3>${trendChart(rd.trend, set.target)}</section>
        <section class="st-card"><h3 class="mk-h">Next best step</h3><div class="xc-nextcard"><span class="xc-pi" aria-hidden="true">${next.icon}</span><div><b>${esc(next.label)}</b><p>${esc(rd.next.why)}</p></div></div><button class="st-btn primary" type="button" data-pick-preset="${next.id}">Set up this paper</button></section></div>
      <section class="st-card" style="margin-top:14px"><h3 class="mk-h">Readiness by subject</h3><p class="rp-note">Recent exams, lesson quizzes and coverage combined. Tap Practise for a paper in that subject.</p><div class="xc-rrows">${rows}</div></section>
      <section class="st-card" style="margin-top:14px"><div class="mk-rhead"><h3 class="mk-h" style="margin:0">Where to focus</h3>${rd.weak.length ? '<button class="st-btn" type="button" data-pick-preset="weak">🎯 Drill these lessons</button>' : ""}</div>${weakRows || '<p class="rp-none" style="margin-top:10px">No lesson is below 60% across your recent exams and quizzes. Keep sitting papers to keep this accurate.</p>'}</section>
      ${planHtml(studyPlan(rd, set))}
      <details class="xc-how"><summary>How is readiness calculated?</summary><p>For each subject we combine your accuracy in the last six exams (weighting newer ones more) with the average of your last three quiz scores per lesson. More questions answered means more weight on that signal. The result is scaled by how many of that subject's lessons you've actually opened, and reduced slightly for each overdue question in your Mistake Notebook. The overall figure is the average of the subjects with data, and the range widens when there is little evidence. It's an estimate to guide revision, not a promise of a real result.</p></details>`;
  }

  // =========================================================== history
  function renderHistory(panel) {
    const h = X.history(), st = X.stats();
    if (!h.length) { panel.innerHTML = `<div class="st-card st-empty"><span class="big">📝</span><b>No exams taken yet.</b><p>Your papers, scores and full analyses will be kept here. <button class="xc-link" type="button" data-to="start">Start your first exam →</button></p></div>`; return; }
    const rich = X.attempts();
    panel.innerHTML = `
      <div class="st-stats"><div class="st-stat"><b>${st.count}</b><span>Exams taken</span></div><div class="st-stat"><b>${st.best}%</b><span>Best score</span></div><div class="st-stat"><b>${st.avg}%</b><span>Average</span></div><div class="st-stat"><b>${st.secs ? X.fmtDur(st.secs) : "—"}</b><span>Time in exams</span></div></div>
      <section class="st-card"><h3 class="mk-h">Score trend</h3>${trendChart(rich.slice(-12).map((a) => ({ at: a.at, pct: a.pct, title: a.title })), X.settings().target)}</section>
      <section class="st-card" style="margin-top:14px"><h3 class="mk-h">All exams</h3><div class="xc-hlist">${h.map((a) => {
        const pill = a.pct >= 80 ? "score-pill-high" : a.pct >= 50 ? "score-pill-mid" : "score-pill-low";
        const date = new Date(a.at).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
        return `<div class="xc-hrow"><div class="xc-ht"><b>${esc(a.title)}</b><small>${date}${a.legacy ? " · earlier test, no question breakdown kept" : " · " + X.fmtDur(a.secsUsed) + " of " + X.fmtDur(a.secsAllowed)}</small></div><span class="xc-hm">${num(a.marks)}/${a.maxMarks}</span><span class="score-pill ${pill}">${a.pct}%</span>${a.legacy ? "<span></span>" : `<span class="xc-ha"><button class="st-btn" type="button" data-open="${esc(a.id)}">${a.qs ? "Review" : "Summary"}</button><button class="st-btn ghost" type="button" data-del="${esc(a.id)}" aria-label="Delete ${esc(a.title)}">🗑</button></span>`}</div>`;
      }).join("")}</div></section>`;
  }

  // =========================================================== wiring
  function selectPreset(id, extra, scroll) {
    cfg = newCfg(id, extra); tab = "start"; renderHome();
    if (scroll !== false) { const el = $("[data-xc-config]"); if (el && el.scrollIntoView) el.scrollIntoView({ behavior: "smooth", block: "start" }); }
  }

  root.addEventListener("click", async (e) => {
    const b = e.target.closest("button"); if (!b) return;
    if (b.hasAttribute("data-print")) { if (rvApi) rvApi.printAll(); setTimeout(() => window.print(), 60); return; }
    if (b.dataset.redo) { startRedo(b.dataset.redo); return; }
    if (b.dataset.tab) { tab = b.dataset.tab; renderHome(); return; }
    if (b.dataset.pickPreset) { selectPreset(b.dataset.pickPreset); return; }
    if (b.dataset.practise) { selectPreset("subject", { subject: b.dataset.practise, n: 20, mins: 22 }); return; }
    if (b.dataset.to) { tab = b.dataset.to; show("home"); renderHome(); return; }
    if (b.dataset.again) { const id = PRESET(b.dataset.again) ? b.dataset.again : "test20"; show("home"); selectPreset(id); return; }
    if (b.dataset.open) { const a = X.attempt(b.dataset.open); if (a) renderResult(a, { fresh: false }); return; }
    if (b.dataset.del) { if (await modal({ title: "Delete this exam?", body: "<p>It will be removed from your history and readiness estimate. Questions already in your Mistake Notebook stay there.</p>", actions: [{ label: "Cancel", value: false }, { label: "Delete", value: true, primary: true }] })) { X.removeAttempt(b.dataset.del); renderHome(); } return; }
    if (b.hasAttribute("data-resume")) { resumeActive(); return; }
    if (b.hasAttribute("data-discard")) { if (await modal({ title: "Discard this exam?", body: "<p>Your answers so far will be lost and nothing will be marked.</p>", actions: [{ label: "Keep it", value: false }, { label: "Discard", value: true, primary: true }] })) { X.clearActive(); renderHome(); } return; }
    if (b.hasAttribute("data-back")) { show("home"); renderHome(); return; }
    if (b.hasAttribute("data-begin")) { startExam(); return; }
    if (b.hasAttribute("data-brief")) { renderBrief(); return; }
    if (b.hasAttribute("data-reroll")) { roll(cfg); renderConfig(); return; }
    if (b.hasAttribute("data-all")) { cfg.subjects = cfg.subjects.size === SUBJECTS.length ? new Set() : new Set(SUBJECTS); renderConfig(); return; }
    if (b.hasAttribute("data-cleardate")) { X.setSettings({ examDate: "" }); renderHome(); return; }
    if (!cfg) return;
    if (b.dataset.subj) { cfg.subjects.has(b.dataset.subj) ? cfg.subjects.delete(b.dataset.subj) : cfg.subjects.add(b.dataset.subj); renderConfig(); }
    else if (b.dataset.subject) { cfg.subject = b.dataset.subject; renderConfig(); }
    else if (b.dataset.len) { cfg.n = Number(b.dataset.len); cfg.mins = Math.ceil(cfg.n * 1.1); renderConfig(); }
    else if (b.dataset.neg != null) { cfg.neg = X.NEG[Number(b.dataset.neg)].v; X.setSettings({ neg: cfg.neg }); renderConfig(); }
    else if (b.dataset.mode) { cfg.strict = b.dataset.mode === "strict"; X.setSettings({ strict: cfg.strict }); renderConfig(); }
  });
  root.addEventListener("input", (e) => {
    const f = e.target.dataset && e.target.dataset.f;
    if (f && cfg) {
      const v = Number(e.target.value);
      if (f === "n") { cfg.n = Math.max(1, Math.min(150, Math.round(v) || 1)); if (!cfg.minsTouched) { cfg.mins = Math.max(5, Math.ceil(cfg.n * 1.1)); const m = $("[data-f=mins]"); if (m) m.value = cfg.mins; } }
      else if (f === "mins") { cfg.mins = Math.max(1, Math.min(240, Math.round(v) || 1)); cfg.minsTouched = true; }
      renderSummary();
    }
  });
  root.addEventListener("change", (e) => {
    const t = e.target;
    if (t.dataset.f && cfg) {
      if (t.dataset.f === "perQ") cfg.perQ = Number(t.value);
      if (t.dataset.f === "n") { cfg.n = Math.max(5, Math.min(150, Math.round(Number(t.value)) || 5)); t.value = cfg.n; if (!cfg.minsTouched) { cfg.mins = Math.max(5, Math.ceil(cfg.n * 1.1)); const m = $("[data-f=mins]"); if (m) m.value = cfg.mins; } }
      if (t.dataset.f === "mins") { cfg.mins = Math.max(5, Math.min(240, Math.round(Number(t.value)) || 5)); t.value = cfg.mins; cfg.minsTouched = true; }
      renderSummary();
    } else if (t.hasAttribute("data-studied") && cfg) { cfg.studied = t.checked; renderSummary(); }
    else if (t.hasAttribute("data-target")) { X.setSettings({ target: Number(t.value) }); renderHome(); }
    else if (t.hasAttribute("data-examdate")) { X.setSettings({ examDate: t.value }); renderHome(); }
  });

  async function startExam() {
    if (!cfg) return;
    if (X.active()) {
      const ok = await modal({ title: "Replace the exam in progress?", body: "<p>You already have a paper in progress. Starting a new one discards it without marking.</p>", actions: [{ label: "Keep the old one", value: false }, { label: "Start new paper", value: true, primary: true }] });
      if (!ok) return;
    }
    const s = buildSession(cfg);
    if (!s.qs.length) { toast("No questions match that setup", { icon: "⚠️" }); return; }
    X.saveActive(s);
    runSession(s);
  }
  function resumeActive() {
    const s = X.active(); if (!s) return;
    if (X.usedSecs(s) >= s.allowed) { session = s; finish(true); return; }
    runSession(s);
    toast("Welcome back — your clock is running", { icon: "▶️", duration: 2500 });
  }

  // refresh when other parts of the site update progress (only while on the home screen)
  function refresh() {
    clearTimeout(refresh.t);
    refresh.t = setTimeout(async () => {
      if (L) { try { learn = await L.get(); } catch (_) { /* keep old snapshot */ } }
      if (stages.home.hidden) return;
      if (tab !== "start" || !cfg) renderHome(); else { renderResume(); renderStats(); }
    }, 200);
  }
  ["curio-learning-updated", "curio-review-updated", "curio-exam-updated"].forEach((ev) => window.addEventListener(ev, refresh));

  // =========================================================== init
  async function init() {
    try { learn = L ? await L.get() : null; } catch (_) { learn = null; }
    const q = new URLSearchParams(location.search);
    if (["start", "readiness", "history"].includes(q.get("tab"))) tab = q.get("tab");
    const start = q.get("start");
    if (start && PRESET(start)) { const subj = q.get("subject"); cfg = newCfg(start, subj && SUBJECTS.includes(subj) ? { subject: subj } : {}); tab = "start"; }
    show("home"); renderHome();
    if (q.get("resume") === "1" && X.active()) resumeActive();
    else if (cfg) { const el = $("[data-xc-config]"); if (el && el.scrollIntoView) setTimeout(() => el.scrollIntoView({ behavior: "smooth", block: "start" }), 100); }
  }
  init();
})();
