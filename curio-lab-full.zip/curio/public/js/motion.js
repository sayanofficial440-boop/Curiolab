// Curio Lab — Motion layer: minor, beautiful, site-wide animations.
// Auto-applies scroll reveal, button ripple, card lift/tilt and a soft page-in fade
// without needing to hand-edit every page. Fully respects prefers-reduced-motion.
(function () {
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // ---------- 1. Soft page-in fade ----------
  document.documentElement.classList.add("curio-loading");
  window.addEventListener("DOMContentLoaded", () => {
    requestAnimationFrame(() => {
      document.documentElement.classList.remove("curio-loading");
      document.documentElement.classList.add("curio-loaded");
    });
  });

  // ---------- 2. Auto scroll-reveal for common content blocks ----------
  function autoTagReveal() {
    const selectors = [
      "main .wrap > section:not(.mode-panel)", ".subject-card", ".about-block", ".card",
      ".game-tile", ".footer-col", ".hero-stat", ".feature-card",
      ".lesson-card", ".timeline-node", ".glossary-entry", ".pricing-card", ".term-card",
    ];
    const seen = new Set();
    selectors.forEach((sel) => {
      document.querySelectorAll(sel).forEach((el, i) => {
        if (seen.has(el) || el.hasAttribute("data-reveal") || el.hasAttribute("data-no-reveal")) return;
        seen.add(el);
        el.setAttribute("data-reveal", "");
        el.setAttribute("data-reveal-delay", String(Math.min(i * 40, 320)));
      });
    });
  }

  function initRevealObserver() {
    const items = document.querySelectorAll("[data-reveal]:not(.revealed)");
    if (!items.length) return;
    if (reduce || !("IntersectionObserver" in window)) {
      items.forEach((el) => el.classList.add("revealed"));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const delay = entry.target.dataset.revealDelay || 0;
          setTimeout(() => entry.target.classList.add("revealed"), +delay);
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -30px 0px" });
    items.forEach((el) => io.observe(el));
  }

  // ---------- 3. Button ripple ----------
  function addRipple(e) {
    const el = e.target.closest("button, .timer-btn, .quiz-next, a.cta");
    if (!el || reduce || el.closest("[data-no-ripple]")) return;
    const rect = el.getBoundingClientRect();
    const r = document.createElement("span");
    r.className = "curio-ripple";
    const size = Math.max(rect.width, rect.height) * 1.6;
    r.style.width = r.style.height = size + "px";
    r.style.left = (e.clientX - rect.left - size / 2) + "px";
    r.style.top = (e.clientY - rect.top - size / 2) + "px";
    const computed = getComputedStyle(el).position;
    if (computed === "static") el.style.position = "relative";
    el.style.overflow = el.style.overflow || "hidden";
    el.appendChild(r);
    r.addEventListener("animationend", () => r.remove());
  }

  // ---------- 4. Card lift on hover (via CSS class toggle, cheap) ----------
  function wireCardLift() {
    document.querySelectorAll(".subject-card, .card, .lesson-card, .feature-card, .pricing-card").forEach((el) => {
      el.classList.add("curio-liftable");
    });
  }

  // ---------- 5. Full-screen page transition on internal navigation ----------
  // Same "cinema" wipe used on the homepage's subject cards, generalized so it
  // fires from any lesson or subject page. Builds its own veil markup if a page
  // doesn't already have one (only index.html ships it inline).
  function initPageTransitions() {
    let veil = document.querySelector("[data-page-veil]");
    let panel = document.querySelector("[data-veil-panel]");
    if (!veil) {
      veil = document.createElement("div");
      veil.className = "page-veil";
      veil.setAttribute("data-page-veil", "");
      veil.setAttribute("aria-hidden", "true");
      panel = document.createElement("span");
      panel.className = "veil-panel";
      panel.setAttribute("data-veil-panel", "");
      veil.appendChild(panel);
      document.body.appendChild(veil);
    }

    document.addEventListener("click", (e) => {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      const link = e.target.closest("a[href]");
      if (!link) return;
      const href = link.getAttribute("href");
      if (!href || href.startsWith("#") || href.startsWith("http") || href.startsWith("mailto:") || href.startsWith("tel:") || link.target === "_blank" || link.hasAttribute("download")) return;

      e.preventDefault();
      // Prefer the clicked card's own accent (homepage subject cards, lesson
      // cards), falling back to the page-level accent set on <body> for
      // subject hub / lesson pages, then the theme default.
      const accentSource = link.closest("[style*='--accent']") || document.body;
      const accent = getComputedStyle(accentSource).getPropertyValue("--accent").trim();
      panel.style.background = accent || "";
      veil.classList.add("is-active");
      const delay = reduce ? 150 : 550;
      setTimeout(() => { window.location.href = href; }, delay);
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    autoTagReveal();
    initRevealObserver();
    wireCardLift();
    initPageTransitions();
    document.addEventListener("click", addRipple);

    // Re-scan after dynamic content renders (games, quizzes, globe cards, etc.)
    const mo = new MutationObserver(() => {
      autoTagReveal();
      initRevealObserver();
      wireCardLift();
    });
    mo.observe(document.body, { childList: true, subtree: true });
  });
})();
