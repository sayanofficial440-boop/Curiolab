// Curio Lab — Realistic geography maps.
// Renders real Natural Earth geometry (pre-projected by the build step in js/geo-data/*.js)
// as (1) an annotated map, (2) a layered explorer with country info, (3) a locate-the-country challenge.
window.onLessonContentReady(() => {
  const G = window.CURIO_GEO;
  if (!G) return;
  const NS = "http://www.w3.org/2000/svg";
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;");
  const PAL = ["#f4b7a6", "#f6d58a", "#cfe0a0", "#a9d6c9", "#b4c8ea", "#d8b9e3", "#f0c3d4", "#e8d9a8"];
  const fmt = (n) => (n == null ? "—" : Math.round(n).toLocaleString("en-US"));
  const compact = (n) => (n >= 1e9 ? (n / 1e9).toFixed(2) + " billion" : n >= 1e6 ? (n / 1e6).toFixed(1) + " million" : fmt(n));
  let uid = 0;
  // North/South America lessons show no compass overlay.
  const NO_COMPASS = new Set(["North America", "South America"]);

  function defs(id) {
    return `<defs>
      <linearGradient id="gsea${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--geo-sea-a)"/><stop offset="1" stop-color="var(--geo-sea-b)"/></linearGradient>
      <filter id="gblur${id}" x="-5%" y="-5%" width="110%" height="110%"><feGaussianBlur stdDeviation="3"/></filter>
      <filter id="gsoft${id}"><feGaussianBlur stdDeviation="2.4"/></filter>
      <filter id="gemboss${id}" x="-5%" y="-5%" width="110%" height="110%">
        <feGaussianBlur in="SourceAlpha" stdDeviation="3.2" result="b"/>
        <feDiffuseLighting in="b" surfaceScale="9" diffuseConstant="1.15" lighting-color="#ffffff" result="l"><feDistantLight azimuth="315" elevation="42"/></feDiffuseLighting>
        <feComposite in="l" in2="SourceAlpha" operator="in"/>
      </filter>
      <filter id="grelief${id}" x="0" y="0" width="100%" height="100%">
        <feTurbulence type="fractalNoise" baseFrequency="0.011 0.017" numOctaves="4" seed="7" result="n"/>
        <feColorMatrix in="n" type="matrix" values="0 0 0 0 .45  0 0 0 0 .40  0 0 0 0 .32  0 0 0 1.1 -.35"/>
      </filter>
      <clipPath id="gclip${id}"><path d="${G.countries.map((c) => c.d).join("")}"/></clipPath>
    </defs>`;
  }

  function riverLabelPaths(id) {
    const want = G.riverLabels || [];
    const best = {};
    G.rivers.forEach((r) => { if (want.includes(r.n) && (!best[r.n] || r.d.length > best[r.n].d.length)) best[r.n] = r; });
    return Object.values(best).map((r, i) => `<path id="gr${id}_${i}" d="${r.d}" fill="none"/><text class="g-rlabel"><textPath href="#gr${id}_${i}" startOffset="45%">${esc(r.n)}</textPath></text>`).join("");
  }

  function svgMarkup(id, o) {
    const land = G.countries.map((c) => c.d).join("");
    const T = (k) => G.terrain.filter((t) => t.k === k).map((t) => t.d).join("");
    const rv = G.rivers.map((r) => `<path class="g-river" d="${r.d}" stroke-width="${Math.max(0.9, 2.6 - r.k * 0.36).toFixed(1)}"/>`).join("");
    const cty = G.countries.map((c, i) => `<path class="g-cty" data-id="${c.id}" style="--pf:${PAL[(c.c || 1) % 8 - 0] || PAL[0]}" d="${c.d}"><title>${esc(c.n)}</title></path>`).join("");
    const labels = G.countries.filter((c) => c.lab && c.area > 60000).map((c) => {
      const fs = c.area > 2.5e6 ? 15 : c.area > 8e5 ? 12 : c.area > 2e5 ? 10 : 8.5;
      return `<text class="g-clabel" x="${c.lab[0]}" y="${c.lab[1]}" font-size="${fs}">${esc(c.n.length > 16 ? c.n.replace("Democratic Republic of the Congo", "DR Congo").replace("Central African Republic", "C.A.R.").replace("United States of America", "United States").replace("Dominican Republic", "Dominican Rep.") : c.n)}</text>`;
    }).join("");
    const seas = G.seas.filter((s) => s.x).map((s) => `<text class="g-sealabel" x="${s.x[0]}" y="${s.x[1]}" font-size="14">${esc(s.n)}</text>`).join("");
    const peaks = G.peaks.map((p) => `<g class="g-peak"><polygon points="${p.x[0]},${p.x[1] - 6} ${p.x[0] - 5},${p.x[1] + 3.5} ${p.x[0] + 5},${p.x[1] + 3.5}"/><text x="${p.x[0] + 7}" y="${p.x[1] + 3}">${esc(p.n)} ${fmt(p.e)} m</text></g>`).join("");
    const cities = G.cities.map((c) => `<g class="g-city${c.cap ? " cap" : ""}">${c.cap ? `<rect x="${c.x[0] - 3.5}" y="${c.x[1] - 3.5}" width="7" height="7"/>` : `<circle cx="${c.x[0]}" cy="${c.x[1]}" r="3.4"/>`}<text x="${c.x[0] + 7}" y="${c.x[1] + 3.5}">${esc(c.n)}</text></g>`).join("");
    const pins = o.pins ? G.pins.map((p, i) => `<g class="g-pin" data-pin="${i}" color="${p.color}" style="color:${p.color}" tabindex="0" role="button" aria-label="${esc(p.device)}"><circle class="ring" cx="${p.x[0]}" cy="${p.x[1]}" r="8"/><circle class="halo" cx="${p.x[0]}" cy="${p.x[1]}" r="17"/><circle class="dot" cx="${p.x[0]}" cy="${p.x[1]}" r="9"/><text x="${p.x[0] + 14}" y="${p.x[1] + 4}" style="fill:var(--geo-label)">${esc(p.device)}</text><text x="${p.x[0]}" y="${p.x[1] + 4}" text-anchor="middle" style="fill:#fff;stroke:none;font-size:10px">${i + 1}</text></g>`).join("") : "";
    return `<svg viewBox="0 0 ${G.W} ${G.H}" role="img" aria-label="Physical map of ${esc(G.cont)}">${defs(id)}
      <rect class="g-sea" width="${G.W}" height="${G.H}" style="fill:url(#gsea${id})"/>
      <g data-l="grat"><path class="g-grat" d="${G.grat}"/></g>
      <path class="g-neigh" d="${G.neigh}"/>
      <path class="g-shadow" d="${land}" transform="translate(2,3)" style="filter:url(#gblur${id})"/>
      <path class="g-land" d="${land}"/>
      <g data-l="terrain" clip-path="url(#gclip${id})">
        <g class="g-terrain" style="filter:url(#gsoft${id})"><path class="t-pln" d="${T("pln")}"/><path class="t-plt" d="${T("plt")}"/><path class="t-wet" d="${T("wet")}"/><path class="t-tun" d="${T("tun")}"/><path class="t-des" d="${T("des")}"/><path class="t-mtn" d="${T("mtn")}"/></g>
        <g class="g-relief" style="mix-blend-mode:multiply;opacity:.5"><rect width="${G.W}" height="${G.H}" style="filter:url(#grelief${id})"/></g>
        <g style="mix-blend-mode:multiply;opacity:.55"><path class="t-mtn" d="${T("mtn")}" style="filter:url(#gemboss${id});fill:#fff;opacity:1"/></g>
      </g>
      <path class="g-lakes" d="${G.lakes}"/>
      <g data-l="rivers">${rv}${riverLabelPaths(id)}</g>
      <g data-l="countries">${cty}</g>
      <g data-l="peaks">${peaks}</g>
      <g data-l="cities">${cities}</g>
      <g data-l="labels">${labels}${seas}</g>
      ${pins}
    </svg>
    ${NO_COMPASS.has(G.cont) ? "" : `<svg class="geo-compass" viewBox="0 0 44 44" aria-hidden="true"><circle cx="22" cy="22" r="20" fill="var(--color-surface)" opacity=".85" stroke="var(--color-line-strong)"/><path d="M22 6 L27 22 L22 20 L17 22Z" fill="#c1361f"/><path d="M22 38 L27 22 L22 24 L17 22Z" fill="var(--color-ink-soft)"/><text x="22" y="15.5" text-anchor="middle" font-size="7" font-weight="700" fill="#fff" font-family="sans-serif">N</text></svg>`}`;
  }

  // ---- pan / zoom (viewBox based) ----
  function makeZoomable(wrap, svg) {
    const W = G.W, H = G.H;
    let vb = { x: 0, y: 0, w: W, h: H };
    const apply = () => svg.setAttribute("viewBox", `${vb.x} ${vb.y} ${vb.w} ${vb.h}`);
    const clamp = () => { vb.w = Math.min(W, Math.max(W / 8, vb.w)); vb.h = vb.w * H / W; vb.x = Math.min(W - vb.w, Math.max(0, vb.x)); vb.y = Math.min(H - vb.h, Math.max(0, vb.y)); };
    const zoomAt = (f, cx, cy) => { const nx = vb.x + (cx) * vb.w, ny = vb.y + (cy) * vb.h; vb.w *= f; vb.h *= f; vb.x = nx - cx * vb.w; vb.y = ny - cy * vb.h; clamp(); apply(); scaleBar(); };
    const scale = document.createElement("div"); scale.className = "geo-scale"; wrap.appendChild(scale);
    const scaleBar = () => { scale.textContent = vb.w >= W - 1 ? "Scroll / pinch to zoom · drag to pan" : `${(W / vb.w).toFixed(1)}× zoom`; };
    scaleBar();
    const zc = document.createElement("div"); zc.className = "geo-zoom";
    zc.innerHTML = `<button type="button" aria-label="Zoom in">+</button><button type="button" aria-label="Zoom out">−</button><button type="button" aria-label="Reset view" style="font-size:12px">⟲</button>`;
    wrap.appendChild(zc);
    const [bi, bo, br] = zc.querySelectorAll("button");
    bi.onclick = () => zoomAt(0.65, 0.5, 0.5); bo.onclick = () => zoomAt(1.5, 0.5, 0.5); br.onclick = () => { vb = { x: 0, y: 0, w: W, h: H }; apply(); scaleBar(); };
    svg.addEventListener("wheel", (e) => { e.preventDefault(); const r = svg.getBoundingClientRect(); zoomAt(e.deltaY < 0 ? 0.85 : 1.18, (e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height); }, { passive: false });
    const pts = new Map(); let last = null, moved = 0, pd = 0;
    svg.addEventListener("pointerdown", (e) => { pts.set(e.pointerId, e); last = { x: e.clientX, y: e.clientY }; moved = 0; if (pts.size === 2) { const [a, b] = [...pts.values()]; pd = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY); } });
    svg.addEventListener("pointermove", (e) => {
      if (!pts.has(e.pointerId)) return; pts.set(e.pointerId, e);
      const r = svg.getBoundingClientRect();
      if (pts.size === 2) { const [a, b] = [...pts.values()]; const d = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY); if (pd) zoomAt(pd / d, ((a.clientX + b.clientX) / 2 - r.left) / r.width, ((a.clientY + b.clientY) / 2 - r.top) / r.height); pd = d; moved = 99; return; }
      const dx = e.clientX - last.x, dy = e.clientY - last.y; moved += Math.abs(dx) + Math.abs(dy);
      if (moved > 6) { svg.classList.add("dragging"); vb.x -= dx * vb.w / r.width; vb.y -= dy * vb.h / r.height; clamp(); apply(); }
      last = { x: e.clientX, y: e.clientY };
    });
    const up = (e) => { pts.delete(e.pointerId); pd = 0; svg.classList.remove("dragging"); setTimeout(() => (moved = 0), 0); };
    svg.addEventListener("pointerup", up); svg.addEventListener("pointercancel", up);
    return { wasDrag: () => moved > 6 };
  }

  function mount(host, opts) {
    const id = ++uid;
    host.classList.add("geo-map");
    host.innerHTML = svgMarkup(id, opts);
    const svg = host.querySelector("svg");
    const zoom = makeZoomable(host, svg);
    return { svg, host, zoom };
  }
  const layer = (m, name, on) => { m.svg.querySelectorAll(`[data-l="${name}"]`).forEach((g) => g.classList.toggle("g-hidden", !on)); };

  // ================= 1. ANNOTATED MAP =================
  const annHost = $("[data-geo-annotated]");
  if (annHost) {
    const m = mount(annHost, { pins: true });
    layer(m, "labels", true); layer(m, "grat", true);
    m.svg.querySelectorAll(".g-cty").forEach((p) => (p.style.pointerEvents = "none"));
    const card = $("[data-analysis-card]");
    const show = (i) => {
      const p = G.pins[i];
      m.svg.querySelectorAll(".g-pin").forEach((g) => g.classList.toggle("active", +g.dataset.pin === i));
      if (window.CurioSound) window.CurioSound.play("open");
      card.innerHTML = `<span class="device-tag" style="background:${p.color};color:#fff">${esc(p.cat)}</span><p class="quoted">${esc(p.device)}</p><p>${p.note}</p>`;
      card.classList.remove("just-updated"); void card.offsetWidth; card.classList.add("just-updated");
    };
    m.svg.querySelectorAll(".g-pin").forEach((g) => {
      g.addEventListener("click", () => !m.zoom.wasDrag() && show(+g.dataset.pin));
      g.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); show(+g.dataset.pin); } });
    });
    const lg = $("[data-geo-annotated-legend]");
    if (lg) { const cats = {}; G.pins.forEach((p) => (cats[p.cat] = p.color)); lg.innerHTML = Object.entries(cats).map(([k, c]) => `<span><i style="background:${c}"></i>${esc(k)}</span>`).join(""); }
  }

  // ================= 2. EXPLORER =================
  const exHost = $("[data-geo-explorer]");
  if (exHost) {
    const m = mount(exHost, {});
    const info = $("[data-geo-info]");
    const state = { terrain: true, rivers: true, peaks: true, cities: true, labels: true, grat: true, political: false };
    const apply = () => { Object.keys(state).forEach((k) => k !== "political" && layer(m, k, state[k])); layer(m, "countries", true); exHost.classList.toggle("political", state.political); };
    $("[data-geo-layers]").querySelectorAll("input").forEach((inp) => {
      inp.addEventListener("change", () => { state[inp.dataset.layer] = inp.checked; inp.parentElement.classList.toggle("on", inp.checked); apply(); if (window.CurioSound) window.CurioSound.play("click"); });
    });
    apply();
    const byId = Object.fromEntries(G.countries.map((c) => [c.id, c]));
    const showC = (c) => {
      m.svg.querySelectorAll(".g-cty.sel").forEach((p) => p.classList.remove("sel"));
      m.svg.querySelector(`.g-cty[data-id="${c.id}"]`).classList.add("sel");
      info.innerHTML = `<h4>${esc(c.n)}</h4><p class="hint">${esc(c.sub || G.cont)}</p><dl>
        <dt>Capital</dt><dd>${esc(c.cap || "—")}</dd><dt>Population</dt><dd>≈ ${compact(c.pop)}</dd>
        <dt>Area</dt><dd>≈ ${fmt(c.area)} km²</dd><dt>Density</dt><dd>≈ ${fmt(c.pop / Math.max(c.area, 1))} people / km²</dd>
        <dt>Income</dt><dd>${esc(c.inc || "—")}</dd><dt>Economy</dt><dd>${c.gdp ? "≈ US$ " + compact(c.gdp * 1e6) : "—"}</dd></dl>`;
      if (window.CurioSound) window.CurioSound.play("open");
    };
    m.svg.querySelectorAll(".g-cty").forEach((p) => p.addEventListener("click", () => !m.zoom.wasDrag() && showC(byId[p.dataset.id])));
    // legend
    const lg = $("[data-geo-legend]");
    if (lg) lg.innerHTML = `<span><i style="background:var(--geo-des)"></i>Desert</span><span><i style="background:var(--geo-mtn)"></i>Mountains</span><span><i style="background:var(--geo-plt)"></i>Plateau</span><span><i style="background:var(--geo-pln)"></i>Plains / basins</span><span><i style="background:var(--geo-wet)"></i>Wetlands</span><span><i style="background:var(--geo-tun)"></i>Tundra</span><span><i style="background:var(--geo-river)"></i>Rivers &amp; lakes</span>`;
  }

  // ================= 3. CHALLENGE =================
  const chHost = $("[data-geo-challenge]");
  if (chHost) {
    const m = mount(chHost, {});
    ["terrain", "rivers", "peaks", "cities", "labels"].forEach((k) => layer(m, k, k === "terrain" || k === "rivers"));
    chHost.classList.add("political");
    const pool = G.countries.filter((c) => c.area >= 12000 && c.d);
    const byId = Object.fromEntries(G.countries.map((c) => [c.id, c]));
    const el = { target: $("[data-geo-target]"), fb: $("[data-geo-feedback]"), score: $("[data-geo-score]"), round: $("[data-geo-round]"), best: $("[data-geo-best]"), res: $("[data-geo-result]"), opts: $("[data-geo-opts]"), modes: $("[data-geo-modes]") };
    const bestKey = "curiolab.geo.best." + G.cont.replace(/\s/g, "");
    let best = 0; try { best = +localStorage.getItem(bestKey) || 0; } catch (e) {}
    el.best.textContent = best;
    let mode = "locate", queue = [], idx = 0, score = 0, streak = 0, locked = false, cur = null, TOTAL = 10;
    const shuffle = (a) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
    const clear = () => m.svg.querySelectorAll(".g-cty").forEach((p) => p.classList.remove("good", "bad", "miss", "sel"));
    function start() {
      queue = shuffle(mode === "capital" ? pool.filter((c) => c.cap) : pool).slice(0, TOTAL); idx = 0; score = 0; streak = 0; el.res.style.display = "none"; next();
    }
    function next() {
      if (idx >= queue.length) return finish();
      clear(); locked = false; cur = queue[idx]; el.round.textContent = `${idx + 1} / ${queue.length}`; el.score.textContent = score; el.fb.textContent = ""; el.fb.className = "geo-feedback";
      el.opts.innerHTML = "";
      if (mode === "locate") { el.target.innerHTML = `Find: ${esc(cur.n)}<small>Click the country on the map</small>`; }
      else {
        m.svg.querySelector(`.g-cty[data-id="${cur.id}"]`).classList.add("sel");
        el.target.innerHTML = `What is the capital of this country?<small>The highlighted country</small>`;
        const wrong = shuffle(pool.filter((c) => c.cap && c.cap !== cur.cap)).slice(0, 3).map((c) => c.cap);
        shuffle([cur.cap, ...wrong]).forEach((cap) => { const b = document.createElement("button"); b.type = "button"; b.className = "quiz-option"; b.textContent = cap; b.onclick = () => answerCap(b, cap); el.opts.appendChild(b); });
      }
    }
    function done(ok, msg) {
      locked = true; if (ok) { score += 1 + (streak >= 2 ? 1 : 0); streak++; } else streak = 0;
      el.score.textContent = score; el.fb.textContent = msg; el.fb.className = "geo-feedback " + (ok ? "ok" : "no");
      if (window.CurioSound) window.CurioSound.play(ok ? "correct" : "wrong");
      setTimeout(() => { idx++; next(); }, ok ? 900 : 1700);
    }
    function answerLoc(id) {
      if (locked) return; const ok = id === cur.id;
      const p = m.svg.querySelector(`.g-cty[data-id="${id}"]`);
      if (ok) { p.classList.add("good"); done(true, `Correct! ${cur.n}${streak >= 2 ? " — streak bonus +1" : ""}`); }
      else { p.classList.add("bad"); m.svg.querySelector(`.g-cty[data-id="${cur.id}"]`).classList.add("miss"); done(false, `That's ${byId[id].n}. ${cur.n} is highlighted in green.`); }
    }
    function answerCap(btn, cap) {
      if (locked) return; const ok = cap === cur.cap; btn.classList.add(ok ? "correct" : "wrong");
      if (!ok) [...el.opts.children].forEach((b) => b.textContent === cur.cap && b.classList.add("correct"));
      [...el.opts.children].forEach((b) => (b.disabled = true));
      done(ok, ok ? `Correct! ${cur.cap} is the capital of ${cur.n}.` : `The capital of ${cur.n} is ${cur.cap}.`);
    }
    m.svg.querySelectorAll(".g-cty").forEach((p) => p.addEventListener("click", () => mode === "locate" && !m.zoom.wasDrag() && answerLoc(p.dataset.id)));
    function finish() {
      clear(); el.opts.innerHTML = ""; el.target.innerHTML = "Round complete";
      const isBest = score > best; if (isBest) { best = score; try { localStorage.setItem(bestKey, best); } catch (e) {} el.best.textContent = best; }
      el.res.style.display = "block";
      el.res.innerHTML = `<h4>${score} points</h4><p>${isBest ? "🏆 New personal best!" : `Personal best: ${best}`} · Maximum is ${TOTAL * 2} with a streak.</p><button class="timer-btn" type="button" data-geo-again>Play again</button>`;
      $("[data-geo-again]").onclick = start;
    }
    el.modes.querySelectorAll("button").forEach((b) => b.addEventListener("click", () => { mode = b.dataset.mode; el.modes.querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b)); start(); }));
    start();
  }
});
