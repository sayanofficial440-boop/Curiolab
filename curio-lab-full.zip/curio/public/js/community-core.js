// Curio Lab — community client core (profiles, leaderboards, friends). Talks to backend/community.py.
// Opt-in only: nothing is sent anywhere until a learner (13+) joins. Children's accounts never join.
// The server recomputes XP, streaks and badges from the quiz/exam summary, so the browser can't set its own score.
(function () {
  "use strict";
  if (window.CurioCommunity) return;
  const SESSION = "curiolab-local-session", PREFIX = "curio.community.v1:", SYNC_MIN_MS = 10 * 60 * 1000;
  const safe = (v, f) => { try { const x = JSON.parse(v); return x == null ? f : x; } catch (_) { return f; } };
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const user = () => safe(localStorage.getItem(SESSION), null);
  const acct = () => { const u = user(); return u && u.email ? String(u.email).toLowerCase() : null; };
  const slot = () => PREFIX + (acct() || "guest");
  const saved = () => safe(localStorage.getItem(slot()), null);          // { key, handle, lastSync }
  const save = (o) => { try { localStorage.setItem(slot(), JSON.stringify(o)); } catch (_) {} };
  const forget = () => { try { localStorage.removeItem(slot()); } catch (_) {} };

  // "ok" | "guest" | "child" | "unknown-age"
  function eligibility() {
    const u = user();
    if (!u) return "guest";
    if (u.child || (window.CurioAge && window.CurioAge.isChild())) return "child";
    if (window.CurioAge && !window.CurioAge.band()) return "unknown-age";
    return "ok";
  }
  const band = () => (window.CurioAge && window.CurioAge.band()) === "teen" ? "teen" : "adult";

  async function api(path, opts) {
    opts = opts || {};
    const h = { Accept: "application/json" };
    const s = saved();
    if (s && s.key) h.Authorization = "Bearer " + s.key;
    if (opts.body !== undefined) h["Content-Type"] = "application/json";
    let r;
    try { r = await fetch("/api/community" + path, { method: opts.method || (opts.body !== undefined ? "POST" : "GET"), headers: h, body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined }); }
    catch (_) { const e = new Error("The community server can't be reached right now."); e.offline = true; throw e; }
    const ct = r.headers.get("content-type") || "";
    if (r.status === 404 && !ct.includes("json")) { const e = new Error("The community server isn't running on this site."); e.offline = true; throw e; }
    const j = ct.includes("json") ? await r.json().catch(() => ({})) : {};
    if (!r.ok) { const e = new Error(j.error || "Something went wrong. Please try again."); e.status = r.status; throw e; }
    return j;
  }

  // Everything the server needs to compute XP: the quiz log and the exam log. It never trusts totals from here.
  function summary() {
    const scores = safe(localStorage.getItem("curiolab-scores"), []);
    const exams = safe(localStorage.getItem("curiolab-exam-log"), []);
    return { scores: (Array.isArray(scores) ? scores : []).slice(-1500), exams: (Array.isArray(exams) ? exams : []).slice(-200) };
  }

  let inflight = null;
  async function sync(force) {
    const s = saved();
    if (!s || !s.key) return null;
    if (!force && s.lastSync && Date.now() - s.lastSync < SYNC_MIN_MS) return null;
    if (inflight) return inflight;
    inflight = api("/sync", { body: { band: band(), summary: summary() } }).then((j) => {
      save(Object.assign({}, saved() || s, { lastSync: Date.now() }));
      window.dispatchEvent(new CustomEvent("curio-community-synced", { detail: j }));
      return j;
    }).catch((e) => { if (e.status === 401) forget(); return null; }).finally(() => { inflight = null; });
    return inflight;
  }

  const initials = (n) => (String(n || "?").trim().split(/\s+/).slice(0, 2).map((w) => w[0] || "").join("") || "?").toUpperCase();
  const avatar = (name, color, cls) => `<span class="cm-avatar ${cls || ""}" style="--cm-av:${esc(color || "#12213B")}" aria-hidden="true">${esc(initials(name))}</span>`;
  const fmt = (n) => Number(n || 0).toLocaleString();
  const profileUrl = (handle) => `${location.pathname.includes("/pages/") ? "" : "pages/"}u.html?h=${encodeURIComponent(handle)}`;
  const shareUrl = (handle) => `${location.origin}/u/${encodeURIComponent(handle)}`;

  // Placeholders and aria-labels aren't text nodes, so the site translator skips them: translate them from the same dictionary.
  function localize(root) {
    const L = window.CurioLang; if (!L || !L.t || !root) return;
    root.querySelectorAll("[placeholder],[aria-label]").forEach((el) => ["placeholder", "aria-label"].forEach((a) => {
      const cur = el.getAttribute(a); if (cur == null) return;
      let k = el.getAttribute("data-orig-" + a); if (k == null) { k = cur; el.setAttribute("data-orig-" + a, k); } const tr = L.t(k);
      if (tr && tr !== cur) el.setAttribute(a, tr);
    }));
  }
  function autoLocalize(root) {
    let t; const run = () => { clearTimeout(t); t = setTimeout(() => localize(root), 60); };
    new MutationObserver(run).observe(root, { childList: true, subtree: true });
    document.addEventListener("curio:langpack", run); run();
  }

  window.CurioCommunity = { localize, autoLocalize, api, saved, save, forget, eligibility, band, summary, sync, esc, avatar, fmt, initials, profileUrl, shareUrl };

  // Quietly keep a joined learner's numbers fresh (at most every 10 minutes) on pages where progress is shown.
  document.addEventListener("DOMContentLoaded", () => { if (saved() && saved().key && /\/(dashboard|scoreboard)\.html$/.test(location.pathname)) sync(false); });
})();
