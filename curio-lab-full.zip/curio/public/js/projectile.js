// Curio Lab — 3D Projectile Motion simulator
// A launched ball follows a real parabolic trajectory (physics-accurate),
// with adjustable launch angle, speed and gravity, a solid ground surface,
// a live on-screen HUD, apex/landing markers, a ghost trail of the previous
// flight for comparison, and velocity-component arrows while the ball flies.
window.onLessonContentReady(() => {
  const container = document.querySelector("[data-projectile-canvas]");
  if (!container || typeof THREE === "undefined") return;

  const angleInput = document.querySelector("[data-projectile-angle]");
  const speedInput = document.querySelector("[data-projectile-speed]");
  const angleLabel = document.querySelector("[data-projectile-angle-label]");
  const speedLabel = document.querySelector("[data-projectile-speed-label]");
  const launchBtn = document.querySelector("[data-projectile-launch]");
  const readout = document.querySelector("[data-projectile-readout]");
  const envButtons = Array.from(document.querySelectorAll("[data-projectile-env] button"));
  const autoRotateBox = document.querySelector("[data-projectile-autorotate]");
  const resetCamBtn = document.querySelector("[data-projectile-reset-cam]");
  const clearTrailBtn = document.querySelector("[data-projectile-clear-trail]");
  const hudHeight = document.querySelector("[data-hud-height]");
  const hudDist = document.querySelector("[data-hud-dist]");
  const hudSpeed = document.querySelector("[data-hud-speed]");
  const hudTime = document.querySelector("[data-hud-time]");

  if (typeof CurioSceneManager === "undefined") {
    console.warn("[projectile.js] CurioSceneManager not loaded — add <script src=\".../js/scene-manager.js\"> before this file");
    return;
  }

  // panelName: "projectile" — this file already assumed a panel by that
  // name existed (see the curiolab:tab-shown listener it had below); the
  // manager now actually gates rendering on it too, so this stops burning
  // GPU while the panel is hidden, not just skip a resize.
  const sceneManager = new CurioSceneManager(container, { fov: 45, near: 0.1, far: 200, panelName: "projectile" });
  const scene = sceneManager.scene;
  const camera = sceneManager.camera;
  const renderer = sceneManager.renderer;

  // Sky gradient background, drawn once to a canvas texture.
  const skyCanvas = document.createElement("canvas");
  skyCanvas.width = 8; skyCanvas.height = 128;
  const skyCtx = skyCanvas.getContext("2d");
  const grad = skyCtx.createLinearGradient(0, 0, 0, 128);
  grad.addColorStop(0, "#cfe0ee");
  grad.addColorStop(1, "#f6ece0");
  skyCtx.fillStyle = grad;
  skyCtx.fillRect(0, 0, 8, 128);
  const skyTex = new THREE.CanvasTexture(skyCanvas);
  scene.background = skyTex;
  scene.fog = new THREE.Fog(0xeadfd0, 26, 55);

  const START_X = -14;
  const BALL_R = 0.35;

  // --- Ground: a solid textured surface (not just a wireframe) ----------
  const groundCanvas = document.createElement("canvas");
  groundCanvas.width = 512; groundCanvas.height = 256;
  const gctx = groundCanvas.getContext("2d");
  gctx.fillStyle = "#bcd6a8";
  gctx.fillRect(0, 0, 512, 256);
  gctx.strokeStyle = "rgba(70,95,55,0.28)";
  gctx.lineWidth = 1.5;
  for (let x = 0; x <= 512; x += 512 / 20) { gctx.beginPath(); gctx.moveTo(x, 0); gctx.lineTo(x, 256); gctx.stroke(); }
  for (let y = 0; y <= 256; y += 256 / 10) { gctx.beginPath(); gctx.moveTo(0, y); gctx.lineTo(512, y); gctx.stroke(); }
  const groundTex = new THREE.CanvasTexture(groundCanvas);
  groundTex.wrapS = groundTex.wrapT = THREE.RepeatWrapping;
  groundTex.repeat.set(2, 1);

  const groundGeo = new THREE.PlaneGeometry(44, 22);
  const groundMat = new THREE.MeshStandardMaterial({ map: groundTex, roughness: 0.95, metalness: 0 });
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = 0;
  scene.add(ground);

  // Distance markers along the flight line, every 5 m, with faint tick lines.
  const tickGroup = new THREE.Group();
  for (let d = 0; d <= 30; d += 5) {
    const geo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(START_X + d, 0.01, -3), new THREE.Vector3(START_X + d, 0.01, 3),
    ]);
    const mat = new THREE.LineBasicMaterial({ color: 0x5c6b4a, transparent: true, opacity: 0.35 });
    tickGroup.add(new THREE.Line(geo, mat));
  }
  scene.add(tickGroup);

  scene.add(new THREE.AmbientLight(0xffffff, 0.75));
  const dl = new THREE.DirectionalLight(0xffffff, 0.85);
  dl.position.set(5, 10, 6);
  scene.add(dl);

  // Launch pad marker
  const padGeo = new THREE.CylinderGeometry(0.7, 0.8, 0.3, 20);
  const padMat = new THREE.MeshStandardMaterial({ color: 0x12213b, roughness: 0.6 });
  const pad = new THREE.Mesh(padGeo, padMat);
  pad.position.set(START_X, 0.15, 0);
  scene.add(pad);

  // Ball
  const ballGeo = new THREE.SphereGeometry(BALL_R, 20, 20);
  const ballMat = new THREE.MeshStandardMaterial({ color: 0xc94a38, roughness: 0.4 });
  const ball = new THREE.Mesh(ballGeo, ballMat);
  ball.position.set(START_X, BALL_R, 0);
  scene.add(ball);

  // Velocity-component arrows (shown only while flying)
  const vxArrow = new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), ball.position, 1, 0x12213b, 0.3, 0.18);
  const vyArrow = new THREE.ArrowHelper(new THREE.Vector3(0, 1, 0), ball.position, 1, 0xd68c1f, 0.3, 0.18);
  vxArrow.visible = false; vyArrow.visible = false;
  scene.add(vxArrow); scene.add(vyArrow);

  // Launch-angle preview: an arc + dashed ray shown at rest, updates live
  // as the angle/speed sliders move, so students can "see" the setting
  // before they launch.
  const previewGroup = new THREE.Group();
  scene.add(previewGroup);
  function updatePreview() {
    previewGroup.clear();
    if (flying) { previewGroup.visible = false; return; }
    previewGroup.visible = true;
    const angleDeg = parseFloat(angleInput.value);
    const speed = parseFloat(speedInput.value);
    const angle = (angleDeg * Math.PI) / 180;
    const len = 2 + speed * 0.18;

    const rayPts = [new THREE.Vector3(START_X, BALL_R, 0), new THREE.Vector3(START_X + len * Math.cos(angle), BALL_R + len * Math.sin(angle), 0)];
    const rayGeo = new THREE.BufferGeometry().setFromPoints(rayPts);
    const rayMat = new THREE.LineDashedMaterial({ color: 0x12213b, dashSize: 0.18, gapSize: 0.12 });
    const ray = new THREE.Line(rayGeo, rayMat);
    ray.computeLineDistances();
    previewGroup.add(ray);

    const arcPts = [];
    const steps = 24;
    const arcR = 1.6;
    for (let i = 0; i <= steps; i++) {
      const a = (angle * i) / steps;
      arcPts.push(new THREE.Vector3(START_X + arcR * Math.cos(a), BALL_R + arcR * Math.sin(a), 0));
    }
    const arcGeo = new THREE.BufferGeometry().setFromPoints(arcPts);
    const arcMat = new THREE.LineBasicMaterial({ color: 0xd68c1f });
    previewGroup.add(new THREE.Line(arcGeo, arcMat));
  }

  // Trajectory line(s): current flight + one faded ghost of the previous flight
  let trajLine = null;
  let ghostLine = null;
  let apexMarker = null, apexDrop = null, landingMarker = null;

  function clearMarkers() {
    [apexMarker, apexDrop, landingMarker].forEach((m) => { if (m) scene.remove(m); });
    apexMarker = apexDrop = landingMarker = null;
  }

  function clearAllTrails() {
    if (trajLine) { scene.remove(trajLine); trajLine = null; }
    if (ghostLine) { scene.remove(ghostLine); ghostLine = null; }
    clearMarkers();
    if (readout) readout.textContent = "—";
    updateHud(0, 0, 0, 0);
  }

  // Drag-to-rotate
  let isDragging = false;
  let prevX = 0, prevY = 0;
  let rotY = 1.15, rotX = 0.28;
  const DEFAULT_ROT = { y: 1.15, x: 0.28 };
  let autoRotate = false;

  function applyRotation() {
    const r = 22;
    camera.position.x = r * Math.sin(rotY) * Math.cos(rotX);
    camera.position.z = r * Math.cos(rotY) * Math.cos(rotX);
    camera.position.y = 4 + r * Math.sin(rotX);
    camera.lookAt(0, 2, 0);
  }
  applyRotation();

  function pointerDown(x, y) { isDragging = true; prevX = x; prevY = y; }
  function pointerMove(x, y) {
    if (!isDragging) return;
    rotY -= (x - prevX) * 0.006;
    rotX = Math.max(-0.3, Math.min(0.85, rotX + (y - prevY) * 0.004));
    prevX = x; prevY = y;
    applyRotation();
  }
  function pointerUp() { isDragging = false; }
  renderer.domElement.addEventListener("mousedown", (e) => pointerDown(e.clientX, e.clientY));
  window.addEventListener("mousemove", (e) => pointerMove(e.clientX, e.clientY));
  window.addEventListener("mouseup", pointerUp);
  renderer.domElement.addEventListener("touchstart", (e) => { const t = e.touches[0]; pointerDown(t.clientX, t.clientY); }, { passive: true });
  renderer.domElement.addEventListener("touchmove", (e) => { const t = e.touches[0]; pointerMove(t.clientX, t.clientY); }, { passive: true });
  renderer.domElement.addEventListener("touchend", pointerUp);

  const GRAVITY = { earth: 9.8, moon: 1.62, mars: 3.71 };
  let G = GRAVITY.earth;

  let flightPath = [];
  let flightStart = null;
  let flying = false;
  let lastTraj = null;

  function computeTrajectory(angleDeg, speed, gravity) {
    const angle = (angleDeg * Math.PI) / 180;
    const vx = speed * Math.cos(angle);
    const vy = speed * Math.sin(angle);
    const totalTime = (2 * vy) / gravity;
    const points = [];
    const steps = 72;
    let maxHeight = BALL_R, apexT = 0;
    for (let i = 0; i <= steps; i++) {
      const t = (totalTime * i) / steps;
      const x = START_X + vx * t;
      const y = Math.max(BALL_R + vy * t - 0.5 * gravity * t * t, BALL_R);
      if (y > maxHeight) { maxHeight = y; apexT = t; }
      points.push(new THREE.Vector3(x, y, 0));
    }
    const range = vx * totalTime;
    return { points, totalTime, maxHeight, range, vx, vy, apexT, apexX: START_X + vx * apexT };
  }

  function makeMarker(color, radius) {
    const geo = new THREE.SphereGeometry(radius, 14, 14);
    const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.4 });
    return new THREE.Mesh(geo, mat);
  }

  function launch() {
    const angleDeg = parseFloat(angleInput.value);
    const speed = parseFloat(speedInput.value);
    const traj = computeTrajectory(angleDeg, speed, G);
    flightPath = traj.points;
    flightStart = performance.now();
    flying = true;
    lastTraj = traj;
    previewGroup.visible = false;

    // Move current line to "ghost" (faded), drop any older ghost.
    if (ghostLine) scene.remove(ghostLine);
    if (trajLine) {
      trajLine.material.color.set(0xb7a99a);
      trajLine.material.opacity = 0.45;
      trajLine.material.transparent = true;
      ghostLine = trajLine;
      trajLine = null;
    }

    clearMarkers();

    const geo = new THREE.BufferGeometry().setFromPoints(traj.points);
    const mat = new THREE.LineBasicMaterial({ color: 0x2e8e80 });
    trajLine = new THREE.Line(geo, mat);
    scene.add(trajLine);

    // Apex marker + dashed drop-line to the ground
    apexMarker = makeMarker(0xd68c1f, 0.22);
    apexMarker.position.set(traj.apexX, traj.maxHeight, 0);
    scene.add(apexMarker);
    const dropGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(traj.apexX, traj.maxHeight, 0), new THREE.Vector3(traj.apexX, 0.02, 0),
    ]);
    const dropMat = new THREE.LineDashedMaterial({ color: 0xd68c1f, dashSize: 0.2, gapSize: 0.15, transparent: true, opacity: 0.7 });
    apexDrop = new THREE.Line(dropGeo, dropMat);
    apexDrop.computeLineDistances();
    scene.add(apexDrop);

    // Landing marker
    landingMarker = makeMarker(0xc94a38, 0.2);
    landingMarker.position.set(START_X + traj.range, BALL_R * 0.4, 0);
    scene.add(landingMarker);

    vxArrow.visible = true; vyArrow.visible = true;

    if (readout) {
      readout.textContent = `Max height: ${(traj.maxHeight - BALL_R).toFixed(1)} m · Range: ${traj.range.toFixed(1)} m · Flight time: ${traj.totalTime.toFixed(1)} s`;
    }
  }

  function updateHud(h, d, spd, t) {
    if (hudHeight) hudHeight.textContent = `Height: ${h.toFixed(1)} m`;
    if (hudDist) hudDist.textContent = `Distance: ${d.toFixed(1)} m`;
    if (hudSpeed) hudSpeed.textContent = `Speed: ${spd.toFixed(1)} m/s`;
    if (hudTime) hudTime.textContent = `t = ${t.toFixed(1)} s`;
  }

  function updateLabels() {
    if (angleLabel) angleLabel.textContent = `${angleInput.value}°`;
    if (speedLabel) speedLabel.textContent = `${speedInput.value} m/s`;
    updatePreview();
  }
  angleInput?.addEventListener("input", updateLabels);
  speedInput?.addEventListener("input", updateLabels);
  updateLabels();

  launchBtn?.addEventListener("click", launch);

  envButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      envButtons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      G = GRAVITY[btn.dataset.env] ?? GRAVITY.earth;
      if (window.CurioSound) window.CurioSound.play("toggle");
      launch();
    });
  });

  autoRotateBox?.addEventListener("change", () => { autoRotate = autoRotateBox.checked; });
  resetCamBtn?.addEventListener("click", () => { rotY = DEFAULT_ROT.y; rotX = DEFAULT_ROT.x; applyRotation(); });
  clearTrailBtn?.addEventListener("click", () => { clearAllTrails(); updatePreview(); });

  // Previously rendered every frame unconditionally, even with this tab
  // hidden. sceneManager.start() only calls this (and only renders) while
  // the "projectile" panel is actually visible; the ball's motion is
  // computed from performance.now() elapsed time, not frame count, so a
  // paused-then-resumed flight still lands at the correct time.
  sceneManager.start(() => {
    if (autoRotate && !isDragging) {
      rotY += 0.0035;
      applyRotation();
    }

    if (flying && flightPath.length && lastTraj) {
      const elapsed = (performance.now() - flightStart) / 1000;
      const t = Math.min(elapsed, lastTraj.totalTime);
      const x = START_X + lastTraj.vx * t;
      const y = Math.max(BALL_R + lastTraj.vy * t - 0.5 * G * t * t, BALL_R);
      ball.position.set(x, y, 0);

      const curVy = lastTraj.vy - G * t;
      vxArrow.position.copy(ball.position);
      vyArrow.position.copy(ball.position);
      const vxLen = Math.max(0.3, Math.min(2.2, Math.abs(lastTraj.vx) * 0.22));
      const vyLen = Math.max(0.3, Math.min(2.2, Math.abs(curVy) * 0.22));
      vxArrow.setDirection(new THREE.Vector3(1, 0, 0));
      vxArrow.setLength(vxLen, 0.22, 0.13);
      vyArrow.setDirection(new THREE.Vector3(0, curVy >= 0 ? 1 : -1, 0));
      vyArrow.setLength(vyLen, 0.22, 0.13);

      updateHud(y - BALL_R, x - START_X, Math.sqrt(lastTraj.vx * lastTraj.vx + curVy * curVy), t);

      if (elapsed >= lastTraj.totalTime) {
        flying = false;
        vxArrow.visible = false; vyArrow.visible = false;
        updatePreview();
      }
    }
  });

  // Launch once by default so the panel isn't empty
  launch();
});
