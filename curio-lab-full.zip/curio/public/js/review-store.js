// Curio Lab — Mistake Notebook + spaced-repetition scheduler (SM-2 style).
//
// Every quiz question a learner gets wrong is saved here automatically and comes
// back for review on a growing schedule (10 min -> 1 day -> 6 days -> ...). Data
// is per account on this device (localStorage), like js/learning-state.js.
// Nothing is pre-filled: an empty notebook means no mistakes have been made yet.
(function () {
  "use strict";
  if (window.CurioReview) return;

  const KEY_PREFIX = "curiolab-review-v1:";
  const SESSION_KEY = "curiolab-local-session";
  const MAX_ITEMS = 600;
  const DAY = 86400000;
  const AGAIN_DELAY = 10 * 60000; // a missed card returns in 10 minutes
  const MASTERED_AT = 21;          // interval (days) at which a card counts as mastered

  const safeParse = (v, f) => { try { const x = JSON.parse(v); return x == null ? f : x; } catch (_) { return f; } };
  const clean = (v, n) => String(v == null ? "" : v).trim().slice(0, n);

  function accountKey() {
    const u = safeParse(localStorage.getItem(SESSION_KEY), null);
    if (u && u.id) return "id:" + u.id;
    if (u && u.email) return "email:" + String(u.email).toLowerCase();
    return "guest";
  }
  const storageKey = () => KEY_PREFIX + accountKey();

  function hash(str) {
    let h = 5381;
    for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  }

  function relHref(href) {
    let p = String(href || "").split("#")[0].split("?")[0];
    try { p = decodeURIComponent(p); } catch (_) { /* keep raw */ }
    const i = p.lastIndexOf("/pages/");
    if (i >= 0) return p.slice(i + 1);
    return p.indexOf("pages/") === 0 ? p : p.replace(/^\/+/, "");
  }

  function load() {
    const raw = safeParse(localStorage.getItem(storageKey()), null);
    const items = raw && Array.isArray(raw.items) ? raw.items : [];
    return items.filter((x) => x && x.id && x.q && Array.isArray(x.options) && x.correct);
  }
  function save(items) {
    try { localStorage.setItem(storageKey(), JSON.stringify({ version: 1, items: items.slice(-MAX_ITEMS) })); } catch (_) { /* blocked or full */ }
    window.dispatchEvent(new CustomEvent("curio-review-updated"));
  }

  const idFor = (lesson, q) => hash(clean(lesson, 120) + "|" + clean(q, 400));

  // Add a missed question, or — if it is already in the notebook — count it as a lapse.
  function addMistake(m) {
    if (!m || !m.q || !Array.isArray(m.options) || !m.correct) return null;
    const items = load();
    const id = idFor(m.lesson, m.q);
    const now = Date.now();
    let item = items.find((x) => x.id === id);
    if (item) {
      applyGrade(item, 1, now);
      item.picked = clean(m.picked, 200);
      item.misses = (item.misses || 1) + 1;
    } else {
      item = {
        id, q: clean(m.q, 400), options: m.options.map((o) => clean(o, 200)), correct: clean(m.correct, 200),
        picked: clean(m.picked, 200), lesson: clean(m.lesson, 120), subject: clean(m.subject, 60), href: relHref(m.href),
        addedAt: new Date(now).toISOString(), lastAt: null, reps: 0, interval: 0, ease: 2.5, lapses: 0, misses: 1,
        due: now + AGAIN_DELAY,
      };
      items.push(item);
    }
    save(items);
    return item;
  }

  // SM-2 variant. grade: 1 = Again, 3 = Hard, 4 = Good, 5 = Easy.
  function applyGrade(item, grade, now) {
    item.lastAt = new Date(now).toISOString();
    if (grade < 3) {
      item.reps = 0; item.interval = 0; item.lapses = (item.lapses || 0) + 1;
      item.ease = Math.max(1.3, item.ease - 0.2);
      item.due = now + AGAIN_DELAY;
      return item;
    }
    item.ease = Math.max(1.3, item.ease + (0.1 - (5 - grade) * (0.08 + (5 - grade) * 0.02)));
    if (item.reps === 0) item.interval = grade === 5 ? 3 : 1;
    else if (item.reps === 1) item.interval = grade === 5 ? 8 : 6;
    else item.interval = Math.max(item.interval + 1, Math.round(item.interval * item.ease * (grade === 3 ? 0.8 : grade === 5 ? 1.3 : 1)));
    item.reps += 1;
    item.due = now + item.interval * DAY;
    return item;
  }

  function grade(id, g) {
    const items = load();
    const item = items.find((x) => x.id === id);
    if (!item) return null;
    applyGrade(item, g, Date.now());
    save(items);
    return item;
  }

  // What would each grade schedule? (for the button labels)
  function preview(item) {
    const out = {};
    [1, 3, 4, 5].forEach((g) => {
      const copy = JSON.parse(JSON.stringify(item));
      applyGrade(copy, g, 0);
      out[g] = g === 1 ? 10 / 1440 : copy.interval;
    });
    return out;
  }

  function remove(id) { save(load().filter((x) => x.id !== id)); }
  function clearAll() { save([]); }

  const isDue = (x, now) => x.due <= (now || Date.now());
  const due = () => { const n = Date.now(); return load().filter((x) => isDue(x, n)).sort((a, b) => a.due - b.due); };

  function stats() {
    const items = load(), now = Date.now();
    const dueItems = items.filter((x) => isDue(x, now));
    const mastered = items.filter((x) => x.interval >= MASTERED_AT).length;
    const bySubject = {};
    items.forEach((x) => { const s = x.subject || "Other"; (bySubject[s] = bySubject[s] || { total: 0, due: 0 }).total += 1; if (isDue(x, now)) bySubject[s].due += 1; });
    // upcoming load for the next 7 days (day 0 = due now / overdue)
    const upcoming = Array(7).fill(0);
    const start = new Date(); start.setHours(0, 0, 0, 0);
    items.forEach((x) => {
      const d = Math.floor((x.due - start.getTime()) / DAY);
      upcoming[Math.min(6, Math.max(0, d))] += 1;
    });
    const reviewedToday = items.filter((x) => x.lastAt && new Date(x.lastAt) >= start).length;
    return { total: items.length, due: dueItems.length, mastered, learning: items.length - mastered, bySubject, upcoming, reviewedToday };
  }

  function fmtInterval(days) {
    if (days < 1) return Math.max(1, Math.round(days * 1440)) + " min";
    if (days < 30) return Math.round(days) + " d";
    return Math.round(days / 30) + " mo";
  }

  window.CurioReview = { addMistake, grade, preview, remove, clearAll, all: load, due, stats, idFor, relHref, fmtInterval, MASTERED_AT };
  window.addEventListener("storage", (e) => { if (e.key && e.key.indexOf(KEY_PREFIX) === 0) window.dispatchEvent(new CustomEvent("curio-review-updated")); });
})();
