// Curio Lab — Interactive Globe (Geography centerpiece)
// Draggable wireframe globe with clickable landmark markers.
document.addEventListener("DOMContentLoaded", () => {
  const container = document.querySelector("[data-globe-canvas]");
  const card = document.querySelector("[data-analysis-card]");
  if (!container || typeof THREE === "undefined") return;

  const LANDMARKS = [
    { name: "Amazon Rainforest", lat: -3.46, lon: -62.22, tag: "Ecosystem", note: "The world's largest rainforest, spanning nine countries in South America and home to more species than any other land ecosystem on Earth." },
    { name: "Sahara Desert", lat: 23.42, lon: 25.66, tag: "Desert", note: "The world's largest hot desert — nearly the size of the entire United States, stretching across North Africa." },
    { name: "Himalayas", lat: 27.99, lon: 86.93, tag: "Mountains", note: "Home to Mount Everest, Earth's highest peak above sea level at 8,849 meters, formed by the collision of two tectonic plates." },
    { name: "Nile River", lat: 15.6, lon: 32.5, tag: "River", note: "Traditionally considered the longest river in the world, flowing north through northeastern Africa into the Mediterranean." },
    { name: "Great Barrier Reef", lat: -18.29, lon: 147.70, tag: "Coral Reef", note: "The world's largest coral reef system, made of thousands of individual reefs — large enough to be visible from space." },
  ];

  if (typeof CurioSceneManager === "undefined") {
    console.warn("[globe.js] CurioSceneManager not loaded — add <script src=\".../js/scene-manager.js\"> before globe.js");
    return;
  }

  // panelName: "globe" matches this widget's own [data-panel="globe"] convention
  // below (see the isVisible check the old code used) — the manager reads the
  // same convention so tab switching / backgrounding still pauses rendering.
  const sceneManager = new CurioSceneManager(container, { fov: 45, near: 0.1, far: 100, panelName: "globe" });
  const scene = sceneManager.scene;
  const camera = sceneManager.camera;
  const renderer = sceneManager.renderer;

  const RADIUS = 2;

  // Loading indicator while the real Earth textures come in
  const loadingTag = document.createElement("div");
  loadingTag.className = "globe-loading";
  loadingTag.textContent = "Loading Earth…";
  container.style.position = container.style.position || "relative";
  container.appendChild(loadingTag);

  const texLoader = new THREE.TextureLoader();
  texLoader.crossOrigin = "anonymous";
  const TEX_BASE = "https://raw.githubusercontent.com/mrdoob/three.js/r128/examples/textures/planets/";

  let loadedCount = 0;
  const TOTAL_TEX = 3;
  function texDone() {
    loadedCount++;
    if (loadedCount >= TOTAL_TEX) loadingTag.style.display = "none";
  }

  // Earth sphere — real day-map texture with bump + specular highlights (oceans shine, land doesn't)
  // Segment counts tuned down from 64x48 — at the widget's actual on-screen size the extra
  // geometry was invisible but still cost real GPU time on every frame.
  const sphereGeo = new THREE.SphereGeometry(RADIUS, 48, 32);
  const sphereMat = new THREE.MeshPhongMaterial({ color: 0xffffff, shininess: 10 });
  const earth = new THREE.Mesh(sphereGeo, sphereMat);
  scene.add(earth);

  texLoader.load(TEX_BASE + "earth_atmos_2048.jpg", (tex) => { sphereMat.map = tex; sphereMat.needsUpdate = true; texDone(); }, undefined, texDone);
  texLoader.load(TEX_BASE + "earth_normal_2048.jpg", (tex) => { sphereMat.normalMap = tex; sphereMat.normalScale = new THREE.Vector2(0.6, 0.6); sphereMat.needsUpdate = true; texDone(); }, undefined, texDone);
  texLoader.load(TEX_BASE + "earth_specular_2048.jpg", (tex) => { sphereMat.specularMap = tex; sphereMat.specular = new THREE.Color(0x333333); sphereMat.needsUpdate = true; texDone(); }, undefined, texDone);

  // Thin cloud layer, drifting slowly and independently of the planet's rotation
  const cloudGeo = new THREE.SphereGeometry(RADIUS * 1.012, 32, 24);
  const cloudMat = new THREE.MeshLambertMaterial({ transparent: true, opacity: 0.35, depthWrite: false });
  const clouds = new THREE.Mesh(cloudGeo, cloudMat);
  earth.add(clouds);
  texLoader.load(TEX_BASE + "earth_clouds_1024.png", (tex) => { cloudMat.map = tex; cloudMat.alphaMap = tex; cloudMat.needsUpdate = true; });

  // Soft atmosphere glow rim
  const glowGeo = new THREE.SphereGeometry(RADIUS * 1.035, 32, 24);
  const glowMat = new THREE.ShaderMaterial({
    uniforms: {},
    vertexShader: `varying vec3 vNormal; void main() { vNormal = normalize(normalMatrix * normal); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: `varying vec3 vNormal; void main() { float intensity = pow(0.68 - dot(vNormal, vec3(0,0,1.0)), 3.0); gl_FragColor = vec4(0.34, 0.76, 0.70, 1.0) * intensity; }`,
    blending: THREE.AdditiveBlending, side: THREE.BackSide, transparent: true,
  });
  scene.add(new THREE.Mesh(glowGeo, glowMat));

  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  const dl = new THREE.DirectionalLight(0xffffff, 1.1);
  dl.position.set(4, 5, 6);
  scene.add(dl);

  function latLonToVec3(lat, lon, r) {
    const phi = (90 - lat) * (Math.PI / 180);
    const theta = (lon + 180) * (Math.PI / 180);
    return new THREE.Vector3(
      -r * Math.sin(phi) * Math.cos(theta),
      r * Math.cos(phi),
      r * Math.sin(phi) * Math.sin(theta)
    );
  }

  const markerGeo = new THREE.SphereGeometry(0.06, 12, 12);
  const markers = LANDMARKS.map((lm) => {
    const mat = new THREE.MeshBasicMaterial({ color: 0xe2624f });
    const mesh = new THREE.Mesh(markerGeo, mat);
    const pos = latLonToVec3(lm.lat, lm.lon, RADIUS * 1.02);
    mesh.position.copy(pos);
    mesh.userData = lm;
    earth.add(mesh);
    return mesh;
  });

  // Drag-to-rotate
  let isDragging = false;
  let prevX = 0, prevY = 0;
  let didDrag = false;
  let rotY = 0.6, rotX = 0.25;

  function applyRotation() {
    const r = 6;
    camera.position.x = r * Math.sin(rotY) * Math.cos(rotX);
    camera.position.z = r * Math.cos(rotY) * Math.cos(rotX);
    camera.position.y = r * Math.sin(rotX);
    camera.lookAt(0, 0, 0);
  }
  applyRotation();

  function pointerDown(x, y) { isDragging = true; didDrag = false; prevX = x; prevY = y; }
  function pointerMove(x, y) {
    if (!isDragging) return;
    if (Math.abs(x - prevX) > 2 || Math.abs(y - prevY) > 2) didDrag = true;
    rotY -= (x - prevX) * 0.006;
    rotX = Math.max(-0.8, Math.min(0.8, rotX + (y - prevY) * 0.004));
    prevX = x; prevY = y;
    applyRotation();
  }

  const raycaster = new THREE.Raycaster();
  const mouseVec = new THREE.Vector2();

  function handleClick(clientX, clientY) {
    if (didDrag) return;
    const rect = renderer.domElement.getBoundingClientRect();
    mouseVec.x = ((clientX - rect.left) / rect.width) * 2 - 1;
    mouseVec.y = -((clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(mouseVec, camera);
    const hits = raycaster.intersectObjects(markers);
    if (hits.length && card) {
      const lm = hits[0].object.userData;
      card.innerHTML = `
        <span class="device-tag">${lm.tag}</span>
        <p class="quoted">${lm.name}</p>
        <p>${lm.note}</p>
      `;
    }
  }

  renderer.domElement.addEventListener("mousedown", (e) => pointerDown(e.clientX, e.clientY));
  window.addEventListener("mousemove", (e) => pointerMove(e.clientX, e.clientY));
  window.addEventListener("mouseup", (e) => { if (isDragging) handleClick(e.clientX, e.clientY); isDragging = false; });

  renderer.domElement.addEventListener("touchstart", (e) => { const t = e.touches[0]; pointerDown(t.clientX, t.clientY); }, { passive: true });
  renderer.domElement.addEventListener("touchmove", (e) => { const t = e.touches[0]; pointerMove(t.clientX, t.clientY); }, { passive: true });
  renderer.domElement.addEventListener("touchend", (e) => {
    const t = e.changedTouches[0];
    if (t) handleClick(t.clientX, t.clientY);
    isDragging = false;
  });

  // Starfield backdrop for depth
  const starGeo = new THREE.BufferGeometry();
  const starCount = 220;
  const starPositions = new Float32Array(starCount * 3);
  for (let i = 0; i < starCount; i++) {
    const r = 30 + Math.random() * 20;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    starPositions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    starPositions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    starPositions[i * 3 + 2] = r * Math.cos(phi);
  }
  starGeo.setAttribute("position", new THREE.BufferAttribute(starPositions, 3));
  const starMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.05, transparent: true, opacity: 0.55 });
  scene.add(new THREE.Points(starGeo, starMat));

  // Performance: only render while the globe is actually on screen — skip
  // GPU work while its tab is hidden or the browser tab is backgrounded.
  // sceneManager.start() only calls this function (and only renders)
  // while its own visibility check (tab-shown / visibilitychange, same
  // [data-panel="globe"] convention this file used before) says so, so
  // there's no separate isVisible flag or resize wiring to maintain here.
  sceneManager.start(() => {
    earth.rotation.y += isDragging ? 0 : 0.0012;
    clouds.rotation.y += isDragging ? 0.0004 : 0.0007;
  });
});
