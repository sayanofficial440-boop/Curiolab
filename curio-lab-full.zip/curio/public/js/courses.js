// Curio Lab — Courses: ordered lesson paths per subject, with progress and a "next up" lesson.
// Path data: js/courses-data.js (window.CurioCourses). Progress: js/learning-state.js (a lesson is
// "done" once its quiz is passed at 60%+). Order is a recommendation — every lesson stays open.
(function () {
  "use strict";
  const COURSES = window.CurioCourses || [], L = window.CurioLearning;
  const LV = { 1: "Beginner", 2: "Intermediate", 3: "Advanced" };
  const rel = (h) => String(h || "").split("#")[0].split("?")[0].replace(/^.*?(pages\/)/, "$1");
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  // state per lesson: done | open (started, not passed) | next | later
  function status(course, prog) {
    const by = {}; (prog || []).forEach((p) => { by[rel(p.href)] = p; });
    let nextSet = false;
    const rows = course.lessons.map((l, i) => {
      const p = by[l.h], done = !!p && p.status === "completed";
      const prevDone = i === 0 || by[course.lessons[i - 1].h]?.status === "completed";
      let st = done ? "done" : p ? "open" : "later";
      if (!done && prevDone && !nextSet) { st = p ? "open" : "next"; nextSet = true; }
      else if (!done && !p && prevDone) st = "ready";
      return { ...l, i, st, best: p ? p.best : null };
    });
    const n = rows.filter((r) => r.st === "done").length;
    return { rows, done: n, total: rows.length, pct: Math.round((n / rows.length) * 100), next: rows.find((r) => r.st === "next" || r.st === "open") || null };
  }
  window.CurioCoursePath = { status, rel };

  const host = document.querySelector("[data-courses]");
  if (!host) return;
  const base = "../";
  let active = new URLSearchParams(location.search).get("c") || COURSES[0]?.id;

  function draw(prog) {
    const tabs = COURSES.map((c) => { const s = status(c, prog); return `<button type="button" class="co-tab" role="tab" aria-selected="${c.id === active}" data-c="${c.id}"><span>${esc(c.subject)}</span><i style="--p:${s.pct}%"></i></button>`; }).join("");
    const c = COURSES.find((x) => x.id === active) || COURSES[0], s = status(c, prog);
    const list = s.rows.map((r) => {
      const why = r.st === "later" && r.i ? `<small>Best after ${esc(s.rows[r.i - 1].t)}</small>` : r.best != null ? `<small>Best quiz ${r.best}%</small>` : `<small>${LV[r.level] || ""} · Grade ${r.grade}+</small>`;
      const tag = { done: "Done", open: "Continue", next: "Up next", ready: "Ready", later: "Later" }[r.st];
      return `<li class="co-step ${r.st}"><span class="co-n">${r.st === "done" ? "✓" : r.i + 1}</span><a href="${base}${r.h.replace(/^pages\//, "")}"><b>${esc(r.t)}</b>${why}</a><em>${tag}</em></li>`;
    }).join("");
    host.innerHTML = `<div class="co-tabs" role="tablist" aria-label="Subjects">${tabs}</div>
      <section class="co-card"><header><div><h2>${esc(c.title)}</h2><p>${esc(c.blurb)} · ${s.total} ordered lessons</p></div><div class="co-ring" style="--p:${s.pct}%"><b>${s.pct}%</b></div></header>
      ${s.next ? `<a class="co-next" href="${base}${s.next.h.replace(/^pages\//, "")}">${s.next.st === "open" ? "Continue" : "Start"}: ${esc(s.next.t)} →</a>` : `<p class="co-finish">Path complete — try the <a href="exams.html">Exam Center</a>.</p>`}
      <ol class="co-list">${list}</ol></section>`;
    host.querySelectorAll("[data-c]").forEach((b) => b.addEventListener("click", () => { active = b.dataset.c; history.replaceState(null, "", "?c=" + active); draw(prog); }));
  }
  const go = async () => { let prog = []; try { prog = (await L.get()).lessonProgress; } catch (_) { /* guest */ } draw(prog); };
  if (L) { go(); window.addEventListener("curio-learning-updated", go); } else draw([]);
})();
