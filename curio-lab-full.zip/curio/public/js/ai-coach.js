// Curio Lab — AI Coach
// LIVE MODE: if the backend in /backend is running (see backend/README.md), this
// automatically uses the real Google Gemini API for every answer, in both regular coaching
// and Debate Mode.
// DEMO MODE (automatic fallback): if the backend isn't running, this falls back to a
// small set of canned keyword-matched responses so the page still works instantly with
// zero setup and no API key.
//
// The backend uses the same origin in the complete package; no localhost URL is required.
window.onLessonContentReady(() => {
  const launcher = document.querySelector("[data-coach-launcher]");
  const panel = document.querySelector("[data-coach-panel]");
  const closeBtn = document.querySelector("[data-coach-close]");
  const log = document.querySelector("[data-coach-log]");
  const form = document.querySelector("[data-coach-form]");
  const input = document.querySelector("[data-coach-input]");
  const debateBtn = document.querySelector("[data-coach-debate]");
  const clearBtn = document.querySelector("[data-coach-clear]");
  const noteEl = document.querySelector("[data-coach-note]");
  if (!launcher || !panel) return;

  const BACKEND_URL = "";
  const HEALTH_TIMEOUT_MS = 1200;

  const topic = panel.dataset.coachTopic || "this lesson";
  const HISTORY_KEY = `curiolab-chat-${topic.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
  let debateMode = false;
  let liveMode = false;

  // --- Context-aware coaching -------------------------------------------
  // The whole point: the student shouldn't have to type "I'm on the Physics
  // Force lesson, in the 3D Forces section" before asking a question — we
  // already know that from the page. This reads it straight off the DOM
  // every time a message is sent (the active tab can change mid-conversation)
  // and folds it into the request payload the student never sees.
  //
  // `data-coach-subject` / `data-coach-difficulty` are set by lesson-engine.js
  // for the new dynamic lesson page (see js/lesson-engine.js populateCoach).
  // The ~27 existing static lesson pages don't set those attributes yet, so
  // we fall back to inferring the subject from the URL path
  // (pages/<subject>/<slug>.html) rather than requiring every legacy page to
  // be edited before this feature works anywhere.
  function inferSubjectFromPath() {
    const parts = window.location.pathname.split("/").filter(Boolean);
    const pagesIdx = parts.lastIndexOf("pages");
    if (pagesIdx !== -1 && parts.length > pagesIdx + 2) return parts[pagesIdx + 1];
    // Dynamic page: pages/lesson.html?subject=physics&lesson=force
    return new URLSearchParams(window.location.search).get("subject");
  }

  function getActiveSectionLabel() {
    const activeTab = document.querySelector("[data-tab].active");
    if (!activeTab) return null;
    // Strip a leading emoji icon like "🪐 3D Forces" -> "3D Forces".
    return activeTab.textContent.replace(/^[^\w]+/, "").trim() || null;
  }

  function getActiveSectionHeading() {
    const activePanel = document.querySelector("[data-panel].active");
    if (!activePanel) return null;
    const heading = activePanel.querySelector("h3, h2");
    return heading ? heading.textContent.trim() : null;
  }

  function buildLessonContext() {
    return {
      subject: panel.dataset.coachSubject || inferSubjectFromPath() || null,
      lesson: topic,
      difficulty: panel.dataset.coachDifficulty || null,
      activeSection: getActiveSectionLabel(),
      sectionHeading: getActiveSectionHeading(),
    };
  }

  let customResponses = [];
  const dataEl = document.querySelector("[data-coach-responses]");
  if (dataEl) {
    try {
      customResponses = JSON.parse(dataEl.textContent).map((r) => ({ match: new RegExp(r.pattern, "i"), reply: r.reply }));
    } catch (e) { customResponses = []; }
  }

  const GENERIC_RESPONSES = [
    { match: /quiz|score|test/i, reply: "You can retake the quiz as many times as you like — only your best score is shown on the scoreboard, so there's no pressure." },
    { match: /help|stuck|confus|understand/i, reply: `Try switching to the Slides tab for a step-by-step walkthrough of ${topic}, then come back to the quiz — it usually clicks after seeing it broken into small steps.` },
  ];

  const RESPONSES = [...customResponses, ...GENERIC_RESPONSES];
  const FALLBACK = "Good question — I'm running in demo mode right now, so my answers are limited to a few common topics. Try asking about one of the key ideas in this lesson!";

  // Suggested-question chips: derive a short human label from each lesson's
  // own canned-response patterns (e.g. "gravity|weight" -> "Gravity").
  const chipsWrap = document.createElement("div");
  chipsWrap.className = "coach-chips";
  form?.insertAdjacentElement("beforebegin", chipsWrap);
  let chipSource = [];
  try { chipSource = dataEl ? JSON.parse(dataEl.textContent) : []; } catch (e) { chipSource = []; }
  const chipTopics = chipSource
    .slice(0, 4)
    .map((r) => (r.pattern.split("|")[0] || "").replace(/[.*+?^${}()[\]\\]/g, ""))
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1));
  function renderChips() {
    chipsWrap.innerHTML = "";
    chipTopics.forEach((topicWord) => {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "coach-chip";
      chip.textContent = topicWord;
      chip.addEventListener("click", () => {
        input.value = `Tell me about ${topicWord.toLowerCase()}`;
        form.requestSubmit ? form.requestSubmit() : form.dispatchEvent(new Event("submit", { cancelable: true }));
      });
      chipsWrap.appendChild(chip);
    });
  }
  renderChips();

  const DEBATE_COUNTERS = [
    "That's a fair point — but what about the opposite view: could someone argue the reverse is also true here?",
    "Interesting take. A skeptic might push back and say the evidence actually cuts the other way — how would you respond to that?",
    "I'll play devil's advocate: what's the strongest argument *against* what you just said?",
    "Good reasoning. Now argue the other side for a moment — what would someone who disagrees say first?",
  ];

  function loadHistory() {
    try { return JSON.parse(localStorage.getItem(HISTORY_KEY)) || []; } catch (e) { return []; }
  }
  function saveHistory(history) {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(-40)));
  }

  function addMsg(text, who, persist = true) {
    const div = document.createElement("div");
    div.className = `coach-msg ${who}`;
    div.textContent = text;
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
    if (persist) {
      const history = loadHistory();
      history.push({ text, who });
      saveHistory(history);
    }
  }

  function addTyping() {
    const div = document.createElement("div");
    div.className = "coach-msg bot";
    div.dataset.typing = "1";
    div.innerHTML = '<span class="typing-dots"><span></span><span></span><span></span></span>';
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
    return div;
  }

  function answerLocally(question) {
    if (debateMode) {
      return DEBATE_COUNTERS[Math.floor(Math.random() * DEBATE_COUNTERS.length)];
    }
    const hit = RESPONSES.find((r) => r.match.test(question));
    return hit ? hit.reply : FALLBACK;
  }

  async function answerLive(question) {
    const history = loadHistory().slice(0, -1); // exclude the message we just added
    const res = await fetch(`${BACKEND_URL}/api/coach`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: question,
        topic,
        mode: debateMode ? "debate" : "coach",
        history,
        context: buildLessonContext(),
      }),
    });
    if (!res.ok) throw new Error(`Backend responded ${res.status}`);
    const data = await res.json();
    if (data.error) throw new Error(data.error);
    return data.reply;
  }

  function setNote() {
    if (!noteEl) return;
    noteEl.textContent = liveMode
      ? "🟢 Live AI — connected to the Curio Lab backend."
      : "🟡 Demo mode — start backend/app.py for live AI. See js/ai-coach.js.";
  }

  async function checkBackend() {
    try {
      const controller = new AbortController();
      const t = setTimeout(() => controller.abort(), HEALTH_TIMEOUT_MS);
      if (window.CurioAge && !window.CurioAge.allowed("liveAI")) throw new Error("child account: live AI off");
      const res = await fetch(`${BACKEND_URL}/api/health`, { signal: controller.signal });
      clearTimeout(t);
      const data = await res.json();
      liveMode = !!(res.ok && data.live);
    } catch (e) {
      liveMode = false;
    }
    setNote();
  }

  function renderHistory() {
    log.innerHTML = "";
    const history = loadHistory();
    if (history.length === 0) {
      addMsg(`Hi! I'm your AI coach for ${topic}. Ask me anything, or try Debate Mode to argue a point.`, "bot");
      chipsWrap.classList.remove("hide");
      return;
    }
    history.forEach((m) => addMsg(m.text, m.who, false));
    chipsWrap.classList.add("hide");
  }

  launcher.addEventListener("click", () => {
    panel.classList.toggle("open");
    if (panel.classList.contains("open")) {
      if (log.children.length === 0) renderHistory();
      checkBackend();
    }
  });
  function closePanel() {
    panel.classList.add("closing");
    setTimeout(() => { panel.classList.remove("open", "closing"); }, 180);
  }
  closeBtn?.addEventListener("click", closePanel);

  debateBtn?.addEventListener("click", () => {
    debateMode = !debateMode;
    debateBtn.classList.toggle("active", debateMode);
    debateBtn.textContent = debateMode ? "🗣️ Debate: ON" : "🗣️ Debate Mode";
    addMsg(debateMode
      ? `Debate mode on — state a position about ${topic} and I'll challenge it.`
      : "Debate mode off — back to regular coaching.", "bot");
  });

  clearBtn?.addEventListener("click", () => {
    localStorage.removeItem(HISTORY_KEY);
    renderHistory();
  });

  form?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const q = input.value.trim();
    if (!q) return;
    addMsg(q, "user");
    input.value = "";
    chipsWrap.classList.add("hide");

    const typingEl = addTyping();

    if (liveMode) {
      try {
        const reply = await answerLive(q);
        typingEl.remove();
        addMsg(reply, "bot");
        return;
      } catch (err) {
        liveMode = false;
        setNote();
      }
    }

    setTimeout(() => {
      typingEl.remove();
      addMsg(answerLocally(q), "bot");
    }, 350);
  });

  checkBackend();
  setNote();
});
