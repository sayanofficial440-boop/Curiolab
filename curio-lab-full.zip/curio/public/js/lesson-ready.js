// Curio Lab — Lesson Content Ready hook
//
// WHY THIS FILE EXISTS:
// Every interactive module (quiz.js, flashcards.js, threed-forces.js, ...) was
// written as `document.addEventListener("DOMContentLoaded", () => { ... query
// selectors ... })`. That's correct for the ~40 static pages/**/*.html files,
// where the markup those selectors target is already in the HTML the browser
// parsed. It breaks the moment content is injected *after* DOMContentLoaded,
// which is exactly what dynamic-lesson.html + lesson-engine.js do: they fetch
// a JSON payload and build the tabs/panels/quiz/coach markup once the fetch
// resolves. On a dynamic page, DOMContentLoaded fires while the panels are
// still empty skeletons, every querySelector returns null, and every module
// silently no-ops forever.
//
// Rather than rewrite ten modules' internal logic, we swap ONE line in each
// of them: replace the DOMContentLoaded listener with `onLessonContentReady`.
// That keeps 100% of existing behavior on static pages (it still just waits
// for DOMContentLoaded) and makes the exact same module code work on the
// dynamic page too, because lesson-engine.js calls `dispatchLessonReady()`
// itself, once, right after it finishes building the DOM from the fetched
// JSON. No module needs to know which kind of page it's running on.
(function () {
  const handlers = [];
  let ready = false;

  function runAll() {
    ready = true;
    handlers.forEach((fn) => {
      try {
        fn();
      } catch (err) {
        // One broken module (e.g. a lesson missing an optional 3D config)
        // must never prevent the quiz, coach, or other panels from working.
        console.error("[lesson-ready] module init failed:", err);
      }
    });
  }

  // Register a callback to run once the lesson DOM is actually populated.
  // Safe to call before OR after content is ready — if it's already ready
  // (e.g. a script loaded late), the callback fires immediately.
  window.onLessonContentReady = function onLessonContentReady(fn) {
    handlers.push(fn);
    if (ready) fn();
  };

  // dynamic-lesson.html sets `window.CURIO_DYNAMIC_LESSON = true` in an
  // inline <script> BEFORE any module <script src="..."> tag loads. That one
  // flag is the entire branch between "static page" and "dynamic page"
  // behavior — everything else about the modules is unchanged.
  if (window.CURIO_DYNAMIC_LESSON) {
    // lesson-engine.js calls this manually once it has rendered the fetched
    // lesson JSON into the page.
    window.dispatchLessonReady = runAll;
  } else if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", runAll, { once: true });
  } else {
    // Script executed after the DOM was already parsed (e.g. deferred late).
    runAll();
  }

  // Lesson discussions (Q&A + comments): one loader here instead of a script tag on every lesson page, so the pages the
  // content pipeline generates later get the Discuss tab too. Static lesson pages only (/pages/<subject>/<lesson>.html).
  try {
    const me = document.currentScript && document.currentScript.src;
    if (me && /\/pages\/[a-z-]+\/[a-z0-9-]+\.html$/.test(location.pathname) && !window.CURIO_DYNAMIC_LESSON) {
      const s = document.createElement("script");
      s.src = me.replace(/js\/lesson-ready\.js.*$/, "js/discuss.js");
      s.defer = true;
      document.head.appendChild(s);
    }
  } catch (_) { /* discussions are optional; never break a lesson */ }
})();
