// Curio Lab — Text to Speech (Audio study mode)
// Uses the browser's built-in speechSynthesis API — works offline, no API key needed.
window.onLessonContentReady(() => {
  const playBtn = document.querySelector("[data-tts-play]");
  const rateInput = document.querySelector("[data-tts-rate]");
  const rateLabel = document.querySelector("[data-tts-rate-label]");
  const textEl = document.querySelector("[data-tts-text]");
  if (!playBtn || !textEl) return;

  if (!("speechSynthesis" in window)) {
    playBtn.disabled = true;
    playBtn.title = "Text-to-speech isn't supported in this browser";
    return;
  }

  let utterance = null;
  let speaking = false;

  function buildUtterance() {
    const u = new SpeechSynthesisUtterance(textEl.textContent.trim());
    if (window.CurioLang) u.lang = window.CurioLang.get();
    u.rate = rateInput ? parseFloat(rateInput.value) : 1;
    // Live captions: a11y-media.js highlights the sentence being spoken.
    u.onboundary = (e) => document.dispatchEvent(new CustomEvent("curio:tts-boundary", { detail: { charIndex: e.charIndex } }));
    u.onend = u.onerror = () => { if (utterance !== u) return; setState(false); };
    return u;
  }
  function setState(on) {
    speaking = on;
    playBtn.textContent = on ? "⏸" : "▶";
    playBtn.setAttribute("aria-pressed", String(on));
    document.dispatchEvent(new CustomEvent("curio:tts-state", { detail: { speaking: on } }));
  }

  playBtn.addEventListener("click", () => {
    if (speaking) {
      utterance = null;
      window.speechSynthesis.cancel();
      setState(false);
      return;
    }
    utterance = buildUtterance();
    window.speechSynthesis.speak(utterance);
    setState(true);
  });

  rateInput?.addEventListener("input", () => {
    if (rateLabel) rateLabel.textContent = `${parseFloat(rateInput.value).toFixed(1)}×`;
    if (speaking) {
      utterance = null;
      window.speechSynthesis.cancel();
      utterance = buildUtterance();
      window.speechSynthesis.speak(utterance);
    }
  });

  window.addEventListener("beforeunload", () => window.speechSynthesis.cancel());
});
