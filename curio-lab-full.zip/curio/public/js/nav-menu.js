// Curio Lab — Mobile Nav Menu
//
// HISTORY: this used to insert its own hamburger button next to the logo
// that expanded the PHY/CHM/BIO/... subject links into a dropdown panel.
// That duplicated the side-rail's own hamburger (bottom-left, all
// subjects/tools/company in one drawer) one inch away in the header,
// which read as broken/dead weight rather than a second real menu. The
// subject links now live in the side-rail's "Subjects" section (see
// js/side-rail.js) on mobile, so this file no longer builds a toggle at
// all — css/nav-menu.css simply hides .main-nav below the 780px
// breakpoint and the header stays a single row (logo + controls).
//
// Kept as a file (rather than deleted) so any page still loading it via
// <script src="js/nav-menu.js"> doesn't 404; it intentionally does
// nothing now.
(function () {
  "use strict";
  window.CurioNavMenu = { init: function () {} };
})();
