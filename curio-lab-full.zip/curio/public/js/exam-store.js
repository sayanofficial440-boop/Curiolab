// Curio Lab — Exam Center store.
//
// Everything the Exam Center needs to remember, per account on this device
// (localStorage): the exam in progress (so it can be resumed), finished attempts
// with full per-question detail, and the learner's target. It also scores a
// paper, and turns a finished paper into progress everywhere else:
//   • curiolab-scores        -> scoreboard, dashboard stats, trophies
//   • CurioLearning          -> dashboard, progress report (one event per subject)
//   • CurioReview            -> every missed / unanswered question lands in the Mistake Notebook
//   • curiolab-exam-log      -> small device-wide log the trophies read
// and computes the readiness model used by the Exam Center, dashboard and report.
// Nothing is pre-filled: with no exams taken, every number says so.
(function () {
  "use strict";
  if (window.CurioExam) return;

  const KEY_PREFIX = "curiolab-exam-v1:";
  const LOG_KEY = "curiolab-exam-log";
  const SCORES_KEY = "curiolab-scores";
  const SESSION_KEY = "curiolab-local-session";
  const MAX_ATTEMPTS = 60;
  const KEEP_DETAIL = 10; // newest attempts keep their full question list for review

  const safeParse = (v, f) => { try { const x = JSON.parse(v); return x == null ? f : x; } catch (_) { return f; } };
  const clean = (v, n) => String(v == null ? "" : v).trim().slice(0, n);
  const round2 = (n) => Math.round(n * 100) / 100;
  const nowIso = () => new Date().toISOString();

  function accountKey() {
    const u = safeParse(localStorage.getItem(SESSION_KEY), null);
    if (u && u.id) return "id:" + u.id;
    if (u && u.email) return "email:" + String(u.email).toLowerCase();
    return "guest";
  }
  const storageKey = () => KEY_PREFIX + accountKey();

  // ---------------------------------------------------------------- presets
  // Real-paper patterns. Marks = questions x marksPerQuestion.
  const PRESETS = [
    { id: "full100", label: "Full Paper", icon: "🏛️", marks: 100, perQ: 2, n: 50, mins: 120, blurb: "Final-exam length. Every subject, in sections, balanced across topics." },
    { id: "board80", label: "Board Paper", icon: "📜", marks: 80, perQ: 2, n: 40, mins: 90, blurb: "A board-style paper: broad coverage with 2 marks a question." },
    { id: "mid40", label: "Mid-term", icon: "📘", marks: 40, perQ: 1, n: 40, mins: 45, blurb: "Half-length test to check a term's worth of learning." },
    { id: "test20", label: "Class Test", icon: "✏️", marks: 20, perQ: 1, n: 20, mins: 20, blurb: "A short, sharp test. Fits in a free period." },
    { id: "weekly", label: "Weekly Check-in", icon: "🗓️", marks: 10, perQ: 1, n: 10, mins: 10, blurb: "Ten quick questions from across the subjects." },
    { id: "monthly", label: "Monthly Deep Exam", icon: "📚", marks: 30, perQ: 1, n: 30, mins: 35, blurb: "Longer and broader — a real test of retention." },
    { id: "weak", label: "Weak-spot Drill", icon: "🎯", marks: 20, perQ: 1, n: 20, mins: 20, blurb: "Built from the lessons you score lowest on and the questions you've missed." },
    { id: "subject", label: "Subject Paper", icon: "🔬", marks: 40, perQ: 1, n: 40, mins: 45, blurb: "One subject, every lesson in it. Choose the length." },
    { id: "custom", label: "Custom Paper", icon: "🛠️", marks: 0, perQ: 1, n: 25, mins: 28, blurb: "Set the questions, marks, time and subjects yourself." },
    { id: "random", label: "Random Paper", icon: "🎲", marks: 0, perQ: 1, n: 0, mins: 0, blurb: "Surprise me — a random length, subject mix and time limit." },
  ];

  const GRADES = [
    { min: 90, label: "Outstanding", short: "A+" },
    { min: 80, label: "Excellent", short: "A" },
    { min: 70, label: "Very good", short: "B" },
    { min: 60, label: "Good — room to grow", short: "C" },
    { min: 50, label: "Pass", short: "D" },
    { min: 0, label: "Needs more revision", short: "E" },
  ];
  const grade = (pct) => GRADES.find((g) => pct >= g.min);

  const NEG = [
    { v: 0, label: "No negative marking" },
    { v: 0.25, label: "−¼ per wrong answer" },
    { v: 1 / 3, label: "−⅓ per wrong answer" },
  ];

  // ---------------------------------------------------------------- state
  const defaults = () => ({ version: 1, attempts: [], active: null, settings: { target: 75, examDate: "", strict: false, neg: 0 } });
  function load() {
    const raw = safeParse(localStorage.getItem(storageKey()), null);
    const s = raw && typeof raw === "object" ? raw : defaults();
    return {
      version: 1,
      attempts: Array.isArray(s.attempts) ? s.attempts.filter((a) => a && a.id && a.n > 0) : [],
      active: s.active && Array.isArray(s.active.qs) && s.active.qs.length ? s.active : null,
      settings: { ...defaults().settings, ...(s.settings || {}) },
    };
  }
  function persist(state) {
    try { localStorage.setItem(storageKey(), JSON.stringify(state)); return true; } catch (_) { return false; }
  }
  const notify = () => window.dispatchEvent(new CustomEvent("curio-exam-updated"));

  window.addEventListener("storage", (e) => { if (e.key === storageKey()) notify(); });

  function settings() { return load().settings; }
  function setSettings(patch) {
    const st = load();
    st.settings = { ...st.settings, ...patch };
    st.settings.target = Math.min(100, Math.max(30, Math.round(Number(st.settings.target) || 75)));
    persist(st); notify();
    return st.settings;
  }

  // ---------------------------------------------------------------- active session (resume)
  function active() {
    const st = load();
    const s = st.active;
    if (!s) return null;
    // A relaxed paper whose tab was killed mid-run: stop the clock where we last saw it.
    if (!s.strict && s.since) {
      const seen = Math.max(s.since, s.seen || s.since);
      s.elapsed = (s.elapsed || 0) + (seen - s.since) / 1000;
      s.since = null; s.paused = true;
      st.active = s; persist(st);
    }
    return s;
  }
  function saveActive(session) {
    const st = load();
    session.seen = Date.now();
    st.active = session;
    return persist(st);
  }
  function clearActive() {
    const st = load();
    if (!st.active) return;
    st.active = null; persist(st); notify();
  }
  function usedSecs(s, now) {
    return (s.elapsed || 0) + (s.since ? ((now || Date.now()) - s.since) / 1000 : 0);
  }
  function summary(s) {
    const used = usedSecs(s);
    return {
      title: s.title, maxMarks: s.maxMarks, n: s.qs.length,
      answered: s.qs.filter((q) => q.picked != null).length,
      flagged: s.qs.filter((q) => q.flagged).length,
      left: Math.max(0, Math.round(s.allowed - used)), allowed: s.allowed,
      strict: !!s.strict, paused: !!s.paused, expired: used >= s.allowed,
    };
  }

  // ---------------------------------------------------------------- scoring + finishing
  function score(session, timedOut) {
    const qs = session.qs, perQ = session.perQ, neg = session.neg || 0;
    const subjects = {}, lessons = {};
    let correct = 0, wrong = 0, skipped = 0, changedRight = 0, changedWrong = 0;
    qs.forEach((q) => {
      const answered = q.picked != null;
      const ok = answered && q.picked === q.correct;
      if (ok) correct += 1; else if (answered) wrong += 1; else skipped += 1;
      if (answered && q.first != null && q.first !== q.picked) { if (ok) changedRight += 1; else changedWrong += 1; }
      const s = (subjects[q.subject] = subjects[q.subject] || { n: 0, c: 0, w: 0, s: 0, marks: 0, max: 0, secs: 0 });
      s.n += 1; s.max += perQ; s.secs += q.secs || 0;
      if (ok) { s.c += 1; s.marks += perQ; } else if (answered) { s.w += 1; s.marks -= perQ * neg; } else s.s += 1;
      const key = q.subject + "|" + (q.lesson || "General");
      const l = (lessons[key] = lessons[key] || { subject: q.subject, lesson: q.lesson || "General", n: 0, c: 0 });
      l.n += 1; if (ok) l.c += 1;
    });
    Object.values(subjects).forEach((s) => { s.marks = round2(s.marks); });
    const marks = round2(correct * perQ - wrong * perQ * neg);
    const used = Math.min(session.allowed, Math.round(usedSecs(session)));
    const pct = Math.max(0, Math.round((marks / session.maxMarks) * 100));
    const subjOk = Object.values(subjects).filter((s) => s.n >= 3 && s.c / s.n >= 0.6).length;
    return {
      id: session.id, at: nowIso(), kind: session.kind, title: session.title,
      maxMarks: session.maxMarks, marks, pct, n: qs.length, correct, wrong, skipped,
      flagged: qs.filter((q) => q.flagged).length, perQ, neg, negMarks: round2(wrong * perQ * neg),
      secsUsed: used, secsAllowed: session.allowed, timedOut: !!timedOut, strict: !!session.strict,
      changedRight, changedWrong, subjOk, scope: session.scope || "",
      subjects, lessons: Object.values(lessons),
      qs: qs.map((q) => ({ q: q.q, options: q.options, correct: q.correct, picked: q.picked, flagged: !!q.flagged, secs: Math.round(q.secs || 0), changes: q.changes || 0, first: q.first, subject: q.subject, lesson: q.lesson || "", section: q.section || "" })),
    };
  }

  // Finish a paper: store the attempt, clear the resume slot and feed every other part of the site.
  function finalize(session, timedOut) {
    const a = score(session, timedOut);
    const st = load();
    st.active = null;
    st.attempts = st.attempts.filter((x) => x.id !== a.id);
    st.attempts.push(a);
    st.attempts = st.attempts.slice(-MAX_ATTEMPTS);
    st.attempts.forEach((x, i, arr) => { if (i < arr.length - KEEP_DETAIL) delete x.qs; });
    persist(st);

    // 1) device-wide score list (scoreboard, trophies) + exam log
    try {
      const all = safeParse(localStorage.getItem(SCORES_KEY), []);
      all.push({ lesson: a.title, subject: "Exam", score: a.correct, total: a.n, date: a.at, exam: { id: a.id, kind: a.kind, marks: a.marks, max: a.maxMarks, pct: a.pct } });
      localStorage.setItem(SCORES_KEY, JSON.stringify(all));
    } catch (_) { /* storage blocked */ }
    if (a.kind !== "redo") try {
      const log = safeParse(localStorage.getItem(LOG_KEY), []);
      log.push({ id: a.id, at: a.at, kind: a.kind, max: a.maxMarks, pct: a.pct, n: a.n, used: a.secsUsed, allowed: a.secsAllowed, subjOk: a.subjOk });
      localStorage.setItem(LOG_KEY, JSON.stringify(log.slice(-200)));
    } catch (_) { /* ignore */ }

    // 2) learning events — one per subject, with a distinct lesson name so none are de-duplicated
    if (window.CurioLearning) {
      Object.entries(a.subjects).forEach(([subj, v]) => {
        window.CurioLearning.recordQuiz({ lesson: "Exam Center · " + subj, subject: subj, score: v.c, total: v.n, href: "" });
      });
    }
    // 3) Mistake Notebook — wrong and unanswered questions
    let saved = 0;
    if (window.CurioReview) {
      const cat = window.CurioCatalog || { lessons: [] };
      (a.qs || []).forEach((q) => {
        if (q.picked === q.correct) return;
        const l = cat.lessons.find((x) => x.s === q.subject && x.t === q.lesson);
        window.CurioReview.addMistake({ q: q.q, options: q.options, correct: q.options[q.correct], picked: q.picked == null ? "" : q.options[q.picked], lesson: q.lesson || "Exam Center", subject: q.subject, href: l ? l.h : "" });
        saved += 1;
      });
    }
    notify();
    return { attempt: a, saved };
  }

  // ---------------------------------------------------------------- reading attempts
  function attempts() { return load().attempts.slice().sort((x, y) => String(x.at).localeCompare(String(y.at))); }
  function attempt(id) { return load().attempts.find((a) => a.id === id) || null; }
  function removeAttempt(id) {
    const st = load();
    st.attempts = st.attempts.filter((a) => a.id !== id);
    persist(st); notify();
  }
  // Exams taken with the old Weekly/Monthly page: they only live in the score list.
  function legacy() {
    const mocks = safeParse(localStorage.getItem("curiolab-mock-history"), []).filter((m) => m && m.at && m.total > 0)
      .map((m) => ({ id: "mock-" + m.at, at: m.at, title: "Mock test · " + m.total + " Qs", n: m.total, correct: Math.round((m.pct / 100) * m.total), maxMarks: m.total, marks: Math.round((m.pct / 100) * m.total), pct: m.pct, legacy: true }));
    return mocks.concat(safeParse(localStorage.getItem(SCORES_KEY), []).filter((s) => s && s.subject === "Exam" && !s.exam && s.total > 0 && s.date)
      .map((s) => ({ id: "legacy-" + s.date, at: s.date, title: s.lesson, n: s.total, correct: s.score, maxMarks: s.total, marks: s.score, pct: Math.round((s.score / s.total) * 100), legacy: true })));
  }
  function history() {
    return [...attempts(), ...legacy()].sort((x, y) => String(y.at).localeCompare(String(x.at)));
  }
  function stats() {
    const h = history().filter((a) => a.kind !== "redo");
    const rich = attempts().filter((a) => a.kind !== "redo");
    const best = h.length ? Math.max(...h.map((a) => a.pct)) : null;
    const avg = h.length ? Math.round(h.reduce((s, a) => s + a.pct, 0) / h.length) : null;
    const full = rich.filter((a) => a.maxMarks >= 80);
    const secs = rich.reduce((s, a) => s + a.secsUsed, 0);
    return { count: h.length, best, avg, fullCount: full.length, bestFull: full.length ? Math.max(...full.map((a) => a.pct)) : null, secs, last: h[0] || null };
  }
  const prevOfKind = (a) => attempts().filter((x) => x.kind === a.kind && x.id !== a.id && String(x.at) < String(a.at)).pop() || null;
  const bestOfKind = (a) => Math.max(0, ...attempts().filter((x) => x.kind === a.kind && x.id !== a.id).map((x) => x.pct));

  // ---------------------------------------------------------------- readiness
  const BANDS = [
    { min: 80, id: "ready", label: "Exam ready" },
    { min: 65, id: "almost", label: "Almost there" },
    { min: 45, id: "building", label: "Building" },
    { min: 0, id: "needs", label: "Needs work" },
  ];
  const band = (v) => (v == null ? { id: "none", label: "No data yet" } : BANDS.find((b) => v >= b.min));

  // learn = snapshot from CurioLearning.get() (or null). Returns the whole readiness picture.
  function readiness(learn) {
    const CAT = window.CurioCatalog || { subjects: [], lessons: [] };
    const events = learn && Array.isArray(learn.events) ? learn.events.filter((e) => e.total > 0) : [];
    const visits = learn && Array.isArray(learn.visits) ? learn.visits : [];
    const rel = (h) => (window.CurioLearning ? window.CurioLearning.relHref(h) : h);
    const recent = attempts().filter((a) => a.kind !== "redo").slice(-6);
    const R = window.CurioReview ? window.CurioReview.stats() : null;
    const isExamEvent = (e) => /^(Exam Center|Mock test)/.test(e.lesson || "") || e.subject === "Exam";

    const subjects = CAT.subjects.map((s) => {
      const ls = CAT.lessons.filter((l) => l.s === s.name);
      // exam signal: recency-weighted accuracy over the last six papers
      let ew = 0, ec = 0;
      recent.forEach((a, i) => {
        const v = a.subjects && a.subjects[s.name]; if (!v || v.n < 3) return;
        const w = Math.pow(0.8, recent.length - 1 - i);
        ew += w * (v.c / v.n); ec += w;
      });
      const examAcc = ec ? Math.round((ew / ec) * 100) : null;
      const examQs = recent.reduce((n, a) => n + ((a.subjects && a.subjects[s.name]) ? a.subjects[s.name].n : 0), 0);
      // practice signal: average of each lesson's last three quiz scores
      const mastery = ls.map((l) => {
        const evs = events.filter((e) => !isExamEvent(e) && ((e.href && rel(e.href) === l.h) || (e.subject === l.s && e.lesson === l.t))).slice(-3);
        return evs.length ? { l, m: Math.round(evs.reduce((n, e) => n + (e.score / e.total) * 100, 0) / evs.length), q: evs.reduce((n, e) => n + e.total, 0) } : null;
      }).filter(Boolean);
      const practice = mastery.length ? Math.round(mastery.reduce((n, x) => n + x.m, 0) / mastery.length) : null;
      const practiceQs = mastery.reduce((n, x) => n + x.q, 0);
      const explored = ls.filter((l) => visits.some((v) => rel(v.href) === l.h) || events.some((e) => !isExamEvent(e) && ((e.href && rel(e.href) === l.h) || (e.subject === l.s && e.lesson === l.t)))).length;
      const coverage = ls.length ? explored / ls.length : 0;
      const due = R && R.bySubject && R.bySubject[s.name] ? R.bySubject[s.name].due : 0;

      const wE = examAcc == null ? 0 : Math.min(1, examQs / 12) * 0.6;
      const wP = practice == null ? 0 : Math.min(1, practiceQs / 15) * 0.4;
      let value = null;
      if (wE + wP > 0) {
        const base = ((examAcc || 0) * wE + (practice || 0) * wP) / (wE + wP);
        value = Math.round(Math.max(0, Math.min(100, base * (0.7 + 0.3 * coverage) - Math.min(8, due * 1.5))));
      }
      const evidence = examQs + practiceQs;
      return { name: s.name, code: s.code, href: s.href, value, band: band(value), examAcc, examQs, practice, practiceQs, explored, total: ls.length, coverage, due, confidence: evidence >= 30 ? "high" : evidence >= 10 ? "medium" : "low" };
    });

    const withData = subjects.filter((s) => s.value != null);
    const overall = withData.length ? Math.round(withData.reduce((n, s) => n + s.value, 0) / withData.length) : null;
    const evidence = withData.reduce((n, s) => n + s.examQs + s.practiceQs, 0);
    const confidence = withData.length < 3 || evidence < 20 ? "low" : evidence < 60 ? "medium" : "high";
    const margin = confidence === "low" ? 14 : confidence === "medium" ? 9 : 5;
    const range = overall == null ? null : [Math.max(0, overall - margin), Math.min(100, overall + margin)];
    const trend = attempts().filter((a) => a.kind !== "redo").slice(-8).map((a) => ({ at: a.at, pct: a.pct, title: a.title }));

    // weak lessons: low accuracy over recent papers, or low quiz mastery
    const wl = {};
    const addWeak = (subject, lesson, c, n, src) => {
      if (!lesson || lesson === "General") return;
      const k = subject + "|" + lesson; const x = (wl[k] = wl[k] || { subject, lesson, c: 0, n: 0, src: new Set() });
      x.c += c; x.n += n; x.src.add(src);
    };
    recent.forEach((a) => (a.lessons || []).forEach((l) => addWeak(l.subject, l.lesson, l.c, l.n, "exam")));
    CAT.lessons.forEach((l) => {
      const evs = events.filter((e) => !isExamEvent(e) && ((e.href && rel(e.href) === l.h) || (e.subject === l.s && e.lesson === l.t))).slice(-3);
      evs.forEach((e) => addWeak(l.s, l.t, e.score, e.total, "quiz"));
    });
    const mistakes = {};
    if (window.CurioReview) window.CurioReview.all().forEach((m) => { const k = m.subject + "|" + m.lesson; mistakes[k] = (mistakes[k] || 0) + 1; });
    const weak = Object.values(wl).filter((x) => x.n >= 3 && x.c / x.n < 0.6)
      .map((x) => ({ subject: x.subject, lesson: x.lesson, acc: Math.round((x.c / x.n) * 100), n: x.n, mistakes: mistakes[x.subject + "|" + x.lesson] || 0, href: (CAT.lessons.find((l) => l.s === x.subject && l.t === x.lesson) || {}).h || "" }))
      .sort((a, b) => a.acc - b.acc || b.mistakes - a.mistakes);

    // next best paper
    const st = stats(); const last = st.last;
    const daysSince = last ? Math.floor((Date.now() - new Date(last.at)) / 86400000) : null;
    let next;
    if (!st.count) next = { id: "test20", why: "You haven't sat an exam yet — a 20-mark test is the quickest way to find where you stand." };
    else if (weak.length >= 2) next = { id: "weak", why: `${weak.length} lessons are dragging your scores down. A drill built from them is the fastest fix.` };
    else if (overall != null && overall >= 65 && !st.fullCount) next = { id: "board80", why: "Your scores are solid — test your stamina with a full-length board paper." };
    else if (st.fullCount && (daysSince == null || daysSince > 14)) next = { id: "full100", why: "It's been a while since a full paper. Run one to refresh your readiness estimate." };
    else if (daysSince != null && daysSince >= 6) next = { id: "weekly", why: `${daysSince} days since your last exam — a weekly check-in keeps your readiness estimate fresh.` };
    else next = { id: "mid40", why: "Keep the momentum going with a mid-term paper." };

    return { subjects, overall, band: band(overall), confidence, range, evidence, subjectsWithData: withData.length, trend, weak, next, daysSince };
  }

  function weakKeys(learn) { return readiness(learn).weak.map((w) => w.subject + "|" + w.lesson); }

  // ---------------------------------------------------------------- formatting + reset
  const fmtClock = (secs) => {
    secs = Math.max(0, Math.round(secs));
    const h = Math.floor(secs / 3600), m = Math.floor((secs % 3600) / 60), s = secs % 60;
    return (h ? h + ":" + String(m).padStart(2, "0") : String(m).padStart(2, "0")) + ":" + String(s).padStart(2, "0");
  };
  const fmtDur = (secs) => {
    secs = Math.round(secs);
    if (secs < 60) return secs + " s";
    const m = Math.floor(secs / 60), s = secs % 60;
    if (m < 60) return m + " min" + (s && m < 10 ? " " + s + " s" : "");
    return Math.floor(m / 60) + " h " + (m % 60 ? (m % 60) + " min" : "");
  };
  function clearAll() {
    Object.keys(localStorage).filter((k) => k.indexOf(KEY_PREFIX) === 0).forEach((k) => localStorage.removeItem(k));
    localStorage.removeItem(LOG_KEY);
    notify();
  }

  window.CurioExam = {
    PRESETS, GRADES, NEG, grade, band, BANDS,
    settings, setSettings,
    active, saveActive, clearActive, usedSecs, summary,
    score, finalize,
    attempts, attempt, history, legacy, removeAttempt, stats, prevOfKind, bestOfKind,
    readiness, weakKeys,
    fmtClock, fmtDur, clearAll, accountKey,
  };
})();
