// Curio Lab — Time & personality-based greeting
(function () {
  const PERSONAS = {
    dawn: [ // 5–8
      { pip: "🌅", text: "Early riser — the lab is quiet, perfect for deep focus." },
      { pip: "☕", text: "Up before the sun. Let's get a head start." },
    ],
    morning: [ // 8–12
      { pip: "🔭", text: "Good morning, explorer. Fresh mind, fresh questions." },
      { pip: "📓", text: "Morning shift at the lab — what's on today's page?" },
    ],
    afternoon: [ // 12–17
      { pip: "🧪", text: "Good afternoon. Prime time for a quick experiment." },
      { pip: "📐", text: "Midday focus window — let's make it count." },
    ],
    evening: [ // 17–21
      { pip: "🌇", text: "Good evening. A calm hour for steady practice." },
      { pip: "📚", text: "Evening study session — one topic at a time." },
    ],
    night: [ // 21–5
      { pip: "🦉", text: "Night-owl researcher, huh? Keep it light and go easy on sleep." },
      { pip: "🌙", text: "Burning the midnight oil in the lab tonight." },
    ],
  };

  function bucketForHour(h) {
    if (h >= 5 && h < 8) return "dawn";
    if (h >= 8 && h < 12) return "morning";
    if (h >= 12 && h < 17) return "afternoon";
    if (h >= 17 && h < 21) return "evening";
    return "night";
  }

  document.addEventListener("DOMContentLoaded", () => {
    const el = document.querySelector("[data-greeting]");
    if (!el) return;
    const bucket = bucketForHour(new Date().getHours());
    const options = PERSONAS[bucket];
    const chosen = options[Math.floor(Math.random() * options.length)];
    el.innerHTML = `<span class="pip">${chosen.pip}</span> ${chosen.text}`;
  });
})();
