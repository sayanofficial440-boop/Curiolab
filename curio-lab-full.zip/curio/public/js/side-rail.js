// Curio Lab — Side Rail (left quick-access bar for tools, subscription, and company pages)
(function () {
  function computePrefixes() {
    const path = window.location.pathname;
    const parts = path.split("/").filter(Boolean);
    const pagesIdx = parts.lastIndexOf("pages");
    if (pagesIdx === -1) return { p: "pages/", r: "" };
    const depthAfterPages = parts.length - pagesIdx - 1;
    if (depthAfterPages <= 1) return { p: "", r: "../" };
    return { p: "../", r: "../../" };
  }

  const { p, r } = computePrefixes();
  const here = window.location.pathname.split("/").pop() || "index.html";

  const svg = (d) => `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const ICON = {
    overview: svg('<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>'),
    learning: svg('<path d="M4 5.5A1.5 1.5 0 0 1 5.5 4H11v15H5.5A1.5 1.5 0 0 0 4 20.5z"/><path d="M20 5.5A1.5 1.5 0 0 0 18.5 4H13v15h5.5a1.5 1.5 0 0 1 1.5 1.5z"/>'),
    calendar: svg('<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>'),
    analytics: svg('<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'),
    trophy: svg('<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M17 5h3a3 3 0 0 1-3 5M7 5H4a3 3 0 0 0 3 5"/>'),
    profile: svg('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'),
    recall: svg('<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>'),
    games: svg('<rect x="2.5" y="7" width="19" height="11" rx="5"/><path d="M7.5 10.5v4M5.5 12.5h4"/><circle cx="16" cy="11.5" r=".8"/><circle cx="18" cy="13.5" r=".8"/>'),
    glossary: svg('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>'),
    help: svg('<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 .9-1 1.7M12 17h.01"/>'),
    home: svg('<path d="M3 11 12 3l9 8"/><path d="M5 9.5V20h14V9.5"/>'),
    notebook: svg('<path d="M6 3h11a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6z"/><path d="M6 3v18M10 8h5M10 12h5"/>'),
    bookmark: svg('<path d="M6 3h12v18l-6-4-6 4z"/>'),
    menu: svg('<path d="M4 7h16M4 12h16M4 17h10"/>'),
  };

  const SECTIONS = [
    {
      label: "Workspace",
      items: [
        { icon: ICON.overview, label: "Overview", href: `${r}dashboard.html` },
        { icon: ICON.learning, label: "My learning", href: `${p}physics.html` },
        { icon: ICON.calendar, label: "Smart calendar", href: `${p}todo.html` },
        { icon: ICON.analytics, label: "Analytics", href: `${p}scoreboard.html` },
        { icon: ICON.trophy, label: "Progress report", href: `${p}report.html` },
        { icon: ICON.trophy, label: "Achievements", href: `${p}certificates.html` },
        { icon: ICON.profile, label: "Community", href: `${p}community.html` },
        { icon: ICON.profile, label: "Profile & settings", href: `${p}profile.html` },
      ],
    },
    {
      label: "Subjects",
      items: [
        { icon: "PHY", label: "Physics", href: `${p}physics.html` },
        { icon: "CHM", label: "Chemistry", href: `${p}chemistry.html` },
        { icon: "BIO", label: "Biology", href: `${p}biology.html` },
        { icon: "ENG", label: "English", href: `${p}english.html` },
        { icon: "MTH", label: "Mathematics", href: `${p}mathematics.html` },
        { icon: "HIS", label: "History", href: `${p}history.html` },
        { icon: "GEO", label: "Geography", href: `${p}geography.html` },
        { icon: "CS", label: "Computer Science", href: `${p}computer-science.html` },
      ],
    },
    {
      label: "Learning tools",
      items: [
        { icon: ICON.recall, label: "Active recall", href: `${p}active-recall.html` },
        { icon: ICON.recall, label: "Practice hub", href: `${p}practice.html` },
        { icon: ICON.analytics, label: "Problem Lab", href: `${p}problem-lab.html` },
        { icon: ICON.analytics, label: "Courses", href: `${p}courses.html` },
        { icon: ICON.analytics, label: "Exam Center", href: `${p}exams.html` },
        { icon: ICON.analytics, label: "Past Papers", href: `${p}past-papers.html` },
        { icon: ICON.notebook, label: "Mistake notebook", href: `${p}review.html` },
        { icon: ICON.bookmark, label: "Saved & notes", href: `${p}saved.html` },
        { icon: ICON.games, label: "Learning games", href: `${p}play.html` },
        { icon: ICON.analytics, label: "Virtual labs", href: `${p}labs/index.html` },
        { icon: ICON.analytics, label: "Graphing & solver", href: `${p}math-tools/index.html` },
        { icon: ICON.bookmark, label: "Revision notes (PDF)", href: `${p}notes/index.html` },
        { icon: ICON.glossary, label: "Glossary", href: `${p}glossary.html` },
        { icon: ICON.help, label: "Accessibility", href: `${p}accessibility.html` },
        { icon: ICON.help, label: "Help center", href: `${p}help.html` },
      ],
    },
  ];
  const MORE = [
    { label: "Certificates", href: `${p}certificates.html` },
    { label: "Subscription", href: `${p}pricing.html` }, { label: "About us", href: `${p}about.html` },
    { label: "Blog", href: `${p}blog.html` }, { label: "FAQ", href: `${p}faq.html` }, { label: "Changelog", href: `${p}changelog.html` }, { label: "Privacy", href: `${p}privacy.html` }, { label: "Terms", href: `${p}terms.html` },
  ];

  function loadRailStyles() {
    if (document.getElementById("curio-rail-mobile-css")) return;
    const link = document.createElement("link");
    link.id = "curio-rail-mobile-css";
    link.rel = "stylesheet";
    link.href = `${r}css/rail-mobile.css`;
    document.head.appendChild(link);
  }

  function buildRail() {
    loadRailStyles();
    const rail = document.createElement("nav");
    rail.className = "side-rail";
    rail.id = "curio-side-rail";

    let html = `<div class="rail-header"><a class="rail-logo" href="${r}dashboard.html"><span class="rail-brand-dot"></span>Curio·Lab</a><button type="button" class="rail-close" aria-label="Close menu">✕</button></div><div class="rail-scroll">`;
    SECTIONS.forEach((section) => {
      html += `<div class="rail-section-label">${section.label}</div>`;
      section.items.forEach((item) => {
        const isCurrent = item.href.endsWith(here) && here !== "index.html";
        html += `<a class="rail-item ${isCurrent ? "current" : ""}" href="${item.href}" title="${item.label}"${isCurrent ? ' aria-current="page"' : ""}>
          <span class="rail-icon${item.icon.startsWith("<svg") ? "" : " is-code"}">${item.icon}</span><span class="rail-label">${item.label}</span>
        </a>`;
      });
    });
    html += `<details class="rail-more"><summary><span>More</span><span>⌄</span></summary><div class="rail-more-links">${MORE.map((item) => `<a href="${item.href}">${item.label}</a>`).join("")}</div></details></div>`;
    rail.innerHTML = html;
    document.body.appendChild(rail);

    const toggle = document.createElement("button");
    toggle.className = "rail-toggle";
    toggle.setAttribute("aria-label", "Open menu");
    toggle.textContent = "☰";
    document.body.appendChild(toggle);

    const backdrop = document.createElement("div");
    backdrop.className = "rail-backdrop";
    document.body.appendChild(backdrop);

    // Compact bottom bar (phones/tablets) — quick links + a Menu button for the drawer
    const BAR = [
      { icon: ICON.home, label: "Home", href: `${r}dashboard.html` },
      { icon: ICON.learning, label: "Learn", href: `${p}physics.html` },
      { icon: ICON.recall, label: "Recall", href: `${p}active-recall.html` },
      { icon: ICON.analytics, label: "Progress", href: `${p}scoreboard.html` },
    ];
    const bar = document.createElement("nav");
    bar.className = "curio-bottom-bar";
    bar.setAttribute("aria-label", "Quick navigation");
    bar.innerHTML = BAR.map((b) => {
      const cur = b.href.endsWith(here) && here !== "index.html";
      return `<a class="cbb-item${cur ? " current" : ""}" href="${b.href}"${cur ? ' aria-current="page"' : ""}>${b.icon}<span>${b.label}</span></a>`;
    }).join("") + `<button type="button" class="cbb-item cbb-menu" aria-label="Open menu" aria-controls="curio-side-rail" aria-expanded="false">${ICON.menu}<span>Menu</span></button>`;
    document.body.appendChild(bar);
    document.body.classList.add("has-bottom-bar");
    const menuBtn = bar.querySelector(".cbb-menu");

    function openRail() {
      rail.classList.add("open");
      backdrop.classList.add("open");
      document.body.classList.add("rail-locked");
      menuBtn.setAttribute("aria-expanded", "true");
      window.CurioSound && window.CurioSound.play("open");
    }
    function closeRail(silent) {
      if (!rail.classList.contains("open")) return;
      rail.classList.remove("open");
      backdrop.classList.remove("open");
      document.body.classList.remove("rail-locked");
      menuBtn.setAttribute("aria-expanded", "false");
      if (!silent) window.CurioSound && window.CurioSound.play("close");
    }
    toggle.addEventListener("click", openRail);
    menuBtn.addEventListener("click", () => (rail.classList.contains("open") ? closeRail() : openRail()));
    backdrop.addEventListener("click", () => closeRail());
    const closeBtn = rail.querySelector(".rail-close");
    if (closeBtn) closeBtn.addEventListener("click", () => closeRail());
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeRail(); });
    window.matchMedia("(min-width: 900px)").addEventListener("change", (e) => { if (e.matches) closeRail(true); });
    rail.querySelectorAll("a").forEach((a) => {
      a.addEventListener("click", () => {
        window.CurioSound && window.CurioSound.play("navigate");
        closeRail(true);
      });
    });

    // Desktop: expand to show labels on hover
    if (window.matchMedia("(min-width: 900px)").matches) {
      rail.addEventListener("mouseenter", () => rail.classList.add("labels-visible"));
      rail.addEventListener("mouseleave", () => rail.classList.remove("labels-visible"));
    }
  }

  document.addEventListener("DOMContentLoaded", buildRail);
})();
