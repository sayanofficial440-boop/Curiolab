// Curio Lab — Community: Study groups and friend quiz duels (the "Groups" and "Duels" tabs). Talks to backend/discuss.py.
(function () {
  "use strict";
  const SUBJECTS = ["Physics", "Chemistry", "Biology", "Mathematics", "English", "History", "Geography", "Computer Science"];
  let lessonsCache = null;
  async function lessons() {
    if (lessonsCache) return lessonsCache;
    try {
      const r = await fetch("../data/learning-index.json", { cache: "force-cache" });
      const d = await r.json();
      const sub = { physics: "Physics", chemistry: "Chemistry", biology: "Biology", mathematics: "Mathematics", english: "English", history: "History", geography: "Geography", "computer-science": "Computer Science" };
      lessonsCache = (d.lessons || []).filter((l) => (l.quizTotal || 0) >= 10).map((l) => ({ id: l.id, title: l.title, subject: sub[l.id.split("/")[0]] || "Other" }));
    } catch (_) { lessonsCache = []; }
    return lessonsCache;
  }
  const mmss = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
  const until = (t) => { const h = Math.max(0, Math.round((t - Date.now() / 1000) / 3600)); return h >= 24 ? Math.round(h / 24) + " d left" : h + " h left"; };

  // ================================================================== groups
  async function groups(el, ctx) {
    const { CC, toast } = ctx, { esc, avatar, fmt } = CC;
    const bar = (v, goal) => `<div class="cm-xpbar" role="img" aria-label="${fmt(v)} of ${fmt(goal)} points this week"><span style="width:${Math.max(2, Math.min(100, (v / Math.max(1, goal)) * 100))}%"></span></div>`;
    async function home() {
      el.innerHTML = `<p class="cm-hint">Loading…</p>`;
      let j;
      try { j = await CC.api("/groups"); } catch (e) { el.innerHTML = `<p class="cm-err">${esc(e.message)}</p>`; return; }
      el.innerHTML = `<div class="cm-s-grid">
        <form class="cm-card cm-s-form" data-join novalidate><h3>Join with a code</h3><label class="cm-sr" for="cm-gcode">Invite code</label>
          <div class="cm-inline"><input id="cm-gcode" name="code" placeholder="ABCD-EFGH" autocomplete="off" autocapitalize="characters" maxlength="12" translate="no" /><button class="cm-btn cm-primary" type="submit">Join</button></div>
          <p class="cm-hint">Groups are private. There's no list to browse: someone who's in the group shares the code with you. Members can see each other's name, avatar and points.</p><p class="cm-err" data-jerr role="alert"></p></form>
        <form class="cm-card cm-s-form" data-new novalidate><h3>Start a group</h3>
          <label class="cm-sr" for="cm-gname">Group name</label><input id="cm-gname" name="name" placeholder="Group name (e.g. Class 9 Physics)" maxlength="40" />
          <div class="cm-row"><label>Focus<select name="subject"><option value="">All subjects</option>${SUBJECTS.map((s) => `<option>${s}</option>`).join("")}</select></label><label>Weekly goal (points)<input name="goal" type="number" inputmode="numeric" min="100" max="10000" step="50" value="500" /></label></div>
          <button class="cm-btn cm-primary" type="submit">Create</button><p class="cm-err" data-nerr role="alert"></p></form></div>
        <h3 class="cm-h"><span>My groups</span> (${j.groups.length})</h3>
        ${j.groups.length ? `<ul class="cm-s-cards">${j.groups.map((g) => `<li class="cm-card"><div class="cm-s-top"><strong>${esc(g.name)}</strong><span class="cm-chip">${esc(g.subject || "All subjects")}</span></div>
          <p class="cm-hint">${g.members} member${g.members === 1 ? "" : "s"} · ${fmt(g.week_total)} / ${fmt(g.goal)} points this week</p>${bar(g.week_total, g.goal)}
          <button type="button" class="cm-btn cm-sm" data-open="${esc(g.id)}">Open</button></li>`).join("")}</ul>` : `<div class="cm-empty">You're not in a group yet. Start one and share the code with friends.</div>`}`;
      const f1 = el.querySelector("[data-join]");
      f1.addEventListener("submit", async (ev) => { ev.preventDefault(); const er = f1.querySelector("[data-jerr]"); er.textContent = ""; try { const r = await CC.api("/groups/join", { body: { code: f1.code.value } }); toast("Joined " + r.group.name, { icon: "👥" }); detail(r.group.id); } catch (e) { er.textContent = e.message; } });
      const f2 = el.querySelector("[data-new]");
      f2.addEventListener("submit", async (ev) => { ev.preventDefault(); const er = f2.querySelector("[data-nerr]"); er.textContent = ""; try { const r = await CC.api("/groups/create", { body: { name: f2.name.value, subject: f2.subject.value, goal: +f2.goal.value } }); toast("Group created", { icon: "👥" }); detail(r.group.id); } catch (e) { er.textContent = e.message; } });
      el.querySelectorAll("[data-open]").forEach((b) => b.addEventListener("click", () => detail(b.dataset.open)));
    }
    async function detail(id) {
      el.innerHTML = `<p class="cm-hint">Loading…</p>`;
      let g;
      try { g = (await CC.api("/groups/" + encodeURIComponent(id))).group; } catch (e) { toast(e.message, { icon: "⚠️" }); return home(); }
      const owner = g.role === "owner", unit = g.subject ? g.subject + " points" : "points";
      el.innerHTML = `<button type="button" class="cm-link" data-back>← All groups</button>
        <div class="cm-card"><div class="cm-s-top"><h3>${esc(g.name)}</h3><span class="cm-chip">${esc(g.subject || "All subjects")}</span></div>
          <p class="cm-hint">Weekly goal: <strong>${fmt(g.week_total)}</strong> of ${fmt(g.goal)} ${esc(unit)} together. Resets Monday 00:00 UTC.</p>${bar(g.week_total, g.goal)}
          <p class="cm-s-invite">Invite code <code translate="no" data-code>${esc(g.invite)}</code> <button type="button" class="cm-btn cm-sm" data-copy>Copy</button>${owner ? ` <button type="button" class="cm-btn cm-sm" data-rotate>New code</button>` : ""}</p>
          <p class="cm-hint">Anyone with the code can join (up to ${g.limit} people). Make a new code if it gets shared too widely.</p></div>
        <h3 class="cm-h"><span>Members</span> (${g.members})</h3>
        <ul class="cm-rows">${g.member_list.map((m, i) => `<li class="${m.you ? "is-me" : ""}"><span class="cm-rank">${i + 1}</span>${avatar(m.name, null)}<span class="cm-name">${esc(m.name)}<small translate="no">@${esc(m.handle)}${m.role === "owner" ? " · owner" : ""}</small></span>
          <span class="cm-pts">${fmt(m.week)}<small>this week</small></span><span class="cm-btns"><span class="cm-pts">${fmt(m.total)}<small>total</small></span>${owner && !m.you ? `<button type="button" class="cm-btn cm-sm" data-kick="${esc(m.handle)}" aria-label="Remove ${esc(m.name)}">Remove</button>` : ""}</span></li>`).join("")}</ul>
        ${owner ? `<form class="cm-card cm-s-form" data-edit novalidate><h3>Group settings</h3><label class="cm-sr" for="cm-ename">Name</label><input id="cm-ename" name="name" value="${esc(g.name)}" maxlength="40" />
          <div class="cm-row"><label>Focus<select name="subject"><option value="">All subjects</option>${SUBJECTS.map((s) => `<option ${s === g.subject ? "selected" : ""}>${s}</option>`).join("")}</select></label><label>Weekly goal<input name="goal" type="number" min="100" max="10000" step="50" value="${g.goal}" /></label></div>
          <div class="cm-btns"><button class="cm-btn cm-primary" type="submit">Save</button><button type="button" class="cm-btn" data-delete>Delete group</button></div><p class="cm-err" data-eerr role="alert"></p></form>` : ""}
        <div class="cm-btns cm-s-foot"><button type="button" class="cm-btn" data-leave>Leave group</button><button type="button" class="cm-btn" data-report>Report group</button></div>`;
      const $ = (s) => el.querySelector(s), call = async (path, body, method) => CC.api("/groups/" + encodeURIComponent(id) + path, { body: body || {}, method: method || "POST" });
      $("[data-back]").addEventListener("click", home);
      $("[data-copy]").addEventListener("click", async () => { try { await navigator.clipboard.writeText(g.invite); toast("Code copied", { icon: "📋" }); } catch (_) { toast(g.invite, { icon: "📋" }); } });
      const rot = $("[data-rotate]"); rot && rot.addEventListener("click", async () => { if (!confirm("Make a new invite code? The old one stops working.")) return; try { await call("/rotate"); detail(id); } catch (e) { toast(e.message, { icon: "⚠️" }); } });
      el.querySelectorAll("[data-kick]").forEach((b) => b.addEventListener("click", async () => { if (!confirm("Remove this member from the group?")) return; try { await call("/remove", { handle: b.dataset.kick }); detail(id); } catch (e) { toast(e.message, { icon: "⚠️" }); } }));
      const ed = $("[data-edit]"); ed && ed.addEventListener("submit", async (ev) => { ev.preventDefault(); try { await call("/update", { name: ed.name.value, subject: ed.subject.value, goal: +ed.goal.value }); toast("Saved", { icon: "✅" }); detail(id); } catch (e) { ed.querySelector("[data-eerr]").textContent = e.message; } });
      const del = $("[data-delete]"); del && del.addEventListener("click", async () => { if (!confirm("Delete this group for everyone?")) return; try { await call("", {}, "DELETE"); toast("Group deleted", { icon: "🗑️" }); home(); } catch (e) { toast(e.message, { icon: "⚠️" }); } });
      $("[data-leave]").addEventListener("click", async () => { if (!confirm(owner ? "Leave? Ownership passes to the longest-standing member." : "Leave this group?")) return; try { await call("/leave"); toast("You left the group", { icon: "👋" }); home(); } catch (e) { toast(e.message, { icon: "⚠️" }); } });
      $("[data-report]").addEventListener("click", async () => {
        if (window.CurioReport) { const sent = await window.CurioReport.open({ what: "group", onSend: (x) => call("/report", { category: x.category, reason: x.reason }) }); if (sent) toast("Thanks, we'll take a look", { icon: "🚩" }); return; }
        const r = prompt("What is wrong with this group? (private)"); if (!r) return; try { await call("/report", { reason: r }); toast("Thanks, we'll take a look", { icon: "🚩" }); } catch (e) { toast(e.message, { icon: "⚠️" }); } });
    }
    home();
  }

  // ================================================================== duels
  async function duels(el, ctx) {
    const { CC, toast } = ctx, { esc, avatar } = CC;
    let timer = null;
    const stop = () => { if (timer) { clearInterval(timer); timer = null; } };
    const D = (path, body) => CC.api("/duels" + path, body === undefined ? {} : { body });
    async function home() {
      stop(); el.innerHTML = `<p class="cm-hint">Loading…</p>`;
      let j, fr, ls;
      try { [j, fr, ls] = await Promise.all([CC.api("/duels"), CC.api("/friends"), lessons()]); } catch (e) { el.innerHTML = `<p class="cm-err">${esc(e.message)}</p>`; return; }
      const bySub = SUBJECTS.map((s) => [s, ls.filter((l) => l.subject === s)]).filter((x) => x[1].length);
      const opp = (d) => d.opponent ? `${avatar(d.opponent.name, d.opponent.avatar)}<span class="cm-name">${esc(d.opponent.name)}<small translate="no">@${esc(d.opponent.handle)}</small></span>` : "<span></span><span></span>";
      const B = (a, id, l, c) => `<button type="button" class="cm-btn cm-sm ${c || ""}" data-act="${a}" data-id="${esc(id)}">${l}</button>`;
      const activeRow = (d) => {
        let note = "", btns = "";
        if (d.can_respond) { note = "challenged you"; btns = B("accept", d.id, "Accept & play", "cm-primary") + B("decline", d.id, "Decline"); }
        else if (d.can_play) { note = d.i_challenged ? "you challenged" : "ready to play"; btns = B("play", d.id, d.started ? "Resume" : "Play", "cm-primary") + (d.can_cancel ? B("cancel", d.id, "Cancel") : ""); }
        else { note = d.i_challenged && d.status === "pending" ? "waiting for them to accept" : "waiting for them to play"; btns = d.can_cancel ? B("cancel", d.id, "Cancel") : ""; }
        return `<li>${opp(d)}<span class="cm-s-lesson">${esc(d.lesson.title)}<small>${esc(note)} · ${until(d.expires_at)}</small></span><span class="cm-btns">${btns}</span></li>`;
      };
      const doneRow = (d) => {
        const label = { win: "🏆 You won", loss: "You lost", draw: "🤝 Draw", none: "No result" }[d.result] || ({ declined: "Declined", cancelled: "Cancelled", expired: "Expired" }[d.status] || d.status);
        const score = d.status === "finished" ? (d.forfeit ? (d.result === "win" ? "They didn't play in time" : "You didn't play in time") : `${d.my_score}–${d.opp_score}`) : "";
        return `<li data-r="${esc(d.result || d.status)}">${opp(d)}<span class="cm-s-lesson">${esc(d.lesson.title)}<small>${esc(score)}</small></span><span class="cm-btns"><span class="cm-s-res">${label}</span>${d.status === "finished" && d.opponent ? B("rematch", d.id, "Rematch") : ""}</span></li>`;
      };
      el.innerHTML = `<div class="cm-card cm-s-record"><div><strong>${j.record.wins}</strong><small>wins</small></div><div><strong>${j.record.losses}</strong><small>losses</small></div><div><strong>${j.record.draws}</strong><small>draws</small></div>
          <p class="cm-hint">Duels are 1v1, ${j.lessons} questions from one lesson's quiz. You each play whenever you like in the next 3 days. Most points wins; the faster player breaks a tie. Duels are for bragging rights and don't change XP.</p></div>
        <form class="cm-card cm-s-form" data-new novalidate><h3>Challenge a friend</h3>
          ${fr.friends.length ? `<div class="cm-row"><label>Friend<select name="handle">${fr.friends.map((f) => `<option value="${esc(f.handle)}">${esc(f.name)} (@${esc(f.handle)})</option>`).join("")}</select></label>
          <label>Lesson<select name="lesson">${bySub.map(([s, l]) => `<optgroup label="${esc(s)}">${l.map((x) => `<option value="${esc(x.id)}">${esc(x.title)}</option>`).join("")}</optgroup>`).join("")}</select></label></div>
          <button class="cm-btn cm-primary" type="submit">Send challenge</button>` : `<p class="cm-hint">Add a friend first (Friends tab), then you can challenge them.</p>`}<p class="cm-err" data-nerr role="alert"></p></form>
        <h3 class="cm-h"><span>Open duels</span> (${j.active.length})</h3>
        ${j.active.length ? `<ul class="cm-rows cm-s-duels">${j.active.map(activeRow).join("")}</ul>` : `<div class="cm-empty">No open duels.</div>`}
        ${j.finished.length ? `<h3 class="cm-h">Recent</h3><ul class="cm-rows cm-s-duels">${j.finished.map(doneRow).join("")}</ul>` : ""}`;
      const f = el.querySelector("[data-new]");
      f && f.addEventListener("submit", async (ev) => { ev.preventDefault(); const er = f.querySelector("[data-nerr]"); er.textContent = ""; try { await D("/create", { handle: f.handle.value, lesson: f.lesson.value }); toast("Challenge sent", { icon: "⚔️" }); home(); } catch (e) { er.textContent = e.message; } });
      el.querySelectorAll("[data-act]").forEach((b) => b.addEventListener("click", async () => {
        const id = b.dataset.id, a = b.dataset.act;
        try {
          if (a === "play" || a === "accept") return play(id);
          if (a === "rematch") { const row = [...j.finished].find((x) => x.id === id); await D("/create", { handle: row.opponent.handle, lesson: row.lesson.id }); toast("Rematch sent", { icon: "⚔️" }); return home(); }
          if (a === "decline") await D("/" + id + "/respond", { accept: false });
          if (a === "cancel") { if (!confirm("Cancel this duel?")) return; await D("/" + id + "/cancel", {}); }
          home();
        } catch (e) { toast(e.message, { icon: "⚠️" }); home(); }
      }));
    }
    async function play(id) {
      stop();
      let s;
      try { s = await D("/" + id + "/start", {}); } catch (e) { toast(e.message, { icon: "⚠️" }); return home(); }
      const qs = s.questions, picks = [], t0 = Date.now(); let i = 0;
      el.innerHTML = `<div class="cm-card cm-s-play"><div class="cm-s-top"><button type="button" class="cm-link" data-quit>← Save for later</button><span class="cm-chip" data-clock aria-live="off">0:00</span></div>
        <p class="cm-hint" data-prog></p><div class="cm-xpbar"><span data-bar style="width:0"></span></div><h3 data-q class="cm-s-q"></h3><div class="cm-s-opts" data-opts></div></div>`;
      const $ = (x) => el.querySelector(x);
      $("[data-quit]").addEventListener("click", () => { stop(); toast("Your timer keeps running. Come back soon.", { icon: "⏳" }); home(); });
      timer = setInterval(() => { const sec = (Date.now() - t0) / 1000; $("[data-clock]").textContent = mmss(sec) ; }, 500);
      function show() {
        const q = qs[i];
        $("[data-prog]").textContent = `Question ${i + 1} of ${qs.length}`; $("[data-bar]").style.width = (i / qs.length) * 100 + "%";
        $("[data-q]").textContent = q.q;
        $("[data-opts]").innerHTML = q.options.map((o, k) => `<button type="button" class="cm-btn cm-s-opt" data-o="${k}">${esc(o)}</button>`).join("");
        $("[data-opts]").querySelectorAll("button").forEach((b) => b.addEventListener("click", () => { picks.push({ k: q.k, o: +b.dataset.o }); if (++i < qs.length) show(); else finish(); }));
      }
      async function finish() {
        stop(); $("[data-opts]").innerHTML = `<p class="cm-hint">Marking…</p>`;
        try { const r = await D("/" + id + "/finish", { answers: picks }); result(r, qs, picks); }
        catch (e) { toast(e.message, { icon: "⚠️" }); home(); }
      }
      show();
    }
    function result(r, qs, picks) {
      const d = r.duel, done = d.status === "finished";
      const head = done ? ({ win: "🏆 You won!", loss: "So close. Rematch?", draw: "🤝 It's a draw", none: "Duel finished" }[d.result]) : "Your score is in";
      el.innerHTML = `<div class="cm-card cm-s-result"><h2>${head}</h2>
        <p class="cm-s-score"><strong>${r.score}</strong> / ${r.total} <small>in ${mmss(r.secs)}</small></p>
        ${r.timed_out ? `<p class="cm-hint">This one timed out, so it counts as 0.</p>` : ""}
        ${done ? `<p>${esc(d.opponent.name)} scored <strong>${d.opp_score == null ? "—" : d.opp_score}</strong>${d.opp_secs != null ? ` in ${mmss(d.opp_secs)}` : ""}.</p>` : `<p class="cm-hint">Waiting for ${esc(d.opponent.name)} to play. You'll see the result here when they do. Their score stays hidden until then.</p>`}
        <ol class="cm-s-review">${r.review.map((x) => `<li class="${x.ok ? "ok" : "no"}"><span aria-hidden="true">${x.ok ? "✔" : "✘"}</span> ${esc(qs[x.k].q)}${!x.ok && x.correct != null ? `<small>Answer: ${esc(qs[x.k].options[x.correct])}</small>` : ""}</li>`).join("")}</ol>
        <div class="cm-btns">${done ? `<button type="button" class="cm-btn" data-rematch>Rematch</button>` : ""}<button type="button" class="cm-btn cm-primary" data-home>Back to duels</button></div></div>`;
      el.querySelector("[data-home]").addEventListener("click", home);
      const rm = el.querySelector("[data-rematch]");
      rm && rm.addEventListener("click", async () => { try { await D("/create", { handle: d.opponent.handle, lesson: d.lesson.id }); toast("Rematch sent", { icon: "⚔️" }); home(); } catch (e) { toast(e.message, { icon: "⚠️" }); } });
    }
    home();
  }

  window.CurioSocial = { groups, duels };
})();
