// Curio Lab — Core Tool Pages FX
// Purely additive interaction layer for scoreboard, todo, certificates,
// glossary, exams and play. Never reaches into localStorage schemas or
// overrides page-specific logic — it only observes the DOM those scripts
// already produce and layers motion/feedback on top.
(function () {
  "use strict";

  function ready(fn) {
    if (document.readyState !== "loading") fn();
    else document.addEventListener("DOMContentLoaded", fn);
  }

  /* ---------------- 1. Scroll reveal for static hero/panels ---------------- */
  function initReveal() {
    const targets = document.querySelectorAll(
      ".tool-hero .scoreboard-stats, .building-panel, .cert-panel, .quiz-shell, [data-todo-chart], .empty-state"
    );
    if (!targets.length) return;
    targets.forEach((el) => el.classList.add("cl-reveal"));
    if (!("IntersectionObserver" in window)) {
      targets.forEach((el) => el.classList.add("is-in"));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-in");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    targets.forEach((el) => io.observe(el));
  }

  /* ---------------- 2. Animated count-up for scoreboard stats ---------------- */
  function initCounters() {
    const nums = document.querySelectorAll(
      "[data-stat-lessons], [data-stat-attempts], [data-stat-avg]"
    );
    if (!nums.length || !("MutationObserver" in window)) return;

    nums.forEach((el) => {
      let animating = false;
      const observer = new MutationObserver(() => {
        if (animating) return;
        const raw = el.textContent.trim();
        const match = raw.match(/-?\d+(\.\d+)?/);
        if (!match) return;
        const target = parseFloat(match[0]);
        const suffix = raw.replace(match[0], "");
        if (Number.isNaN(target) || target === 0) return;
        animating = true;
        observer.disconnect();
        const start = performance.now();
        const duration = 700;
        function step(now) {
          const t = Math.min(1, (now - start) / duration);
          const eased = 1 - Math.pow(1 - t, 3);
          const val = Math.round(target * eased * 10) / 10;
          el.textContent = (Number.isInteger(target) ? Math.round(val) : val) + suffix;
          if (t < 1) requestAnimationFrame(step);
          else {
            el.textContent = raw;
            animating = false;
            observer.observe(el, { childList: true, characterData: true, subtree: true });
          }
        }
        requestAnimationFrame(step);
      });
      observer.observe(el, { childList: true, characterData: true, subtree: true });
    });
  }

  /* ---------------- 3. Button ripple ---------------- */
  function initRipple() {
    document.addEventListener("click", (e) => {
      const btn = e.target.closest(".timer-btn, .cmdk-trigger, .back-home");
      if (!btn) return;
      const rect = btn.getBoundingClientRect();
      const ripple = document.createElement("span");
      const size = Math.max(rect.width, rect.height) * 1.2;
      ripple.className = "cl-ripple";
      ripple.style.width = ripple.style.height = size + "px";
      ripple.style.left = e.clientX - rect.left - size / 2 + "px";
      ripple.style.top = e.clientY - rect.top - size / 2 + "px";
      btn.appendChild(ripple);
      ripple.addEventListener("animationend", () => ripple.remove());
    });
  }

  /* ---------------- 4. Confetti burst ---------------- */
  const CONFETTI_COLORS = ["#D68C1F", "#2E8E80", "#C94A38", "#5F7A34", "#12213B"];
  function confettiBurst(x, y, count) {
    count = count || 26;
    for (let i = 0; i < count; i++) {
      const piece = document.createElement("span");
      piece.className = "cl-confetti-piece";
      const angle = Math.random() * Math.PI * 2;
      const dist = 60 + Math.random() * 90;
      piece.style.setProperty("--cl-x", Math.cos(angle) * dist + "px");
      piece.style.setProperty("--cl-r", Math.round(Math.random() * 600 - 300) + "deg");
      piece.style.left = x + "px";
      piece.style.top = y + "px";
      piece.style.background = CONFETTI_COLORS[i % CONFETTI_COLORS.length];
      piece.style.animationDelay = Math.random() * 0.15 + "s";
      document.body.appendChild(piece);
      piece.addEventListener("animationend", () => piece.remove());
    }
  }
  window.CurioCoreFX = window.CurioCoreFX || {};
  window.CurioCoreFX.confetti = confettiBurst;

  /* ---------------- 5. Certificates: confetti on generate/download + newly-earned trophies ---------------- */
  function initCertificates() {
    const grid = document.querySelector("[data-trophy-grid]");
    if (grid) {
      const seenKey = "curiolab-trophies-seen";
      let seen = [];
      try { seen = JSON.parse(localStorage.getItem(seenKey)) || []; } catch (e) { seen = []; }
      const mo = new MutationObserver(() => {
        const earnedNow = Array.from(grid.querySelectorAll(".trophy-card.earned h4")).map((h) => h.textContent.trim());
        const fresh = earnedNow.filter((name) => !seen.includes(name));
        if (fresh.length) {
          const rect = grid.getBoundingClientRect();
          confettiBurst(rect.left + rect.width / 2, rect.top + 40, 34);
        }
        seen = earnedNow;
        try { localStorage.setItem(seenKey, JSON.stringify(seen)); } catch (e) { /* ignore */ }
      });
      mo.observe(grid, { childList: true, subtree: true });
    }

    ["[data-cert-generate]", "[data-cert-download]"].forEach((sel) => {
      document.addEventListener("click", (e) => {
        const btn = e.target.closest(sel);
        if (!btn) return;
        const rect = btn.getBoundingClientRect();
        confettiBurst(rect.left + rect.width / 2, rect.top, 18);
      });
    });
  }

  /* ---------------- 6. To-do: confetti when a subject bar hits 100% ---------------- */
  function initTodoCelebration() {
    const chart = document.querySelector("[data-todo-chart]");
    if (!chart) return;
    let completedSubjects = new Set();
    const mo = new MutationObserver(() => {
      chart.querySelectorAll(".bar-col").forEach((col) => {
        const bar = col.querySelector(".bar");
        const label = col.querySelector(".bar-label");
        if (!bar || !label) return;
        const height = parseFloat(bar.style.height) || 0;
        const key = label.textContent.trim();
        if (height >= 100) {
          if (!completedSubjects.has(key)) {
            completedSubjects.add(key);
            const rect = bar.getBoundingClientRect();
            confettiBurst(rect.left + rect.width / 2, rect.top, 22);
          }
        } else {
          completedSubjects.delete(key);
        }
      });
    });
    mo.observe(chart, { childList: true, subtree: true, attributes: true });
  }

  /* ---------------- 7. Glossary: live result count ---------------- */
  function initGlossaryCount() {
    const grid = document.querySelector("[data-glossary-grid]");
    const search = document.querySelector("[data-glossary-search]");
    if (!grid || !search) return;
    const counter = document.createElement("p");
    counter.className = "cl-glossary-count";
    grid.parentElement.insertBefore(counter, grid);
    function update() {
      const n = grid.querySelectorAll(".term-card").length;
      counter.textContent = n + (n === 1 ? " term" : " terms");
    }
    const mo = new MutationObserver(update);
    mo.observe(grid, { childList: true });
    update();
  }

  /* ---------------- 8. Subtle tilt on trophy/term cards (pointer:fine only) ---------------- */
  function initTilt() {
    if (!window.matchMedia("(pointer: fine)").matches) return;
    document.addEventListener("mousemove", (e) => {
      const card = e.target.closest(".trophy-card, .glossary-grid .term-card");
      if (!card) return;
      const rect = card.getBoundingClientRect();
      const px = (e.clientX - rect.left) / rect.width - 0.5;
      const py = (e.clientY - rect.top) / rect.height - 0.5;
      card.style.transform = `translateY(-4px) rotateX(${(-py * 6).toFixed(2)}deg) rotateY(${(px * 6).toFixed(2)}deg)`;
    });
    document.addEventListener(
      "mouseout",
      (e) => {
        const card = e.target.closest(".trophy-card, .glossary-grid .term-card");
        if (card) card.style.transform = "";
      },
      true
    );
  }

  /* ---------------- 9. Play & Exams: confetti when a round/quiz finishes ---------------- */
  function initFinishCelebration() {
    const watchTargets = [
      document.querySelector("[data-game-win]"),
      document.querySelector("[data-quiz-result]"),
    ].filter(Boolean);
    watchTargets.forEach((el) => {
      const mo = new MutationObserver(() => {
        const visible = window.getComputedStyle(el).display !== "none";
        if (visible) {
          const rect = el.getBoundingClientRect();
          confettiBurst(rect.left + rect.width / 2, rect.top + 30, 28);
        }
      });
      mo.observe(el, { attributes: true, attributeFilter: ["style", "class"] });
    });
  }

  ready(function () {
    initReveal();
    initCounters();
    initRipple();
    initCertificates();
    initTodoCelebration();
    initGlossaryCount();
    initTilt();
    initFinishCelebration();
  });
})();
