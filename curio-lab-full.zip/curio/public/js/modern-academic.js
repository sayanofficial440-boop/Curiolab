(() => {
  const ready = () => requestAnimationFrame(() => document.body.classList.add("curio-ready"));
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", ready, { once: true });
  else ready();

  document.addEventListener("click", (event) => {
    const anchor = event.target.closest("a[href]");
    if (!anchor || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    if (anchor.target === "_blank" || anchor.hasAttribute("download")) return;
    const url = new URL(anchor.href, window.location.href);
    if (url.origin !== window.location.origin || url.protocol === "mailto:" || url.protocol === "tel:") return;
    if (url.pathname === window.location.pathname && url.search === window.location.search) return;
    event.preventDefault();
    document.body.classList.add("curio-leaving");
    window.setTimeout(() => { window.location.href = url.href; }, 150);
  });
})();
