// Curio Lab — 3D Model: forces on a box (Newton's Laws)
// Uses three.js loaded via CDN in the page <head>.
window.onLessonContentReady(() => {
  const container = document.querySelector("[data-model-canvas]");
  if (!container || typeof THREE === "undefined") return;

  const forceSlider = document.querySelector("[data-model-force]");
  const forceLabel = document.querySelector("[data-model-force-label]");

  if (typeof CurioSceneManager === "undefined") {
    console.warn("[threed-forces.js] CurioSceneManager not loaded — add <script src=\".../js/scene-manager.js\"> before this file");
    return;
  }

  const sceneManager = new CurioSceneManager(container, { fov: 45, near: 0.1, far: 100, panelName: "model" });
  const scene = sceneManager.scene;
  const camera = sceneManager.camera;
  const renderer = sceneManager.renderer;
  scene.background = null;
  camera.position.set(4.5, 3.2, 5.5);
  camera.lookAt(0, 0.5, 0);

  // Ground
  const groundGeo = new THREE.PlaneGeometry(10, 10, 10, 10);
  const groundMat = new THREE.MeshBasicMaterial({ color: 0x9aa3b0, wireframe: true, transparent: true, opacity: 0.35 });
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);

  // Box (the object forces act on)
  const boxGeo = new THREE.BoxGeometry(1.3, 1.3, 1.3);
  const boxMat = new THREE.MeshStandardMaterial({ color: 0xd68c1f, roughness: 0.5, metalness: 0.1 });
  const box = new THREE.Mesh(boxGeo, boxMat);
  box.position.y = 0.65;
  scene.add(box);

  const light1 = new THREE.DirectionalLight(0xffffff, 1.1);
  light1.position.set(4, 6, 4);
  scene.add(light1);
  scene.add(new THREE.AmbientLight(0xffffff, 0.55));

  // Arrows: gravity (down, fixed), normal (up, fixed), applied force (adjustable)
  const origin = new THREE.Vector3(0, 0.65, 0);
  const gravityArrow = new THREE.ArrowHelper(new THREE.Vector3(0, -1, 0), origin, 1.1, 0x2e8e80, 0.25, 0.15);
  const normalArrow = new THREE.ArrowHelper(new THREE.Vector3(0, 1, 0), origin, 1.1, 0x12213b, 0.25, 0.15);
  const appliedArrow = new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), origin, 1.2, 0xc94a38, 0.25, 0.15);
  scene.add(gravityArrow, normalArrow, appliedArrow);

  function updateForce(val) {
    const len = 0.4 + (val / 100) * 2.2;
    appliedArrow.setLength(len, 0.25, 0.15);
    if (forceLabel) forceLabel.textContent = `${val} N`;
  }
  updateForce(forceSlider ? parseFloat(forceSlider.value) : 40);
  forceSlider?.addEventListener("input", (e) => updateForce(parseFloat(e.target.value)));

  // Drag-to-rotate (no external OrbitControls dependency)
  let isDragging = false;
  let prevX = 0, prevY = 0;
  let rotY = 0.5, rotX = 0.35;

  function applyRotation() {
    const radius = 7;
    camera.position.x = radius * Math.sin(rotY) * Math.cos(rotX);
    camera.position.z = radius * Math.cos(rotY) * Math.cos(rotX);
    camera.position.y = 2 + radius * Math.sin(rotX);
    camera.lookAt(0, 0.5, 0);
  }
  applyRotation();

  function pointerDown(x, y) { isDragging = true; prevX = x; prevY = y; }
  function pointerMove(x, y) {
    if (!isDragging) return;
    rotY -= (x - prevX) * 0.006;
    rotX = Math.max(-0.4, Math.min(0.9, rotX + (y - prevY) * 0.004));
    prevX = x; prevY = y;
    applyRotation();
  }
  function pointerUp() { isDragging = false; }

  renderer.domElement.addEventListener("mousedown", (e) => pointerDown(e.clientX, e.clientY));
  window.addEventListener("mousemove", (e) => pointerMove(e.clientX, e.clientY));
  window.addEventListener("mouseup", pointerUp);
  renderer.domElement.addEventListener("touchstart", (e) => { const t = e.touches[0]; pointerDown(t.clientX, t.clientY); }, { passive: true });
  renderer.domElement.addEventListener("touchmove", (e) => { const t = e.touches[0]; pointerMove(t.clientX, t.clientY); }, { passive: true });
  renderer.domElement.addEventListener("touchend", pointerUp);

  // Previously rendered every frame unconditionally, even with this tab
  // hidden or the browser backgrounded. sceneManager.start() only calls
  // this (and only renders) while the tab is actually visible.
  sceneManager.start(() => {
    box.rotation.y += isDragging ? 0 : 0.0015;
  });
});
