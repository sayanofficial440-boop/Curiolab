// Curio Lab — History Timeline renderer.
// Reads <script type="application/json" data-htl-data> => { eras:[{id,label,range,color}], events:[{year,sort,era,icon,tag,title,blurb,detail,matters}] }
// and builds: era ribbon (filter), year scrubber, and an alternating spine of expandable cards.
window.onLessonContentReady(() => {
  const root = document.querySelector("[data-htl]");
  const dataEl = document.querySelector("[data-htl-data]");
  if (!root || !dataEl) return;

  let data;
  try { data = JSON.parse(dataEl.textContent); } catch (e) { return; }
  const eras = data.eras, events = data.events.slice().sort((a, b) => a.sort - b.sort);
  const eraById = Object.fromEntries(eras.map((e) => [e.id, e]));
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  // Era ribbon width is proportional to the number of events it holds (readable, not literal years)
  const counts = {};
  events.forEach((ev) => (counts[ev.era] = (counts[ev.era] || 0) + 1));

  root.innerHTML = `
    <div class="htl-ribbon" role="tablist" aria-label="Filter by era">
      ${eras.map((e) => `<button type="button" class="htl-era active" role="tab" data-era="${e.id}" style="--era:${e.color};--span:${Math.max(counts[e.id] || 1, 2)}"><strong>${esc(e.label)}</strong><span>${esc(e.range)}</span></button>`).join("")}
    </div>
    <div class="htl-bar">
      <div class="htl-scrub">
        <div class="htl-scrub-label"><span>Scrub through time</span><b data-htl-now>—</b></div>
        <input class="htl-range" type="range" min="0" max="${events.length - 1}" value="0" step="1" aria-label="Scrub through the timeline" data-htl-range />
      </div>
      <div class="htl-actions">
        <button type="button" class="htl-btn" data-htl-all>Expand all</button>
        <button type="button" class="htl-btn" data-htl-reset>Show all eras</button>
      </div>
    </div>
    <p class="htl-count" data-htl-count></p>
    <ol class="htl-spine" data-htl-spine><div class="htl-progress" data-htl-progress></div></ol>`;

  const spine = root.querySelector("[data-htl-spine]");
  const progress = root.querySelector("[data-htl-progress]");
  const range = root.querySelector("[data-htl-range]");
  const now = root.querySelector("[data-htl-now]");
  const countEl = root.querySelector("[data-htl-count]");

  // Build spine, inserting an era divider before the first event of each era
  let lastEra = null;
  const items = [];
  events.forEach((ev, i) => {
    const era = eraById[ev.era];
    if (ev.era !== lastEra) {
      const d = document.createElement("li");
      d.className = "htl-divider"; d.dataset.era = ev.era; d.style.setProperty("--era", era.color);
      d.innerHTML = `<span>${esc(era.label)} · ${esc(era.range)}</span>`;
      spine.appendChild(d); lastEra = ev.era;
    }
    const li = document.createElement("li");
    li.className = "htl-item" + (i % 2 ? " r" : ""); li.dataset.era = ev.era; li.dataset.idx = i; li.style.setProperty("--era", era.color);
    li.innerHTML = `
      <span class="htl-node" role="button" tabindex="0" aria-label="Open ${esc(ev.title)}">${ev.icon || "•"}</span>
      <button type="button" class="htl-card" aria-expanded="false">
        <span class="htl-chev" aria-hidden="true">▼</span>
        <span class="htl-year">${esc(ev.year)}</span><span class="htl-tag">${esc(ev.tag || era.label)}</span>
        <h4>${esc(ev.title)}</h4>
        <p>${esc(ev.blurb)}</p>
        <span class="htl-more"><span>
          <p class="htl-detail">${esc(ev.detail)}</p>
          <span class="htl-matters" style="display:block"><b>Why it mattered</b>${esc(ev.matters)}</span>
        </span></span>
      </button>`;
    spine.appendChild(li); items.push(li);
  });

  // Reveal on scroll
  if ("IntersectionObserver" in window) {
    const io = new IntersectionObserver((entries) => entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); } }), { threshold: 0.12 });
    items.forEach((li) => io.observe(li));
  } else items.forEach((li) => li.classList.add("in"));

  function visibleItems() { return items.filter((li) => !li.classList.contains("hidden")); }

  function setCurrent(li, scroll) {
    items.forEach((x) => x.classList.remove("current"));
    if (!li) return;
    li.classList.add("current");
    const ev = events[+li.dataset.idx];
    now.textContent = `${ev.year} — ${ev.title}`;
    spine.style.setProperty("--cur", eraById[ev.era].color);
    const sr = spine.getBoundingClientRect(), lr = li.getBoundingClientRect();
    progress.style.height = Math.max(0, lr.top - sr.top + 30) + "px";
    const vis = visibleItems();
    range.value = +li.dataset.idx;
    if (scroll) li.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "center" });
    li.classList.add("in");
  }

  function toggle(li) {
    const open = !li.classList.contains("open");
    li.classList.toggle("open", open);
    li.querySelector(".htl-card").setAttribute("aria-expanded", open);
    if (window.CurioSound) window.CurioSound.play(open ? "open" : "click");
    setCurrent(li, false);
    if (open) setTimeout(() => setCurrent(li, false), 450);
  }

  spine.addEventListener("click", (e) => {
    const li = e.target.closest(".htl-item"); if (li) toggle(li);
  });
  spine.addEventListener("keydown", (e) => {
    if ((e.key === "Enter" || e.key === " ") && e.target.classList.contains("htl-node")) { e.preventDefault(); toggle(e.target.closest(".htl-item")); }
  });

  // Scrubber: jump to the nearest visible event
  range.addEventListener("input", () => {
    const target = +range.value;
    const vis = visibleItems(); if (!vis.length) return;
    const li = vis.reduce((best, x) => (Math.abs(+x.dataset.idx - target) < Math.abs(+best.dataset.idx - target) ? x : best), vis[0]);
    setCurrent(li, true);
  });

  // Era filter (click an era to isolate it; click again to show all)
  let activeEra = null;
  function applyFilter() {
    root.querySelectorAll(".htl-era").forEach((b) => b.classList.toggle("active", !activeEra || b.dataset.era === activeEra));
    spine.querySelectorAll("[data-era]").forEach((n) => n.classList.toggle("hidden", !!activeEra && n.dataset.era !== activeEra));
    const vis = visibleItems();
    countEl.textContent = `${vis.length} of ${items.length} events shown`;
    vis.forEach((li) => li.classList.add("in"));
    setCurrent(vis[0] || null, false);
    requestAnimationFrame(() => setCurrent(vis[0] || null, false));
  }
  root.querySelectorAll(".htl-era").forEach((b) => b.addEventListener("click", () => { activeEra = activeEra === b.dataset.era ? null : b.dataset.era; applyFilter(); }));
  root.querySelector("[data-htl-reset]").addEventListener("click", () => { activeEra = null; applyFilter(); });
  root.querySelector("[data-htl-all]").addEventListener("click", (e) => {
    const vis = visibleItems(); const openAll = vis.some((li) => !li.classList.contains("open"));
    vis.forEach((li) => { li.classList.toggle("open", openAll); li.classList.add("in"); });
    e.target.textContent = openAll ? "Collapse all" : "Expand all";
  });

  // Keep the progress line correct when the panel becomes visible or the window resizes
  const refresh = () => { const c = spine.querySelector(".htl-item.current"); if (c) setCurrent(c, false); };
  window.addEventListener("resize", refresh);
  document.querySelectorAll(".mode-tab").forEach((t) => t.addEventListener("click", () => setTimeout(refresh, 60)));
  applyFilter();
});
