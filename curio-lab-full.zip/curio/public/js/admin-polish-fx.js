// Curio Lab — Admin Panel Polish FX
// Purely additive: never touches admin.js's data fetching/rendering logic,
// only observes the DOM it produces and layers motion/feedback on top.
(function () {
  "use strict";

  function ready(fn) {
    if (document.readyState !== "loading") fn();
    else document.addEventListener("DOMContentLoaded", fn);
  }

  /* ---------------- 1. Ripple on buttons ---------------- */
  function initRipple() {
    document.addEventListener("click", (e) => {
      const btn = e.target.closest(".toggle-btn, .cmdk-trigger, .admin-logout-btn, .auth-submit");
      if (!btn || btn.disabled) return;
      const rect = btn.getBoundingClientRect();
      const ripple = document.createElement("span");
      const size = Math.max(rect.width, rect.height) * 1.2;
      ripple.className = "cl-ripple";
      ripple.style.width = ripple.style.height = size + "px";
      ripple.style.left = e.clientX - rect.left - size / 2 + "px";
      ripple.style.top = e.clientY - rect.top - size / 2 + "px";
      btn.appendChild(ripple);
      ripple.addEventListener("animationend", () => ripple.remove());
    });
  }

  /* ---------------- 2. Refresh button spin (dashboard) ---------------- */
  function initRefreshSpin() {
    const btn = document.getElementById("refresh-btn");
    if (!btn) return;
    btn.addEventListener("click", () => {
      btn.classList.add("is-spinning");
      window.setTimeout(() => btn.classList.remove("is-spinning"), 700);
    });
  }

  /* ---------------- 3. Count-up for stat-value cells once populated ---------------- */
  function initStatCounters() {
    const cells = document.querySelectorAll(".stat-value");
    if (!cells.length || !("MutationObserver" in window)) return;
    cells.forEach((el) => {
      let animating = false;
      const observer = new MutationObserver(() => {
        if (animating) return;
        const raw = el.textContent.trim();
        const match = raw.match(/-?\d+(\.\d+)?/);
        if (!match || raw === "—") return;
        const target = parseFloat(match[0]);
        if (Number.isNaN(target)) return;
        const prefix = raw.slice(0, match.index);
        const suffix = raw.slice(match.index + match[0].length);
        animating = true;
        observer.disconnect();
        const start = performance.now();
        const duration = 600;
        function step(now) {
          const t = Math.min(1, (now - start) / duration);
          const eased = 1 - Math.pow(1 - t, 3);
          const val = Math.round(target * eased);
          el.textContent = prefix + val + suffix;
          if (t < 1) requestAnimationFrame(step);
          else {
            el.textContent = raw;
            animating = false;
            observer.observe(el, { childList: true, characterData: true, subtree: true });
          }
        }
        requestAnimationFrame(step);
      });
      observer.observe(el, { childList: true, characterData: true, subtree: true });
    });
  }

  ready(function () {
    initRipple();
    initRefreshSpin();
    initStatCounters();
  });
})();
