// Curio Lab — Sound Effects & Ambient Bed (Web Audio API, no external files)
//
// Fixes three real bugs in the previous version:
//   1. Hover sounds used a delegated "mouseover" listener, which re-bubbles
//      for every nested child element as the pointer moves across a button's
//      icon/text/etc — so hovering one element could fire SFX.hover() a
//      dozen times in quick succession, stacking oscillators and audibly
//      crackling. Fixed by tracking the last-hovered matched element and
//      only firing on genuine entry/exit (mirrors what mouseenter/mouseleave
//      would do, but delegated).
//   2. ctx.resume() is async and browsers reject it if called before any
//      user gesture (autoplay policy) — the previous version never caught
//      that rejection, so opening a page could throw an unhandled promise
//      rejection in the console before the user had clicked anything.
//   3. Every tone() connected straight to destination with no shared gain
//      stage, so several overlapping cues (e.g. a mini-game's success chord
//      firing while a hover click is still ringing) could sum past 0dBFS and
//      clip/pop. Fixed with a shared bus through a DynamicsCompressorNode.
//
// Also adds what was missing entirely: a synthesized ambient background bed
// (CurioSound.ambient) for study sessions, and new cues (matchCorrect,
// matchIncorrect, navigate, compileSuccess/compileError — the last two now
// wired into js/code-playground.js's run results).
(function () {
  const STORAGE_KEY = "curiolab-sound";
  const AMBIENT_KEY = "curiolab-ambient";
  let ctx = null;
  let unlocked = false;
  let masterBus = null;   // DynamicsCompressorNode -> destination
  let sfxGain = null;     // one-shot SFX route into masterBus
  let ambientGain = null; // ambient bed route into masterBus

  function getPref() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === "on") return true;
    if (saved === "off") return false;
    // default: on, but off for users who prefer reduced motion (often correlates with sensory sensitivity)
    return !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }

  let enabled = getPref();

  function buildGraph(c) {
    masterBus = c.createDynamicsCompressor();
    masterBus.threshold.setValueAtTime(-18, c.currentTime);
    masterBus.knee.setValueAtTime(24, c.currentTime);
    masterBus.ratio.setValueAtTime(4, c.currentTime);
    masterBus.attack.setValueAtTime(0.003, c.currentTime);
    masterBus.release.setValueAtTime(0.25, c.currentTime);
    masterBus.connect(c.destination);

    sfxGain = c.createGain();
    sfxGain.gain.setValueAtTime(1, c.currentTime);
    sfxGain.connect(masterBus);

    ambientGain = c.createGain();
    ambientGain.gain.setValueAtTime(0, c.currentTime); // starts silent, ramped in by ambient.start()
    ambientGain.connect(masterBus);
  }

  function ensureCtx() {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
      buildGraph(ctx);
    }
    if (ctx.state === "suspended") {
      // Autoplay policy rejects resume() before a user gesture — that's
      // expected, not an error, so swallow it rather than let it surface as
      // an unhandled rejection in the console.
      ctx.resume().catch(() => {});
    }
    return ctx;
  }

  function tone({ freq = 440, duration = 0.08, type = "sine", gain = 0.05, glideTo = null, delay = 0 }) {
    if (!enabled) return;
    const c = ensureCtx();
    if (!c || !sfxGain) return;
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = type;
    const t0 = c.currentTime + delay;
    osc.frequency.setValueAtTime(freq, t0);
    if (glideTo) osc.frequency.exponentialRampToValueAtTime(glideTo, t0 + duration);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
    osc.connect(g).connect(sfxGain);
    osc.start(t0);
    osc.stop(t0 + duration + 0.02);
    // Explicit cleanup once playback ends — Web Audio keeps a playing node
    // alive on its own, but disconnecting promptly after stop keeps the
    // graph from accumulating references during a long study session with
    // hundreds of clicks.
    osc.onended = () => { try { osc.disconnect(); g.disconnect(); } catch (e) { /* already gone */ } };
  }

  const SFX = {
    click: () => tone({ freq: 620, duration: 0.06, type: "sine", gain: 0.045 }),
    hover: () => tone({ freq: 880, duration: 0.035, type: "sine", gain: 0.018 }),
    toggle: () => tone({ freq: 520, duration: 0.07, type: "triangle", gain: 0.04, glideTo: 720 }),
    success: () => {
      tone({ freq: 523.25, duration: 0.11, type: "sine", gain: 0.05 });
      tone({ freq: 659.25, duration: 0.14, type: "sine", gain: 0.05, delay: 0.09 });
      tone({ freq: 783.99, duration: 0.2, type: "sine", gain: 0.05, delay: 0.18 });
    },
    error: () => {
      tone({ freq: 220, duration: 0.14, type: "sawtooth", gain: 0.035 });
      tone({ freq: 165, duration: 0.18, type: "sawtooth", gain: 0.035, delay: 0.08 });
    },
    flip: () => tone({ freq: 340, duration: 0.05, type: "triangle", gain: 0.03, glideTo: 460 }),
    open: () => tone({ freq: 440, duration: 0.09, type: "sine", gain: 0.035, glideTo: 660 }),
    close: () => tone({ freq: 660, duration: 0.08, type: "sine", gain: 0.03, glideTo: 420 }),
    // Distinct from the generic success/error chords — short and bright so
    // rapid-fire card matching doesn't feel like it's replaying a whole jingle.
    matchCorrect: () => {
      tone({ freq: 660, duration: 0.07, type: "sine", gain: 0.045 });
      tone({ freq: 990, duration: 0.09, type: "sine", gain: 0.04, delay: 0.05 });
    },
    matchIncorrect: () => tone({ freq: 180, duration: 0.09, type: "square", gain: 0.03 }),
    // Soft, low-gain tick for list/menu navigation (arrow keys in the command
    // palette, moving through side-rail items) — meant to be heard dozens of
    // times in a row without fatigue, so it's much quieter than click.
    navigate: () => tone({ freq: 760, duration: 0.025, type: "sine", gain: 0.014 }),
    // Wired to js/code-playground.js's run results.
    compileSuccess: () => {
      tone({ freq: 392, duration: 0.09, type: "sine", gain: 0.045 });
      tone({ freq: 523.25, duration: 0.12, type: "sine", gain: 0.045, delay: 0.07 });
      tone({ freq: 659.25, duration: 0.16, type: "sine", gain: 0.045, delay: 0.14 });
    },
    compileError: () => {
      tone({ freq: 200, duration: 0.1, type: "sawtooth", gain: 0.035 });
      tone({ freq: 140, duration: 0.16, type: "sawtooth", gain: 0.035, delay: 0.09 });
    },
  };

  // --- Ambient background bed --------------------------------------------
  // Fully synthesized (no audio files): two detuned low oscillators through
  // a lowpass filter whose cutoff is slowly modulated by an LFO, giving a
  // soft "breathing" pad. Runs continuously once started rather than
  // looping a buffer — nothing to loop, no seam to click at.
  let ambientNodes = null; // { oscA, oscB, lfo, filter } while playing
  let ambientTargetVolume = 0.05;
  let ambientWasHiddenPause = false;

  function ambientIsPlaying() { return !!ambientNodes; }

  function startAmbient(volume) {
    if (!enabled || ambientIsPlaying()) return;
    const c = ensureCtx();
    if (!c || !ambientGain) return;
    ambientTargetVolume = typeof volume === "number" ? volume : ambientTargetVolume;

    const filter = c.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(500, c.currentTime);
    filter.Q.setValueAtTime(0.7, c.currentTime);

    const oscA = c.createOscillator();
    oscA.type = "sine";
    oscA.frequency.setValueAtTime(110, c.currentTime);
    const oscB = c.createOscillator();
    oscB.type = "triangle";
    oscB.frequency.setValueAtTime(165.5, c.currentTime); // slightly detuned fifth, not a pure ratio, so it doesn't phase-cancel into silence

    const lfo = c.createOscillator();
    lfo.type = "sine";
    lfo.frequency.setValueAtTime(0.06, c.currentTime); // ~16s slow sweep
    const lfoGain = c.createGain();
    lfoGain.gain.setValueAtTime(220, c.currentTime); // sweeps filter cutoff 280Hz..720Hz
    lfo.connect(lfoGain).connect(filter.frequency);

    oscA.connect(filter);
    oscB.connect(filter);
    filter.connect(ambientGain);

    ambientGain.gain.cancelScheduledValues(c.currentTime);
    ambientGain.gain.setValueAtTime(ambientGain.gain.value, c.currentTime);
    ambientGain.gain.linearRampToValueAtTime(ambientTargetVolume, c.currentTime + 1.5); // fade in, no pop

    oscA.start();
    oscB.start();
    lfo.start();

    ambientNodes = { oscA, oscB, lfo, filter, lfoGain };
    localStorage.setItem(AMBIENT_KEY, "on");
  }

  function stopAmbient({ persistPref = true } = {}) {
    if (!ambientIsPlaying()) return;
    const c = ctx;
    const nodes = ambientNodes;
    ambientNodes = null; // mark stopped immediately so re-entrant calls no-op
    if (persistPref) localStorage.setItem(AMBIENT_KEY, "off");

    if (c && ambientGain) {
      ambientGain.gain.cancelScheduledValues(c.currentTime);
      ambientGain.gain.setValueAtTime(ambientGain.gain.value, c.currentTime);
      ambientGain.gain.linearRampToValueAtTime(0, c.currentTime + 0.8); // fade out, no pop
    }
    const stopAt = c ? c.currentTime + 0.85 : 0;
    [nodes.oscA, nodes.oscB, nodes.lfo].forEach((osc) => {
      try { osc.stop(stopAt); } catch (e) { /* already stopped */ }
      osc.onended = () => { try { osc.disconnect(); } catch (e2) { /* already gone */ } };
    });
    setTimeout(() => { try { nodes.filter.disconnect(); nodes.lfoGain.disconnect(); } catch (e) { /* already gone */ } }, 900);
  }

  function setAmbientVolume(v) {
    ambientTargetVolume = Math.max(0, Math.min(0.15, v)); // hard ceiling — this is a background bed, never louder than the SFX it sits under
    if (ambientIsPlaying() && ctx && ambientGain) {
      ambientGain.gain.cancelScheduledValues(ctx.currentTime);
      ambientGain.gain.linearRampToValueAtTime(ambientTargetVolume, ctx.currentTime + 0.3);
    }
  }

  // Pause (not stop) while the tab is hidden, so nothing plays silently in a
  // background tab, and resume automatically when the user comes back —
  // avoids both wasted CPU and the "wait, is my study music still going?"
  // surprise.
  document.addEventListener("visibilitychange", () => {
    if (!ambientIsPlaying() || !ctx || !ambientGain) return;
    if (document.hidden) {
      ambientWasHiddenPause = true;
      ambientGain.gain.cancelScheduledValues(ctx.currentTime);
      ambientGain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.3);
    } else if (ambientWasHiddenPause) {
      ambientWasHiddenPause = false;
      ambientGain.gain.cancelScheduledValues(ctx.currentTime);
      ambientGain.gain.linearRampToValueAtTime(ambientTargetVolume, ctx.currentTime + 0.6);
    }
  });

  window.CurioSound = {
    play: (name) => { if (SFX[name]) SFX[name](); },
    isEnabled: () => enabled,
    setEnabled: (val) => {
      enabled = val;
      localStorage.setItem(STORAGE_KEY, val ? "on" : "off");
      document.querySelectorAll("[data-sound-toggle]").forEach((btn) => {
        btn.setAttribute("aria-pressed", String(val));
        btn.classList.toggle("is-muted", !val);
      });
      document.querySelectorAll("[data-ambient-toggle]").forEach((btn) => { btn.disabled = !val; });
      if (!val) stopAmbient({ persistPref: false }); // mute kills the ambient bed too, without forgetting the user wanted it on
      else if (localStorage.getItem(AMBIENT_KEY) === "on") startAmbient();
    },
    ambient: {
      start: (volume) => startAmbient(volume),
      stop: () => stopAmbient(),
      isPlaying: ambientIsPlaying,
      setVolume: setAmbientVolume,
    },
  };

  function unlock() {
    if (unlocked) return;
    unlocked = true;
    ensureCtx();
    if (localStorage.getItem(AMBIENT_KEY) === "on") startAmbient();
  }
  ["pointerdown", "keydown"].forEach((evt) => document.addEventListener(evt, unlock, { once: true, passive: true }));

  document.addEventListener("DOMContentLoaded", () => {
    // Delegate light click sounds to common interactive elements, skip anything opting out.
    document.addEventListener("click", (e) => {
      const el = e.target.closest("button, a.logo, .mode-tab, .timer-btn, .theme-toggle, .game-tile, .spec-card, [data-sfx]");
      if (!el || el.closest("[data-no-sfx]")) return;
      if (el.matches("[data-sound-toggle]")) { SFX.toggle(); return; }
      SFX.click();
    });

    // Hover sounds, fixed: track the last matched element and only fire on
    // genuine entry, not on every bubbled mouseover from a child element.
    let lastHoverEl = null;
    document.addEventListener(
      "mouseover",
      (e) => {
        const el = e.target.closest(".mode-tab, .subject-card, .spec-card, .game-tile:not(.matched)");
        if (!el || el.closest("[data-no-sfx]")) return;
        if (el === lastHoverEl) return; // already hovering this one — a child fired the bubble, not a real re-entry
        lastHoverEl = el;
        SFX.hover();
      },
      { passive: true }
    );
    document.addEventListener(
      "mouseout",
      (e) => {
        if (lastHoverEl && (!e.relatedTarget || !lastHoverEl.contains(e.relatedTarget))) {
          lastHoverEl = null;
        }
      },
      { passive: true }
    );

    // Inject a small mute/unmute control into the header if a hook exists
    document.querySelectorAll("[data-sound-toggle]").forEach((btn) => {
      btn.setAttribute("aria-pressed", String(enabled));
      btn.classList.toggle("is-muted", !enabled);
      btn.addEventListener("click", () => window.CurioSound.setEnabled(!window.CurioSound.isEnabled()));

      // (Ambient headphone button removed — replaced by the language switcher in js/i18n.js)
    });
  });
})();
