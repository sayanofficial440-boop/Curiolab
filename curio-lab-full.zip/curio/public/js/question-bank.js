// Curio Lab — Question Bank: every hand-written quiz question, filterable by subject,
// topic (lesson) and difficulty. Data comes from js/bank/bank-exams.js (built by
// scripts/sync-learning.mjs, difficulty tags included). Wrong answers go to the Mistake Notebook.
(function () {
  "use strict";
  const BANK = window.CURIO_BANK && window.CURIO_BANK.exams;
  const host = document.querySelector("[data-qb]");
  if (!BANK || !host) return;
  const LV = { 1: "Easy", 2: "Medium", 3: "Hard" };
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const all = BANK.q.map((q, i) => ({ ...q, id: i, d: q.d === 1 || q.d === 3 ? q.d : 2 }));
  const subjects = [...new Set(all.map((q) => q.subject))];
  const PAGE = 10;

  const qs = new URLSearchParams(location.search);
  const st = { subject: qs.get("subject") || "", topic: qs.get("topic") || "", d: qs.get("d") || "", q: "", shown: PAGE, order: [] };
  if (!subjects.includes(st.subject)) st.subject = "";
  if (!["1", "2", "3"].includes(st.d)) st.d = "";
  const answered = new Map(); // id -> picked index

  const style = document.createElement("style");
  style.textContent = `
  .qb-row{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 10px}
  .qb-row label{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;opacity:.75;min-width:64px}
  .qb-sel{flex:1;min-width:150px;max-width:340px;padding:9px 10px;border-radius:10px;border:1px solid var(--line,#d9d4ee);background:var(--panel,transparent);color:inherit;font:inherit}
  .qb-card{border:1px solid var(--line,#e5e1f4);border-radius:14px;padding:14px 16px;margin:0 0 12px;text-align:left;background:var(--panel,transparent)}
  .qb-meta{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px;font-size:12px}
  .qb-chip{padding:2px 9px;border-radius:99px;border:1px solid var(--line,#d9d4ee);opacity:.9}
  .qb-chip.d1{border-color:#177d75;color:#177d75}.qb-chip.d2{border-color:#a8680f;color:#a8680f}.qb-chip.d3{border-color:#b3372d;color:#b3372d}
  .qb-q{font-weight:600;margin:0 0 10px;font-size:15px}
  .qb-opts{display:grid;gap:8px}
  .qb-opt{text-align:left;padding:10px 12px;border-radius:10px;border:1px solid var(--line,#d9d4ee);background:transparent;color:inherit;font:inherit;cursor:pointer}
  .qb-opt:hover:not(:disabled){border-color:var(--accent,#6547da)}
  .qb-opt:focus-visible,.qb-more:focus-visible,.qb-shuffle:focus-visible{outline:2px solid var(--accent,#6547da);outline-offset:2px}
  .qb-opt.ok{border-color:#177d75;background:rgba(23,125,117,.14)} .qb-opt.no{border-color:#b3372d;background:rgba(179,55,45,.14)}
  .qb-opt:disabled{cursor:default;color:inherit;opacity:1}
  .qb-more,.qb-shuffle{padding:10px 18px;border-radius:10px;border:1px solid var(--accent,#6547da);background:transparent;color:inherit;font:inherit;font-weight:700;cursor:pointer}
  .qb-tools{display:flex;gap:10px;flex-wrap:wrap;align-items:center;justify-content:space-between;margin:6px 0 14px}`;
  document.head.appendChild(style);

  const topicsFor = (subject) => [...new Set(all.filter((q) => !subject || q.subject === subject).map((q) => q.lesson))].sort();
  if (st.topic && !topicsFor(st.subject).includes(st.topic)) st.topic = "";

  function filtered() {
    const t = st.q.toLowerCase();
    const list = all.filter((q) => (!st.subject || q.subject === st.subject) && (!st.topic || q.lesson === st.topic) &&
      (!st.d || q.d === Number(st.d)) && (!t || q.q.toLowerCase().includes(t) || q.options.some((o) => o.toLowerCase().includes(t))));
    if (!st.order.length) return list;
    const rank = new Map(st.order.map((id, i) => [id, i]));
    return list.slice().sort((a, b) => (rank.get(a.id) ?? 0) - (rank.get(b.id) ?? 0));
  }

  function url() {
    const q = new URLSearchParams();
    ["subject", "topic", "d"].forEach((k) => st[k] && q.set(k, st[k]));
    try { history.replaceState(null, "", location.pathname + (q.toString() ? "?" + q : "")); } catch (e) { /* ignore */ }
  }

  function record(q, picked) {
    const R = window.CurioReview; if (!R) return;
    try {
      if (picked !== q.correct) R.addMistake({ q: q.q, lesson: q.lesson, subject: q.subject, href: location.pathname, options: q.options, correct: q.options[q.correct], picked: q.options[picked] });
      else { const hit = R.due().find((x) => x.id === R.idFor(q.lesson, q.q)); if (hit) R.grade(hit.id, 4); }
    } catch (e) { /* review is best-effort */ }
  }

  function card(q) {
    const picked = answered.get(q.id), done = picked !== undefined;
    return `<article class="qb-card" data-id="${q.id}"><div class="qb-meta"><span class="qb-chip d${q.d}">${LV[q.d]}</span><span class="qb-chip">${esc(q.subject)}</span><span class="qb-chip">${esc(q.lesson)}</span></div>
      <p class="qb-q">${esc(q.q)}</p><div class="qb-opts">${q.options.map((o, i) =>
        `<button type="button" class="qb-opt${done && i === q.correct ? " ok" : ""}${done && i === picked && i !== q.correct ? " no" : ""}" data-i="${i}"${done ? " disabled" : ""}>${esc(o)}</button>`).join("")}</div></article>`;
  }

  function render() {
    const list = filtered(), topics = topicsFor(st.subject);
    const sel = (id, label, opts, val) => `<div class="qb-row"><label for="${id}">${label}</label><select class="qb-sel" id="${id}"><option value="">All</option>${opts.map((o) => `<option value="${esc(o[0])}"${String(o[0]) === String(val) ? " selected" : ""}>${esc(o[1])}</option>`).join("")}</select></div>`;
    host.innerHTML = `<div class="gf-bar" role="region" aria-label="Filter questions">
        <div class="qb-row"><label for="qb-s">Search</label><input class="gf-search qb-sel" id="qb-s" type="search" placeholder="Search questions…" value="${esc(st.q)}" autocomplete="off"></div>
        ${sel("qb-sub", "Subject", subjects.map((s) => [s, s]), st.subject)}
        ${sel("qb-top", "Topic", topics.map((t) => [t, t]), st.topic)}
        <div class="gf-row"><span class="gf-label">Difficulty</span><div class="gf-pills" role="group" aria-label="Difficulty">${[["", "All"], ["1", "Easy"], ["2", "Medium"], ["3", "Hard"]].map((x) => `<button type="button" class="gf-pill" data-d="${x[0]}" aria-pressed="${st.d === x[0]}">${x[1]}</button>`).join("")}</div></div>
        <div class="gf-foot"><span class="gf-count" aria-live="polite">${list.length} of ${all.length} questions</span>${st.subject || st.topic || st.d || st.q ? '<button type="button" class="gf-reset" data-reset>Clear filters</button>' : ""}</div></div>
      <div class="qb-tools"><button type="button" class="qb-shuffle">🔀 Shuffle</button></div>
      <div data-list>${list.slice(0, st.shown).map(card).join("") || '<div class="gf-empty">No questions match these filters — try a different topic or difficulty.</div>'}</div>
      ${list.length > st.shown ? `<p style="text-align:center"><button type="button" class="qb-more">Show ${Math.min(PAGE, list.length - st.shown)} more</button></p>` : ""}`;
    bind(list); url();
  }

  function bind(list) {
    const $ = (s) => host.querySelector(s);
    const reset = () => { st.shown = PAGE; render(); };
    $("#qb-s").addEventListener("input", (e) => { st.q = e.target.value.trim(); st.shown = PAGE; const pos = e.target.selectionStart; render(); const n = $("#qb-s"); n.focus(); n.setSelectionRange(pos, pos); });
    $("#qb-sub").addEventListener("change", (e) => { st.subject = e.target.value; st.topic = ""; reset(); });
    $("#qb-top").addEventListener("change", (e) => { st.topic = e.target.value; reset(); });
    host.querySelectorAll("[data-d]").forEach((b) => b.addEventListener("click", () => { st.d = b.dataset.d; reset(); }));
    const r = $("[data-reset]"); if (r) r.addEventListener("click", () => { st.subject = st.topic = st.d = st.q = ""; reset(); });
    $(".qb-shuffle").addEventListener("click", () => { st.order = all.map((q) => q.id).sort(() => Math.random() - 0.5); reset(); });
    const more = $(".qb-more"); if (more) more.addEventListener("click", () => { st.shown += PAGE; render(); });
    host.querySelectorAll(".qb-card").forEach((c) => c.addEventListener("click", (e) => {
      const b = e.target.closest(".qb-opt"); if (!b || b.disabled) return;
      const q = all[Number(c.dataset.id)], i = Number(b.dataset.i);
      answered.set(q.id, i); record(q, i);
      c.querySelectorAll(".qb-opt").forEach((o, k) => { o.disabled = true; if (k === q.correct) o.classList.add("ok"); else if (k === i) o.classList.add("no"); });
    }));
  }
  render();
})();
