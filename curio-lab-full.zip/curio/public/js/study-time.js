// Curio Lab — study-time tracker. Counts seconds the learner is actually on a study
// page (tab visible and recent interaction), per day and per subject, on this device.
(function () {
  "use strict";
  if (window.CurioTime) return;
  const PREFIX = "curiolab-time-v1:", SESSION = "curiolab-local-session";
  const KEEP_DAYS = 400, IDLE_MS = 90000, TICK = 5;
  const safe = (v, f) => { try { const x = JSON.parse(v); return x == null ? f : x; } catch (_) { return f; } };
  const acct = () => { const u = safe(localStorage.getItem(SESSION), null); return u && u.id ? "id:" + u.id : u && u.email ? "email:" + String(u.email).toLowerCase() : "guest"; };
  const key = () => PREFIX + acct();
  const dayKey = (d) => { d = new Date(d); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };
  const load = () => { const d = safe(localStorage.getItem(key()), {}); return d && typeof d === "object" ? d : {}; };

  const SUBJECTS = { physics: "Physics", chemistry: "Chemistry", biology: "Biology", english: "English", mathematics: "Mathematics", history: "History", geography: "Geography", "computer-science": "Computer Science" };
  const m = location.pathname.match(/\/pages\/([^/]+)\//);
  const subject = (m && SUBJECTS[m[1]]) || "Other";

  let pending = 0, lastActive = Date.now(), lastFlush = Date.now();
  ["pointerdown", "keydown", "scroll", "touchstart", "mousemove"].forEach((ev) => window.addEventListener(ev, () => { lastActive = Date.now(); }, { passive: true }));

  function flush() {
    if (pending <= 0) return;
    const data = load(), k = dayKey(Date.now());
    const day = data[k] || { total: 0, subjects: {} };
    day.total += pending; day.subjects[subject] = (day.subjects[subject] || 0) + pending;
    data[k] = day; pending = 0; lastFlush = Date.now();
    const keys = Object.keys(data).sort(); while (keys.length > KEEP_DAYS) delete data[keys.shift()];
    try { localStorage.setItem(key(), JSON.stringify(data)); } catch (_) { /* full or blocked */ }
    window.dispatchEvent(new CustomEvent("curio-time-updated"));
  }
  setInterval(() => {
    if (document.visibilityState !== "visible" || Date.now() - lastActive > IDLE_MS) return;
    pending += TICK;
    if (Date.now() - lastFlush > 30000) flush();
  }, TICK * 1000);
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") flush(); });
  window.addEventListener("pagehide", flush);

  // seconds per day for the last n days (oldest first)
  function series(n) {
    const data = load(), out = [];
    for (let i = n - 1; i >= 0; i--) { const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() - i); const v = data[dayKey(d)]; out.push({ date: d, secs: v ? v.total : 0, subjects: v ? v.subjects : {} }); }
    return out;
  }
  window.CurioTime = { series, today: () => { const v = load()[dayKey(Date.now())]; return (v ? v.total : 0) + pending; }, flush, dayKey };
})();
