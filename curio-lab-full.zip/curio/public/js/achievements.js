// Curio Lab — Certificates & Trophies
// Reads the same localStorage scores the scoreboard uses, computes earned trophies,
// and can render a downloadable certificate onto a canvas.

window.CurioAchievements = (function () {
  function getScores() {
    try { return JSON.parse(localStorage.getItem("curiolab-scores")) || []; } catch (e) { return []; }
  }

  // Exam Center results (written by js/exam-store.js) — a small device-wide log.
  function getExams() {
    try { const l = JSON.parse(localStorage.getItem("curiolab-exam-log")); return Array.isArray(l) ? l : []; } catch (e) { return []; }
  }
  // Exam attempts are saved with subject "Exam"; they are not a school subject.
  const realSubjects = (s) => new Set(s.filter((x) => x.subject !== "Exam").map((x) => x.subject));

  const TROPHIES = [
    { id: "first-quiz", name: "First Steps", icon: "🥉", desc: "Complete your first quiz.", test: (s) => s.length >= 1 },
    { id: "five-attempts", name: "Building Momentum", icon: "🥈", desc: "Complete 5 quiz attempts.", test: (s) => s.length >= 5 },
    { id: "perfect-score", name: "Perfect Score", icon: "🏆", desc: "Score 100% on any quiz.", test: (s) => s.some((x) => x.score === x.total) },
    { id: "three-subjects", name: "Well Rounded", icon: "🌐", desc: "Quiz in 3 different subjects.", test: (s) => realSubjects(s).size >= 3 },
    { id: "six-subjects", name: "Wide Explorer", icon: "🧭", desc: "Quiz in 6 different subjects.", test: (s) => realSubjects(s).size >= 6 },
    { id: "all-subjects", name: "Renaissance Learner", icon: "⭐", desc: "Quiz in all 8 subjects.", test: (s) => realSubjects(s).size >= 8 },
    { id: "ten-attempts", name: "Dedicated Scholar", icon: "🎖️", desc: "Complete 10 quiz attempts.", test: (s) => s.length >= 10 },
    { id: "first-exam", name: "Exam Day", icon: "📝", desc: "Finish your first Exam Center paper.", test: () => getExams().length >= 1 },
    { id: "full-paper", name: "Marathon Runner", icon: "🏃", desc: "Finish an 80 or 100 mark paper.", test: () => getExams().some((e) => e.max >= 80) },
    { id: "exam-ace", name: "Exam Ace", icon: "🎓", desc: "Score 90% or more on an exam of 20+ marks.", test: () => getExams().some((e) => e.max >= 20 && e.pct >= 90) },
    { id: "beat-clock", name: "Beat the Clock", icon: "⏱️", desc: "Score 60%+ on a 20+ mark exam using under 75% of the time.", test: () => getExams().some((e) => e.max >= 20 && e.pct >= 60 && e.allowed > 0 && e.used <= e.allowed * 0.75) },
    { id: "all-rounder", name: "All-Rounder", icon: "🌈", desc: "Score 60%+ in at least four subjects in one exam.", test: () => getExams().some((e) => e.subjOk >= 4) },
    { id: "exam-regular", name: "Exam Regular", icon: "📅", desc: "Finish 5 Exam Center papers.", test: () => getExams().length >= 5 },
  ];

  function earned() {
    const scores = getScores();
    return TROPHIES.map((t) => ({ ...t, earned: t.test(scores) }));
  }

  function drawCertificate(canvas, name, lessonName) {
    const ctx = canvas.getContext("2d");
    const W = canvas.width, H = canvas.height;
    ctx.fillStyle = "#F3EFE3";
    ctx.fillRect(0, 0, W, H);
    ctx.strokeStyle = "#D68C1F";
    ctx.lineWidth = 8;
    ctx.strokeRect(24, 24, W - 48, H - 48);
    ctx.strokeStyle = "#12213B";
    ctx.lineWidth = 2;
    ctx.strokeRect(40, 40, W - 80, H - 80);

    ctx.fillStyle = "#12213B";
    ctx.textAlign = "center";
    ctx.font = "italic 28px Georgia, serif";
    ctx.fillText("Curio · Lab", W / 2, 110);

    ctx.font = "16px monospace";
    ctx.fillStyle = "#5C594E";
    ctx.fillText("CERTIFICATE OF ACHIEVEMENT", W / 2, 150);

    ctx.font = "bold 42px Georgia, serif";
    ctx.fillStyle = "#1B1B18";
    ctx.fillText(name || "Curious Learner", W / 2, 240);

    ctx.font = "18px Georgia, serif";
    ctx.fillStyle = "#5C594E";
    ctx.fillText("has achieved a perfect score on", W / 2, 285);

    ctx.font = "bold 26px Georgia, serif";
    ctx.fillStyle = "#C94A38";
    ctx.fillText(lessonName, W / 2, 325);

    ctx.font = "14px monospace";
    ctx.fillStyle = "#5C594E";
    const dateStr = new Date().toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" });
    ctx.fillText(dateStr, W / 2, H - 70);
  }

  return { getScores, getExams, TROPHIES, earned, drawCertificate };
})();
