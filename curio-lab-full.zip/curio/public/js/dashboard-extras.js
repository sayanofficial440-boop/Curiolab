// Curio Lab — dashboard: "Recommended next" (from weak topics and course order) and
// daily / weekly quests. Everything is derived from real activity in CurioLearning,
// CurioReview and CurioTime; nothing is sample data.
(function () {
  "use strict";
  const L = window.CurioLearning, CAT = window.CurioCatalog;
  const anchor = document.querySelector("[data-review-card]") || document.querySelector(".greet-row");
  if (!L || !CAT || !anchor || document.querySelector("[data-extras]")) return;
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const pct = (e) => Math.round((e.score / e.total) * 100);
  const sameDay = (a, b) => new Date(a).toDateString() === new Date(b).toDateString();

  const style = document.createElement("style");
  style.textContent = `
  .ex-grid{display:grid;grid-template-columns:1.25fr 1fr;gap:16px;margin:0 0 20px}
  .ex-card{background:var(--panel,#fff);border:1px solid var(--line,#e5e1f4);border-radius:var(--radius,16px);padding:16px 18px;box-shadow:var(--shadow);min-width:0}
  .ex-card h3{margin:0 0 4px;font-size:14px;font-weight:700} .ex-card .sub{font-size:12px;color:var(--ink-soft,#5b5f68);margin:0 0 12px}
  .ex-rec{display:flex;align-items:center;gap:12px;padding:10px 0;border-top:1px solid var(--line-soft,#f0eef9);text-decoration:none;color:inherit}
  .ex-rec:first-of-type{border-top:0}
  .ex-rec .ic{width:36px;height:36px;border-radius:10px;display:grid;place-items:center;background:var(--accent-soft,#efeaff);flex:none}
  .ex-rec .tx{flex:1;min-width:0} .ex-rec strong{display:block;font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis} .ex-rec span.s{font-size:12px;color:var(--ink-soft,#5b5f68)}
  .ex-rec .go{font-size:12.5px;font-weight:600;color:var(--accent,#6547da);white-space:nowrap}
  .ex-rec:hover strong{text-decoration:underline} .ex-rec:focus-visible,.ex-q:focus-visible{outline:2px solid var(--accent,#6547da);outline-offset:2px}
  .ex-q{display:block;padding:9px 0;border-top:1px solid var(--line-soft,#f0eef9);text-decoration:none;color:inherit}
  .ex-q:first-of-type{border-top:0}
  .ex-q .row{display:flex;justify-content:space-between;gap:8px;font-size:13px;font-weight:600} .ex-q .row em{font-style:normal;font-weight:500;color:var(--ink-soft,#5b5f68);font-size:12px}
  .ex-q .bar{height:6px;border-radius:99px;background:var(--line-soft,#f0eef9);margin-top:6px;overflow:hidden} .ex-q .bar i{display:block;height:100%;background:var(--accent,#6547da);border-radius:99px}
  .ex-q.done .bar i{background:var(--teal,#177d75)} .ex-q.done .row b::before{content:"✓ ";color:var(--teal,#177d75)}
  .ex-wk{margin-top:12px;padding-top:10px;border-top:1px dashed var(--line,#e5e1f4);font-size:12.5px;color:var(--ink-soft,#5b5f68)}
  .ex-time{grid-column:1/-1}
  .ex-th{display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap}
  .ex-tg{display:flex;gap:6px} .ex-tg button{border:1px solid var(--line,#e5e1f4);background:transparent;color:inherit;border-radius:99px;padding:4px 12px;font:inherit;font-size:12px;font-weight:600;cursor:pointer}
  .ex-tg button[aria-pressed="true"]{background:var(--accent,#6547da);color:#fff;border-color:transparent}
  .ex-tg button:focus-visible{outline:2px solid var(--accent,#6547da);outline-offset:2px}
  .ex-bars{display:flex;align-items:flex-end;gap:8px;height:96px;margin-top:12px}
  .ex-bars div{flex:1;min-width:0;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;font-size:11px;color:var(--ink-soft,#5b5f68)}
  .ex-bars i{display:block;width:100%;max-width:34px;min-height:2px;background:var(--accent,#6547da);border-radius:6px 6px 0 0}
  .ex-bars b{font-weight:600;font-size:11px;color:inherit;min-height:14px}
  @media(max-width:820px){.ex-grid{grid-template-columns:1fr}}`;
  document.head.appendChild(style);

  const wrap = document.createElement("div");
  wrap.className = "ex-grid"; wrap.setAttribute("data-extras", "");
  anchor.insertAdjacentElement("afterend", wrap);

  function lessonStats(state) {
    const rel = (h) => L.relHref(h);
    return CAT.lessons.map((l) => {
      const evs = state.events.filter((e) => e.total > 0 && ((e.href && rel(e.href) === l.h) || (e.subject === l.s && e.lesson === l.t)));
      const last3 = evs.slice(-3);
      const mastery = last3.length ? Math.round(last3.reduce((a, e) => a + pct(e), 0) / last3.length) : null;
      const visited = state.visits.some((v) => rel(v.href) === l.h);
      return { ...l, mastery, attempts: evs.length, visited };
    });
  }

  function recommendations(state, lessons) {
    const out = [], used = new Set();
    const add = (l, icon, title, why, cta) => { if (!l || used.has(l.h) || out.length >= 3) return; used.add(l.h); out.push({ l, icon, title, why, cta }); };
    const weak = lessons.filter((l) => l.mastery != null && l.mastery < 60).sort((a, b) => a.mastery - b.mastery);
    weak.slice(0, 2).forEach((l) => add(l, "🎯", l.t, `${l.s} · you scored ${l.mastery}% — worth another go`, "Retake"));
    add(lessons.filter((l) => l.visited && l.attempts === 0)[0], "📖", "", "", "Finish");
    if (out.length && !out[out.length - 1].title) { const o = out[out.length - 1]; o.title = o.l.t; o.why = `${o.l.s} · opened but no quiz taken yet`; }
    // next unexplored lesson in course order for the most recent subject
    const lastSubject = (state.resume && state.resume.subject) || (state.visits.length && state.visits[state.visits.length - 1].subject) || null;
    const fresh = lessons.filter((l) => !l.visited && l.attempts === 0);
    add(fresh.find((l) => l.s === lastSubject) || fresh[0], "✨", "", "", "Start");
    if (out.length && !out[out.length - 1].title) { const o = out[out.length - 1]; o.title = o.l.t; o.why = `${o.l.s} · ${o.l.s === lastSubject ? "next in your current subject" : "something new to explore"}`; }
    return out;
  }

  function quests(state) {
    const today = Date.now();
    const evToday = state.events.filter((e) => e.total > 0 && sameDay(e.at, today));
    const qs = evToday.reduce((a, e) => a + e.total, 0);
    const R = window.CurioReview ? window.CurioReview.stats() : null;
    const secs = window.CurioTime ? window.CurioTime.today() : 0;
    const list = [
      { t: "Finish a quiz", v: Math.min(1, evToday.length), g: 1, label: evToday.length ? "done" : "0 / 1", href: "pages/physics.html" },
      { t: "Answer 10 quiz questions", v: Math.min(10, qs), g: 10, label: Math.min(10, qs) + " / 10", href: "pages/exams.html?start=test20" },
      { t: "Study for 15 minutes", v: Math.min(15, Math.floor(secs / 60)), g: 15, label: Math.min(15, Math.floor(secs / 60)) + " / 15 min", href: "pages/physics.html" },
    ];
    if (R && R.total && (R.due || R.reviewedToday)) {
      const goal = Math.min(5, Math.max(1, R.reviewedToday + R.due));
      list.push({ t: "Review missed questions", v: Math.min(goal, R.reviewedToday), g: goal, label: Math.min(goal, R.reviewedToday) + " / " + goal, href: "pages/review.html" });
    }
    // weekly: study on 5 different days (this Monday-start week)
    const mon = new Date(); mon.setHours(0, 0, 0, 0); mon.setDate(mon.getDate() - ((mon.getDay() + 6) % 7));
    const days = new Set([...state.events, ...state.visits].filter((x) => new Date(x.at) >= mon).map((x) => new Date(x.at).toDateString()));
    return { list, week: Math.min(5, days.size) };
  }

  let timeView = "week";
  const fmt = (m) => (m >= 60 ? Math.floor(m / 60) + " h " + (m % 60) + " min" : m + " min");
  function timeCard() {
    const T = window.CurioTime; if (!T) return "";
    T.flush();
    const week = timeView === "week";
    let bars, total;
    if (week) {
      const sr = T.series(7); total = sr.reduce((a, d) => a + d.secs, 0); const mx = Math.max(60, ...sr.map((d) => d.secs));
      bars = sr.map((d) => `<div><b>${d.secs ? Math.round(d.secs / 60) : ""}</b><i style="height:${Math.round((d.secs / mx) * 70)}px"></i><span>${d.date.toLocaleDateString(undefined, { weekday: "short" })}</span></div>`).join("");
    } else {
      const sr = T.series(56), wk = []; for (let i = 0; i < 8; i++) { const c = sr.slice(i * 7, i * 7 + 7); wk.push({ secs: c.reduce((a, d) => a + d.secs, 0), start: c[0].date }); }
      total = wk.reduce((a, w) => a + w.secs, 0); const mx = Math.max(60, ...wk.map((w) => w.secs));
      bars = wk.map((w) => `<div><b>${w.secs ? Math.round(w.secs / 60) : ""}</b><i style="height:${Math.round((w.secs / mx) * 70)}px"></i><span>${w.start.toLocaleDateString(undefined, { day: "numeric", month: "short" })}</span></div>`).join("");
    }
    const m = Math.round(total / 60);
    return `<section class="ex-card ex-time" aria-label="Study time"><div class="ex-th"><div><h3>Study time · ${fmt(m)} ${week ? "this week" : "in 8 weeks"}</h3><p class="sub" style="margin:0">Minutes per ${week ? "day" : "week"}, counted while you are actively studying. <a href="pages/report.html">Full report →</a></p></div>
      <div class="ex-tg" role="group" aria-label="Study time range"><button type="button" data-tv="week" aria-pressed="${week}">Weekly</button><button type="button" data-tv="month" aria-pressed="${!week}">Monthly</button></div></div>
      ${total ? `<div class="ex-bars">${bars}</div>` : `<p class="sub" style="margin:12px 0 0">No study time recorded yet — it starts counting when you read a lesson.</p>`}</section>`;
  }
  wrap.addEventListener("click", (e) => { const b = e.target.closest("[data-tv]"); if (b) { timeView = b.dataset.tv; render(); } });

  async function render() {
    const state = await L.get(), lessons = lessonStats(state);
    const recs = recommendations(state, lessons), q = quests(state);
    const recHtml = recs.length
      ? recs.map((r) => `<a class="ex-rec" href="${esc(r.l.h)}"><div class="ic" aria-hidden="true">${r.icon}</div><div class="tx"><strong>${esc(r.title)}</strong><span class="s">${esc(r.why)}</span></div><span class="go">${r.cta} →</span></a>`).join("")
      : `<p class="sub" style="margin:0">You've explored every lesson — nice. Sit a <a href="pages/exams.html">timed exam</a> to keep sharp.</p>`;
    const done = q.list.filter((x) => x.v >= x.g).length;
    wrap.innerHTML = `
      <section class="ex-card" aria-label="Recommended next"><h3>Recommended for you</h3><p class="sub">${state.events.length ? "Picked from your weak topics and course order." : "Start anywhere — suggestions sharpen as you finish quizzes."}</p>${recHtml}</section>
      <section class="ex-card" aria-label="Quests"><h3>Today's quests · ${done}/${q.list.length}</h3><p class="sub">Resets every day. Progress comes from what you actually do.</p>
        ${q.list.map((x) => `<a class="ex-q${x.v >= x.g ? " done" : ""}" href="${x.href}"><div class="row"><b>${esc(x.t)}</b><em>${esc(x.label)}</em></div><div class="bar" role="progressbar" aria-valuenow="${Math.round((x.v / x.g) * 100)}" aria-valuemin="0" aria-valuemax="100"><i style="width:${(x.v / x.g) * 100}%"></i></div></a>`).join("")}
        <div class="ex-wk">Weekly quest: study on 5 different days — <b>${q.week}/5</b>${q.week >= 5 ? " ✓" : ""}</div></section>${timeCard()}`;
  }
  ["curio-learning-updated", "curio-review-updated", "curio-time-updated"].forEach((ev) => window.addEventListener(ev, () => { clearTimeout(render.t); render.t = setTimeout(render, 200); }));
  L.ready().then(render);
  setInterval(render, 60000);
})();
