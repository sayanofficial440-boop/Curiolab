// Curio Lab — Accessibility & offline settings page.
(function () {
  "use strict";
  const A = window.CurioA11y, root = document.querySelector("[data-a11y-app]");
  if (!A || !root) return;
  const $ = (s) => root.querySelector(s);

  function paint() {
    const p = A.get();
    $("[data-scale-out]").textContent = p.scale + "%";
    $("[data-scale]").value = p.scale;
    root.querySelectorAll("[data-font]").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.font === p.font)));
    root.querySelectorAll("[data-spacing]").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.spacing === p.spacing)));
    root.querySelectorAll("[data-hc]").forEach((b) => b.setAttribute("aria-pressed", String((b.dataset.hc === "dark") === (p.hc === "dark"))));
    const hcRow = $("[data-hc-row]"); if (hcRow) hcRow.hidden = !p.contrast;
    ["contrast", "links", "motion", "cb"].forEach((k) => { const el = $("[data-toggle=" + k + "]"); if (el) el.checked = !!p[k]; });
    const cap = $("[data-toggle=captions]"); if (cap) cap.checked = p.captions !== false;
  }
  $("[data-scale]").addEventListener("input", (e) => { A.set({ scale: Number(e.target.value) }); paint(); });
  root.querySelectorAll("[data-font]").forEach((b) => b.addEventListener("click", () => { A.set({ font: b.dataset.font }); paint(); }));
  root.querySelectorAll("[data-spacing]").forEach((b) => b.addEventListener("click", () => { A.set({ spacing: b.dataset.spacing }); paint(); }));
  root.querySelectorAll("[data-hc]").forEach((b) => b.addEventListener("click", () => { A.set({ hc: b.dataset.hc }); paint(); }));
  root.querySelectorAll("[data-toggle]").forEach((el) => el.addEventListener("change", () => { A.set({ [el.dataset.toggle]: el.checked }); paint(); }));
  $("[data-reset]").addEventListener("click", () => { A.reset(); paint(); A.announce("All accessibility settings were reset"); });

  // Indian-language quick picks
  const chips = $("[data-lang-chips]"), langStatus = $("[data-lang-status]");
  const INDIAN = ["en", "hi", "bn", "ta", "te", "mr", "gu", "kn", "ml", "pa", "ur", "ne", "or", "as", "sa", "mai", "bho", "gom", "doi", "sd"];
  function drawLangs() {
    if (!chips || !window.CurioLang) return;
    chips.innerHTML = "";
    INDIAN.forEach((code) => {
      const l = window.CurioLang.languages.find((x) => x.code === code); if (!l) return;
      const b = document.createElement("button"); b.type = "button"; b.className = "mk-chip"; b.textContent = l.name; b.setAttribute("lang", code);
      b.setAttribute("aria-pressed", String(window.CurioLang.get() === code)); b.setAttribute("data-no-i18n", "");
      b.addEventListener("click", () => { window.CurioLang.set(code); langStatus.textContent = l.en + " selected."; setTimeout(drawLangs, 400); });
      chips.appendChild(b);
    });
  }
  window.addEventListener("load", drawLangs); document.addEventListener("curio:langchange", () => setTimeout(drawLangs, 450));

  // offline / install
  const status = $("[data-offline-status]"), installBtn = $("[data-install]"), saveBtn = $("[data-save-offline]");
  const supported = "serviceWorker" in navigator && /^https?:$/.test(location.protocol);
  if (!supported) {
    status.textContent = "Offline mode needs the site to be opened over http(s) in a modern browser. It isn't available when opened straight from a file.";
    saveBtn.disabled = true; installBtn.hidden = true;
  } else {
    const upd = () => { installBtn.hidden = !(window.CurioPWA && window.CurioPWA.canInstall()); };
    window.addEventListener("curio-install-ready", upd); upd();
    installBtn.addEventListener("click", async () => { if (await window.CurioPWA.install()) status.textContent = "Curio Lab was added to your device."; upd(); });
    saveBtn.addEventListener("click", async () => {
      saveBtn.disabled = true; status.textContent = "Saving lessons to this device…";
      try { const n = await window.CurioPWA.saveLessonsOffline(); status.textContent = "Saving " + n + " pages in the background. Keep this tab open for a minute, then lessons will open without internet."; }
      catch (_) { status.textContent = "Couldn't start offline saving. Reload the page and try again."; }
      setTimeout(() => { saveBtn.disabled = false; }, 4000);
    });
    navigator.serviceWorker.getRegistration().then((r) => { if (r && r.active) status.textContent = "Offline mode is on: lessons you open are kept on this device automatically."; });
  }
  paint();
})();
