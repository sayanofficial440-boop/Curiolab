// Curio Lab — public learner profile page (pages/u.html?h=<handle>  or  /u/<handle>)
(function () {
  "use strict";
  const CC = window.CurioCommunity;
  document.addEventListener("DOMContentLoaded", async () => {
    const root = document.querySelector("[data-pu-root]");
    if (!root || !CC) return;
    CC.autoLocalize(root);
    const { esc, avatar, fmt } = CC;
    const toast = (m, o) => (window.CurioToast ? window.CurioToast.show(m, o || {}) : null);
    const handle = (new URLSearchParams(location.search).get("h") || (location.pathname.match(/\/u\/([^/?#]+)/) || [])[1] || "").trim().toLowerCase();
    const note = (t, b) => { root.innerHTML = `<div class="cm-card cm-notice"><div class="cm-big" aria-hidden="true">🔎</div><h2>${t}</h2><p>${b}</p><div class="cm-actions"><a class="cm-btn cm-primary" href="${location.pathname.includes("/pages/") ? "" : "/pages/"}community.html">Go to the community</a></div></div>`; };
    if (!handle) return note("No profile selected", "Open a profile from a leaderboard or a friend's link.");

    let meta = null, p;
    try {
      meta = await CC.api("/meta");
      p = (await CC.api("/profile/" + encodeURIComponent(handle))).profile;
    } catch (e) {
      return e.offline ? note("Community unavailable", esc(e.message)) : note("Profile not found", "This profile doesn't exist, or its owner keeps it private or friends-only.");
    }
    document.title = `${p.display_name} (@${p.handle}) — Curio Lab`;
    const have = new Set(p.badges.map((b) => b.id));
    const max = Math.max(1, ...p.subjects.map((s) => s.xp));
    const joined = new Date(p.joined * 1000).toLocaleDateString(undefined, { month: "long", year: "numeric" });
    const signedIn = !!(CC.saved() && CC.saved().key);

    root.innerHTML = `
      <div class="cm-card cm-me">
        ${avatar(p.display_name, p.avatar, "cm-lg")}
        <div class="cm-me-id"><h1 class="cm-pname">${esc(p.display_name)}</h1><p><span translate="no">@${esc(p.handle)}</span> · <span>Joined</span> ${esc(joined)}${p.visibility === "friends" ? " · <span>Friends only</span>" : ""}</p>
          ${p.bio ? `<p class="cm-bio">${esc(p.bio)}</p>` : ""}
          <div class="cm-actions" data-actions></div></div>
        <dl class="cm-stats"><div><dt>Level</dt><dd>${p.level}</dd></div><div><dt>XP</dt><dd>${fmt(p.xp)}</dd></div><div><dt>Rank</dt><dd>${p.rank ? "#" + p.rank : "—"}</dd></div><div><dt>Streak</dt><dd>${p.streak_cur}🔥</dd></div><div><dt>Best streak</dt><dd>${p.streak_best}</dd></div></dl>
      </div>
      <div class="cm-grid">
        <div class="cm-card"><h2 class="cm-h2">Badges <small>${p.badges.length}/${meta.badges.length}</small></h2>
          <ul class="cm-badges">${meta.badges.map((b) => `<li class="${have.has(b.id) ? "is-on" : ""}" title="${esc(b.desc)}"><span class="cm-bi" aria-hidden="true">${b.icon}</span><span><strong>${esc(b.name)}</strong><small>${have.has(b.id) ? "Earned" : "Locked"}</small></span></li>`).join("")}</ul></div>
        <div class="cm-card"><h2 class="cm-h2">Activity</h2>
          <dl class="cm-facts"><div><dt>Quiz attempts</dt><dd>${fmt(p.quizzes)}</dd></div><div><dt>Lessons quizzed</dt><dd>${fmt(p.lessons)}</dd></div><div><dt>Average score</dt><dd>${p.quizzes ? p.avg_pct + "%" : "—"}</dd></div><div><dt>XP this week</dt><dd>${fmt(p.week_xp)}</dd></div></dl>
          <h2 class="cm-h2">XP by subject</h2>
          ${p.subjects.length ? `<ul class="cm-bars">${p.subjects.map((s) => `<li><span>${esc(s.subject)}</span><span class="cm-bar"><i style="width:${Math.max(4, (s.xp / max) * 100)}%"></i></span><b>${fmt(s.xp)}</b></li>`).join("")}</ul>` : `<p class="cm-hint">No quizzes yet.</p>`}</div>
      </div>
      <p class="cm-hint cm-fine">XP is graded by Curio Lab's server from quizzes taken after joining. It shows effort on Curio Lab; it isn't a proctored exam.</p>`;

    const box = root.querySelector("[data-actions]");
    const btn = (t, a, c) => `<button type="button" class="cm-btn cm-sm ${c || ""}" data-a="${a}">${t}</button>`;
    if (p.relation === "self") box.innerHTML = `<a class="cm-btn cm-sm cm-primary" href="community.html">Edit my profile</a>`;
    else if (!signedIn) box.innerHTML = `<a class="cm-btn cm-sm cm-primary" href="community.html">Join to add friends</a>`;
    else {
      const map = { none: btn("Add friend", "add", "cm-primary"), pending_out: `<span class="cm-chip">Request sent</span>`, pending_in: btn("Accept request", "accept", "cm-primary"), friend: `<span class="cm-chip">✓ Friends</span>` };
      box.innerHTML = (map[p.relation] || "") + btn("Block", "block") + btn("Report", "report");
    }
    box.addEventListener("click", async (ev) => {
      const a = ev.target.closest("[data-a]"); if (!a) return;
      try {
        if (a.dataset.a === "add") { const j = await CC.api("/friends/request", { body: { handle: p.handle } }); toast(j.status === "friend" ? "You're now friends" : "Request sent", { icon: "🤝" }); }
        else if (a.dataset.a === "accept") { await CC.api("/friends/respond", { body: { handle: p.handle, accept: true } }); toast("You're now friends", { icon: "🤝" }); }
        else if (a.dataset.a === "block") { if (!confirm(`Block @${p.handle}? You'll stop seeing each other everywhere.`)) return; await CC.api("/block", { body: { handle: p.handle } }); return note("Blocked", `You won't see @${esc(p.handle)} and they won't see you.`); }
        else {
          const send = (x) => CC.api("/report", { body: { handle: p.handle, category: x.category, reason: x.reason } });
          if (window.CurioReport) { const sent = await window.CurioReport.open({ what: "profile", onSend: send }); if (!sent) return; }
          else { const r = window.prompt("What's wrong with this profile? (the profile is also hidden from you)"); if (!r) return; await send({ reason: r }); }
          return note("Thanks for reporting", "A moderator will look at it. We've hidden this profile from you.");
        }
        location.reload();
      } catch (e) { toast(e.message); }
    });
  });
})();
