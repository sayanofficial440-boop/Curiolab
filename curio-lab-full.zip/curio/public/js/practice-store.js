// Curio Lab — Practice store.
//
// Remembers everything the new practice tools (Smart Cards, Type It, Fill the Blank,
// Explain It, True/False, Problem Lab) learn about the learner:
//   - per-card spaced-repetition state (SM-2 variant, same maths as the Mistake Notebook)
//   - which cards are "weak" (missed more often than got right) so every mode can lean on them
//   - a per-day activity log that powers streaks, the dashboard quest and the report
//
// Data is per account on this device (localStorage), like js/learning-state.js and
// js/review-store.js. Nothing is pre-filled: no activity means every number is zero.
(function () {
  "use strict";
  if (window.CurioPracticeStore) return;

  const KEY_PREFIX = "curiolab-practice-v1:";
  const SESSION_KEY = "curiolab-local-session";
  const DAY = 86400000;
  const AGAIN_DELAY = 10 * 60000;
  const MATURE_AT = 21;            // interval (days) at which a card counts as mature
  const MAX_CARDS = 4000;
  const MAX_DAYS = 400;

  const safeParse = (v, f) => { try { const x = JSON.parse(v); return x == null ? f : x; } catch (_) { return f; } };

  function accountKey() {
    const u = safeParse(localStorage.getItem(SESSION_KEY), null);
    if (u && u.id) return "id:" + u.id;
    if (u && u.email) return "email:" + String(u.email).toLowerCase();
    return "guest";
  }
  const storageKey = () => KEY_PREFIX + accountKey();

  const pad = (n) => String(n).padStart(2, "0");
  const dayKey = (d) => { const x = d ? new Date(d) : new Date(); return x.getFullYear() + "-" + pad(x.getMonth() + 1) + "-" + pad(x.getDate()); };

  const fresh = () => ({ version: 1, cards: {}, days: {}, settings: { newPerDay: 10 }, problems: {} });

  function load() {
    const raw = safeParse(localStorage.getItem(storageKey()), null);
    const s = raw && typeof raw === "object" ? raw : fresh();
    s.cards = s.cards && typeof s.cards === "object" ? s.cards : {};
    s.days = s.days && typeof s.days === "object" ? s.days : {};
    s.problems = s.problems && typeof s.problems === "object" ? s.problems : {};
    s.settings = Object.assign({ newPerDay: 10 }, s.settings || {});
    return s;
  }

  function save(state) {
    // keep storage bounded: drop the least recently touched cards / oldest days
    const ids = Object.keys(state.cards);
    if (ids.length > MAX_CARDS) {
      ids.sort((a, b) => (state.cards[a].t || 0) - (state.cards[b].t || 0)).slice(0, ids.length - MAX_CARDS).forEach((id) => delete state.cards[id]);
    }
    const days = Object.keys(state.days).sort();
    if (days.length > MAX_DAYS) days.slice(0, days.length - MAX_DAYS).forEach((d) => delete state.days[d]);
    try { localStorage.setItem(storageKey(), JSON.stringify(state)); } catch (_) { /* storage full or blocked */ }
    window.dispatchEvent(new CustomEvent("curio-practice-updated"));
  }

  // ---------- cards ----------
  // c = { r: reps, i: interval (days), e: ease, d: due (ms), l: lapses, t: last touched (ms),
  //       f: first-seen day key, m: miss balance (>0 means weak), n: times seen }
  function blank(now) { return { r: 0, i: 0, e: 2.5, d: now, l: 0, t: 0, f: "", m: 0, n: 0 }; }

  // SM-2 variant. grade: 1 = Again, 3 = Hard, 4 = Good, 5 = Easy.
  function applyGrade(c, grade, now) {
    c.t = now;
    c.n = (c.n || 0) + 1;
    if (!c.f) c.f = dayKey(now);
    if (grade < 3) {
      c.r = 0; c.i = 0; c.l = (c.l || 0) + 1;
      c.e = Math.max(1.3, c.e - 0.2);
      c.d = now + AGAIN_DELAY;
      c.m = (c.m || 0) + 1;
      return c;
    }
    c.e = Math.max(1.3, c.e + (0.1 - (5 - grade) * (0.08 + (5 - grade) * 0.02)));
    if (c.r === 0) c.i = grade === 5 ? 3 : 1;
    else if (c.r === 1) c.i = grade === 5 ? 8 : 6;
    else c.i = Math.max(c.i + 1, Math.round(c.i * c.e * (grade === 3 ? 0.8 : grade === 5 ? 1.3 : 1)));
    c.r += 1;
    c.d = now + c.i * DAY;
    c.m = Math.max(0, (c.m || 0) - 1);
    return c;
  }

  function gradeCard(id, grade) {
    const s = load(), now = Date.now();
    const c = s.cards[id] || blank(now);
    applyGrade(c, grade, now);
    s.cards[id] = c;
    save(s);
    return c;
  }

  // Result from a non-scheduling mode (Type It, Cloze, Explain, True/False): only the miss balance moves.
  function noteResult(id, correct) {
    const s = load(), now = Date.now();
    const c = s.cards[id] || blank(now);
    // Deliberately leaves n / f / due alone: a card only enters the spaced-repetition
    // schedule once it has been studied in Smart Cards.
    c.t = now; c.x = (c.x || 0) + 1;
    c.m = correct ? Math.max(0, (c.m || 0) - 1) : (c.m || 0) + 1;
    s.cards[id] = c;
    save(s);
    return c;
  }

  const getCard = (id) => load().cards[id] || null;

  // What would each grade schedule, in days? (for the button labels)
  function preview(id) {
    const c = JSON.parse(JSON.stringify(load().cards[id] || blank(0)));
    const out = {};
    [1, 3, 4, 5].forEach((g) => {
      const copy = JSON.parse(JSON.stringify(c));
      applyGrade(copy, g, 0);
      out[g] = g === 1 ? AGAIN_DELAY / DAY : copy.i;
    });
    return out;
  }

  function fmtInterval(days) {
    if (days < 1) return Math.max(1, Math.round(days * 1440)) + " min";
    if (days < 30) return Math.round(days) + " d";
    return Math.round(days / 30) + " mo";
  }

  // Splits a list of card ids into { due, fresh, later } using the saved state.
  function queueFor(ids, newLimit) {
    const s = load(), now = Date.now();
    const today = dayKey();
    let introduced = 0;
    Object.keys(s.cards).forEach((id) => { if (s.cards[id].f === today) introduced += 1; });
    const budget = Math.max(0, (newLimit == null ? s.settings.newPerDay : newLimit) - introduced);
    const due = [], fresh = [], later = [];
    ids.forEach((id) => {
      const c = s.cards[id];
      if (!c || !c.n) fresh.push(id);
      else if (c.d <= now) due.push(id);
      else later.push(id);
    });
    due.sort((a, b) => s.cards[a].d - s.cards[b].d);
    return { due, fresh, later, newBudget: budget, introducedToday: introduced };
  }

  const weakIds = () => { const s = load(); return Object.keys(s.cards).filter((id) => (s.cards[id].m || 0) > 0); };
  const cardMap = () => load().cards;

  // ---------- daily log ----------
  // mode: "cards" | "type" | "cloze" | "explain" | "tf" | "problems"
  function log({ mode, answered, correct, subject }) {
    const a = Math.max(0, Number(answered) || 0), c = Math.max(0, Math.min(a, Number(correct) || 0));
    if (!a) return;
    const s = load(), k = dayKey();
    const d = s.days[k] || { a: 0, c: 0, modes: {}, subjects: {} };
    d.a += a; d.c += c;
    d.modes[mode] = (d.modes[mode] || 0) + a;
    if (subject) d.subjects[subject] = (d.subjects[subject] || 0) + a;
    s.days[k] = d;
    save(s);
  }

  // A finished session (for "sessions today" and the report)
  function logSession(mode) {
    const s = load(), k = dayKey();
    const d = s.days[k] || { a: 0, c: 0, modes: {}, subjects: {} };
    d.s = (d.s || 0) + 1;
    s.days[k] = d;
    save(s);
  }

  function streak() {
    const s = load();
    const active = (key) => s.days[key] && s.days[key].a > 0;
    let n = 0;
    const d = new Date();
    if (!active(dayKey(d))) d.setDate(d.getDate() - 1);      // today not practised yet: streak still alive until midnight
    while (active(dayKey(d))) { n += 1; d.setDate(d.getDate() - 1); }
    return n;
  }

  function stats() {
    const s = load(), now = Date.now(), k = dayKey();
    const today = s.days[k] || { a: 0, c: 0, modes: {}, s: 0 };
    let answered = 0, correct = 0;
    Object.values(s.days).forEach((d) => { answered += d.a || 0; correct += d.c || 0; });
    const all = Object.values(s.cards);
    const cards = all.filter((c) => c.n);          // cards that have entered the spaced-repetition schedule
    const learned = cards.filter((c) => c.r >= 1).length;
    const mature = cards.filter((c) => c.i >= MATURE_AT).length;
    const due = cards.filter((c) => c.d <= now).length;
    const week = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() - i);
      const rec = s.days[dayKey(d)];
      week.push({ date: d, a: rec ? rec.a : 0, c: rec ? rec.c : 0 });
    }
    return {
      todayAnswered: today.a, todayCorrect: today.c, todaySessions: today.s || 0, todayModes: today.modes || {},
      totalAnswered: answered, totalCorrect: correct,
      accuracy: answered ? Math.round((correct / answered) * 100) : null,
      streak: streak(), seen: cards.length, learned, mature, due, weak: all.filter((c) => (c.m || 0) > 0).length,
      newPerDay: s.settings.newPerDay, week, activeDays: Object.keys(s.days).filter((x) => s.days[x].a > 0).length,
    };
  }

  // ---------- problem lab (per-generator accuracy) ----------
  function logProblem(key, correct) {
    const s = load();
    const p = s.problems[key] || { a: 0, c: 0 };
    p.a += 1; if (correct) p.c += 1;
    s.problems[key] = p;
    save(s);
  }
  const problemStats = () => load().problems;

  // ---------- settings ----------
  const getSettings = () => load().settings;
  function setSettings(patch) {
    const s = load();
    s.settings = Object.assign({}, s.settings, patch);
    save(s);
    return s.settings;
  }

  function clearAll() { try { localStorage.removeItem(storageKey()); } catch (_) { /* ignore */ } window.dispatchEvent(new CustomEvent("curio-practice-updated")); }

  window.CurioPracticeStore = {
    dayKey, getCard, gradeCard, noteResult, preview, fmtInterval, queueFor, weakIds, cardMap,
    log, logSession, stats, streak, logProblem, problemStats, getSettings, setSettings, clearAll, MATURE_AT,
  };
  window.addEventListener("storage", (e) => { if (e.key && e.key.indexOf(KEY_PREFIX) === 0) window.dispatchEvent(new CustomEvent("curio-practice-updated")); });
})();
