// Curio Lab — Dynamic Architectural Diagram Engine
//
// Renders interactive, animated, responsive diagrams (flowcharts, org charts,
// cycles) from a small JSON definition — no Mermaid/rough.js CDN dependency,
// so there is no render-blocking network fetch and no version drift. Ships
// as pure inline SVG so it inherits every theme variable (--color-*,
// --accent) automatically and re-themes instantly when js/theme.js or
// js/theme-engine.js swap palettes.
//
// DROP-IN CONTRACT (works on static pages AND lesson-engine.js pages):
//   <div class="flow-diagram" data-flow-diagram="rxn-1"></div>
//   <script type="application/json" data-flow-diagram-def="rxn-1">
//     { "type": "flow", "direction": "LR",
//       "nodes": [
//         { "id": "a", "label": "CH4 + 2 O2", "detail": "Methane + oxygen react on ignition." },
//         { "id": "b", "label": "CO2 + 2 H2O", "detail": "Combustion products.", "color": "--color-coral" }
//       ],
//       "edges": [ { "from": "a", "to": "b", "label": "combustion" } ] }
//   <\/script>
//
// This also plugs straight into lesson-engine.js's `extensions[]` escape
// hatch — an extension entry with `"type": "diagram2"` (kept distinct from
// the existing hand-built free-body `"diagram"` type) can set `customHtml`
// to exactly the two-element snippet above, and this file does the rest
// once window.onLessonContentReady fires.
(function () {
  "use strict";

  const STYLE_ID = "curio-diagram-engine-styles";
  const NODE_W = 168;
  const NODE_H = 64;
  const GAP_X = 96;
  const GAP_Y = 48;
  const PAD = 32;

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .flow-diagram {
        position: relative;
        border: 1px solid var(--color-line);
        border-radius: var(--radius-md, 12px);
        background: var(--color-bg-alt);
        box-shadow: var(--shadow-card);
        overflow: hidden;
        touch-action: none;
      }
      .flow-diagram-toolbar {
        position: absolute; top: 10px; right: 10px; z-index: 3;
        display: flex; gap: 6px;
      }
      .flow-diagram-toolbar button {
        width: 30px; height: 30px; border-radius: 8px; border: 1px solid var(--color-line);
        background: var(--color-surface); color: var(--color-ink); cursor: pointer;
        font-size: 0.95rem; line-height: 1; display: flex; align-items: center; justify-content: center;
        transition: transform 150ms var(--ease-standard, ease), border-color 150ms;
      }
      .flow-diagram-toolbar button:hover { border-color: var(--accent); transform: translateY(-1px); }
      .flow-diagram-toolbar button:active { transform: translateY(0) scale(0.94); }
      .flow-diagram-viewport { width: 100%; cursor: grab; display: block; }
      .flow-diagram-viewport.grabbing { cursor: grabbing; }
      .flow-diagram-viewport .fd-node rect {
        fill: var(--color-surface); stroke: var(--color-line-strong); stroke-width: 1.5;
        transition: stroke 180ms var(--ease-standard, ease), filter 180ms var(--ease-standard, ease);
      }
      .flow-diagram-viewport .fd-node text { fill: var(--color-ink); font-family: var(--font-body); }
      .flow-diagram-viewport .fd-node .fd-node-label { font-size: 13px; font-weight: 600; }
      .flow-diagram-viewport .fd-node { cursor: pointer; }
      .flow-diagram-viewport .fd-node:hover rect { stroke: var(--accent); filter: drop-shadow(0 4px 10px rgba(0,0,0,0.12)); }
      .flow-diagram-viewport .fd-node.active rect { stroke: var(--accent); stroke-width: 2.5; }
      .flow-diagram-viewport .fd-edge-path {
        fill: none; stroke: var(--color-line-strong); stroke-width: 2;
        stroke-dasharray: 6 500; stroke-dashoffset: 0;
        animation: fd-draw 900ms var(--ease-standard, ease) forwards;
      }
      .flow-diagram-viewport .fd-edge-path.dimmed { opacity: 0.25; }
      .flow-diagram-viewport .fd-edge-path.lit { stroke: var(--accent); stroke-width: 2.5; }
      .flow-diagram-viewport .fd-edge-label {
        fill: var(--color-ink-soft); font-family: var(--font-mono); font-size: 10.5px;
      }
      .flow-diagram-viewport .fd-arrowhead { fill: var(--color-line-strong); transition: fill 180ms; }
      .flow-diagram-viewport .fd-edge-path.lit + .fd-arrowhead,
      .flow-diagram-viewport .fd-arrowhead.lit { fill: var(--accent); }
      @keyframes fd-draw { from { stroke-dashoffset: 500; } to { stroke-dashoffset: 0; } }
      .flow-diagram-detail {
        border-top: 1px solid var(--color-line);
        padding: 0.85rem 1rem;
        font-size: 0.86rem;
        color: var(--color-ink-soft);
        min-height: 2.4em;
        transition: background 200ms;
      }
      .flow-diagram-detail strong { color: var(--color-ink); }
      @media (prefers-reduced-motion: reduce) {
        .flow-diagram-viewport .fd-edge-path { animation: none; stroke-dasharray: none; }
      }
    `;
    document.head.appendChild(style);
  }

  // --- Layout ---------------------------------------------------------
  // Layered layout via BFS depth from root nodes (nodes nobody points to).
  // Good enough for lesson-scale diagrams (reaction chains, org charts,
  // dynasty trees) without pulling in a full graph-layout dependency.
  function layoutLayers(nodes, edges, direction) {
    const byId = new Map(nodes.map((n) => [n.id, n]));
    const incoming = new Map(nodes.map((n) => [n.id, 0]));
    const adj = new Map(nodes.map((n) => [n.id, []]));
    edges.forEach((e) => {
      if (!byId.has(e.from) || !byId.has(e.to)) return;
      adj.get(e.from).push(e.to);
      incoming.set(e.to, (incoming.get(e.to) || 0) + 1);
    });

    const depth = new Map();
    const queue = [];
    nodes.forEach((n) => {
      if ((incoming.get(n.id) || 0) === 0) {
        depth.set(n.id, 0);
        queue.push(n.id);
      }
    });
    if (!queue.length && nodes.length) {
      depth.set(nodes[0].id, 0);
      queue.push(nodes[0].id);
    }
    let qi = 0;
    while (qi < queue.length) {
      const id = queue[qi++];
      const d = depth.get(id);
      (adj.get(id) || []).forEach((to) => {
        if (!depth.has(to) || depth.get(to) < d + 1) {
          depth.set(to, d + 1);
          queue.push(to);
        }
      });
    }
    nodes.forEach((n) => { if (!depth.has(n.id)) depth.set(n.id, 0); });

    const layers = [];
    nodes.forEach((n) => {
      const d = depth.get(n.id);
      layers[d] = layers[d] || [];
      layers[d].push(n.id);
    });

    const pos = new Map();
    const horizontal = direction !== "TB";
    layers.forEach((layerIds, li) => {
      layerIds.forEach((id, ii) => {
        const main = li * ((horizontal ? NODE_W : NODE_H) + GAP_X * (horizontal ? 1 : 0) + GAP_Y * (horizontal ? 0 : 0));
        const cross = ii * ((horizontal ? NODE_H : NODE_W) + GAP_Y);
        pos.set(id, horizontal
          ? { x: PAD + li * (NODE_W + GAP_X), y: PAD + ii * (NODE_H + GAP_Y) }
          : { x: PAD + ii * (NODE_W + GAP_X), y: PAD + li * (NODE_H + GAP_Y) });
      });
    });

    const maxLayerCount = Math.max(1, ...layers.map((l) => l.length));
    const width = horizontal
      ? PAD * 2 + layers.length * NODE_W + Math.max(0, layers.length - 1) * GAP_X
      : PAD * 2 + maxLayerCount * NODE_W + Math.max(0, maxLayerCount - 1) * GAP_X;
    const height = horizontal
      ? PAD * 2 + maxLayerCount * NODE_H + Math.max(0, maxLayerCount - 1) * GAP_Y
      : PAD * 2 + layers.length * NODE_H + Math.max(0, layers.length - 1) * GAP_Y;

    return { pos, width: Math.max(width, NODE_W + PAD * 2), height: Math.max(height, NODE_H + PAD * 2) };
  }

  // Circular layout for "cycle" diagrams (e.g. water cycle, carbon cycle).
  function layoutCircle(nodes) {
    const n = Math.max(nodes.length, 1);
    const radius = Math.max(120, n * 42);
    const cx = radius + NODE_W / 2 + PAD;
    const cy = radius + NODE_H / 2 + PAD;
    const pos = new Map();
    nodes.forEach((node, i) => {
      const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
      pos.set(node.id, { x: cx + Math.cos(angle) * radius - NODE_W / 2, y: cy + Math.sin(angle) * radius - NODE_H / 2 });
    });
    return { pos, width: cx * 2, height: cy * 2 };
  }

  // --- Rendering --------------------------------------------------------
  function svgEl(tag, attrs) {
    const el = document.createElementNS("http://www.w3.org/2000/svg", tag);
    Object.entries(attrs || {}).forEach(([k, v]) => el.setAttribute(k, v));
    return el;
  }

  function edgePath(from, to, curveHint) {
    const x1 = from.x + NODE_W / 2, y1 = from.y + NODE_H / 2;
    const x2 = to.x + NODE_W / 2, y2 = to.y + NODE_H / 2;
    if (curveHint === "cycle") {
      const mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
      const dx = x2 - x1, dy = y2 - y1;
      const nx = -dy, ny = dx;
      const len = Math.hypot(nx, ny) || 1;
      const bow = 18;
      const cx = mx + (nx / len) * bow, cy = my + (ny / len) * bow;
      return `M ${x1} ${y1} Q ${cx} ${cy} ${x2} ${y2}`;
    }
    const mx = (x1 + x2) / 2;
    return `M ${x1} ${y1} C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`;
  }

  function clampToRectEdge(from, to) {
    // Pull the arrowhead endpoint back to the border of the target box
    // rather than its center, so arrows visually terminate at the node.
    const cx = to.x + NODE_W / 2, cy = to.y + NODE_H / 2;
    const dx = cx - (from.x + NODE_W / 2), dy = cy - (from.y + NODE_H / 2);
    const angle = Math.atan2(dy, dx);
    const halfW = NODE_W / 2, halfH = NODE_H / 2;
    const scale = Math.min(Math.abs(halfW / Math.cos(angle) || Infinity), Math.abs(halfH / Math.sin(angle) || Infinity));
    return { x: cx - Math.cos(angle) * scale, y: cy - Math.sin(angle) * scale };
  }

  function render(container, def) {
    injectStyles();
    container.innerHTML = "";
    container.classList.add("flow-diagram");

    const nodes = def.nodes || [];
    const edges = def.edges || [];
    const isCycle = def.type === "cycle";
    const layout = isCycle ? layoutCircle(nodes) : layoutLayers(nodes, edges, def.direction || "LR");

    const toolbar = document.createElement("div");
    toolbar.className = "flow-diagram-toolbar";
    toolbar.innerHTML = `
      <button type="button" data-fd-zoom-out aria-label="Zoom out">−</button>
      <button type="button" data-fd-zoom-reset aria-label="Reset view">⤢</button>
      <button type="button" data-fd-zoom-in aria-label="Zoom in">+</button>`;
    container.appendChild(toolbar);

    const svg = svgEl("svg", {
      viewBox: `0 0 ${layout.width} ${layout.height}`,
      class: "flow-diagram-viewport",
      role: "img",
      "aria-label": def.title || "Interactive diagram",
    });
    container.appendChild(svg);

    const viewBoxState = { x: 0, y: 0, w: layout.width, h: layout.height, baseW: layout.width, baseH: layout.height };
    function applyViewBox() {
      svg.setAttribute("viewBox", `${viewBoxState.x} ${viewBoxState.y} ${viewBoxState.w} ${viewBoxState.h}`);
    }

    // Arrowhead marker (shared, tinted via CSS class on demand per-edge copy)
    const defs = svgEl("defs", {});
    const marker = svgEl("marker", {
      id: `fd-arrow-${Math.random().toString(36).slice(2, 8)}`,
      markerWidth: "8", markerHeight: "8", refX: "6", refY: "4", orient: "auto",
    });
    marker.appendChild(svgEl("path", { d: "M0,0 L8,4 L0,8 Z", class: "fd-arrowhead" }));
    defs.appendChild(marker);
    svg.appendChild(defs);

    const edgeLayer = svgEl("g", { class: "fd-edge-layer" });
    const nodeLayer = svgEl("g", { class: "fd-node-layer" });
    svg.appendChild(edgeLayer);
    svg.appendChild(nodeLayer);

    const byId = new Map(nodes.map((n) => [n.id, n]));
    const edgeEls = [];

    edges.forEach((e, i) => {
      const from = layout.pos.get(e.from);
      const to = layout.pos.get(e.to);
      if (!from || !to) return;
      const clipped = clampToRectEdge(from, to);
      const d = edgePath(from, isCycle ? to : { x: clipped.x - NODE_W / 2, y: clipped.y - NODE_H / 2 }, isCycle ? "cycle" : "flow");
      const path = svgEl("path", {
        d, class: "fd-edge-path", "marker-end": `url(#${marker.id})`,
        "data-from": e.from, "data-to": e.to,
        style: `animation-delay:${i * 90}ms`,
      });
      edgeLayer.appendChild(path);
      edgeEls.push(path);

      if (e.label) {
        const midX = (from.x + to.x) / 2 + NODE_W / 2;
        const midY = (from.y + to.y) / 2 + NODE_H / 2;
        const label = svgEl("text", { x: midX, y: midY - 6, class: "fd-edge-label", "text-anchor": "middle" });
        label.textContent = e.label;
        edgeLayer.appendChild(label);
      }
    });

    const detailBox = document.createElement("div");
    detailBox.className = "flow-diagram-detail";
    detailBox.innerHTML = def.hint || "Tap a node to see details here.";

    const nodeEls = new Map();
    nodes.forEach((n) => {
      const p = layout.pos.get(n.id);
      const g = svgEl("g", { class: "fd-node", transform: `translate(${p.x}, ${p.y})`, tabindex: "0", role: "button", "aria-label": n.label });
      const rectColor = n.color ? `var(${n.color})` : null;
      const rect = svgEl("rect", { width: NODE_W, height: NODE_H, rx: 12, ry: 12 });
      if (rectColor) rect.setAttribute("style", `stroke:${rectColor};`);
      g.appendChild(rect);

      const text = svgEl("text", {
        x: NODE_W / 2, y: NODE_H / 2, "text-anchor": "middle", "dominant-baseline": "middle",
        class: "fd-node-label",
      });
      wrapSvgText(text, n.label || n.id, NODE_W - 20);
      g.appendChild(text);

      g.addEventListener("click", () => selectNode(n.id));
      g.addEventListener("keydown", (ev) => {
        if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); selectNode(n.id); }
      });

      nodeLayer.appendChild(g);
      nodeEls.set(n.id, g);
    });

    function selectNode(id) {
      nodeEls.forEach((el, nid) => el.classList.toggle("active", nid === id));
      edgeEls.forEach((el) => {
        const touches = el.dataset.from === id || el.dataset.to === id;
        el.classList.toggle("lit", touches);
        el.classList.toggle("dimmed", !touches && (el.dataset.from !== undefined));
      });
      const node = byId.get(id);
      if (node) {
        detailBox.innerHTML = `<strong>${escapeHtml(node.label || node.id)}</strong>${node.detail ? " — " + escapeHtml(node.detail) : ""}`;
      }
    }

    container.appendChild(detailBox);

    // --- Pan + zoom ------------------------------------------------------
    let isDragging = false;
    let dragStart = null;
    svg.addEventListener("pointerdown", (ev) => {
      isDragging = true;
      svg.classList.add("grabbing");
      dragStart = { x: ev.clientX, y: ev.clientY, vb: { ...viewBoxState } };
      svg.setPointerCapture(ev.pointerId);
    });
    svg.addEventListener("pointermove", (ev) => {
      if (!isDragging) return;
      const scaleX = viewBoxState.w / svg.clientWidth;
      const scaleY = viewBoxState.h / svg.clientHeight;
      viewBoxState.x = dragStart.vb.x - (ev.clientX - dragStart.x) * scaleX;
      viewBoxState.y = dragStart.vb.y - (ev.clientY - dragStart.y) * scaleY;
      applyViewBox();
    });
    ["pointerup", "pointercancel", "pointerleave"].forEach((evt) =>
      svg.addEventListener(evt, () => { isDragging = false; svg.classList.remove("grabbing"); })
    );

    function zoomBy(factor) {
      const newW = Math.max(layout.baseW * 0.4, Math.min(layout.baseW * 2.2, viewBoxState.w * factor));
      const newH = viewBoxState.h * (newW / viewBoxState.w);
      viewBoxState.x += (viewBoxState.w - newW) / 2;
      viewBoxState.y += (viewBoxState.h - newH) / 2;
      viewBoxState.w = newW;
      viewBoxState.h = newH;
      applyViewBox();
    }
    toolbar.querySelector("[data-fd-zoom-in]").addEventListener("click", () => zoomBy(0.85));
    toolbar.querySelector("[data-fd-zoom-out]").addEventListener("click", () => zoomBy(1.18));
    toolbar.querySelector("[data-fd-zoom-reset]").addEventListener("click", () => {
      viewBoxState.x = 0; viewBoxState.y = 0; viewBoxState.w = layout.baseW; viewBoxState.h = layout.baseH;
      applyViewBox();
    });
    svg.addEventListener("wheel", (ev) => {
      ev.preventDefault();
      zoomBy(ev.deltaY > 0 ? 1.08 : 0.93);
    }, { passive: false });

    // Responsive re-layout is unnecessary since viewBox scaling already
    // handles resizing; ResizeObserver only needed if container width
    // changes drastically enough to warrant refitting the initial zoom.
    if (window.ResizeObserver) {
      new ResizeObserver(() => { /* viewBox-based scaling — no-op, kept for future refit hooks */ }).observe(container);
    }
  }

  function wrapSvgText(textEl, label, maxWidth) {
    const words = String(label).split(" ");
    const approxCharWidth = 7.2;
    const maxChars = Math.max(6, Math.floor(maxWidth / approxCharWidth));
    const lines = [];
    let current = "";
    words.forEach((w) => {
      const next = current ? current + " " + w : w;
      if (next.length > maxChars && current) {
        lines.push(current);
        current = w;
      } else {
        current = next;
      }
    });
    if (current) lines.push(current);
    const lineHeight = 14;
    const startY = -((lines.length - 1) * lineHeight) / 2;
    lines.slice(0, 3).forEach((line, i) => {
      const tspan = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
      tspan.setAttribute("x", 0);
      tspan.setAttribute("y", startY + i * lineHeight);
      tspan.textContent = line;
      textEl.appendChild(tspan);
    });
  }

  function escapeHtml(str) {
    return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function initAll() {
    document.querySelectorAll("[data-flow-diagram]").forEach((container) => {
      if (container.dataset.fdInitialized) return;
      const id = container.getAttribute("data-flow-diagram");
      const defScript = document.querySelector(`script[data-flow-diagram-def="${CSS.escape(id)}"]`);
      if (!defScript) return;
      let def;
      try { def = JSON.parse(defScript.textContent); } catch (err) {
        console.error("[diagram-engine] invalid diagram definition for", id, err);
        return;
      }
      container.dataset.fdInitialized = "true";
      render(container, def);
    });
  }

  window.CurioDiagram = { init: initAll, render };

  if (window.onLessonContentReady) {
    window.onLessonContentReady(initAll);
  } else if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initAll, { once: true });
  } else {
    initAll();
  }
})();
