// Curio Lab — Admin Dashboard Logic
(function () {
  const BACKEND_URL = "";
  let adminCache = null;

  async function api(path, opts) {
    const res = await fetch(`${BACKEND_URL}${path}`, {
      credentials: "include",
      ...opts,
      headers: { "Content-Type": "application/json", ...(opts?.headers || {}) },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Request failed.");
    return data;
  }

  function el(id) { return document.getElementById(id); }
  function esc(str) {
    const d = document.createElement("div");
    d.textContent = str == null ? "" : String(str);
    return d.innerHTML;
  }

  // ── Stats ──
  async function loadStats() {
    const data = await api("/api/admin/stats");
    el("stat-users").textContent = data.users;
    el("stat-admins").textContent = data.admins;
    el("stat-active-subs").textContent = data.subscriptions.active;
    el("stat-revenue").textContent = `₹${Number(data.subscriptions.revenue).toFixed(0)}`;
    el("stat-total-subs").textContent = data.subscriptions.total;
    el("stat-today").textContent = data.audit.today;
    el("stat-total-events").textContent = data.audit.total;
    el("stat-suspicious").textContent = data.audit.suspicious;
    el("stat-logins").textContent = data.audit.logins;
    el("stat-signups").textContent = data.audit.signups;
  }

  // ── Users table ──
  async function loadUsers() {
    const data = await api("/api/admin/users");
    const tbody = el("users-tbody");
    if (!data.users.length) {
      tbody.innerHTML = `<tr><td colspan="5" class="empty-state">No users yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = data.users.map(u => `<tr>
      <td class="mono">${u.id}</td>
      <td>${esc(u.name)}</td>
      <td class="mono">${esc(u.email)}</td>
      <td><span class="badge badge-blue">${esc(u.provider)}</span></td>
      <td class="small">${new Date(u.created_at * 1000).toLocaleDateString()}</td>
    </tr>`).join("");
  }

  // ── Audit logs ──
  async function loadAuditLogs() {
    const actionFilter = document.getElementById("audit-filter")?.value || "";
    let url = "/api/admin/audit-logs?limit=200";
    if (actionFilter) url += `&action=${encodeURIComponent(actionFilter)}`;
    const data = await api(url);
    const tbody = el("audit-tbody");
    if (!data.logs.length) {
      tbody.innerHTML = `<tr><td colspan="5" class="empty-state">No audit events.</td></tr>`;
      return;
    }
    tbody.innerHTML = data.logs.map(log => {
      const date = new Date(log.created_at * 1000).toLocaleString();
      let badgeClass = "badge-blue";
      if (log.action === "suspicious_activity") badgeClass = "badge-red";
      else if (log.action === "failed_login" || log.action === "failed_admin_login") badgeClass = "badge-amber";
      else if (log.action === "login" || log.action === "admin_login") badgeClass = "badge-green";
      else if (log.action === "logout" || log.action === "admin_logout") badgeClass = "badge-blue";
      else if (log.action === "signup") badgeClass = "badge-teal";
      return `<tr>
        <td class="small">${date}</td>
        <td><span class="badge ${badgeClass}">${esc(log.action)}</span></td>
        <td>${esc(log.user_name || "-")}</td>
        <td class="mono">${esc(log.user_email || "-")}</td>
        <td class="small">${esc(log.detail || "-")}</td>
      </tr>`;
    }).join("");
  }

  // ── Subscriptions ──
  async function loadSubscriptions() {
    const data = await api("/api/admin/subscriptions");
    const tbody = el("subs-tbody");
    if (!data.subscriptions.length) {
      tbody.innerHTML = `<tr><td colspan="6" class="empty-state">No subscriptions yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = data.subscriptions.map(s => {
      const statusBadge = s.status === "active"
        ? `<span class="badge badge-green">active</span>`
        : `<span class="badge badge-red">${esc(s.status)}</span>`;
      return `<tr>
        <td class="mono">${s.id}</td>
        <td>${esc(s.name || "—")}</td>
        <td class="mono">${esc(s.email || "—")}</td>
        <td><span class="badge badge-amber">${esc(s.plan)}</span></td>
        <td>${s.amount ? `₹${Number(s.amount).toFixed(2)}` : "—"}</td>
        <td>${statusBadge}</td>
      </tr>`;
    }).join("");
  }

  // ── Admins ──
  async function loadAdmins() {
    const data = await api("/api/admin/admins");
    const tbody = el("admins-tbody");
    if (!data.admins.length) {
      tbody.innerHTML = `<tr><td colspan="5" class="empty-state">No admins.</td></tr>`;
      return;
    }
    tbody.innerHTML = data.admins.map(a => {
      const activeBadge = a.is_active
        ? `<span class="badge badge-green">active</span>`
        : `<span class="badge badge-red">inactive</span>`;
      const roleBadge = a.role === "superadmin"
        ? `<span class="badge badge-amber">superadmin</span>`
        : `<span class="badge badge-blue">admin</span>`;
      const toggleHtml = a.role === "superadmin"
        ? `<span class="small">—</span>`
        : `<button class="toggle-btn ${a.is_active ? "danger" : ""}" data-toggle-admin="${a.id}">${a.is_active ? "Deactivate" : "Activate"}</button>`;
      return `<tr>
        <td class="mono">${a.id}</td>
        <td>${esc(a.name)}</td>
        <td class="mono">${esc(a.email)}</td>
        <td>${roleBadge} ${activeBadge}</td>
        <td>${toggleHtml}</td>
      </tr>`;
    }).join("");

    // Bind toggle buttons
    tbody.querySelectorAll("[data-toggle-admin]").forEach(btn => {
      btn.addEventListener("click", async () => {
        const adminId = btn.dataset.toggleAdmin;
        try {
          await api(`/api/admin/admins/${adminId}/toggle`, { method: "POST" });
          loadAdmins();
          window.CurioToast?.show("Admin status toggled.", { icon: "✓" });
        } catch (err) {
          window.CurioToast?.show(err.message, { icon: "⚠️", duration: 5000 });
        }
      });
    });
  }

  // ── Invite admin ──
  function setupInviteForm() {
    const form = el("invite-form");
    if (!form) return;
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const btn = form.querySelector("[data-invite-btn]");
      btn.disabled = true; btn.textContent = "Creating…";
      try {
        await api("/api/admin/invite", {
          method: "POST",
          body: JSON.stringify({
            email: el("invite-email").value,
            name: el("invite-name").value,
            password: el("invite-password").value,
            role: el("invite-role").value,
          }),
        });
        window.CurioToast?.show("Admin created.", { icon: "✓" });
        form.reset();
        loadAdmins();
      } catch (err) {
        window.CurioToast?.show(err.message, { icon: "⚠️", duration: 5000 });
      }
      btn.disabled = false; btn.textContent = "Create Admin";
    });
  }

  // ── Setup superadmin form ──
  function setupSetupForm() {
    const form = el("setup-form");
    if (!form) return;
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const btn = form.querySelector("[data-setup-btn]");
      btn.disabled = true; btn.textContent = "Creating…";
      try {
        await api("/api/admin/setup", {
          method: "POST",
          body: JSON.stringify({
            email: el("setup-email").value,
            name: el("setup-name").value,
            password: el("setup-password").value,
          }),
        });
        window.CurioToast?.show("Superadmin created! Redirecting…", { icon: "✓" });
        setTimeout(() => { window.location.href = "dashboard.html"; }, 800);
      } catch (err) {
        window.CurioToast?.show(err.message, { icon: "⚠️", duration: 5000 });
      }
      btn.disabled = false; btn.textContent = "Create Superadmin";
    });
  }

  // ── Logout ──
  function setupLogout() {
    document.querySelectorAll("[data-admin-logout]").forEach(el => {
      el.addEventListener("click", async () => {
        await window.CurioAdminAuth.logout();
        window.location.href = "login.html";
      });
    });
  }

  // ── Tabs / navigation highlight ──
  function highlightNav() {
    const page = window.location.pathname.split("/").pop() || "dashboard.html";
    document.querySelectorAll("[data-admin-nav]").forEach(a => {
      const href = a.getAttribute("href");
      a.classList.toggle("active", href === page);
    });
  }

  // ── Init ──
  document.addEventListener("DOMContentLoaded", async () => {
    highlightNav();
    setupLogout();

    const currentPage = window.location.pathname.split("/").pop() || "";

    // setup.html is the one admin page meant to be used with nobody logged in yet
    // (it's how the very first superadmin account gets created).
    if (currentPage === "setup.html") {
      setupSetupForm();
      return;
    }

    // Every other admin page requires a real logged-in admin session.
    const admin = await window.CurioAdminAuth.checkSession();
    if (!admin) {
      window.location.href = "login.html";
      return;
    }

    // Fill admin info in topbar
    document.querySelectorAll("[data-admin-name]").forEach(el => { el.textContent = admin.name; });
    document.querySelectorAll("[data-admin-role]").forEach(el => { el.textContent = admin.role; });

    setupInviteForm();

    // Load data sections only if their target elements exist
    if (el("stat-users")) loadStats();
    if (el("users-tbody")) loadUsers();
    if (el("audit-tbody")) { loadAuditLogs(); }
    if (el("subs-tbody")) loadSubscriptions();
    if (el("admins-tbody")) loadAdmins();

    // Audit filter change
    const auditFilter = el("audit-filter");
    if (auditFilter) {
      auditFilter.addEventListener("change", loadAuditLogs);
    }

    // Refresh button
    const refreshBtn = el("refresh-btn");
    if (refreshBtn) {
      refreshBtn.addEventListener("click", () => {
        if (el("stat-users")) loadStats();
        if (el("users-tbody")) loadUsers();
        if (el("audit-tbody")) loadAuditLogs();
        if (el("subs-tbody")) loadSubscriptions();
        if (el("admins-tbody")) loadAdmins();
        window.CurioToast?.show("Refreshed.", { icon: "↻" });
      });
    }
  });
})();
