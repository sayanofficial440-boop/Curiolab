// Curio Lab — Lesson redesign interaction layer.
// Everything here is ADDITIVE: it only reads existing data-* hooks and adds
// classes/elements around them. It never replaces logic in quiz.js,
// flashcards.js, slides.js, timer.js, etc. Safe to drop onto any lesson page
// that already includes lesson-ready.js + lesson.css + lesson-redesign.css.
window.onLessonContentReady(() => {
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  initProgressRail();
  initTabDock();
  initTimerRing();
  initFlashcardFx();
  initSlideFx();
  initQuizFx();
  initModelFullscreen();
  initReaderFx();
  initCodeFx();

  // ---------------- Reading progress rail ----------------
  function initProgressRail() {
    const rail = document.createElement("div");
    rail.className = "lesson-progress-rail";
    document.body.appendChild(rail);
    function update() {
      const h = document.documentElement;
      const scrolled = h.scrollTop;
      const max = h.scrollHeight - h.clientHeight;
      const pct = max > 0 ? Math.min(100, (scrolled / max) * 100) : 0;
      rail.style.setProperty("--progress", pct + "%");
    }
    document.addEventListener("scroll", update, { passive: true });
    update();
  }

  // ---------------- Sliding tab pill + visited tracking + keyboard + fade edges ----------------
  function initTabDock() {
    const dock = document.querySelector(".mode-tabs");
    const tabs = Array.from(document.querySelectorAll("[data-tab]"));
    if (!dock || !tabs.length) return;

    tabs.forEach((t) => {
      const dot = document.createElement("span");
      dot.className = "mode-tab-visited";
      t.appendChild(dot);
      t.setAttribute("tabindex", "-1");
    });

    function markVisited(tab) { tab.classList.add("is-visited"); }

    tabs.forEach((t) => t.addEventListener("click", () => {
      markVisited(t);
      t.setAttribute("tabindex", "0");
      tabs.forEach((o) => { if (o !== t) o.setAttribute("tabindex", "-1"); });
      t.scrollIntoView({ behavior: reduce ? "auto" : "smooth", inline: "center", block: "nearest" });
    }));

    // Left/Right arrow keys move focus + activate the neighboring tab.
    dock.addEventListener("keydown", (e) => {
      if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
      const active = dock.querySelector(".mode-tab.active");
      const idx = tabs.indexOf(active);
      if (idx === -1) return;
      e.preventDefault();
      const nextIdx = e.key === "ArrowRight" ? (idx + 1) % tabs.length : (idx - 1 + tabs.length) % tabs.length;
      tabs[nextIdx].click();
      tabs[nextIdx].focus();
    });

    const active = dock.querySelector(".mode-tab.active") || tabs[0];
    active.setAttribute("tabindex", "0");
    requestAnimationFrame(() => { markVisited(active); });
    window.addEventListener("resize", () => { syncFadeEdges(); });

    // Fade edges only appear when the dock actually overflows horizontally.
    function syncFadeEdges() {
      dock.classList.toggle("can-scroll", dock.scrollWidth > dock.clientWidth + 2);
      dock.classList.toggle("at-start", dock.scrollLeft < 4);
      dock.classList.toggle("at-end", dock.scrollLeft + dock.clientWidth > dock.scrollWidth - 4);
    }
    dock.addEventListener("scroll", syncFadeEdges, { passive: true });
    requestAnimationFrame(syncFadeEdges);
  }

  // ---------------- Timer → radial progress ring ----------------
  function initTimerRing() {
    const widget = document.querySelector(".timer-widget");
    const display = document.querySelector("[data-timer-display]");
    if (!widget || !display) return;

    const MODE_TOTAL = { focus: 25 * 60, short: 5 * 60, long: 15 * 60 };
    let total = MODE_TOTAL.focus;

    const R = 46;
    const circ = 2 * Math.PI * R;
    const ringWrap = document.createElement("div");
    ringWrap.className = "timer-ring-wrap";
    ringWrap.innerHTML = `
      <svg viewBox="0 0 100 100">
        <circle class="timer-ring-track" cx="50" cy="50" r="${R}" fill="none" stroke-width="6"/>
        <circle class="timer-ring-bar" cx="50" cy="50" r="${R}" fill="none" stroke-width="6"
          stroke-dasharray="${circ}" stroke-dashoffset="0"/>
      </svg>`;
    display.replaceWith(ringWrap);
    ringWrap.appendChild(display);
    const bar = ringWrap.querySelector(".timer-ring-bar");

    function syncFromDisplay() {
      const [m, s] = display.textContent.split(":").map(Number);
      const secondsLeft = m * 60 + s;
      const frac = Math.max(0, Math.min(1, secondsLeft / total));
      bar.style.strokeDashoffset = String(circ * (1 - frac));
      widget.style.setProperty("--tprog", String(Math.round((1 - frac) * 100)));
    }

    document.querySelectorAll("[data-timer-mode]").forEach((btn) => {
      btn.addEventListener("click", () => {
        total = MODE_TOTAL[btn.dataset.timerMode] || MODE_TOTAL.focus;
        syncFromDisplay();
      });
    });
    document.querySelector("[data-timer-start]")?.addEventListener("click", () => {
      widget.classList.toggle("is-running");
    });
    document.querySelector("[data-timer-reset]")?.addEventListener("click", () => {
      widget.classList.remove("is-running");
      requestAnimationFrame(syncFromDisplay);
    });

    const mo = new MutationObserver(syncFromDisplay);
    mo.observe(display, { childList: true, characterData: true, subtree: true });
    syncFromDisplay();
  }

  // ---------------- Flashcards: stack deco + hover tilt/glow + swipe ----------------
  function initFlashcardFx() {
    const card = document.querySelector("[data-flashcard]");
    if (!card) return;

    const deco1 = document.createElement("div"); deco1.className = "flashcard-stack-deco";
    const deco2 = document.createElement("div"); deco2.className = "flashcard-stack-deco";
    card.parentElement.insertBefore(deco2, card);
    card.parentElement.insertBefore(deco1, card);

    // Hover tilt + cursor-follow glow (desktop only, skipped for reduced motion / touch)
    if (!reduce && matchMedia("(hover: hover)").matches) {
      card.addEventListener("pointermove", (e) => {
        if (card.classList.contains("dragging")) return;
        const r = card.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width;
        const py = (e.clientY - r.top) / r.height;
        card.style.setProperty("--mx", `${px * 100}%`);
        card.style.setProperty("--my", `${py * 100}%`);
        const rotY = (px - 0.5) * 10;
        const rotX = (0.5 - py) * 10;
        card.style.transform = `rotateX(${rotX}deg) rotateY(${rotY}deg)`;
      });
      card.addEventListener("pointerleave", () => {
        if (!card.classList.contains("dragging")) card.style.transform = "";
      });
    }

    // Swipe/drag to flip
    if (reduce) return;
    let startX = 0, dragging = false;
    card.addEventListener("pointerdown", (e) => { startX = e.clientX; dragging = true; card.classList.add("dragging"); });
    window.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const dx = e.clientX - startX;
      card.style.transform = `translateX(${dx * 0.15}px) rotate(${dx * 0.02}deg)`;
    });
    window.addEventListener("pointerup", (e) => {
      if (!dragging) return;
      dragging = false;
      card.classList.remove("dragging");
      card.style.transform = "";
      const dx = e.clientX - startX;
      if (Math.abs(dx) > 60) {
        (dx < 0 ? document.querySelector("[data-card-next]") : document.querySelector("[data-card-prev]"))?.click();
      }
    });
  }

  // ---------------- Slides: directional transition + progress bar + swipe ----------------
  function initSlideFx() {
    const frame = document.querySelector("[data-slide-frame]");
    if (!frame) return;
    const prevBtn = document.querySelector("[data-slide-prev]");
    const nextBtn = document.querySelector("[data-slide-next]");
    let deck = [];
    try { deck = JSON.parse(document.querySelector("[data-slide-deck]").textContent); } catch (e) { /* noop */ }

    const bar = document.createElement("div");
    bar.className = "slide-progress-bar";
    bar.innerHTML = "<span></span>";
    frame.querySelector(".slide-controls")?.insertAdjacentElement("afterend", bar);
    const fill = bar.querySelector("span");

    function flash(dir) {
      frame.setAttribute("data-dir", dir);
      window.requestAnimationFrame(() => {
        setTimeout(() => frame.removeAttribute("data-dir"), 360);
      });
    }
    function syncProgress() {
      const eyebrow = document.querySelector("[data-slide-eyebrow]");
      if (!eyebrow || !deck.length) return;
      const cur = parseInt(eyebrow.textContent.match(/\d+/)?.[0] || "1", 10);
      fill.style.width = (cur / deck.length) * 100 + "%";
    }
    prevBtn?.addEventListener("click", () => { flash("prev"); syncProgress(); });
    nextBtn?.addEventListener("click", () => { flash("next"); syncProgress(); });
    syncProgress();

    if (reduce) return;
    let startX = 0, tracking = false;
    frame.addEventListener("pointerdown", (e) => {
      if (e.target.closest("button")) return;
      startX = e.clientX; tracking = true;
    });
    frame.addEventListener("pointerup", (e) => {
      if (!tracking) return;
      tracking = false;
      const dx = e.clientX - startX;
      if (Math.abs(dx) > 60) (dx < 0 ? nextBtn : prevBtn)?.click();
    });
  }

  // ---------------- Quiz: dot rail (confetti/score-ring handled directly by quiz.js) ----------------
  function initQuizFx() {
    const shell = document.querySelector("[data-quiz]");
    if (!shell) return;
    const progressEl = shell.querySelector("[data-quiz-progress]");
    if (!progressEl) return;

    // quiz.js runs its onLessonContentReady callback before this one (script
    // order), so by now progressEl already reads "Question 1 of N" where N
    // is the randomized session length, not the full question bank size.
    const totalMatch = progressEl.textContent.match(/of (\d+)/);
    const total = totalMatch ? parseInt(totalMatch[1], 10) : 0;
    if (!total) return;

    const railWrap = document.createElement("div");
    railWrap.className = "quiz-dot-rail";
    for (let n = 0; n < total; n++) railWrap.appendChild(document.createElement("span"));
    progressEl.insertAdjacentElement("beforebegin", railWrap);

    function syncRail() {
      const m = progressEl.textContent.match(/Question (\d+)/);
      const cur = m ? parseInt(m[1], 10) - 1 : 0;
      railWrap.querySelectorAll("span").forEach((d, idx) => {
        d.classList.toggle("done", idx < cur);
        d.classList.toggle("current", idx === cur);
      });
    }
    new MutationObserver(syncRail).observe(progressEl, { childList: true });
    syncRail();
  }

  window.CurioConfetti = { burst: burstConfetti };

  function burstConfetti(big) {
    if (reduce) return;
    const colors = ["#2E8E80", "#D68C1F", "#C94A38", "#12213B", "#5F7A34"];
    const count = big ? 70 : 36;
    for (let i = 0; i < count; i++) {
      const piece = document.createElement("div");
      piece.className = "quiz-confetti-piece";
      const size = 6 + Math.random() * 6;
      piece.style.left = Math.random() * 100 + "vw";
      piece.style.width = size + "px";
      piece.style.height = size * 0.4 + "px";
      piece.style.background = colors[i % colors.length];
      piece.style.animationDuration = 1.6 + Math.random() * 1.2 + "s";
      piece.style.animationDelay = Math.random() * 0.3 + "s";
      document.body.appendChild(piece);
      piece.addEventListener("animationend", () => piece.remove());
    }
  }

  // ---------------- Annotated reader / diagram analysis card pop ----------------
  function initReaderFx() {
    const card = document.querySelector("[data-analysis-card]");
    const annots = document.querySelectorAll("[data-annot]");
    if (!card || !annots.length) return;
    const mo = new MutationObserver(() => {
      card.classList.remove("just-updated");
      void card.offsetWidth; // restart animation
      card.classList.add("just-updated");
    });
    mo.observe(card, { childList: true });
  }

  // ---------------- Code playground: run pulse + console stagger ----------------
  function initCodeFx() {
    const runBtn = document.querySelector("[data-code-run]");
    const consoleEl = document.querySelector("[data-code-console]");
    if (!runBtn) return;
    runBtn.addEventListener("click", () => {
      runBtn.classList.remove("is-running");
      void runBtn.offsetWidth;
      runBtn.classList.add("is-running");
      if (!consoleEl || reduce) return;
      setTimeout(() => {
        Array.from(consoleEl.children).forEach((line, i) => {
          line.style.animationDelay = i * 0.04 + "s";
        });
      }, 0);
    });
  }

  // ---------------- Model/graph/diagram panels: fullscreen toggle ----------------
  function initModelFullscreen() {
    document.querySelectorAll(".model-panel").forEach((panel) => {
      if (!panel.querySelector(".model-canvas") && !panel.querySelector("svg")) return;
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "model-fullscreen-btn";
      btn.setAttribute("aria-label", "Toggle fullscreen");
      btn.textContent = "⤢";
      panel.style.position = panel.style.position || "relative";
      panel.appendChild(btn);
      btn.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          panel.requestFullscreen?.().catch(() => {});
        } else {
          document.exitFullscreen?.();
        }
      });
      document.addEventListener("fullscreenchange", () => {
        btn.textContent = document.fullscreenElement === panel ? "⤡" : "⤢";
        window.dispatchEvent(new Event("resize"));
      });
    });
  }
});
