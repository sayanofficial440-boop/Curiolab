// Curio Lab — Annotated Reader (English centerpiece: click a phrase, see the analysis)
window.onLessonContentReady(() => {
  const annots = document.querySelectorAll("[data-annot]");
  const card = document.querySelector("[data-analysis-card]");
  if (!annots.length || !card) return;

  function show(el) {
    annots.forEach((a) => a.classList.remove("active"));
    el.classList.add("active");
    if (window.CurioSound) window.CurioSound.play("open");
    card.innerHTML = `
      <span class="device-tag">${el.dataset.device}</span>
      <p class="quoted">"${el.textContent.trim()}"</p>
      <p>${el.dataset.note}</p>
    `;
  }

  annots.forEach((el) => el.addEventListener("click", () => show(el)));
});
