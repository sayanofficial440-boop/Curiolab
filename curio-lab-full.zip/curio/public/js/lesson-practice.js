// Curio Lab — adds a "Practice" tab to every lesson page.
//
// The lesson's own flashcards and quiz questions become five practice modes (Smart Cards,
// Type It, Fill the Blank, Explain It, True or False) next to the existing Quiz tab.
//
// This file is deliberately tiny and loads before js/lesson-tabs.js, so the tab exists when the
// tab bar is wired up. The heavy parts (practice-text/store/engine + CSS) load the first time the
// tab is opened, so lessons that never use it pay nothing.
(function () {
  "use strict";
  const me = document.currentScript;
  if (!me || window.__curioLessonPractice) return;
  window.__curioLessonPractice = true;
  const JS = new URL("./", me.src).href;                   // …/js/
  const SITE = new URL("../", JS).href;                    // site root
  const PAGES = SITE + "pages/";

  function inject() {
    const tabs = document.querySelector(".mode-tabs");
    const quizPanel = document.querySelector('.mode-panel[data-panel="quiz"]');
    if (!tabs || !quizPanel || document.querySelector('[data-tab="practice"]')) return;
    // Needs a deck or quiz to practise with.
    if (!document.querySelector("script[data-card-deck]") && !document.querySelector("script[data-quiz-data]")) return;

    const btn = document.createElement("button");
    btn.className = "mode-tab";
    btn.type = "button";
    btn.dataset.tab = "practice";
    btn.textContent = "🏋️ Practice";
    const quizTab = tabs.querySelector('[data-tab="quiz"]');
    if (quizTab) quizTab.insertAdjacentElement("afterend", btn); else tabs.appendChild(btn);

    const panel = document.createElement("section");
    panel.className = "mode-panel";
    panel.dataset.panel = "practice";
    panel.innerHTML = '<div class="pr-lessonhead"><h2>Practice this lesson</h2><p>Quizzes check what you recognise. These modes make you <em>recall</em> — which is what actually builds memory.</p></div><div data-practice-mount><p class="pr-note" style="padding:1rem 0">Loading practice tools…</p></div>';
    quizPanel.insertAdjacentElement("afterend", panel);
  }

  function lessonMeta() {
    const shell = document.querySelector("[data-quiz]");
    const m = location.pathname.match(/\/pages\/([^/]+)\/([^/]+?)\.html$/);
    const q = new URLSearchParams(location.search);
    const key = m ? m[1] + "/" + m[2] : (q.get("subject") && q.get("lesson") ? q.get("subject") + "/" + q.get("lesson") : location.pathname.replace(/^\/|\.html$/g, ""));
    const h1 = document.querySelector("h1");
    return {
      lessonKey: key,
      lesson: (shell && shell.dataset.quizLesson) || (h1 && h1.textContent.trim()) || "Lesson",
      subject: (shell && shell.dataset.quizSubject) || (m ? m[1] : "Subject"),
      href: location.pathname.replace(/^.*\/pages\//, "") + location.search,
    };
  }

  function loadCss(href) {
    if (document.querySelector(`link[href="${href}"]`)) return;
    const l = document.createElement("link"); l.rel = "stylesheet"; l.href = href; document.head.appendChild(l);
  }
  function loadScript(src) {
    return new Promise((res, rej) => {
      const s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = () => rej(new Error("Could not load " + src)); document.head.appendChild(s);
    });
  }

  let started = false;
  async function boot() {
    if (started) return; started = true;
    const host = document.querySelector("[data-practice-mount]");
    if (!host) return;
    loadCss(SITE + "css/practice.css");
    try {
      for (const f of ["practice-text.js", "practice-store.js", "practice-engine.js"]) if (!document.querySelector(`script[src="${JS + f}"]`)) await loadScript(JS + f);
      host.innerHTML = "";
      const meta = lessonMeta();
      const items = window.CurioPractice.itemsFromPage(meta);
      window.CurioPractice.mount(host, { items, emptyText: "This lesson has no flashcards or quiz questions to practise with yet." });
    } catch (err) {
      host.innerHTML = '<p class="pr-note">Practice tools could not be loaded. Check your connection and reopen this tab.</p>';
      started = false;
      console.error("[lesson-practice]", err);
    }
  }

  window.addEventListener("curiolab:tab-shown", (e) => { if (e.detail && e.detail.name === "practice") boot(); });

  // Register BEFORE lesson-tabs.js so the tab is in the DOM when the tab bar is wired.
  if (typeof window.onLessonContentReady === "function") window.onLessonContentReady(inject);
  else document.addEventListener("DOMContentLoaded", inject);
})();
