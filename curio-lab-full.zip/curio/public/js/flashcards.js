// Curio Lab — Photo / Flash cards
window.onLessonContentReady(() => {
  const card = document.querySelector("[data-flashcard]");
  if (!card) return;

  const front = card.querySelector("[data-card-front]");
  const back = card.querySelector("[data-card-back]");
  const counter = document.querySelector("[data-card-counter]");
  const prevBtn = document.querySelector("[data-card-prev]");
  const nextBtn = document.querySelector("[data-card-next]");
  const nav = document.querySelector(".card-nav");
  const panel = document.querySelector('[data-panel="cards"]');

  let deck = [];
  try {
    deck = JSON.parse(document.querySelector("[data-card-deck]").textContent);
  } catch (e) {
    deck = [];
  }
  // Tag each card with a stable id (based on its term) so mastery survives shuffles.
  deck.forEach((c) => { c.__id = c.term; });
  // Randomize the order each time the lesson is opened.
  for (let k = deck.length - 1; k > 0; k--) {
    const j = Math.floor(Math.random() * (k + 1));
    [deck[k], deck[j]] = [deck[j], deck[k]];
  }

  const MASTERY_KEY = `curiolab-mastery-${window.location.pathname}`;
  let mastered = new Set();
  try { mastered = new Set(JSON.parse(localStorage.getItem(MASTERY_KEY)) || []); } catch (e) { mastered = new Set(); }
  function saveMastery() { localStorage.setItem(MASTERY_KEY, JSON.stringify([...mastered])); }

  let i = 0;

  // ---- Progress / mastery dot rail ----
  const dotsWrap = document.createElement("div");
  dotsWrap.className = "flashcard-progress";
  nav?.insertAdjacentElement("afterend", dotsWrap);

  function renderDots() {
    dotsWrap.innerHTML = "";
    deck.forEach((c, idx) => {
      const dot = document.createElement("span");
      if (idx === i) dot.classList.add("current");
      if (mastered.has(c.__id)) dot.classList.add("known");
      dotsWrap.appendChild(dot);
    });
  }

  // ---- Toolbar: shuffle + "I know this" ----
  const toolbar = document.createElement("div");
  toolbar.className = "flashcard-toolbar";
  const shuffleBtn = document.createElement("button");
  shuffleBtn.type = "button";
  shuffleBtn.className = "timer-btn flashcard-shuffle";
  shuffleBtn.innerHTML = "🔀 Shuffle";
  const knowBtn = document.createElement("button");
  knowBtn.type = "button";
  knowBtn.className = "timer-btn flashcard-know";
  const masteryCount = document.createElement("span");
  masteryCount.className = "flashcard-mastery-count";
  toolbar.append(shuffleBtn, knowBtn, masteryCount);
  nav?.insertAdjacentElement("beforebegin", toolbar);

  function render() {
    card.classList.remove("flipped");
    front.textContent = deck[i].term;
    back.textContent = deck[i].def;
    if (counter) counter.textContent = `${i + 1} / ${deck.length}`;
    knowBtn.textContent = mastered.has(deck[i].__id) ? "✓ Known" : "I know this";
    knowBtn.classList.toggle("is-known", mastered.has(deck[i].__id));
    masteryCount.textContent = `${mastered.size}/${deck.length} mastered`;
    renderDots();
  }

  function flip() { card.classList.toggle("flipped"); }
  function goPrev() { i = (i - 1 + deck.length) % deck.length; render(); }
  function goNext() { i = (i + 1) % deck.length; render(); }

  card.addEventListener("click", flip);
  prevBtn?.addEventListener("click", goPrev);
  nextBtn?.addEventListener("click", goNext);

  shuffleBtn.addEventListener("click", () => {
    for (let k = deck.length - 1; k > 0; k--) {
      const j = Math.floor(Math.random() * (k + 1));
      [deck[k], deck[j]] = [deck[j], deck[k]];
    }
    i = 0;
    card.classList.add("just-shuffled");
    setTimeout(() => card.classList.remove("just-shuffled"), 400);
    render();
  });

  knowBtn.addEventListener("click", () => {
    const id = deck[i].__id;
    if (mastered.has(id)) mastered.delete(id); else mastered.add(id);
    saveMastery();
    render();
    if (mastered.size === deck.length) {
      knowBtn.classList.add("all-mastered-pulse");
      setTimeout(() => knowBtn.classList.remove("all-mastered-pulse"), 700);
    }
  });

  // ---- Keyboard: arrows to navigate, space/enter to flip (only while this panel is active) ----
  document.addEventListener("keydown", (e) => {
    if (!panel || !panel.classList.contains("active")) return;
    if (["ArrowLeft", "ArrowRight", " ", "Enter"].includes(e.key)) {
      const tag = document.activeElement?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.key === "ArrowLeft") { e.preventDefault(); goPrev(); }
      else if (e.key === "ArrowRight") { e.preventDefault(); goNext(); }
      else { e.preventDefault(); flip(); }
    }
  });

  if (deck.length) render();
});
