/* Curio Lab - first-party error reports + optional, consent-gated analytics.
 *
 * Errors: uncaught JavaScript errors and unhandled promise rejections are sent to /api/client-error on our own server
 *   (no third party). A report has the message, a short stack, the page PATH (no query or hash) and the script path. No
 *   cookies, no account details, no user agent. Max 5 per page view. Silent when the backend is not there (static hosting).
 * Analytics: OFF unless site.config.json sets analytics.plausibleDomain. When set, the cookie banner shows an "analytics" switch,
 *   the script loads only after the visitor allows it, never for child accounts or under-13 age screens, never on admin pages,
 *   and never when the browser sends Do Not Track / Global Privacy Control. Plausible sets no cookies.
 * Config comes from js/site-config.js (generated: node scripts/build-runtime-config.mjs). Must load BEFORE cookie-consent.js. */
(function () {
  "use strict";
  var cfg = window.CURIO_CONFIG || {};
  var an = cfg.analytics || {};
  if (an.plausibleDomain) window.CURIO_CONSENT_CONFIG = Object.assign({}, window.CURIO_CONSENT_CONFIG || {}, { analytics: true });

  var isAdmin = /\/pages\/admin\//.test(location.pathname);
  var http = /^https?:$/.test(location.protocol);

  /* ---- error reports ---- */
  if (http && cfg.errorReporting !== false && !isAdmin) {
    var sent = 0, seen = {};
    var send = function (message, stack, source, line) {
      if (sent >= 5 || !message) return;
      var key = message + "|" + source + "|" + line;
      if (seen[key]) return; seen[key] = 1; sent++;
      var body = JSON.stringify({ message: String(message).slice(0, 300), stack: String(stack || "").slice(0, 1500), page: location.pathname, source: source ? String(source).split("?")[0] : "", line: line || 0 });
      try {
        if (navigator.sendBeacon) { if (navigator.sendBeacon("/api/client-error", new Blob([body], { type: "application/json" }))) return; }
        fetch("/api/client-error", { method: "POST", headers: { "Content-Type": "application/json" }, body: body, keepalive: true }).catch(function () {});
      } catch (e) { /* never let reporting break the page */ }
    };
    window.addEventListener("error", function (e) {
      if (e.target && e.target !== window) return; // resource load failures are noisy; only script errors
      send(e.message, e.error && e.error.stack, e.filename, e.lineno);
    });
    window.addEventListener("unhandledrejection", function (e) {
      var r = e.reason; send("Unhandled rejection: " + (r && r.message ? r.message : r), r && r.stack, "", 0);
    });
  }

  /* ---- analytics (Plausible), only with consent ---- */
  if (!an.plausibleDomain || isAdmin || !http) return;
  var loaded = false;
  function maybeLoad() {
    if (loaded || !window.CurioConsent) return;
    var c = window.CurioConsent.get();
    var dnt = navigator.doNotTrack === "1" || window.doNotTrack === "1" || navigator.globalPrivacyControl;
    var child = window.CurioAge && window.CurioAge.isChild && window.CurioAge.isChild();
    if (!c.analytics || dnt || child) return;
    loaded = true;
    var s = document.createElement("script");
    s.defer = true; s.setAttribute("data-domain", an.plausibleDomain);
    s.src = an.plausibleScript || "https://plausible.io/js/script.js";
    document.head.appendChild(s);
  }
  window.addEventListener("DOMContentLoaded", function () {
    if (!window.CurioConsent) return;
    maybeLoad();
    window.CurioConsent.onChange(maybeLoad);
  });
})();
