// Curio Lab — dashboard "Exam readiness" card. Shows an exam in progress (resume),
// otherwise your readiness estimate and the next best paper. Real data only (CurioExam).
(function () {
  "use strict";
  const X = window.CurioExam, L = window.CurioLearning;
  const anchor = document.querySelector("[data-extras]") || document.querySelector("[data-review-card]") || document.querySelector(".greet-row");
  if (!X || !anchor || document.querySelector("[data-exam-card]")) return;
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const style = document.createElement("style");
  style.textContent = `
  .xd-card{display:flex;align-items:center;gap:16px;flex-wrap:wrap;background:var(--panel,#fff);border:1px solid var(--line,#e5e1f4);border-radius:var(--radius,16px);padding:14px 18px;margin:0 0 20px;box-shadow:var(--shadow);text-decoration:none;color:inherit}
  .xd-card:hover{border-color:var(--accent,#6547da)}
  .xd-card:focus-visible{outline:2px solid var(--accent,#6547da);outline-offset:2px}
  .xd-card.live{border-color:var(--accent,#6547da)}
  .xd-ring{width:54px;height:54px;border-radius:50%;display:grid;place-items:center;flex:none;font-size:13px;font-weight:700;background:conic-gradient(var(--accent,#6547da) calc(var(--p,0)*1%),var(--line-soft,#f0eef9) 0)}
  .xd-ring span{width:42px;height:42px;border-radius:50%;background:var(--panel,#fff);display:grid;place-items:center}
  .xd-ic{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;font-size:20px;background:var(--accent-soft,#efeaff);flex:none}
  .xd-tx{flex:1;min-width:180px}.xd-tx strong{display:block;font-size:14px;font-weight:700}.xd-tx span{font-size:12.5px;color:var(--ink-soft,#5b5f68)}
  .xd-go{background:var(--accent,#6547da);color:#fff;border-radius:10px;padding:9px 16px;font-size:13px;font-weight:600;white-space:nowrap}
  @media(max-width:640px){.xd-card{padding:12px 14px;gap:12px}.xd-go{width:100%;text-align:center}}`;
  document.head.appendChild(style);

  const card = document.createElement("a");
  card.className = "xd-card"; card.setAttribute("data-exam-card", ""); card.href = "pages/exams.html";
  anchor.insertAdjacentElement("afterend", card);

  let learn = null;
  function paint() {
    const act = X.active();
    if (act) {
      const m = X.summary(act);
      card.classList.add("live"); card.href = "pages/exams.html?resume=1";
      card.innerHTML = `<div class="xd-ic" aria-hidden="true">⏳</div><div class="xd-tx"><strong>${m.expired ? "Time ran out on" : "Exam in progress:"} ${esc(m.title)}</strong><span>${m.answered}/${m.n} answered · ${m.expired ? "see your result" : X.fmtClock(m.left) + " left"}</span></div><span class="xd-go">${m.expired ? "See result" : "Resume exam"}</span>`;
      return;
    }
    card.classList.remove("live"); card.href = "pages/exams.html";
    const rd = X.readiness(learn), nxt = X.PRESETS.find((p) => p.id === rd.next.id), st = X.stats();
    if (rd.overall == null) {
      card.innerHTML = `<div class="xd-ic" aria-hidden="true">📝</div><div class="xd-tx"><strong>Exam Center</strong><span>Sit a timed paper to get an exam-readiness score and a full analysis.</span></div><span class="xd-go">Start an exam</span>`;
    } else {
      card.innerHTML = `<div class="xd-ring" style="--p:${rd.overall}" role="img" aria-label="Exam readiness ${rd.overall} percent"><span>${rd.overall}%</span></div><div class="xd-tx"><strong>Exam readiness: ${esc(rd.band.label)}</strong><span>About ${rd.range[0]}–${rd.range[1]}% on a full paper · ${st.count} exam${st.count === 1 ? "" : "s"} taken · next: ${esc(nxt.label)}</span></div><span class="xd-go">Open Exam Center</span>`;
    }
  }
  async function refresh() { if (L) { try { learn = await L.get(); } catch (_) { learn = null; } } paint(); }
  ["curio-learning-updated", "curio-review-updated", "curio-exam-updated"].forEach((ev) => window.addEventListener(ev, () => { clearTimeout(refresh.t); refresh.t = setTimeout(refresh, 200); }));
  window.addEventListener("storage", () => { clearTimeout(refresh.t); refresh.t = setTimeout(refresh, 200); });
  paint(); refresh();
  setInterval(paint, 30000);
})();
