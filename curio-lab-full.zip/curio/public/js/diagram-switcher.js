// Curio Lab — Free-Body Diagram scenario switcher
// Lets a lesson ship several annotated SVG diagrams in the "Diagram" tab
// and flip between them with a small button row, while reusing the single
// shared analysis-card + annotated-reader.js click-to-explain wiring.
window.onLessonContentReady(() => {
  const switcher = document.querySelector("[data-diagram-switcher]");
  if (!switcher) return;

  const buttons = Array.from(switcher.querySelectorAll("button[data-diagram]"));
  const scenes = Array.from(document.querySelectorAll("[data-diagram-scene]"));
  const hint = document.querySelector("[data-diagram-hint]");
  const analysisCard = document.querySelector("[data-analysis-card]");
  if (!buttons.length || !scenes.length) return;

  const hints = {
    flat: "A free-body diagram — click any labeled arrow to see what force it represents.",
    ramp: "On a slope, weight still points straight down, but the normal force tilts with the ramp — click an arrow to see why.",
    flight: "Once a ball leaves your hand, only gravity acts on it (ignoring air resistance) — click the arrows to compare a force with a velocity.",
    tension: "A block hanging still is in equilibrium — the rope's tension force exactly balances its weight. Click an arrow to explore.",
  };

  function activate(name) {
    buttons.forEach((b) => b.classList.toggle("active", b.dataset.diagram === name));
    scenes.forEach((s) => {
      s.style.display = s.dataset.diagramScene === name ? "block" : "none";
    });
    if (hint) hint.textContent = hints[name] || hint.textContent;
    if (analysisCard) {
      analysisCard.innerHTML = '<p class="analysis-hint">Click an arrow on the diagram to see the force explained here.</p>';
    }
    if (window.CurioSound) window.CurioSound.play("click");
  }

  buttons.forEach((btn) => {
    btn.addEventListener("click", () => activate(btn.dataset.diagram));
  });
});
