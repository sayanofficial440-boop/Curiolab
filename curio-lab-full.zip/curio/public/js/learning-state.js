// Curio Lab — learning progress store.
//
// Every lesson a learner opens and every quiz they finish is recorded here, per
// account, on this device (localStorage). Nothing is pre-filled: the dashboard,
// profile and analytics read exactly what this file has recorded.
//
// Works for signed-in accounts (keyed by account id/email) and for guests
// (keyed "guest"), and never depends on a server, so it also works when the
// site is opened straight from files.
(function () {
  "use strict";
  if (window.CurioLearning) return;

  const KEY_PREFIX = "curiolab-learning-v3:";
  const OLD_PREFIX = "curiolab-learning-v2:";
  const LEGACY_SCORES_KEY = "curiolab-scores";
  const LEGACY_IMPORTED_KEY = "curiolab-legacy-scores-imported";
  const MAX_QUIZ_EVENTS = 500;
  const MAX_VISITS = 400;
  const VISIT_DEDUPE_MS = 20 * 60 * 1000;

  let user = null;
  let current = null;
  let initPromise = null;

  const nowIso = () => new Date().toISOString();
  const clean = (value, limit) => String(value == null ? "" : value).trim().slice(0, limit);
  const safeParse = (value, fallback) => { try { const v = JSON.parse(value); return v == null ? fallback : v; } catch (_) { return fallback; } };
  const accountKey = () => (user && (user.id ? "id:" + user.id : user.email ? "email:" + String(user.email).toLowerCase() : null)) || "guest";
  const storageKey = () => KEY_PREFIX + accountKey();

  // "/storage/emulated/0/site/pages/physics/force.html?x=1" -> "pages/physics/force.html"
  function relHref(href) {
    let path = String(href || "").split("#")[0].split("?")[0];
    try { path = decodeURIComponent(path); } catch (_) { /* keep raw */ }
    const i = path.lastIndexOf("/pages/");
    if (i >= 0) return path.slice(i + 1);
    if (path.indexOf("pages/") === 0) return path;
    return path.replace(/^\/+/, "");
  }

  const empty = () => ({ version: 3, profile: null, events: [], visits: [], resume: null, createdAt: nowIso(), updatedAt: nowIso() });

  function normalise(raw) {
    const s = raw && typeof raw === "object" ? raw : {};
    return {
      version: 3,
      profile: s.profile && typeof s.profile === "object" ? s.profile : null,
      events: (Array.isArray(s.events) ? s.events : []).filter((e) => e && e.total > 0 && e.at).slice(-MAX_QUIZ_EVENTS),
      visits: (Array.isArray(s.visits) ? s.visits : []).filter((v) => v && v.href && v.at).slice(-MAX_VISITS),
      resume: s.resume && typeof s.resume === "object" ? s.resume : null,
      createdAt: s.createdAt || nowIso(),
      updatedAt: s.updatedAt || nowIso(),
    };
  }

  // lessonProgress is derived (never stored), so it can't drift from the raw events.
  function deriveLessonProgress(state) {
    const map = new Map();
    const touch = (href, title, subject) => {
      const key = relHref(href) || (subject + ":" + title);
      if (!map.has(key)) map.set(key, { href: relHref(href), title, subject, visitCount: 0, attempts: 0, best: null, firstVisitedAt: null, visitedAt: null, status: "visited" });
      return map.get(key);
    };
    state.visits.forEach((v) => {
      const item = touch(v.href, v.title, v.subject);
      item.visitCount += 1;
      if (!item.firstVisitedAt || v.at < item.firstVisitedAt) item.firstVisitedAt = v.at;
      if (!item.visitedAt || v.at > item.visitedAt) item.visitedAt = v.at;
    });
    state.events.forEach((e) => {
      const key = e.href ? relHref(e.href) : "";
      let item = key && map.has(key) ? map.get(key) : null;
      if (!item) {
        item = [...map.values()].find((x) => x.subject === e.subject && x.title === e.lesson) || touch(e.href, e.lesson, e.subject);
      }
      const pct = Math.round((e.score / e.total) * 100);
      item.attempts += 1;
      item.best = item.best == null ? pct : Math.max(item.best, pct);
      if (!item.firstVisitedAt || e.at < item.firstVisitedAt) item.firstVisitedAt = e.at;
      if (!item.visitedAt || e.at > item.visitedAt) item.visitedAt = e.at;
    });
    map.forEach((item) => { item.status = item.best == null ? "visited" : item.best >= 60 ? "completed" : "attempted"; });
    return [...map.values()].sort((a, b) => String(b.visitedAt).localeCompare(String(a.visitedAt)));
  }

  function snapshot() {
    const state = normalise(current || empty());
    return { ...state, lessonProgress: deriveLessonProgress(state), planItems: [], achievements: [] };
  }

  function persist() {
    try { localStorage.setItem(storageKey(), JSON.stringify(current)); } catch (_) { /* storage full or blocked */ }
  }

  function publish(next) {
    current = normalise(next);
    current.updatedAt = nowIso();
    persist();
    window.dispatchEvent(new CustomEvent("curio-learning-updated", { detail: snapshot() }));
    return snapshot();
  }

  // One-time carry-over of things this device already recorded before this store existed.
  function seedFromOlderData(state) {
    // Old per-account store (v2): profile + resume + quiz history.
    const old = safeParse(localStorage.getItem(OLD_PREFIX + accountKey()), null);
    if (old) {
      if (!state.profile && old.profile) state.profile = old.profile;
      if (!state.resume && old.resume) state.resume = { ...old.resume, href: relHref(old.resume.href) };
      (old.events || []).forEach((e) => { if (e && e.total > 0 && e.at) state.events.push({ type: "quiz", lesson: e.lesson, subject: e.subject, score: e.score, total: e.total, href: relHref(e.href), at: e.at }); });
      (old.lessonProgress || []).forEach((p) => { if (p && p.href && p.visitedAt) state.visits.push({ href: relHref(p.href), title: p.title, subject: p.subject, at: p.visitedAt }); });
    }
    // Progress made before signing in (guest) carries over to the account on first sign-in.
    if (accountKey() !== "guest") {
      const guest = safeParse(localStorage.getItem(KEY_PREFIX + "guest"), null);
      if (guest) {
        const g = normalise(guest);
        if (!state.profile && g.profile) state.profile = g.profile;
        if (!state.resume && g.resume) state.resume = g.resume;
        state.events.push(...g.events); state.visits.push(...g.visits);
        state.events.sort((a, b) => String(a.at).localeCompare(String(b.at)));
        state.visits.sort((a, b) => String(a.at).localeCompare(String(b.at)));
      }
    }
    // Quiz scores saved by the quiz engine on this device (first account to open the dashboard adopts them).
    if (!localStorage.getItem(LEGACY_IMPORTED_KEY)) {
      const legacy = safeParse(localStorage.getItem(LEGACY_SCORES_KEY), []);
      if (Array.isArray(legacy)) {
        legacy.forEach((s) => {
          if (!s || !(s.total > 0) || !s.date) return;
          const dupe = state.events.some((e) => e.lesson === s.lesson && e.score === s.score && Math.abs(new Date(e.at) - new Date(s.date)) < 5000);
          if (!dupe) state.events.push({ type: "quiz", lesson: clean(s.lesson, 120), subject: clean(s.subject, 60), score: Number(s.score), total: Number(s.total), href: "", at: new Date(s.date).toISOString() });
        });
        state.events.sort((a, b) => String(a.at).localeCompare(String(b.at)));
      }
      try { localStorage.setItem(LEGACY_IMPORTED_KEY, "1"); } catch (_) { /* ignore */ }
    }
    return state;
  }

  async function ready() {
    if (initPromise) return initPromise;
    initPromise = (async () => {
      try { user = window.CurioAuth ? await window.CurioAuth.getCurrentUser() : null; } catch (_) { user = null; }
      const stored = localStorage.getItem(storageKey());
      const state = stored ? normalise(safeParse(stored, empty())) : seedFromOlderData(empty());
      current = normalise(state);
      if (!stored) persist();
      window.dispatchEvent(new CustomEvent("curio-learning-updated", { detail: snapshot() }));
      return snapshot();
    })();
    return initPromise;
  }

  async function update(mutator) {
    await ready();
    const next = normalise(current);
    mutator(next);
    return publish(next);
  }

  // Another tab (e.g. a lesson) saved progress: pick it up so an open dashboard refreshes itself.
  window.addEventListener("storage", (event) => {
    if (!current || event.key !== storageKey() || !event.newValue) return;
    current = normalise(safeParse(event.newValue, empty()));
    window.dispatchEvent(new CustomEvent("curio-learning-updated", { detail: snapshot() }));
  });

  window.CurioLearning = {
    ready,
    relHref,
    get: async () => { await ready(); return snapshot(); },
    isOnboarded: async () => { await ready(); return Boolean(snapshot().profile); },
    completeOnboarding: async ({ name, age, course }) => update((state) => {
      const ageNum = Number(age);
      state.profile = { name: clean(name, 60), age: ageNum > 0 ? ageNum : null, course: clean(course, 50), completedAt: nowIso() };
    }),
    recordLessonVisit: async ({ title, subject, href }) => {
      const data = { title: clean(title, 120), subject: clean(subject, 60), href: relHref(href) };
      if (!data.href || !data.title) return snapshot();
      return update((state) => {
        const at = nowIso();
        const last = [...state.visits].reverse().find((v) => v.href === data.href);
        if (!last || new Date(at) - new Date(last.at) > VISIT_DEDUPE_MS) state.visits.push({ ...data, at });
        state.visits = state.visits.slice(-MAX_VISITS);
        state.resume = { ...data, visitedAt: at };
      });
    },
    recordQuiz: async ({ lesson, subject, score, total, href }) => {
      const data = { lesson: clean(lesson, 120), subject: clean(subject, 60), score: Number(score), total: Number(total), href: relHref(href) };
      if (!(data.total > 0) || !(data.score >= 0)) return snapshot();
      return update((state) => {
        const at = nowIso();
        // The quiz engine also writes the older score list, which may already have been imported.
        const dupe = state.events.some((e) => e.lesson === data.lesson && e.score === data.score && e.total === data.total && Math.abs(new Date(at) - new Date(e.at)) < 10000);
        if (!dupe) state.events.push({ type: "quiz", ...data, at });
        state.events = state.events.slice(-MAX_QUIZ_EVENTS);
        state.resume = { title: data.lesson, subject: data.subject, href: data.href || (state.resume && state.resume.href) || "", visitedAt: at };
      });
    },
  };
})();
