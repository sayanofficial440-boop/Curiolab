// Curio Lab — installable app + offline support. Registers the service worker and
// the web-app manifest. Does nothing on file:// or when service workers are unavailable.
(function () {
  "use strict";
  const me = document.currentScript;
  if (!me || !me.src) return;
  const root = new URL("../", me.src);
  if (!document.querySelector('link[rel="manifest"]')) {
    const l = document.createElement("link"); l.rel = "manifest"; l.href = new URL("manifest.webmanifest", root).href; document.head.appendChild(l);
  }
  if (!document.querySelector('meta[name="theme-color"]')) {
    const t = document.createElement("meta"); t.name = "theme-color"; t.content = "#12213B"; document.head.appendChild(t);
  }
  if (!("serviceWorker" in navigator) || !/^https?:$/.test(location.protocol)) return;
  window.addEventListener("load", () => {
    navigator.serviceWorker.register(new URL("sw.js", root).href, { scope: root.pathname }).catch(() => { /* optional feature */ });
  });

  // "Install app" prompt, surfaced on the accessibility/settings page.
  let deferred = null;
  window.addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); deferred = e; window.dispatchEvent(new CustomEvent("curio-install-ready")); });
  window.CurioPWA = {
    canInstall: () => !!deferred,
    install: async () => { if (!deferred) return false; deferred.prompt(); const r = await deferred.userChoice; deferred = null; return r.outcome === "accepted"; },
    // Save every lesson page for offline use.
    saveLessonsOffline: async () => {
      const reg = await navigator.serviceWorker.ready; const cat = window.CurioCatalog;
      const urls = [];
      (cat ? cat.lessons : []).forEach((l) => urls.push(new URL(l.h, root).href));
      ["dashboard.html", "pages/review.html", "pages/practice.html", "pages/problem-lab.html", "js/problem-lab.js", "js/practice-hub.js", "pages/report.html", "pages/saved.html", "pages/exams.html", "js/exam-store.js", "js/exam-center.js", "css/exam-center.css", "js/bank/bank-exams.js", "pages/courses.html", "js/courses.js", "js/courses-data.js", "css/courses.css", "pages/past-papers.html", "js/past-papers.js", "js/papers/papers-data.js", "css/past-papers.css"].forEach((p) => urls.push(new URL(p, root).href));
      if (reg.active) reg.active.postMessage({ type: "cache-urls", urls });
      return urls.length;
    },
  };
})();
