// Curio Lab — Global AI Coach ("Curio Concierge")
//
// Deliberately NOT a replacement for js/ai-coach.js, which stays exactly as
// it is: a per-lesson coach embedded in each lesson page's own markup
// ([data-coach-launcher]), with deep per-section context and per-lesson
// canned demo responses. This is a second, separate assistant — one
// continuous conversation thread that follows the student across every page
// (homepage, scoreboard, certificates, any lesson), which is what "elevate
// the AI coach out of sub-pages into something persistent on the front page"
// actually calls for: promoting a new global instance, not tearing out the
// lesson-specific one that already works well.
//
// Positioned bottom-RIGHT (same side as the per-lesson coach launcher in
// css/lesson.css). On lesson pages, where both launchers can be on screen
// at once, this one detects the per-lesson launcher and stacks itself
// higher up so the two never overlap.
//
// Same live/demo-mode fallback convention as js/ai-coach.js and
// js/auth.js: talks to POST /api/coach with mode:"concierge" (see
// backend/app.py's CONCIERGE_SYSTEM) when the backend is reachable, falls
// back to canned platform-help responses otherwise.
(function () {
  "use strict";

  if (document.querySelector("[data-global-coach-launcher]")) return; // don't double-inject

  const BACKEND_URL = "";
  const HEALTH_TIMEOUT_MS = 1200;
  const HISTORY_KEY = "curiolab-chat-global"; // one thread, shared across every page — this IS the persistence the spec asked for
  const STYLE_ID = "curio-global-coach-styles";

  let liveMode = false;

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .gcoach-launcher {
        position: fixed; right: var(--space-3, 1.6rem); bottom: var(--space-3, 1.6rem); z-index: 60;
        background: var(--color-navy, #1B2A4A); color: var(--color-surface, #fff); border: none;
        border-radius: 999px; padding: 0.8rem 1.1rem; display: flex; align-items: center; gap: 0.5rem;
        font-size: 0.88rem; box-shadow: var(--shadow-lift, 0 8px 24px rgba(0,0,0,0.18));
        cursor: pointer; transition: transform 0.15s ease;
      }
      .gcoach-launcher:hover { transform: translateY(-2px); }
      /* On lesson pages the per-lesson AI Coach button is hidden (see
         css/lesson.css) so this stacking case shouldn't normally trigger —
         kept only as a defensive fallback. */
      .gcoach-launcher.gcoach-stacked { bottom: calc(var(--space-3, 1.6rem) + 60px); }
      .gcoach-panel {
        position: fixed; right: var(--space-3, 1.6rem); bottom: calc(var(--space-3, 1.6rem) + 60px); z-index: 60;
        width: min(340px, calc(100vw - 2 * var(--space-3, 1.6rem))); max-height: 60vh;
        background: var(--color-surface); border: 1px solid var(--color-line-strong);
        border-radius: var(--radius-md, 12px); box-shadow: var(--shadow-lift, 0 8px 24px rgba(0,0,0,0.18));
        display: none; flex-direction: column; overflow: hidden;
      }
      .gcoach-panel.gcoach-stacked { bottom: calc(var(--space-3, 1.6rem) + 120px); }
      .gcoach-panel.open { display: flex; }
      .gcoach-head { padding: 0.6rem 0.9rem; border-bottom: 1px solid var(--color-line); display: flex; justify-content: space-between; align-items: center; }
      .gcoach-head strong { font-size: 0.88rem; }
      .gcoach-close { background: none; border: none; color: var(--color-ink-soft); font-size: 1rem; cursor: pointer; }
      .gcoach-log { flex: 1; overflow-y: auto; padding: 0.9rem; display: flex; flex-direction: column; gap: 0.6rem; font-size: 0.86rem; }
      .gcoach-msg { padding: 0.5rem 0.7rem; border-radius: 8px; max-width: 88%; }
      .gcoach-msg.bot { background: var(--color-bg-alt); align-self: flex-start; }
      .gcoach-msg.user { background: var(--color-navy, #1B2A4A); color: var(--color-surface); align-self: flex-end; }
      .gcoach-msg[data-typing] { animation: gcoach-pulse 1s ease-in-out infinite; }
      @keyframes gcoach-pulse { 0%, 100% { opacity: 0.4; } 50% { opacity: 1; } }
      .gcoach-input-row { display: flex; border-top: 1px solid var(--color-line); }
      .gcoach-input-row input { flex: 1; border: none; padding: 0.7rem; font-size: 0.86rem; background: none; color: var(--color-ink); outline: none; }
      .gcoach-input-row button { border: none; background: none; color: var(--color-navy, #1B2A4A); padding: 0 0.9rem; font-size: 1rem; cursor: pointer; }
      .gcoach-note { font-size: 0.7rem; color: var(--color-ink-soft); padding: 0.35rem 0.9rem 0.55rem; font-family: var(--font-mono); }
      @media (max-width: 640px) {
        .gcoach-launcher {
          width: 48px; height: 48px; padding: 0; border-radius: 50%;
          justify-content: center; font-size: 1.2rem;
        }
        .gcoach-launcher span.gcoach-label { display: none; } /* icon-only on small screens to save space, matching the rail-toggle circle on the opposite corner */
      }
    `;
    document.head.appendChild(style);
  }

  function build() {
    // The per-lesson AI Coach launcher (css/lesson.css .coach-launcher) is
    // now hidden site-wide in favor of this single global assistant, so
    // there's nothing left to stack above — this only checks in case that
    // ever changes back.
    const legacyLauncher = document.querySelector("[data-coach-launcher]");
    const stacked = !!legacyLauncher && getComputedStyle(legacyLauncher).display !== "none";

    const launcher = document.createElement("button");
    launcher.type = "button";
    launcher.className = stacked ? "gcoach-launcher gcoach-stacked" : "gcoach-launcher";
    launcher.setAttribute("data-global-coach-launcher", "");
    launcher.setAttribute("data-sfx", ""); // picks up sound.js's generic click cue for free
    launcher.innerHTML = `💬 <span class="gcoach-label">Curio Assistant</span>`;

    const panel = document.createElement("div");
    panel.className = stacked ? "gcoach-panel gcoach-stacked" : "gcoach-panel";
    panel.setAttribute("data-global-coach-panel", "");
    panel.innerHTML = `
      <div class="gcoach-head">
        <strong>💬 Curio Assistant</strong>
        <button type="button" class="gcoach-close" data-sfx aria-label="Close">✕</button>
      </div>
      <div class="gcoach-log" data-gcoach-log></div>
      <form class="gcoach-input-row" data-gcoach-form>
        <input type="text" placeholder="Ask about Curio Lab…" data-gcoach-input autocomplete="off" />
        <button type="submit" aria-label="Send">➤</button>
      </form>
      <p class="gcoach-note" data-gcoach-note>Checking connection…</p>
    `;

    document.body.appendChild(launcher);
    document.body.appendChild(panel);
    return { launcher, panel };
  }

  function inferSubjectFromPath() {
    const parts = window.location.pathname.split("/").filter(Boolean);
    const pagesIdx = parts.lastIndexOf("pages");
    if (pagesIdx !== -1 && parts.length > pagesIdx + 2) return parts[pagesIdx + 1];
    return new URLSearchParams(window.location.search).get("subject");
  }

  function friendlyPageLabel() {
    const h1 = document.querySelector("h1");
    if (h1 && h1.textContent.trim()) return h1.textContent.trim().slice(0, 60);
    return (document.title || window.location.pathname).slice(0, 60);
  }

  const CANNED = [
    { match: /certificate/i, reply: "Head to the Certificates page from the side menu — score 100% on any quiz to unlock your first one, and there are higher server-verified tiers too as you build up streaks and subject mastery." },
    { match: /streak/i, reply: "Streaks build across every mini-game and arcade round on the site — hit a 10-win streak and you'll unlock the Gold-tier certificate for it!" },
    { match: /theme|color|dark mode|appearance/i, reply: "Open the theme picker in the header — there are 8 base looks plus 5 premium palettes like Cyberpunk Matrix and Cream Pearl if you're logged in." },
    { match: /subject|lesson|start|where.*begin/i, reply: "Browse subjects right from the homepage — pick whatever looks interesting, each one has slides, a quiz, and mini-games built in." },
    { match: /score|progress|scoreboard/i, reply: "Your Scoreboard page (side menu) tracks every quiz attempt and shows your averages per subject." },
  ];
  const FALLBACK = "Good question! I'm in demo mode right now, so I can only help with general Curio Lab navigation — start backend/app.py for full AI answers.";

  function loadHistory() {
    try { return JSON.parse(localStorage.getItem(HISTORY_KEY)) || []; } catch (e) { return []; }
  }
  function saveHistory(history) {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(-40)));
  }

  function init() {
    injectStyles();
    const { launcher, panel } = build();
    const log = panel.querySelector("[data-gcoach-log]");
    const form = panel.querySelector("[data-gcoach-form]");
    const input = panel.querySelector("[data-gcoach-input]");
    const noteEl = panel.querySelector("[data-gcoach-note]");
    const closeBtn = panel.querySelector(".gcoach-close");

    function addMsg(text, who, persist = true) {
      const div = document.createElement("div");
      div.className = `gcoach-msg ${who}`;
      div.textContent = text;
      log.appendChild(div);
      log.scrollTop = log.scrollHeight;
      if (persist) {
        const history = loadHistory();
        history.push({ text, who });
        saveHistory(history);
      }
    }

    function addTyping() {
      const div = document.createElement("div");
      div.className = "gcoach-msg bot";
      div.dataset.typing = "1";
      div.textContent = "…";
      log.appendChild(div);
      log.scrollTop = log.scrollHeight;
      return div;
    }

    function renderHistory() {
      log.innerHTML = "";
      const history = loadHistory();
      if (history.length === 0) {
        addMsg("Hi! I'm the Curio Assistant — ask me anything about navigating Curio Lab, or say hi from any page and I'll remember our chat as you move around the site.", "bot");
        return;
      }
      history.forEach((m) => addMsg(m.text, m.who, false));
    }

    function setNote() {
      noteEl.textContent = liveMode
        ? "🟢 Live AI — connected to the Curio Lab backend."
        : "🟡 Demo mode — start backend/app.py for live AI.";
    }

    async function checkBackend() {
      try {
        const controller = new AbortController();
        const t = setTimeout(() => controller.abort(), HEALTH_TIMEOUT_MS);
        if (window.CurioAge && !window.CurioAge.allowed("liveAI")) throw new Error("child account: live AI off");
        const res = await fetch(`${BACKEND_URL}/api/health`, { signal: controller.signal });
        clearTimeout(t);
        const data = await res.json();
        liveMode = !!(res.ok && data.live);
      } catch (e) {
        liveMode = false;
      }
      setNote();
    }

    function answerLocally(question) {
      const hit = CANNED.find((r) => r.match.test(question));
      return hit ? hit.reply : FALLBACK;
    }

    async function answerLive(question) {
      const history = loadHistory().slice(0, -1);
      const res = await fetch(`${BACKEND_URL}/api/coach`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: question,
          topic: "Curio Lab (general)",
          mode: "concierge",
          history,
          context: { subject: inferSubjectFromPath(), currentPage: friendlyPageLabel() },
        }),
      });
      if (!res.ok) throw new Error(`Backend responded ${res.status}`);
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      return data.reply;
    }

    launcher.addEventListener("click", () => {
      panel.classList.toggle("open");
      if (panel.classList.contains("open")) {
        if (log.children.length === 0) renderHistory();
        checkBackend();
        setTimeout(() => input.focus(), 10);
      }
    });
    closeBtn.addEventListener("click", () => panel.classList.remove("open"));

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const q = input.value.trim();
      if (!q) return;
      window.CurioSound && window.CurioSound.play("click");
      addMsg(q, "user");
      input.value = "";
      const typingEl = addTyping();

      if (liveMode) {
        try {
          const reply = await answerLive(q);
          typingEl.remove();
          addMsg(reply, "bot");
          return;
        } catch (err) {
          liveMode = false;
          setNote();
        }
      }
      setTimeout(() => {
        typingEl.remove();
        addMsg(answerLocally(q), "bot");
      }, 350);
    });

    checkBackend();
    setNote();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
