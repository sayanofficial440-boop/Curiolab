// Curio Lab — "Review due today" card for the dashboard (real data from the Mistake Notebook).
(function () {
  "use strict";
  const R = window.CurioReview, host = document.querySelector(".greet-row");
  if (!R || !host || document.querySelector("[data-review-card]")) return;

  const style = document.createElement("style");
  style.textContent = `
  .rv-card{display:flex;align-items:center;gap:16px;background:var(--panel,#fff);border:1px solid var(--line,#e5e1f4);border-radius:var(--radius,16px);padding:14px 18px;margin:0 0 20px;box-shadow:var(--shadow);text-decoration:none;color:inherit;flex-wrap:wrap}
  .rv-card .ic{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;font-size:20px;background:var(--accent-soft,#efeaff);flex:none}
  .rv-card.due .ic{background:var(--gold-soft,#fff3dc)}
  .rv-card .tx{flex:1;min-width:180px}
  .rv-card strong{display:block;font-size:14px;font-weight:700}
  .rv-card span.s{font-size:12.5px;color:var(--ink-soft,#5b5f68)}
  .rv-card .go{background:var(--accent,#6547da);color:#fff;border-radius:10px;padding:9px 16px;font-size:13px;font-weight:600;white-space:nowrap}
  .rv-card:hover{border-color:var(--accent,#6547da)}
  .rv-card:focus-visible{outline:2px solid var(--accent,#6547da);outline-offset:2px}
  @media(max-width:640px){.rv-card{padding:12px 14px;gap:12px}.rv-card .go{width:100%;text-align:center}}`;
  document.head.appendChild(style);

  const card = document.createElement("a");
  card.className = "rv-card"; card.setAttribute("data-review-card", ""); card.href = "pages/review.html";
  host.insertAdjacentElement("afterend", card);

  function paint() {
    const s = R.stats();
    card.classList.toggle("due", s.due > 0);
    if (!s.total) {
      card.innerHTML = `<div class="ic">📓</div><div class="tx"><strong>Mistake Notebook</strong><span class="s">Questions you miss in quizzes are saved here and come back on a smart schedule.</span></div><span class="go">Open</span>`;
    } else if (s.due) {
      card.innerHTML = `<div class="ic">🧠</div><div class="tx"><strong>${s.due} question${s.due === 1 ? "" : "s"} due for review</strong><span class="s">${s.total} in your notebook · ${s.mastered} mastered${s.reviewedToday ? " · " + s.reviewedToday + " reviewed today" : ""}</span></div><span class="go">Start review</span>`;
    } else {
      card.innerHTML = `<div class="ic">✅</div><div class="tx"><strong>Review is all caught up</strong><span class="s">${s.total} in your notebook · ${s.mastered} mastered</span></div><span class="go">Open notebook</span>`;
    }
  }
  window.addEventListener("curio-review-updated", paint);
  paint();
})();
