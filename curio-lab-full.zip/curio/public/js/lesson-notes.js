// Curio Lab — bookmark button + notes drawer on every lesson page.
(function () {
  "use strict";
  const N = window.CurioNotes;
  if (!N || document.querySelector(".ln-fab")) return;
  const SUBJECTS = { physics: "Physics", chemistry: "Chemistry", biology: "Biology", english: "English", mathematics: "Mathematics", history: "History", geography: "Geography", "computer-science": "Computer Science" };
  const href = N.relHref(location.pathname);
  const m = href.match(/^pages\/([^/]+)\/[^/]+\.html$/);
  if (!m || !SUBJECTS[m[1]]) return; // lesson pages only
  const subject = SUBJECTS[m[1]];
  const h1 = document.querySelector("h1");
  const title = (h1 && h1.textContent.trim()) || document.title.replace(/\s*[—|-]\s*Curio.*$/i, "").trim() || href;
  const meta = { title, subject };

  const fab = document.createElement("div");
  fab.className = "ln-fab";
  fab.innerHTML = `<button type="button" data-ln-bm aria-pressed="false" aria-label="Bookmark this lesson"><span aria-hidden="true">🔖</span><span class="t">Save</span></button>
    <button type="button" data-ln-open aria-haspopup="dialog" aria-label="Open my notes for this lesson"><span aria-hidden="true">📝</span><span class="t">Notes</span></button>`;
  const backdrop = document.createElement("div");
  backdrop.className = "ln-backdrop";
  const drawer = document.createElement("aside");
  drawer.className = "ln-drawer";
  drawer.setAttribute("role", "dialog");
  drawer.setAttribute("aria-label", "My notes");
  drawer.setAttribute("aria-hidden", "true");
  drawer.innerHTML = `<div class="ln-head"><div><strong>My notes</strong><small></small></div><button class="ln-close" type="button" aria-label="Close notes">×</button></div>
    <div class="ln-body"><textarea data-ln-text placeholder="Write what you want to remember — formulas, doubts, examples… Saved automatically on this device." maxlength="20000"></textarea>
    <div class="ln-foot"><span data-ln-status>Not saved yet</span><a href="saved.html" style="color:inherit">All saved →</a></div></div>`;
  drawer.querySelector("small").textContent = title;
  document.body.append(fab, backdrop, drawer);

  const bm = fab.querySelector("[data-ln-bm]"), openBtn = fab.querySelector("[data-ln-open]");
  const ta = drawer.querySelector("[data-ln-text]"), status = drawer.querySelector("[data-ln-status]");
  let timer = null, lastFocus = null;

  function paint() {
    const rec = N.get(href);
    bm.setAttribute("aria-pressed", String(!!(rec && rec.bookmarked)));
    bm.querySelector(".t").textContent = rec && rec.bookmarked ? "Saved" : "Save";
    openBtn.querySelector(".t").textContent = rec && rec.note && rec.note.trim() ? "Notes ●" : "Notes";
  }
  function flush() {
    if (timer) { clearTimeout(timer); timer = null; }
    const ok = N.set(href, meta, { note: ta.value });
    status.textContent = ok ? (ta.value.trim() ? "Saved " + new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "Empty") : "Couldn't save — storage is full or blocked";
    paint();
  }
  function open() {
    lastFocus = document.activeElement;
    const rec = N.get(href);
    ta.value = rec ? rec.note : "";
    status.textContent = rec && rec.note ? "Saved" : "Not saved yet";
    drawer.classList.add("open"); backdrop.classList.add("open"); drawer.setAttribute("aria-hidden", "false");
    setTimeout(() => ta.focus(), 120);
  }
  function close() {
    if (!drawer.classList.contains("open")) return;
    flush();
    drawer.classList.remove("open"); backdrop.classList.remove("open"); drawer.setAttribute("aria-hidden", "true");
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  bm.addEventListener("click", () => {
    const rec = N.get(href), next = !(rec && rec.bookmarked);
    N.set(href, meta, { bookmarked: next });
    paint();
    if (window.CurioToast) window.CurioToast.show(next ? "Lesson bookmarked — find it under Saved." : "Bookmark removed.", { icon: next ? "🔖" : "✖️" });
  });
  openBtn.addEventListener("click", open);
  backdrop.addEventListener("click", close);
  drawer.querySelector(".ln-close").addEventListener("click", close);
  ta.addEventListener("input", () => { status.textContent = "Saving…"; clearTimeout(timer); timer = setTimeout(flush, 600); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
  window.addEventListener("pagehide", () => { if (timer) flush(); });
  window.addEventListener("curio-notes-updated", () => { if (!drawer.classList.contains("open")) paint(); });
  paint();
})();
