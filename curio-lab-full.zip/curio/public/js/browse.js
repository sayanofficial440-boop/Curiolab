// Curio Lab — "Browse by Grade" page. Shares filter state (grade/level) with the subject hubs.
(function () {
  const META = window.CurioMeta, CAT = window.CurioCatalog;
  if (!META || !CAT) return;
  const STORE = "curio.gf.v1";
  const ACCENT = { Physics: "var(--color-teal)", Chemistry: "var(--color-amber)", Biology: "var(--color-moss)", English: "var(--color-coral)",
    Mathematics: "var(--color-navy)", History: "var(--color-coral)", Geography: "var(--color-teal)", "Computer Science": "var(--color-navy)" };
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const bandById = Object.fromEntries(META.bands.map((b) => [b.id, b]));
  const levelById = Object.fromEntries(META.levels.map((l) => [String(l.id), l]));
  const gradeText = (a, b) => (a === b ? `Grade ${a}` : b >= 13 ? `Grades ${a}+` : `Grades ${a}–${b}`);

  const st = { subject: "", grade: "", level: "", q: "" };
  try { const s = JSON.parse(localStorage.getItem(STORE) || "{}"); st.grade = s.grade || ""; st.level = s.level || ""; } catch (e) {}
  const qs = new URLSearchParams(location.search);
  if (qs.has("grade") || qs.has("level") || qs.has("subject")) { st.grade = qs.get("grade") || ""; st.level = qs.get("level") || ""; }
  st.subject = qs.get("subject") || "";
  if (!bandById[st.grade]) st.grade = "";
  if (!levelById[st.level]) st.level = "";
  if (!CAT.subjects.some((s) => s.name === st.subject)) st.subject = "";

  const $ = (sel) => document.querySelector(sel);
  const lessons = CAT.lessons.map((l) => {
    const m = l.h.match(/pages\/([a-z-]+\/[a-z0-9-]+)\.html/);
    return { s: l.s, t: l.t, h: l.h.replace(/^pages\//, ""), m: m ? META.lessons[m[1]] : null };
  }).filter((l) => l.m);

  function pills(host, label, items, key) {
    host.className = "gf-row";
    host.setAttribute("role", "group");
    host.setAttribute("aria-label", label);
    host.innerHTML = `<span class="gf-label">${label}</span><div class="gf-pills"></div>`;
    const box = host.querySelector(".gf-pills");
    [{ id: "", label: "All" }].concat(items).forEach((it) => {
      const b = document.createElement("button");
      b.type = "button"; b.className = "gf-pill"; b.dataset.id = String(it.id);
      b.textContent = it.short || it.label;
      b.addEventListener("click", () => { st[key] = String(it.id); render(); });
      box.appendChild(b);
    });
  }
  pills($("[data-gf-subject]"), "Subject", CAT.subjects.map((s) => ({ id: s.name, label: s.name, short: s.code })), "subject");
  pills($("[data-gf-grade]"), "Grade", META.bands, "grade");
  pills($("[data-gf-level]"), "Level", META.levels, "level");
  $("[data-gf-search]").addEventListener("input", (e) => { st.q = e.target.value.trim().toLowerCase(); render(); });
  $("[data-gf-reset]").addEventListener("click", () => { st.subject = st.grade = st.level = st.q = ""; $("[data-gf-search]").value = ""; render(); });

  function render() {
    document.querySelectorAll("[data-gf-subject],[data-gf-grade],[data-gf-level]").forEach((row) => {
      const key = row.hasAttribute("data-gf-subject") ? "subject" : row.hasAttribute("data-gf-grade") ? "grade" : "level";
      row.querySelectorAll(".gf-pill").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.id === st[key])));
    });
    const band = st.grade ? bandById[st.grade] : null;
    const list = lessons.filter((l) =>
      (!st.subject || l.s === st.subject) &&
      (!band || (l.m[0] <= band.max && l.m[1] >= band.min)) &&
      (!st.level || l.m[2] === Number(st.level)) &&
      (!st.q || l.t.toLowerCase().includes(st.q) || l.s.toLowerCase().includes(st.q)));

    const host = $("[data-gf-results]");
    host.innerHTML = CAT.subjects.map((sub) => {
      const items = list.filter((l) => l.s === sub.name);
      if (!items.length) return "";
      return `<section class="gf-group"><h2>${esc(sub.name)} <small>${items.length} lesson${items.length > 1 ? "s" : ""}</small></h2><div class="gf-grid">` +
        items.map((l) => `<a class="gf-card" style="--gf-accent:${ACCENT[l.s] || "var(--accent)"}" href="${esc(l.h)}"><h3>${esc(l.t)}</h3>` +
          `<div class="gf-badges"><span class="gf-badge">${gradeText(l.m[0], l.m[1])}</span><span class="gf-badge lv-${l.m[2]}">${levelById[l.m[2]].label}</span></div></a>`).join("") +
        `</div></section>`;
    }).join("");

    const active = !!(st.subject || st.grade || st.level || st.q);
    $("[data-gf-count]").textContent = `${list.length} of ${lessons.length} lessons`;
    $("[data-gf-reset]").hidden = !active;
    $("[data-gf-empty]").hidden = list.length > 0;

    try { localStorage.setItem(STORE, JSON.stringify({ grade: st.grade, level: st.level })); } catch (e) {}
    const q = new URLSearchParams();
    ["subject", "grade", "level"].forEach((k) => st[k] && q.set(k, st[k]));
    try { history.replaceState(null, "", location.pathname + (q.toString() ? "?" + q : "")); } catch (e) {}
  }
  render();
})();
