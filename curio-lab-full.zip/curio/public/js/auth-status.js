// Curio Lab — Header auth widget
// Asks window.CurioAuth.getCurrentUser() (see js/auth.js) who's actually
// logged in — in live mode that's a real question to the server (the
// HttpOnly JWT cookie is invisible to this script and sent automatically by
// the browser), in demo mode it's the browser's own demo-only localStorage.
// Either way, this file never stores identity itself — it only displays it.
(function () {
  function computePrefixes() {
    const path = window.location.pathname;
    const parts = path.split("/").filter(Boolean);
    const pagesIdx = parts.lastIndexOf("pages");
    if (pagesIdx === -1) return { p: "pages/" };
    const depthAfterPages = parts.length - pagesIdx - 1;
    return { p: depthAfterPages <= 1 ? "" : "../" };
  }

  function initials(name) {
    if (!name) return "?";
    return name.trim().split(/\s+/).slice(0, 2).map((w) => w[0].toUpperCase()).join("");
  }

  async function render() {
    const slot = document.querySelector("[data-auth-widget]");
    if (!slot) return;
    const { p } = computePrefixes();

    // Show a neutral placeholder while the /api/auth/me round-trip is in
    // flight, so the header doesn't flash "guest" then "logged in" every load.
    slot.innerHTML = `<div class="auth-widget-guest auth-widget-loading" aria-hidden="true"></div>`;

    const user = window.CurioAuth ? await window.CurioAuth.getCurrentUser() : null;

    if (!user) {
      // The dashboard is currently a guest-friendly learning workspace.
      // Keep the authentication code available without exposing guest CTAs.
      slot.hidden = true;
      slot.innerHTML = "";
      return;
    }

    slot.innerHTML = `
      <div class="auth-widget-user">
        <button class="auth-avatar" data-auth-avatar type="button" aria-label="Account menu">${initials(user.name)}</button>
        <div class="auth-dropdown" data-auth-dropdown>
          <div class="who"><strong>${user.name}</strong>${user.child ? "Child account" : user.email}</div>
          <a href="${p}profile.html">👤 My Profile</a>
          <a href="${p}scoreboard.html">📊 My Progress</a>
          <a href="${p}certificates.html">🏆 Certificates</a>
          ${user.child ? "" : `<a href="${p}community.html">🌍 Community</a>`}
          <button type="button" data-auth-logout>🚪 Log out</button>
        </div>
      </div>
    `;

    const avatar = slot.querySelector("[data-auth-avatar]");
    const dropdown = slot.querySelector("[data-auth-dropdown]");
    avatar.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdown.classList.toggle("open");
    });
    document.addEventListener("click", () => dropdown.classList.remove("open"));

    slot.querySelector("[data-auth-logout]").addEventListener("click", async () => {
      if (window.CurioAuth) await window.CurioAuth.logout();
      if (window.CurioToast) window.CurioToast.show("Logged out.", { icon: "👋" });
      render();
    });
  }

  document.addEventListener("DOMContentLoaded", render);
})();
