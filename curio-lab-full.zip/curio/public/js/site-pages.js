/* Curio Lab — behaviour for the public-site pages (FAQ, Help, Blog, forms, press kit). Plain JS, no dependencies. */
(function () {
  "use strict";
  function ready(fn) { if (document.readyState !== "loading") fn(); else document.addEventListener("DOMContentLoaded", fn); }
  var norm = function (s) { return (s || "").toLowerCase(); };

  /* ---------- live search + category chips for FAQ / Help / Blog ----------
     <input data-filter-input="#list"> filters children of #list that carry data-search="text".
     <button data-filter-chip="cat"> hides items whose data-cat differs. */
  function initFilters() {
    document.querySelectorAll("[data-filter-root]").forEach(function (root) {
      var input = root.querySelector("[data-filter-input]");
      var chips = root.querySelectorAll("[data-filter-chip]");
      var items = root.querySelectorAll("[data-search]");
      var groups = root.querySelectorAll("[data-filter-group]");
      var empty = root.querySelector("[data-filter-empty]");
      var cat = "all";
      function run() {
        var q = norm(input && input.value).trim(), shown = 0;
        items.forEach(function (it) {
          var okQ = !q || norm(it.getAttribute("data-search")).indexOf(q) !== -1;
          var okC = cat === "all" || it.getAttribute("data-cat") === cat;
          it.hidden = !(okQ && okC);
          if (!it.hidden) shown++;
        });
        groups.forEach(function (g) { g.hidden = !g.querySelector("[data-search]:not([hidden])"); });
        if (empty) empty.hidden = shown !== 0;
      }
      if (input) input.addEventListener("input", run);
      chips.forEach(function (c) {
        c.addEventListener("click", function () {
          cat = c.getAttribute("data-filter-chip");
          chips.forEach(function (o) { o.setAttribute("aria-pressed", String(o === c)); });
          run();
        });
      });
      run();
    });
    // open the FAQ entry named in the URL (#fq-...)
    if (location.hash && /^#[\w-]+$/.test(location.hash)) {
      var t = document.querySelector(location.hash);
      if (t && t.tagName === "DETAILS") { t.open = true; setTimeout(function () { t.scrollIntoView({ block: "center" }); }, 60); }
    }
  }

  /* ---------- forms that post to /api/contact ----------
     If the site is hosted without the Flask backend the request fails; we then offer a mailto link instead of
     pretending the message was sent. */
  function initApiForms() {
    document.querySelectorAll("form[data-api-form]").forEach(function (form) {
      var ok = form.querySelector("[data-cl-success]") || form.parentNode.querySelector("[data-cl-success]");
      var err = form.querySelector("[data-cl-error]");
      var btn = form.querySelector("button[type=submit]");
      var topicSel = form.querySelector("[name=topic]");
      var pre = form.getAttribute("data-topic");
      if (topicSel && pre) topicSel.value = pre;
      var qp = new URLSearchParams(location.search).get("topic");
      if (topicSel && qp && topicSel.querySelector('option[value="' + qp + '"]')) topicSel.value = qp;

      if (window.CurioAge && !window.CurioAge.allowed("contact")) {
        var cb = form.querySelector("[data-child-block]");
        if (cb) { cb.textContent = window.CurioAge.why("contact"); cb.style.display = "block"; }
        form.querySelectorAll("input,textarea,select,button").forEach(function (el) { el.disabled = true; });
        return;
      }
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        if (err) { err.classList.remove("is-visible"); err.textContent = ""; }
        if (ok) ok.classList.remove("is-visible");
        var fd = new FormData(form);
        var body = {
          name: (fd.get("name") || "").toString().trim(),
          email: (fd.get("email") || "").toString().trim(),
          topic: (fd.get("topic") || form.getAttribute("data-topic") || "general").toString(),
          message: (fd.get("message") || "").toString().trim(),
          consent: !!fd.get("consent"),
          age_ok: !!fd.get("age_ok"),
          website: (fd.get("website") || "").toString()
        };
        if (!form.checkValidity()) { form.reportValidity(); return; }
        if (btn) { btn.disabled = true; btn.classList.add("is-loading"); }
        fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
          .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { status: r.status, j: j }; }); })
          .then(function (res) {
            if (res.status === 200 && res.j.ok) {
              form.reset();
              if (ok) ok.classList.add("is-visible");
              if (window.CurioToast) window.CurioToast.show("Message sent. Thank you!", { icon: "✉️" });
            } else if (res.status === 404 || res.status === 405 || res.status >= 500) {
              fail(body, "This site is running without its mail backend, so your message was not sent.");
            } else {
              fail(null, res.j.error || "Something went wrong. Please try again.");
            }
          })
          .catch(function () { fail(body, "We couldn't reach the server, so your message was not sent."); })
          .then(function () { if (btn) { btn.disabled = false; btn.classList.remove("is-loading"); } });
      });

      function fail(body, text) {
        if (!err) return;
        err.textContent = text + " ";
        if (body) {
          var a = document.createElement("a");
          var to = form.getAttribute("data-mailto") || "";
          a.href = "mailto:" + to + "?subject=" + encodeURIComponent("[Curio Lab] " + body.topic) +
            "&body=" + encodeURIComponent(body.message + "\n\n— " + body.name + " (" + body.email + ")");
          a.textContent = "Send it from your email app instead";
          err.appendChild(a);
        }
        err.classList.add("is-visible");
      }
    });
  }

  /* ---------- press kit: copy-to-clipboard ---------- */
  function initCopy() {
    document.querySelectorAll("[data-copy]").forEach(function (b) {
      b.addEventListener("click", function () {
        var src = document.querySelector(b.getAttribute("data-copy"));
        if (!src) return;
        var text = src.innerText.trim();
        var done = function () { var o = b.textContent; b.textContent = "Copied ✓"; setTimeout(function () { b.textContent = o; }, 1600); };
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, done); else done();
      });
    });
  }

  /* ---------- live numbers (press page + landing) from the generated learning index ---------- */
  function initLiveStats() {
    var nodes = document.querySelectorAll("[data-stat]");
    if (!nodes.length) return;
    var base = (document.querySelector("meta[name=curio-root]") || {}).content || "";
    fetch(base + "data/learning-index.json").then(function (r) { return r.json(); }).then(function (d) {
      var t = d.totals || {};
      var subjects = {}; (d.lessons || []).forEach(function (l) { subjects[l.id.split("/")[0]] = 1; });
      var map = { lessons: t.lessons, flashcards: t.flashcards, quizQuestions: t.quizQuestions, examQuestions: t.examQuestions, recallPrompts: t.recallPrompts, subjects: Object.keys(subjects).length };
      nodes.forEach(function (n) {
        var v = map[n.getAttribute("data-stat")];
        if (v == null) return;
        n.setAttribute("data-value", v);
        n.textContent = v.toLocaleString("en-US");
      });
    }).catch(function () {});
  }

  ready(function () { initFilters(); initApiForms(); initCopy(); initLiveStats(); });
})();
