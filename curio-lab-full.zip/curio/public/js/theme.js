// Curio Lab — Theme system (18 themes: Daylight, Sepia, Blueprint, Midnight, Forest, Aurora, Rosewood, Slate, Lagoon, Obsidian, Cocoa, Citrus, Glacier, Nebula, Volt, Copper, Indigo, Mint)
(function () {
  const STORAGE_KEY = "curiolab-theme";
  const root = document.documentElement;

  const THEMES = [
    { id: "daylight", label: "Daylight", swatchA: "#F3EFE3", swatchB: "#D68C1F" },
    { id: "sepia", label: "Sepia", swatchA: "#EDE0C8", swatchB: "#B8721F" },
    { id: "blueprint", label: "Blueprint", swatchA: "#0E1B30", swatchB: "#56C2B2" },
    { id: "midnight", label: "Midnight", swatchA: "#1A1626", swatchB: "#E2799A" },
    { id: "forest", label: "Forest", swatchA: "#EAF0E1", swatchB: "#4F7A2E" },
    { id: "aurora", label: "Aurora", swatchA: "#0B1A22", swatchB: "#37D6B6" },
    { id: "rosewood", label: "Rosewood", swatchA: "#F7E9EC", swatchB: "#C2445A" },
    { id: "slate", label: "Slate", swatchA: "#1C2126", swatchB: "#5FB8C7" },
    { id: "lagoon", label: "Lagoon", swatchA: "#EAF6F2", swatchB: "#1E8F7A" },
    { id: "obsidian", label: "Obsidian", swatchA: "#15140F", swatchB: "#E8A23D" },
    { id: "cocoa", label: "Cocoa", swatchA: "#F0E4D8", swatchB: "#C97D2E" },
    { id: "citrus", label: "Citrus", swatchA: "#F7F6DE", swatchB: "#7FA82E" },
    { id: "glacier", label: "Glacier", swatchA: "#EAF2F7", swatchB: "#3FA3C7" },
    { id: "nebula", label: "Nebula", swatchA: "#170F26", swatchB: "#E257A0" },
    { id: "volt", label: "Volt", swatchA: "#0A0F0C", swatchB: "#ADFF4F" },
    { id: "copper", label: "Copper", swatchA: "#FBF1E7", swatchB: "#D65A3A" },
    { id: "indigo", label: "Indigo", swatchA: "#141A2E", swatchB: "#8C9EFF" },
    { id: "mint", label: "Mint", swatchA: "#EAF7F1", swatchB: "#2FB894" },
  ];

  function applyTheme(id) {
    if (id === "daylight") {
      root.removeAttribute("data-theme");
    } else {
      root.setAttribute("data-theme", id);
    }
    const label = document.querySelector("[data-theme-label]");
    const found = THEMES.find((t) => t.id === id) || THEMES[0];
    if (label) label.textContent = found.label;
    document.querySelectorAll("[data-theme-option]").forEach((el) => {
      el.classList.toggle("active", el.dataset.themeOption === id);
    });
  }

  function getPreferredTheme() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved && THEMES.some((t) => t.id === saved)) return saved;
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "blueprint" : "daylight";
  }

  // Apply immediately (before paint) to avoid flash
  const current = getPreferredTheme();
  applyTheme(current);

  function buildDropdown(btn) {
    // Wrap the existing button so the dropdown can position relative to it
    const wrap = document.createElement("span");
    wrap.className = "theme-picker-wrap";
    btn.parentNode.insertBefore(wrap, btn);
    wrap.appendChild(btn);

    const dropdown = document.createElement("div");
    dropdown.className = "theme-dropdown";
    dropdown.innerHTML = `<div class="theme-dropdown-label">Base Themes</div>` + THEMES.map((t) => `
      <button type="button" class="theme-option" data-theme-option="${t.id}" style="--sa:${t.swatchA}; --sb:${t.swatchB};">
        <span class="theme-swatch"></span>
        <span>${t.label}</span>
      </button>
    `).join("");
    wrap.appendChild(dropdown);

    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdown.classList.toggle("open");
    });
    document.addEventListener("click", () => dropdown.classList.remove("open"));

    dropdown.querySelectorAll("[data-theme-option]").forEach((opt) => {
      opt.addEventListener("click", () => {
        const id = opt.dataset.themeOption;
        localStorage.setItem(STORAGE_KEY, id);
        applyTheme(id);
        // A premium palette (theme-sync.js) writes its colors as *inline*
        // custom properties on <html>, which otherwise keep overriding
        // whichever base theme is selected here. Picking a base theme is a
        // clear signal to drop back out of any premium palette.
        if (window.CurioThemeSync) window.CurioThemeSync.applyPalette(null);
        dropdown.classList.remove("open");
      });
    });

    applyTheme(getPreferredTheme());
  }

  document.addEventListener("DOMContentLoaded", () => {
    const btn = document.querySelector("[data-theme-toggle]");
    if (!btn) return;
    // Give the label span a stable hook, then build the dropdown around the button
    const label = btn.querySelector(".theme-label");
    if (label) label.setAttribute("data-theme-label", "");
    buildDropdown(btn);
  });

  // ---------------------------------------------------------------------
  // Mobile header regroup — runs on every page (theme.js is universally
  // loaded). Groups search / auth / sound / theme controls into a single
  // .header-controls unit so they wrap as one block on narrow screens
  // instead of spilling past the viewport edge, and splits the search
  // trigger into icon + label so the label can be hidden on small phones.
  //
  // Only the icon-only controls that never open their own popover (search
  // trigger, sound toggle) go inside the horizontally-scrollable inner
  // strip. Auth and theme both open an absolutely-positioned dropdown of
  // their own, and CSS's overflow-x/overflow-y are paired at computed-value
  // time (an ancestor with overflow-x:auto silently gets overflow-y:auto
  // too, even if overflow-y is written as visible) — so anything with a
  // popover has to stay outside the scrollable strip or its dropdown gets
  // clipped and becomes invisible on narrow screens.
  // ---------------------------------------------------------------------
  document.addEventListener("DOMContentLoaded", () => {
    const headerWrap = document.querySelector(".site-header .wrap");
    if (!headerWrap || headerWrap.querySelector(".header-controls")) return;

    const cmdk = headerWrap.querySelector("[data-cmdk-trigger]");
    if (cmdk && !cmdk.querySelector(".cmdk-label")) {
      const kbd = cmdk.querySelector("kbd");
      cmdk.innerHTML =
        '<span class="cmdk-icon" aria-hidden="true">🔍</span><span class="cmdk-label">Search</span>' +
        (kbd ? kbd.outerHTML : "");
    }

    const scrollables = [cmdk, headerWrap.querySelector("[data-sound-toggle]")].filter(Boolean);
    const popoverOwners = [
      headerWrap.querySelector(".auth-widget"),
      headerWrap.querySelector(".theme-picker-wrap") || headerWrap.querySelector("[data-theme-toggle]"),
    ].filter(Boolean);
    const pieces = [...scrollables, ...popoverOwners];
    if (!pieces.length) return;

    const group = document.createElement("div");
    group.className = "header-controls";
    pieces[0].parentNode.insertBefore(group, pieces[0]);

    if (scrollables.length) {
      const scrollStrip = document.createElement("div");
      scrollStrip.className = "header-controls-scroll";
      scrollables.forEach((el) => scrollStrip.appendChild(el));
      group.appendChild(scrollStrip);
    }
    popoverOwners.forEach((el) => group.appendChild(el));
  });
})();
