// Curio Lab — Force vs Acceleration graph (F = m × a)
// A canvas plot of the line F = m*a, with a mass slider and a draggable point on the line.
window.onLessonContentReady(() => {
  const container = document.querySelector("[data-force-graph-canvas]");
  if (!container) return;

  const massInput = document.querySelector("[data-force-graph-mass]");
  const massLabel = document.querySelector("[data-force-graph-mass-label]");
  const readout = document.querySelector("[data-force-graph-readout]");

  const canvas = document.createElement("canvas");
  container.appendChild(canvas);
  const ctx = canvas.getContext("2d");

  const A_MAX = 10; // acceleration axis 0..10 m/s^2
  let W, H, padding = 40;
  let accel = 4; // draggable point's acceleration value
  let dragging = false;

  function resize() {
    W = container.clientWidth;
    H = container.clientHeight;
    canvas.width = W * devicePixelRatio;
    canvas.height = H * devicePixelRatio;
    canvas.style.width = W + "px";
    canvas.style.height = H + "px";
    ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    draw();
  }

  const gridColor = () => getComputedStyle(document.documentElement).getPropertyValue("--color-line").trim() || "rgba(0,0,0,0.1)";
  const inkColor = () => getComputedStyle(document.documentElement).getPropertyValue("--color-ink").trim() || "#111";
  const inkSoft = () => getComputedStyle(document.documentElement).getPropertyValue("--color-ink-soft").trim() || "#666";
  const accentColor = () => getComputedStyle(document.body).getPropertyValue("--accent").trim() || "#2e8e80";

  function toXY(a, f, mass) {
    const fMax = 10 * mass || 1;
    const x = padding + (a / A_MAX) * (W - padding * 1.5);
    const y = H - padding - (f / fMax) * (H - padding * 1.5);
    return [x, y];
  }

  function draw() {
    const mass = parseFloat(massInput ? massInput.value : 2);
    const fMax = A_MAX * mass;

    ctx.clearRect(0, 0, W, H);

    ctx.strokeStyle = gridColor();
    ctx.lineWidth = 1;
    for (let i = 0; i <= 10; i++) {
      const [gx] = toXY((i / 10) * A_MAX, 0, mass);
      ctx.beginPath(); ctx.moveTo(gx, padding * 0.5); ctx.lineTo(gx, H - padding); ctx.stroke();
    }
    for (let i = 0; i <= 5; i++) {
      const [, gy] = toXY(0, (i / 5) * fMax, mass);
      ctx.beginPath(); ctx.moveTo(padding, gy); ctx.lineTo(W - padding * 0.5, gy); ctx.stroke();
    }

    ctx.strokeStyle = inkColor();
    ctx.globalAlpha = 0.7;
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(padding, H - padding); ctx.lineTo(W - padding * 0.5, H - padding); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(padding, padding * 0.5); ctx.lineTo(padding, H - padding); ctx.stroke();
    ctx.globalAlpha = 1;

    ctx.fillStyle = inkSoft();
    ctx.font = "11px 'JetBrains Mono', monospace";
    ctx.textAlign = "center";
    ctx.fillText("Acceleration (m/s²) →", W / 2, H - 10);
    ctx.save();
    ctx.translate(14, H / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText("Force (N) →", 0, 0);
    ctx.restore();

    const [x1, y1] = toXY(0, 0, mass);
    const [x2, y2] = toXY(A_MAX, A_MAX * mass, mass);
    ctx.strokeStyle = accentColor();
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();

    const force = mass * accel;
    const [px, py] = toXY(accel, force, mass);
    ctx.fillStyle = accentColor();
    ctx.beginPath(); ctx.arc(px, py, 8, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.beginPath(); ctx.arc(px, py, 3, 0, Math.PI * 2); ctx.fill();

    if (readout) {
      readout.textContent = `At ${accel.toFixed(1)} m/s² acceleration with a ${mass} kg mass → Force = ${force.toFixed(1)} N`;
    }
  }

  function eventPos(e) {
    const rect = canvas.getBoundingClientRect();
    const t = e.touches ? e.touches[0] : e;
    return [t.clientX - rect.left, t.clientY - rect.top];
  }

  function nearPoint(x, y) {
    const mass = parseFloat(massInput ? massInput.value : 2);
    const [px, py] = toXY(accel, mass * accel, mass);
    return Math.hypot(px - x, py - y) < 18;
  }

  canvas.addEventListener("mousedown", (e) => { const [x, y] = eventPos(e); if (nearPoint(x, y)) dragging = true; });
  canvas.addEventListener("touchstart", (e) => { const [x, y] = eventPos(e); if (nearPoint(x, y)) dragging = true; }, { passive: true });

  function move(x) {
    if (!dragging) return;
    const a = ((x - padding) / (W - padding * 1.5)) * A_MAX;
    accel = Math.max(0, Math.min(A_MAX, a));
    draw();
  }
  window.addEventListener("mousemove", (e) => { if (dragging) { const [x] = eventPos(e); move(x); } });
  window.addEventListener("mouseup", () => { dragging = false; });
  canvas.addEventListener("touchmove", (e) => { const [x] = eventPos(e); move(x); }, { passive: true });
  canvas.addEventListener("touchend", () => { dragging = false; });

  massInput?.addEventListener("input", () => {
    if (massLabel) massLabel.textContent = `${massInput.value} kg`;
    draw();
  });

  window.addEventListener("resize", resize);
  window.addEventListener("curiolab:tab-shown", (e) => { if (e.detail.name === "graph") resize(); });

  resize();
});
