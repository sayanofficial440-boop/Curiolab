// Curio Lab — Interactive Graph (drag two points to reshape a line, y = mx + b)
document.addEventListener("DOMContentLoaded", () => {
  const container = document.querySelector("[data-graph-canvas]");
  if (!container) return;

  const eqLabel = document.querySelector("[data-graph-eq]");
  const resetBtn = document.querySelector("[data-graph-reset]");

  const canvas = document.createElement("canvas");
  container.appendChild(canvas);
  const ctx = canvas.getContext("2d");

  const RANGE = 10; // math coords go from -RANGE to +RANGE on both axes
  let W, H, scale, originX, originY;

  function resize() {
    W = container.clientWidth;
    H = container.clientHeight;
    canvas.width = W * devicePixelRatio;
    canvas.height = H * devicePixelRatio;
    canvas.style.width = W + "px";
    canvas.style.height = H + "px";
    ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    scale = Math.min(W, H) / (RANGE * 2);
    originX = W / 2;
    originY = H / 2;
    draw();
  }

  function toCanvas(x, y) { return [originX + x * scale, originY - y * scale]; }
  function toMath(px, py) { return [(px - originX) / scale, (originY - py) / scale]; }

  // Two draggable points, default forming y = 0.5x + 1
  let p1 = { x: -4, y: -1 };
  let p2 = { x: 4, y: 3 };
  let dragging = null;

  function getLineParams() {
    const m = (p2.y - p1.y) / (p2.x - p1.x || 0.0001);
    const b = p1.y - m * p1.x;
    return { m, b };
  }

  const gridColor = () => getComputedStyle(document.documentElement).getPropertyValue("--color-line").trim() || "rgba(0,0,0,0.1)";
  const inkColor = () => getComputedStyle(document.documentElement).getPropertyValue("--color-ink").trim() || "#111";
  const accentColor = () => getComputedStyle(document.body).getPropertyValue("--accent").trim() || "#c94a38";

  function draw() {
    ctx.clearRect(0, 0, W, H);

    // grid
    ctx.strokeStyle = gridColor();
    ctx.lineWidth = 1;
    for (let i = -RANGE; i <= RANGE; i++) {
      const [gx] = toCanvas(i, 0);
      const [, gy] = toCanvas(0, i);
      ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke();
    }

    // axes
    ctx.strokeStyle = inkColor();
    ctx.globalAlpha = 0.6;
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(0, originY); ctx.lineTo(W, originY); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(originX, 0); ctx.lineTo(originX, H); ctx.stroke();
    ctx.globalAlpha = 1;

    // the line itself, extended to canvas edges
    const { m, b } = getLineParams();
    const xLeftMath = -RANGE * 1.4, xRightMath = RANGE * 1.4;
    const yLeft = m * xLeftMath + b, yRight = m * xRightMath + b;
    const [lx1, ly1] = toCanvas(xLeftMath, yLeft);
    const [lx2, ly2] = toCanvas(xRightMath, yRight);
    ctx.strokeStyle = accentColor();
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(lx1, ly1); ctx.lineTo(lx2, ly2); ctx.stroke();

    // handles
    [p1, p2].forEach((p) => {
      const [cx, cy] = toCanvas(p.x, p.y);
      ctx.fillStyle = accentColor();
      ctx.beginPath(); ctx.arc(cx, cy, 8, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.beginPath(); ctx.arc(cx, cy, 3, 0, Math.PI * 2); ctx.fill();
    });

    if (eqLabel) {
      eqLabel.textContent = `y = ${m.toFixed(2)}x ${b >= 0 ? "+" : "-"} ${Math.abs(b).toFixed(2)}`;
    }
  }

  function pointNear(px, py) {
    for (const p of [p1, p2]) {
      const [cx, cy] = toCanvas(p.x, p.y);
      if (Math.hypot(cx - px, cy - py) < 16) return p;
    }
    return null;
  }

  function eventPos(e) {
    const rect = canvas.getBoundingClientRect();
    const t = e.touches ? e.touches[0] : e;
    return [t.clientX - rect.left, t.clientY - rect.top];
  }

  canvas.addEventListener("mousedown", (e) => { const [x, y] = eventPos(e); dragging = pointNear(x, y); });
  canvas.addEventListener("touchstart", (e) => { const [x, y] = eventPos(e); dragging = pointNear(x, y); }, { passive: true });

  function move(x, y) {
    if (!dragging) return;
    let [mx, my] = toMath(x, y);
    mx = Math.max(-RANGE, Math.min(RANGE, Math.round(mx * 2) / 2));
    my = Math.max(-RANGE, Math.min(RANGE, Math.round(my * 2) / 2));
    dragging.x = mx; dragging.y = my;
    draw();
  }

  window.addEventListener("mousemove", (e) => { if (dragging) { const [x, y] = eventPos(e); move(x, y); } });
  window.addEventListener("mouseup", () => { dragging = null; });
  canvas.addEventListener("touchmove", (e) => { const [x, y] = eventPos(e); move(x, y); }, { passive: true });
  canvas.addEventListener("touchend", () => { dragging = null; });

  resetBtn?.addEventListener("click", () => {
    p1 = { x: -4, y: -1 }; p2 = { x: 4, y: 3 }; draw();
  });

  window.addEventListener("resize", resize);
  window.addEventListener("curiolab:tab-shown", (e) => { if (e.detail.name === "graph") resize(); });

  resize();
});
