// Curio Lab — accessibility preferences, applied on every page before first paint.
//
// Preferences (saved on this device, edited from the quick panel on every page and
// from pages/accessibility.html):
//   scale 85–200 · font (default | dyslexia | readable) · spacing · contrast + hc theme
//   (light | dark) · underlined links · reduced motion · colour-blind-safe palette ·
//   captions on by default for video.
// Anything the learner has NOT chosen follows the device: "reduce motion" and
// "increase contrast" start on when the operating system asks for them.
//
// The quick panel / keyboard shortcut / ARIA + media enhancements live in
// a11y-panel.js, which this file loads once the page is parsed.
(function () {
  "use strict";
  if (window.CurioA11y) return;
  const SRC = (document.currentScript && document.currentScript.src) || "";
  const KEY = "curiolab-a11y";
  const DEFAULTS = { scale: 100, font: "default", spacing: "normal", contrast: false, hc: "light", links: false, motion: false, cb: false, captions: true };
  const mq = (q) => { try { return window.matchMedia(q); } catch (_) { return { matches: false, addEventListener() {}, addListener() {} }; } };
  const mqMotion = mq("(prefers-reduced-motion: reduce)"), mqContrast = mq("(prefers-contrast: more)"), mqForced = mq("(forced-colors: active)");

  const stored = () => { try { const o = JSON.parse(localStorage.getItem(KEY)); return o && typeof o === "object" ? o : {}; } catch (_) { return {}; } };
  // defaults < what the device asks for < what the learner chose
  const read = () => {
    const sys = {};
    if (mqMotion.matches) sys.motion = true;
    if (mqContrast.matches && !mqForced.matches) sys.contrast = true;
    return Object.assign({}, DEFAULTS, sys, stored());
  };

  const CSS = `
  /* ---------- shared tokens: Okabe–Ito colour-blind-safe palette (use these for any chart) ---------- */
  :root{--cb-blue:#0072b2;--cb-orange:#e69f00;--cb-sky:#56b4e9;--cb-green:#009e73;--cb-yellow:#f0e442;--cb-vermillion:#d55e00;--cb-purple:#cc79a7;--cb-black:#111}
  /* ---------- text size / font / spacing ---------- */
  html[data-a11y-scale]{font-size:calc(var(--a11y-scale,100) * 1%)}
  html[data-a11y-scale] body{font-size:calc(16px * var(--a11y-scale,100) / 100)}
  html[data-a11y-font="dyslexia"] body,html[data-a11y-font="dyslexia"] body *:not(svg):not(svg *):not(code):not(pre):not(kbd):not([data-lang-btn] *){font-family:"Lexend","OpenDyslexic","Atkinson Hyperlegible","Verdana",sans-serif!important;letter-spacing:.02em;word-spacing:.08em}
  html[data-a11y-font="readable"] body,html[data-a11y-font="readable"] body *:not(svg):not(svg *):not(code):not(pre):not(kbd){font-family:"Atkinson Hyperlegible","Verdana",sans-serif!important}
  html[data-a11y-font="dyslexia"] body :is(p,li,dd,blockquote,td){text-align:left!important;hyphens:none!important}
  html[data-a11y-spacing="relaxed"] body :is(p,li,dd,td,label){line-height:1.85!important}
  html[data-a11y-spacing="loose"] body :is(p,li,dd,td,label){line-height:2.1!important;letter-spacing:.03em;word-spacing:.12em}
  html[data-a11y-links="on"] a:not(.logo):not(.st-btn):not(.hm-t){text-decoration:underline!important;text-underline-offset:3px}

  /* ---------- keyboard focus: a two-tone ring that shows on light and dark surfaces ---------- */
  :where(a[href],button,input,select,textarea,summary,[role=button],[role=tab],[role=switch],[tabindex]):focus-visible{outline:3px solid #1d4ed8;outline-offset:2px;box-shadow:0 0 0 5px rgba(255,255,255,.92)}
  .a11y-skip{position:fixed;left:8px;top:-80px;z-index:2147483600;background:#000;color:#fff;padding:12px 18px;border-radius:8px;font:600 15px/1.2 system-ui,sans-serif;text-decoration:none;border:2px solid #fff}
  .a11y-skip:focus{top:8px}
  .a11y-sr{position:absolute!important;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap;border:0}

  /* ---------- high contrast (forced scheme, like Windows contrast themes) ---------- */
  html[data-a11y-contrast]{color-scheme:light;--hc-bg:#fff;--hc-fg:#000;--hc-link:#0000c8;--hc-focus:#0000c8;--hc-mute:#fff;--color-bg:#fff;--color-bg-alt:#fff;--color-surface:#fff;--color-ink:#000;--color-ink-soft:#000;--color-line:#000;--color-line-strong:#000;--bg:#fff;--panel:#fff;--ink:#000;--ink-soft:#000;--ink-faint:#000;--line:#000;--line-soft:#000}
  html[data-a11y-contrast][data-a11y-hc="dark"]{color-scheme:dark;--hc-bg:#000;--hc-fg:#fff;--hc-link:#ffff4d;--hc-focus:#ffff4d;--color-bg:#000;--color-bg-alt:#000;--color-surface:#000;--color-ink:#fff;--color-ink-soft:#fff;--color-line:#fff;--color-line-strong:#fff;--bg:#000;--panel:#000;--ink:#fff;--ink-soft:#fff;--ink-faint:#fff;--line:#fff;--line-soft:#fff}
  html[data-a11y-contrast]::before,html[data-a11y-contrast]::after,html[data-a11y-contrast] body::before,html[data-a11y-contrast] body::after{display:none!important}
  html[data-a11y-contrast],html[data-a11y-contrast] body{background:var(--hc-bg)!important;color:var(--hc-fg)!important;background-image:none!important}
  html[data-a11y-contrast] body *:not(img):not(video):not(canvas):not(iframe):not(svg):not(svg *):not(.hm-t):not(.hm-key i):not(.mk-meter i):not(.rv-bar i):not(.a11y-keep):not(.a11y-keep *):not([class*=backdrop]):not([class*=veil]):not([class*=overlay]):not([class*=scrim]):not([class*=curtain]):not([class*=confetti]):not([class*=cursor]):not([class*=shine]):not([class*=glow]){background-color:var(--hc-bg)!important;background-image:none!important;color:var(--hc-fg)!important;border-color:var(--hc-fg)!important;text-shadow:none!important;box-shadow:none!important;-webkit-text-fill-color:var(--hc-fg)!important}
  html[data-a11y-contrast] body *::before,html[data-a11y-contrast] body *::after{color:var(--hc-fg)!important;text-shadow:none!important}
  html[data-a11y-contrast] body a:not(.hm-t),html[data-a11y-contrast] body a:not(.hm-t) *{color:var(--hc-link)!important;-webkit-text-fill-color:var(--hc-link)!important;text-decoration:underline!important;text-underline-offset:3px}
  html[data-a11y-contrast] :is(button,.st-btn,input,select,textarea,.mk-chip,[role=tab],[role=button]){border:2px solid var(--hc-fg)!important}
  html[data-a11y-contrast] :is(button,.st-btn,.mk-chip,[role=tab])[aria-pressed=true],html[data-a11y-contrast] [role=tab][aria-selected=true],html[data-a11y-contrast] :is(.mode-tab,.tab).active{background-color:var(--hc-fg)!important;color:var(--hc-bg)!important;-webkit-text-fill-color:var(--hc-bg)!important}
  html[data-a11y-contrast] :is(.card,.st-card,.panel,.st-stat,.stat-card,section.card,article,details,fieldset){border:2px solid var(--hc-fg)!important}
  html[data-a11y-contrast] :focus-visible{outline:4px solid var(--hc-focus)!important;outline-offset:3px!important;box-shadow:0 0 0 7px var(--hc-bg)!important}
  html[data-a11y-contrast] .mk-meter,html[data-a11y-contrast] .rv-bar{border:2px solid var(--hc-fg)!important;background:var(--hc-bg)!important}
  html[data-a11y-contrast] .mk-meter i,html[data-a11y-contrast] .rv-bar i{background:var(--hc-fg)!important}
  html[data-a11y-contrast] .hm-t{border:2px solid var(--hc-fg)!important;color:#000!important}
  html[data-a11y-contrast][data-a11y-hc="dark"] .hm-t{color:#000!important}

  /* ---------- reduced motion ---------- */
  html[data-a11y-motion="reduce"] *,html[data-a11y-motion="reduce"] *::before,html[data-a11y-motion="reduce"] *::after{animation-duration:.001ms!important;animation-iteration-count:1!important;animation-delay:0s!important;transition-duration:.001ms!important;transition-delay:0s!important;scroll-behavior:auto!important}
  html[data-a11y-motion="reduce"] :is(.curio-cursor-dot,.curio-cursor-ring,.cl-confetti-piece,.quiz-confetti-piece,.marquee-track,[data-parallax]){display:none!important}
  html[data-a11y-motion="reduce"] [data-reveal],html[data-a11y-motion="reduce"] .reveal{opacity:1!important;transform:none!important}

  /* ---------- colour-blind-safe charts: never colour alone ---------- */
  /* Always on: each state also carries a pattern or glyph, so the palette is a bonus, not the only cue. */
  .hm-weak{background-image:repeating-linear-gradient(135deg,rgba(0,0,0,.16) 0 3px,transparent 3px 8px)}
  .hm-ok{background-image:radial-gradient(rgba(0,0,0,.2) 1.2px,transparent 1.4px);background-size:8px 8px}
  .hm-key i.hm-weak{background-image:repeating-linear-gradient(135deg,rgba(0,0,0,.28) 0 2px,transparent 2px 5px)}
  .hm-key i.hm-ok{background-image:radial-gradient(rgba(0,0,0,.35) 1px,transparent 1.2px);background-size:5px 5px}
  :is(.quiz-option,.st-opt,.xc-ropt,.pl-choice,.tf-btn,.mcq-opt).correct::after,:is(.pl-choice,.pr-feedback).ok::before{content:" ✓";font-weight:800}
  :is(.quiz-option,.st-opt,.xc-ropt,.pl-choice,.tf-btn,.mcq-opt).wrong::after,:is(.pl-choice,.pr-feedback).bad::before{content:" ✗";font-weight:800}
  html[data-a11y-cb="on"]{--color-teal:#0072b2;--color-moss:#0072b2;--color-coral:#d55e00;--color-amber:#e69f00;--pr-ok:#0072b2;--pr-bad:#d55e00;--pr-warn:#e69f00}
  html[data-a11y-cb="on"] .hm-strong{background-color:#56b4e9!important;color:#000!important}
  html[data-a11y-cb="on"] .hm-ok{background-color:#f0e442!important;color:#000!important}
  html[data-a11y-cb="on"] .hm-weak{background-color:#d55e00!important;color:#fff!important}
  html[data-a11y-cb="on"] .mk-meter i,html[data-a11y-cb="on"] .rv-bar i{background:#0072b2!important}
  html[data-a11y-cb="on"] :is(.quiz-option,.st-opt,.xc-ropt,.pl-choice,.tf-btn).correct,html[data-a11y-cb="on"] .pl-choice.ok{border-color:#0072b2!important;background-color:rgba(0,114,178,.14)!important;border-style:solid!important;border-width:2.5px!important}
  html[data-a11y-cb="on"] :is(.quiz-option,.st-opt,.xc-ropt,.pl-choice,.tf-btn).wrong,html[data-a11y-cb="on"] .pl-choice.bad{border-color:#d55e00!important;background-color:rgba(213,94,0,.14)!important;border-style:dashed!important;border-width:2.5px!important}
  html[data-a11y-cb="on"] :is(.pr-feedback.ok,.xc-ropt.correct em){border-color:#0072b2!important;color:inherit}
  html[data-a11y-cb="on"] :is(.pr-feedback.bad,.xc-ropt.wrong em){border-color:#d55e00!important}
  html[data-a11y-cb="on"] .ok{--ok:#0072b2}
  html[data-a11y-cb="on"] .bad{--bad:#d55e00}`;

  const FONT_HREF = "https://fonts.googleapis.com/css2?family=Lexend:wght@400;500;600;700&family=Atkinson+Hyperlegible:wght@400;700&display=swap";
  const listeners = [];
  function apply(p) {
    const h = document.documentElement;
    h.setAttribute("data-a11y-scale", String(p.scale)); h.style.setProperty("--a11y-scale", String(p.scale));
    p.font !== "default" ? h.setAttribute("data-a11y-font", p.font) : h.removeAttribute("data-a11y-font");
    p.spacing !== "normal" ? h.setAttribute("data-a11y-spacing", p.spacing) : h.removeAttribute("data-a11y-spacing");
    if (p.contrast) { h.setAttribute("data-a11y-contrast", "high"); h.setAttribute("data-a11y-hc", p.hc === "dark" ? "dark" : "light"); }
    else { h.removeAttribute("data-a11y-contrast"); h.removeAttribute("data-a11y-hc"); }
    p.links ? h.setAttribute("data-a11y-links", "on") : h.removeAttribute("data-a11y-links");
    p.cb ? h.setAttribute("data-a11y-cb", "on") : h.removeAttribute("data-a11y-cb");
    p.motion ? h.setAttribute("data-a11y-motion", "reduce") : h.removeAttribute("data-a11y-motion");
    h.setAttribute("data-a11y-captions", p.captions === false ? "off" : "on");
    if (p.scale === 100) { h.removeAttribute("data-a11y-scale"); h.style.removeProperty("--a11y-scale"); }
    if ((p.font === "dyslexia" || p.font === "readable") && !document.getElementById("a11y-font-link")) {
      const l = document.createElement("link"); l.id = "a11y-font-link"; l.rel = "stylesheet"; l.href = FONT_HREF;
      (document.head || h).appendChild(l);
    }
    listeners.forEach((fn) => { try { fn(p); } catch (_) { /* a listener must never break the page */ } });
  }

  const style = document.createElement("style"); style.id = "a11y-css"; style.textContent = CSS;
  (document.head || document.documentElement).appendChild(style);
  apply(read());

  // When motion is reduced, smooth scrolling is switched off for script-driven scrolls too.
  const reduced = () => document.documentElement.getAttribute("data-a11y-motion") === "reduce";
  try {
    const sIV = Element.prototype.scrollIntoView;
    Element.prototype.scrollIntoView = function (a) { if (reduced() && a && typeof a === "object") a = Object.assign({}, a, { behavior: "auto" }); return sIV.call(this, a); };
    const sT = window.scrollTo.bind(window);
    window.scrollTo = function (a, b) { if (reduced() && a && typeof a === "object") a = Object.assign({}, a, { behavior: "auto" }); return b === undefined ? sT(a) : sT(a, b); };
  } catch (_) { /* old browser: CSS still applies */ }

  // Polite screen-reader announcements (language changed, setting applied, …).
  let live = null;
  function announce(msg) {
    if (!live) { live = document.createElement("div"); live.className = "a11y-sr"; live.setAttribute("role", "status"); live.setAttribute("aria-live", "polite"); live.setAttribute("data-no-i18n", ""); (document.body || document.documentElement).appendChild(live); }
    live.textContent = ""; setTimeout(() => { live.textContent = msg; }, 60);
  }

  window.CurioA11y = {
    DEFAULTS, get: read, announce, reducedMotion: reduced,
    onChange(fn) { listeners.push(fn); },
    // Only what the learner changes is saved, so everything else keeps following the device.
    set(patch) { const o = Object.assign(stored(), patch); try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (_) { /* private mode */ } const p = read(); apply(p); return p; },
    reset() { try { localStorage.removeItem(KEY); } catch (_) { /* ignore */ } const p = read(); apply(p); return p; },
    isDefault: () => !Object.keys(stored()).length,
  };
  window.addEventListener("storage", (e) => { if (e.key === KEY) apply(read()); });
  [mqMotion, mqContrast].forEach((m) => { const f = () => apply(read()); m.addEventListener ? m.addEventListener("change", f) : m.addListener && m.addListener(f); });

  // "Skip to content" link for keyboard and screen-reader users.
  function skipLink() {
    const main = document.querySelector("main, .main, [role=main]");
    if (!main || document.querySelector(".a11y-skip")) return;
    if (!main.id) main.id = "main-content";
    const a = document.createElement("a"); a.className = "a11y-skip"; a.href = "#" + main.id; a.textContent = "Skip to main content";
    document.body.insertBefore(a, document.body.firstChild);
    if (!main.hasAttribute("tabindex")) main.setAttribute("tabindex", "-1");
  }

  // The quick panel, ARIA fixes and caption/transcript tools load once the page is parsed.
  function loadPanel() {
    skipLink();
    if (!SRC || document.getElementById("a11y-panel-js")) return;
    const s = document.createElement("script"); s.id = "a11y-panel-js"; s.src = SRC.replace(/a11y\.js(\?.*)?$/, "a11y-panel.js$1"); s.async = true;
    document.head.appendChild(s);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", loadPanel); else loadPanel();
})();
