// Curio Lab — Store.js
//
// A small reactive pub/sub state store. Plain script, attaches to
// `window.CurioStore` — matches every other module in js/ (sound.js,
// theme.js, etc.), NOT an ES module. This project's pages load scripts as
// `<script src="js/whatever.js">`, not `type="module"`, so an import/export
// file would silently do nothing when dropped in. See vite.config.js's own
// comment for why: Vite only bundles module-type scripts, and none of the
// current <script> tags are declared that way yet.
//
// WHY THIS SHAPE:
// The project doesn't currently lack "state" — it has ~15 independent
// localStorage keys (curiolab-theme, curiolab-sound, curiolab-scores,
// curiolab-mastery-<path>, etc.) each read/written by a different file with
// its own JSON.parse/stringify boilerplate. This store reads and writes
// those SAME keys, so:
//   1. Nothing breaks today — theme.js, sound.js, quiz.js, profile.js,
//      flashcards.js etc. keep working exactly as they do now.
//   2. Any file can be migrated to go through the store later, one at a
//      time, instead of a single risky rewrite of everything at once.
//   3. New code (or new pages) gets one API instead of copy-pasting
//      localStorage try/catch boilerplate again.
//
// USAGE
//   CurioStore.get('theme')                 -> 'daylight'
//   CurioStore.set('theme', 'midnight')     -> writes + notifies subscribers
//   const unsub = CurioStore.subscribe('theme', (value) => { ... });
//   unsub(); // stop listening
//
// Cross-tab: if the user has two Curio Lab tabs open and changes the theme
// in one, the other tab's subscribers fire too (via the native `storage`
// event), without either tab needing to poll.

(function () {
  "use strict";

  if (window.CurioStore) return; // already loaded on this page — no-op

  /**
   * Registry of known state slices. Each entry maps a short store key to
   * the real localStorage key already used elsewhere in the codebase, plus
   * how to serialize/deserialize it (most existing keys are JSON, a couple
   * are raw strings like "on"/"off").
   *
   * Two entries — cameraPosition and activePlanet — aren't written by any
   * existing file. They're placeholders for the 3D navigation state a
   * SceneManager-style module would need; they default sensibly and don't
   * assume that module exists yet.
   */
  var REGISTRY = {
    theme: { storageKey: "curiolab-theme", raw: true, fallback: "daylight" },
    sound: { storageKey: "curiolab-sound", raw: true, fallback: "on" },
    ambient: { storageKey: "curiolab-ambient", raw: true, fallback: "off" },
    scores: { storageKey: "curiolab-scores", json: true, fallback: {} },
    profilePrefs: { storageKey: "curiolab-profile-prefs", json: true, fallback: {} },
    microgameStreak: { storageKey: "curiolab-microgame-streak", json: true, fallback: { count: 0, lastDay: null } },
    playgroundStreak: { storageKey: "curiolab-playground-streak", json: true, fallback: { count: 0, lastDay: null } },
    recallStats: { storageKey: "curiolab-recall-stats", json: true, fallback: {} },
    // Mastery is per-page in the existing code (curiolab-mastery-<pathname>).
    // Exposed as a function-backed slice below rather than a fixed key.
    activePlanet: { storageKey: "curiolab-active-planet", raw: true, fallback: null, virtual: true },
    cameraPosition: { storageKey: "curiolab-camera-position", json: true, fallback: null, virtual: true },
  };

  function mastersKeyFor(pathname) {
    return "curiolab-mastery-" + (pathname || window.location.pathname);
  }

  /** @type {Object<string, Array<Function>>} key -> list of subscriber callbacks */
  var listeners = {};

  function notify(key, value) {
    var subs = listeners[key];
    if (!subs || !subs.length) return;
    // Copy before iterating: a subscriber unsubscribing itself mid-notify
    // shouldn't skip the next callback in line.
    subs.slice().forEach(function (cb) {
      try {
        cb(value, key);
      } catch (err) {
        console.error("[CurioStore] subscriber for '" + key + "' threw:", err);
      }
    });
  }

  function readRaw(entry) {
    try {
      var stored = window.localStorage.getItem(entry.storageKey);
      if (stored === null) return entry.fallback;
      if (entry.json) {
        return JSON.parse(stored);
      }
      return stored;
    } catch (err) {
      // Storage disabled (private browsing lockouts on some browsers) or
      // corrupt JSON from a previous version — fall back rather than throw,
      // so a bad value never breaks page load.
      console.warn("[CurioStore] failed reading '" + entry.storageKey + "', using fallback:", err);
      return entry.fallback;
    }
  }

  function writeRaw(entry, value) {
    try {
      if (value === null || value === undefined) {
        window.localStorage.removeItem(entry.storageKey);
        return;
      }
      window.localStorage.setItem(entry.storageKey, entry.json ? JSON.stringify(value) : String(value));
    } catch (err) {
      console.warn("[CurioStore] failed writing '" + entry.storageKey + "':", err);
    }
  }

  var CurioStore = {
    /**
     * Read a state slice by its short key (e.g. 'theme', 'scores').
     * Always returns the fallback shape rather than null/undefined for
     * json entries, so callers can destructure without guarding.
     */
    get: function (key) {
      var entry = REGISTRY[key];
      if (!entry) {
        console.warn("[CurioStore] unknown key '" + key + "'");
        return undefined;
      }
      return readRaw(entry);
    },

    /**
     * Write a state slice and notify subscribers. Pass null to clear it.
     */
    set: function (key, value) {
      var entry = REGISTRY[key];
      if (!entry) {
        console.warn("[CurioStore] unknown key '" + key + "'");
        return;
      }
      writeRaw(entry, value);
      notify(key, value);
    },

    /**
     * Convenience for object-shaped slices: merges `patch` into the
     * current value instead of requiring the caller to read-modify-write.
     * e.g. CurioStore.patch('profilePrefs', { bio: 'new bio' })
     */
    patch: function (key, patch) {
      var current = this.get(key);
      var merged = Object.assign({}, current, patch);
      this.set(key, merged);
      return merged;
    },

    /**
     * Subscribe to changes on a key. Returns an unsubscribe function.
     * Fires only on CurioStore.set()/patch() calls in THIS tab; for
     * cross-tab updates see the native 'storage' listener registered below,
     * which re-fires the same subscribers.
     */
    subscribe: function (key, callback) {
      if (!REGISTRY[key]) {
        console.warn("[CurioStore] subscribing to unknown key '" + key + "'");
      }
      if (!listeners[key]) listeners[key] = [];
      listeners[key].push(callback);
      return function unsubscribe() {
        var subs = listeners[key];
        if (!subs) return;
        var idx = subs.indexOf(callback);
        if (idx !== -1) subs.splice(idx, 1);
      };
    },

    /** Per-page mastery set (flashcards.js's curiolab-mastery-<pathname>). */
    getMastery: function (pathname) {
      try {
        var stored = window.localStorage.getItem(mastersKeyFor(pathname));
        return stored ? new Set(JSON.parse(stored)) : new Set();
      } catch (err) {
        console.warn("[CurioStore] failed reading mastery set:", err);
        return new Set();
      }
    },
    setMastery: function (pathname, masteredSet) {
      var key = mastersKeyFor(pathname);
      try {
        window.localStorage.setItem(key, JSON.stringify(Array.from(masteredSet)));
      } catch (err) {
        console.warn("[CurioStore] failed writing mastery set:", err);
        return;
      }
      notify("mastery:" + key, masteredSet);
    },
  };

  // Cross-tab sync: when another tab writes one of our tracked keys, fire
  // the same local subscribers so a component watching e.g. 'theme'
  // updates without polling or a page reload.
  window.addEventListener("storage", function (evt) {
    if (!evt.key) return;
    for (var key in REGISTRY) {
      if (REGISTRY[key].storageKey === evt.key) {
        notify(key, CurioStore.get(key));
        return;
      }
    }
    if (evt.key.indexOf("curiolab-mastery-") === 0) {
      notify("mastery:" + evt.key, CurioStore.getMastery(evt.key.replace("curiolab-mastery-", "")));
    }
  });

  window.CurioStore = CurioStore;
})();
