# Added: courses, past papers, review push
- Courses: pages/courses.html, js/courses-data.js (ordered path per subject, generated from catalog + lesson-meta), js/courses.js, js/course-bar.js (bar on every lesson with prev/next + "recommended first" hint). Soft ordering: lessons never lock.
- Past papers: pages/past-papers.html, js/past-papers.js, js/papers/papers-data.js (2 original 27-mark papers: Physics, Mathematics; MCQ/FIB/TF auto-marked, VSA/SA/LA/CBQ self-marked against marking points). Linked from Exam Center, nav, palette.
- Review push: backend/app.py (/api/push/key|sync|unsubscribe + scheduler, VAPID auto-generated), js/review-push.js, sw.js push + click handlers (cache bumped to curio-v2). Toggle on the Mistake Notebook page.
- Deploy: pip install -r backend/requirements.txt; HTTPS; gunicorn -w 1 (see backend/README.md).
- Next for you: js/next-lesson.js (weak-spot recommendation: missing foundation -> weakest lesson -> next in path; uses Mistake Notebook + quiz scores). Shown as the first dashboard plan step, first row of the Recommended tab, the Coach card, and a "Next for you" link on lesson pages (course-bar). Loaded on the dashboard and all 92 lesson pages.

# Added: children's privacy, SEO and sharing
- COPPA-style handling: neutral age screen on sign-up (js/age-gate.js, only the age band is kept), child accounts with nickname + parent email, parent approval by "email plus", parent page (pages/parent.html) to review/download/delete, features that send data off the device switched off for children (contact form, live AI, push, Google Translate, social share, subscribe; videos and certificates need approval). Backend: backend/coppa.py, backend/mailer.py. Privacy page and FAQ rewritten.
- SEO: `node scripts/build-seo.mjs` (npm run seo; runs before dev/build) writes a unique title, description, canonical, Open Graph + Twitter card and JSON-LD (Course, Quiz for questions, Quiz for flashcards, BreadcrumbList) into every lesson, a CollectionPage list into each subject hub, canonical + share image into other pages, sitemap.xml (lastmod only moves when a page changes, plus image entries) and robots.txt. Share images: `python3 scripts/seo/og_images.py` (Pillow), 101 PNGs in public/og/. `npm run seo:check` fails in CI when stale.
- Sharing: Share button on every lesson (js/share.js), tab deep links (`#quiz`, `#cards`, ...).
- Certificates: real server endpoints and shareable verification pages `/verify/<code>` with previews, a code-entry page (pages/verify.html), revocation.

# Added: reliability and monitoring
- Backups (backend/backup.py): daily verified, compressed SQLite backups with pruning, optional second copy location, verify/restore commands.
- Admin login lockout stored in the DB (5/account, 20/address per 15 min), audit-logged.
- Branded 500 page (public/500.html) and 404/500/JSON handlers in the backend (backend/monitoring.py); 404 now loads from any URL depth.
- First-party browser error reports (js/monitor.js -> /api/client-error -> /api/admin/errors); optional server Sentry via SENTRY_DSN.
- Optional consent-gated Plausible analytics (off until analytics.plausibleDomain is set); runtime config generated from site.config.json.
- CI (.github/workflows/checks.yml): learning sync, SEO/sitemap, runtime config, page chrome, backend tests. Privacy page now mentions error reports and backups. Service worker cache bumped to curio-v5.

# Added: remaining partly-done items
- Scripts: `defer` added to 280+ script tags (scripts/defer-scripts.mjs; theme, a11y, consent and monitor stay synchronous). Checked in headless Chromium on 145 pages: no new JS errors, same page structure. Wired into `npm run prebuild`, `npm run check` and CI.
- Images: share images re-saved with a 128-colour palette (3.1 MB to 1.5 MB, visually identical); author portraits get lazy loading, reserved size and no-referrer; certificate preview lazy.
- Rate limiting: database-backed and shared across workers (contact, push, certificates, child accounts, error reports).
- Certificates: reported scores must name a real lesson and a possible quiz length.
- Blog: 5 new articles (10 total), RSS feed at /feed.xml with auto-discovery link; Help Center has HowTo schema for each guide.
