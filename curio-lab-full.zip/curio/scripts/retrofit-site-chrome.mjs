#!/usr/bin/env node
// One-off, idempotent: adds the cookie-consent script to every HTML page and extends the footer's Company column
// with Careers / Press / Partners plus a "Help & legal" column. Safe to re-run.   node scripts/retrofit-site-chrome.mjs [--check]
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { companyCols } from "./site-pages/shell.mjs";

const PUB = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "public");
const check = process.argv.includes("--check");
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : e.name.endsWith(".html") ? [path.join(d, e.name)] : []));
let age = 0, consent = 0, footer = 0, mon = 0, pending = 0;
const COL = /<div class="footer-col">\s*<h5>Company<\/h5>\s*<ul>[\s\S]*?<\/ul>\s*<\/div>/;

for (const f of walk(PUB)) {
  let s = fs.readFileSync(f, "utf8"), o = s;
  const rel = path.relative(PUB, f);
  if (rel === "500.html") continue; // must stay self-contained: it is shown when the server is unhealthy
  const P = "../".repeat(rel.split(path.sep).length - 1);
  if (!s.includes("cookie-consent.js") && s.includes("</head>")) {
    s = s.replace("</head>", `<script src="${P}js/cookie-consent.js"></script>\n</head>`);
    consent++;
  }
  if (!s.includes("age-gate.js") && s.includes("cookie-consent.js")) {
    s = s.replace(/<script src="((?:\.\.\/)*|\/?)js\/cookie-consent\.js"><\/script>/, '<script src="$1js/age-gate.js"></script>\n$&');
    age++;
  }
  if (!s.includes("monitor.js") && /<script src="(?:\.\.\/)*\/?js\/age-gate\.js"><\/script>/.test(s)) {
    s = s.replace(/<script src="((?:\.\.\/)*|\/?)js\/age-gate\.js"><\/script>/, '<script src="$1js/site-config.js"></script>\n<script src="$1js/monitor.js"></script>\n$&');
    mon++;
  }
  if (COL.test(s) && !s.includes("Help &amp; legal")) {
    const m = s.match(/href="((?:\.\.\/)*)about\.html"/);
    const L = m ? m[1] : "";
    s = s.replace(COL, companyCols(L));
    footer++;
  }
  if (s !== o) { pending++; if (!check) fs.writeFileSync(f, s); }
}
console.log(`${check ? "[check] " : ""}age-gate script added to ${age} files, cookie script added to ${consent} files, footer extended in ${footer} files, monitor script added to ${mon} files`);
if (check && pending) process.exit(1);
