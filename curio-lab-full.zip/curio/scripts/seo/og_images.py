#!/usr/bin/env python3
"""Render the Open Graph share images listed in public/data/seo-manifest.json.

Run after `node scripts/build-seo.mjs` (npm run seo does both). Only images whose content hash changed are redrawn.
Needs Pillow:  pip install -r backend/requirements.txt
"""
import hashlib, json, os, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "backend"))
from imaging import og_card, SUBJECT_ACCENT, GOLD  # noqa: E402

PUB = os.path.join(ROOT, "public")
man_path = os.path.join(PUB, "data", "seo-manifest.json")
state_path = os.path.join(PUB, "data", ".og-state.json")
force = "--force" in sys.argv

manifest = json.load(open(man_path, encoding="utf8"))
state = json.load(open(state_path)) if os.path.exists(state_path) and not force else {}
made = skipped = 0
for item in manifest["og"]:
    out = os.path.join(PUB, item["image"].lstrip("/"))
    h = hashlib.sha1(json.dumps(item, sort_keys=True).encode()).hexdigest()[:12]
    if state.get(item["image"]) == h and os.path.exists(out):
        skipped += 1
        continue
    os.makedirs(os.path.dirname(out), exist_ok=True)
    accent = SUBJECT_ACCENT.get(item.get("subject", ""), GOLD)
    og_card(out, item["title"], item.get("subjectLabel", ""), accent, item.get("chips", []))
    state[item["image"]] = h
    made += 1
json.dump(state, open(state_path, "w"), indent=0)
print(f"og images: {made} drawn, {skipped} up to date")
