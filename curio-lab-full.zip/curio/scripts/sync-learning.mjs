#!/usr/bin/env node
/**
 * Curio Lab — learning content sync
 * ---------------------------------------------------------------------------
 * Lesson pages are the single source of truth. Every lesson under
 * public/pages/<subject>/<lesson>.html carries three JSON blocks:
 *
 *   <script type="application/json" data-card-deck>   flashcards  [{term, def}]
 *   <script type="application/json" data-slide-deck>  slides
 *   <script type="application/json" data-quiz-data>   quiz        [{q, options, correct}]
 *
 * This script reads all of them and keeps everything downstream in step:
 *
 *   1. QUIZZES       Lessons whose hand-written quiz has fewer than --quiz-min
 *                    questions are topped up with questions generated from the
 *                    lesson's own flashcards (tagged "auto": true so they are
 *                    regenerated, never duplicated, on every run).
 *   2. ACTIVE RECALL public/js/bank/bank-recall.js   (cards + quiz Q/A, every lesson)
 *   3. GAMES         public/js/bank/bank-games.js    (term/definition pairs, every lesson)
 *   4. EXAMS         public/js/bank/bank-exams.js    (hand-written quiz questions, every lesson)
 *   5. MANIFEST      public/data/learning-index.json (per-lesson counts + content hash)
 *
 * Usage
 *   node scripts/sync-learning.mjs                run the sync
 *   node scripts/sync-learning.mjs --check        fail (exit 1) if anything is stale
 *   node scripts/sync-learning.mjs --watch        re-sync whenever a lesson changes
 *   node scripts/sync-learning.mjs --quiz-min=20  target quiz size per lesson (default 20)
 *   node scripts/sync-learning.mjs --no-topup     never touch lesson pages
 *
 * Zero dependencies. Idempotent: running it twice changes nothing.
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PUBLIC = path.join(ROOT, "public");
const PAGES = path.join(PUBLIC, "pages");
const BANK_DIR = path.join(PUBLIC, "js", "bank");
const DATA_DIR = path.join(PUBLIC, "data");

// ---------------------------------------------------------------- CLI ------
const argv = process.argv.slice(2);
const flag = (name) => argv.includes(`--${name}`);
const opt = (name, fallback) => {
  const hit = argv.find((a) => a.startsWith(`--${name}=`));
  return hit ? hit.slice(name.length + 3) : fallback;
};
const CHECK = flag("check");
const WATCH = flag("watch");
const TOPUP = !flag("no-topup");
const QUIZ_MIN = Math.max(0, parseInt(opt("quiz-min", "20"), 10) || 0);
const QUIET = flag("quiet");

// ------------------------------------------------------------ Subjects ------
const SUBJECT_META = [
  ["physics", "Physics", "PHY"],
  ["chemistry", "Chemistry", "CHM"],
  ["biology", "Biology", "BIO"],
  ["english", "English", "ENG"],
  ["mathematics", "Mathematics", "MTH"],
  ["history", "History", "HIS"],
  ["geography", "Geography", "GEO"],
  ["computer-science", "Computer Science", "CS"],
];

// -------------------------------------------------------------- Helpers -----
const log = (...a) => { if (!QUIET) console.log(...a); };
const errors = [];
const warnings = [];
const err = (m) => errors.push(m);
const warn = (m) => warnings.push(m);

const plain = (s) => String(s ?? "").replace(/\s+/g, " ").trim();
// Comparison key: case-insensitive, straight quotes, no trailing punctuation. Keeps maths symbols and decimals (1/2 ≠ 2/1, 2.5 ≠ 25).
const norm = (s) => plain(s).toLowerCase().replace(/[“”]/g, '"').replace(/[‘’]/g, "'").replace(/[\s.?!:;,]+$/g, "");
// Lesson flashcards sometimes lead with a decorative emoji ("🏙️ Civilization"); banks use the bare term.
const LEADING_DECOR = /^(?:[\p{Extended_Pictographic}\p{Regional_Indicator}\u{13000}-\u{1342F}\uFE0F\u200D\s])+/u;
const bareTerm = (t) => plain(t).replace(LEADING_DECOR, "") || plain(t);
const stripEnd = (s) => plain(s).replace(/[\s.]+$/, "");
const decodeAttr = (s) =>
  String(s)
    .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n));

function hash32(str) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function seededShuffle(arr, r) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(r() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
const sha = (s) => crypto.createHash("sha1").update(s).digest("hex").slice(0, 10);
const titleCase = (slug) => slug.split("-").map((w) => w[0].toUpperCase() + w.slice(1)).join(" ");

// ------------------------------------------------------ Lesson parsing ------
const BLOCK = (attr) =>
  new RegExp(`(<script\\b[^>]*\\b${attr}\\b[^>]*>)([\\s\\S]*?)(</script>)`, "i");
const CARD_RE = BLOCK("data-card-deck");
const SLIDE_RE = BLOCK("data-slide-deck");
const QUIZ_RE = BLOCK("data-quiz-data");

function parseBlock(html, re, label, file) {
  const m = html.match(re);
  if (!m) return { found: false, data: null, match: null };
  try {
    return { found: true, data: JSON.parse(m[2]), match: m };
  } catch (e) {
    err(`${file}: ${label} block is not valid JSON (${e.message})`);
    return { found: true, data: null, match: m };
  }
}

function listSubjectDirs() {
  const known = new Map(SUBJECT_META.map(([slug, label, code], i) => [slug, { slug, label, code, order: i }]));
  const dirs = fs.readdirSync(PAGES, { withFileTypes: true })
    .filter((d) => d.isDirectory() && d.name !== "admin")
    .map((d) => d.name);
  const extra = dirs.filter((d) => !known.has(d)).sort();
  return [...known.keys()].filter((k) => dirs.includes(k)).concat(extra).map((slug, i) => known.get(slug) || { slug, label: titleCase(slug), code: slug.replace(/[^a-z]/g, "").slice(0, 3).toUpperCase(), order: 100 + i });
}

function readLessons() {
  const subjects = listSubjectDirs();
  const lessons = [];
  for (const subj of subjects) {
    const dir = path.join(PAGES, subj.slug);
    const files = fs.readdirSync(dir).filter((f) => f.endsWith(".html")).sort();
    for (const f of files) {
      const abs = path.join(dir, f);
      const rel = path.relative(ROOT, abs).split(path.sep).join("/");
      const html = fs.readFileSync(abs, "utf8");
      const card = parseBlock(html, CARD_RE, "data-card-deck", rel);
      const quiz = parseBlock(html, QUIZ_RE, "data-quiz-data", rel);
      const slide = parseBlock(html, SLIDE_RE, "data-slide-deck", rel);
      if (!card.found || !quiz.found) {
        const tiny = html.length < 3000 || /http-equiv=["']refresh/i.test(html);
        (tiny ? log : warn)(
          tiny ? `  skip  ${rel} (redirect/stub, no lesson data)` : `${rel}: no card deck / quiz block — not included in the bank`
        );
        continue;
      }
      if (!Array.isArray(card.data) || !Array.isArray(quiz.data)) {
        err(`${rel}: card deck and quiz data must be JSON arrays`);
        continue;
      }
      const slug = f.replace(/\.html$/, "");
      const titleAttr = html.match(/data-quiz-lesson="([^"]*)"/);
      const subjAttr = html.match(/data-quiz-subject="([^"]*)"/);
      lessons.push({
        id: `${subj.slug}/${slug}`,
        subject: subj,
        slug,
        title: titleAttr ? plain(decodeAttr(titleAttr[1])) : titleCase(slug),
        subjectLabel: subjAttr ? plain(decodeAttr(subjAttr[1])) : subj.label,
        href: `${subj.slug}/${f}`,
        abs,
        rel,
        html,
        cardsRaw: card.data,
        quizRaw: quiz.data,
        slideCount: Array.isArray(slide.data) ? slide.data.length : 0,
        quizMatch: quiz.match,
      });
    }
  }
  return { subjects, lessons };
}

// ----------------------------------------------------------- Validation -----
function cleanCards(lesson) {
  const out = [];
  const seen = new Set();
  lesson.cardsRaw.forEach((c, i) => {
    if (!c || typeof c.term !== "string" || typeof c.def !== "string" || !plain(c.term) || !plain(c.def)) {
      err(`${lesson.rel}: flashcard #${i + 1} needs non-empty "term" and "def" strings`);
      return;
    }
    const term = bareTerm(c.term);
    const key = norm(term);
    if (seen.has(key)) { warn(`${lesson.rel}: duplicate flashcard term "${term}"`); return; }
    seen.add(key);
    out.push({ term, def: plain(c.def) });
  });
  return out;
}

function validQuestion(q, rel, i) {
  const at = `${rel}: quiz question #${i + 1}`;
  if (!q || typeof q.q !== "string" || !plain(q.q)) { err(`${at} needs a "q" string`); return false; }
  if (!Array.isArray(q.options) || q.options.length < 2 || q.options.some((o) => typeof o !== "string" || !plain(o))) {
    err(`${at} needs an "options" array of 2+ non-empty strings`); return false;
  }
  if (!Number.isInteger(q.correct) || q.correct < 0 || q.correct >= q.options.length) {
    err(`${at} has an out-of-range "correct" index`); return false;
  }
  const uniq = new Set(q.options.map((o) => plain(o).toLowerCase()));
  if (uniq.size !== q.options.length) warn(`${at} has duplicate answer options`);
  return true;
}

// -------------------------------------------- Quiz top-up (from cards) -------
const DANGLING = new Set(["a", "an", "the", "and", "or", "of", "to", "in", "on", "with", "that", "which", "for", "by", "as", "is", "are", "at", "from"]);

function shortDef(def, max = 110) {
  const d = plain(def);
  if (d.length <= max) return stripEnd(d);
  const sentence = d.match(/^(.{20,}?[.!?])(\s|$)/);
  if (sentence && sentence[1].length <= max) return stripEnd(sentence[1]);
  const cut = d.slice(0, max);
  const i = Math.max(cut.lastIndexOf(", "), cut.lastIndexOf("; "), cut.lastIndexOf(" — "), cut.lastIndexOf(" – "));
  if (i >= 35) {
    const clause = cut.slice(0, i).trim();
    const last = clause.split(" ").pop().toLowerCase();
    if (!DANGLING.has(last)) return clause;
  }
  return null;
}

function buildAutoQuestions(lesson, cards, manual, need) {
  if (need <= 0 || cards.length < 4) return [];
  const r = rng(hash32(`${lesson.id}:auto`));
  const existing = new Set(manual.map((q) => norm(q.q)));
  const longDefOk = (c) => c.def.length <= 170;
  const defPool = cards.filter(longDefOk);
  const order = seededShuffle(cards.map((_, i) => i), r);
  const out = [];

  const makeTermQuestion = (ci) => {
    const c = cards[ci];
    if (c.def.length > 220) return null;
    const nd = norm(c.def), nt = norm(c.term);
    if (nt.length >= 4 && nd.includes(nt)) return null; // description would give the answer away
    const q = `Which term matches this description: “${stripEnd(c.def)}”?`;
    if (existing.has(norm(q))) return null;
    const others = cards.filter((_, i) => i !== ci && norm(cards[i].term) !== nt);
    if (others.length < 3) return null;
    const picks = seededShuffle(others, r).slice(0, 3).map((o) => o.term);
    const options = seededShuffle([c.term, ...picks], r);
    return { q, options, correct: options.indexOf(c.term), auto: true };
  };

  const makeDefQuestion = (ci) => {
    const c = cards[ci];
    if (!longDefOk(c) || defPool.length < 4) return null;
    const q = `In ${lesson.title}, which statement best describes “${c.term}”?`;
    if (existing.has(norm(q))) return null;
    const others = defPool.filter((o) => o !== c && norm(o.def) !== norm(c.def));
    if (others.length < 3) return null;
    const picks = seededShuffle(others, r).slice(0, 3).map((o) => o.def);
    const options = seededShuffle([c.def, ...picks], r);
    return { q, options, correct: options.indexOf(c.def), auto: true };
  };

  // Pass 1 alternates the question style per card, pass 2 fills with the other style.
  const passes = [
    (rank, ci) => (rank % 2 === 0 ? makeTermQuestion(ci) : makeDefQuestion(ci)),
    (rank, ci) => (rank % 2 === 0 ? makeDefQuestion(ci) : makeTermQuestion(ci)),
  ];
  for (const make of passes) {
    for (let rank = 0; rank < order.length && out.length < need; rank++) {
      const item = make(rank, order[rank]);
      if (item) { out.push(item); existing.add(norm(item.q)); }
    }
  }
  return out.slice(0, need);
}

function serializeBlock(match, list) {
  const [whole, open, , close] = match;
  const at = match.index;
  const lineStart = match.input.lastIndexOf("\n", at - 1) + 1;
  const ind = /^[ \t]*$/.test(match.input.slice(lineStart, at)) ? match.input.slice(lineStart, at) : "";
  const pad = ind + "  ";
  const body = JSON.stringify(list, null, 2)
    .replace(/<\/(script)/gi, "<\\/$1")
    .replace(/<!--/g, "<\\!--")
    .split("\n").map((l) => pad + l).join("\n");
  return { whole, next: `${open}\n${body}\n${ind}${close}` };
}


// ------------------------------------------------------- Difficulty tags ----
// Every quiz question gets d = 1 (Easy) | 2 (Medium) | 3 (Hard). It is a heuristic, not an
// editor's judgement: each question is scored on wording (length, calculation / reasoning /
// negation cues, recall-style openers) and then ranked *within its lesson*, so every lesson
// ends up with a spread the quiz can adapt across. Add "lock": true to a question to keep a
// hand-set "d" untouched.
function difficultyScore(q) {
  const text = plain(q.q);
  const opts = (q.options || []).map(plain);
  const words = (t) => (t ? t.split(" ").length : 0);
  const correct = opts[q.correct] || "";
  let s = Math.min(words(text), 40) / 10;
  s += Math.min(opts.reduce((a, o) => a + words(o), 0) / Math.max(opts.length, 1) / 4, 2);
  if (/\d/.test(text) || opts.some((o) => /\d/.test(o))) s += 0.7;
  if (/\b(calculate|compute|solve|evaluate|how many|how much|find the|what will be|derive|work out)\b/i.test(text)) s += 1.5;
  if (/\b(why|explain|reason|because|best describes|primarily|most likely|implies|infer|compare|difference|effect of|consequence|significance|impact|justify)\b/i.test(text)) s += 1.2;
  if (/\b(not|except|least|incorrect|false)\b/i.test(text)) s += 0.8;
  if (opts.some((o) => /all of the above|none of the above|\bboth\b.*\band\b/i.test(o))) s += 0.8;
  if (words(correct) > 8) s += 0.5;
  if (/^(what is the (unit|name|symbol)|who |when |which .* is called|define|what does .* stand for|name the)/i.test(text)) s -= 1.2;
  if (q.auto === true) s -= 0.8;
  return s;
}

function tagDifficulty(list) {
  const rank = list
    .map((q, i) => ({ q, i, s: difficultyScore(q) }))
    .filter((x) => x.q && !x.q.lock)
    .sort((a, b) => a.s - b.s || a.i - b.i);
  const n = rank.length;
  rank.forEach((x, k) => { x.q.d = k < n * 0.35 ? 1 : k < n * 0.75 ? 2 : 3; });
  list.forEach((q) => { if (q && q.lock && ![1, 2, 3].includes(q.d)) q.d = 2; });
}

// ------------------------------------------------------------- Main sync ----
function buildModel() {
  const { subjects, lessons } = readLessons();
  const writes = new Map(); // abs path -> string
  const model = [];

  for (const lesson of lessons) {
    const cards = cleanCards(lesson);
    const manual = [];
    lesson.quizRaw.forEach((q, i) => {
      if (q && q.auto === true) return; // generated last time — rebuilt below
      if (validQuestion(q, lesson.rel, i)) manual.push(q);
    });
    const seenQ = new Set();
    const manualUnique = manual.filter((q) => {
      const k = norm(q.q);
      if (seenQ.has(k)) { warn(`${lesson.rel}: duplicate quiz question "${plain(q.q).slice(0, 60)}…"`); return false; }
      seenQ.add(k);
      return true;
    });

    let quizFinal = lesson.quizRaw;
    let autos = [];
    const quizBefore = JSON.stringify(lesson.quizRaw);
    if (TOPUP) {
      autos = buildAutoQuestions(lesson, cards, manualUnique, QUIZ_MIN - manualUnique.length);
      quizFinal = [...manual, ...autos];
      tagDifficulty(quizFinal);
      if (quizFinal.length < QUIZ_MIN) warn(`${lesson.rel}: only ${quizFinal.length}/${QUIZ_MIN} quiz questions possible (add flashcards or hand-written questions)`);
      if (quizBefore !== JSON.stringify(quizFinal)) {
        const { whole, next } = serializeBlock(lesson.quizMatch, quizFinal);
        writes.set(lesson.abs, lesson.html.replace(whole, () => next));
      }
    } else {
      autos = lesson.quizRaw.filter((q) => q && q.auto === true);
    }

    model.push({ lesson, cards, manual: manualUnique, autoCount: autos.length, quizTotal: quizFinal.length });
  }
  return { subjects, model, writes };
}

// ---------------------------------------------------------- Bank builders ---
// Type-in games (Scramble, Word Guess, Rapid Recall, Flash Type) only need ASCII terms; punctuation/digits are auto-handled client-side.
const TYPEABLE = /^(?=(?:.*[A-Za-z]){3})[A-Za-z0-9][A-Za-z0-9 '’&.\-]{1,26}[A-Za-z0-9.]$/;
const BAD_ANSWER = /^(all|none|both|neither)\b.*\b(above|these|them)\b/i;

function buildBanks({ subjects, model }) {
  const usedSubjects = subjects.filter((s) => model.some((m) => m.lesson.subject.slug === s.slug));
  const subjIndex = new Map(usedSubjects.map((s, i) => [s.slug, i]));
  const subjList = usedSubjects.map((s) => ({ k: s.slug, l: s.label, c: s.code }));

  // -- recall ---------------------------------------------------------------
  const recallLessons = [];
  const lessonIndex = new Map();
  for (const m of model) {
    const r = [];
    const seen = new Set();
    for (const q of m.manual) {
      const question = plain(q.q);
      const answer = plain(q.options[q.correct]);
      if (question.length < 15 || answer.length > 160) continue;
      if (/^(true|false)$/i.test(answer) || BAD_ANSWER.test(answer)) continue;
      if (seen.has(norm(question))) continue;
      seen.add(norm(question));
      r.push([question, answer]);
    }
    lessonIndex.set(m.lesson.id, recallLessons.length);
    recallLessons.push({
      k: m.lesson.id,
      s: subjIndex.get(m.lesson.subject.slug),
      t: m.lesson.title,
      h: m.lesson.href,
      c: m.cards.map((c) => [c.term, c.def]),
      r,
    });
  }
  const recall = { subjects: subjList, lessons: recallLessons };

  // -- games ----------------------------------------------------------------
  const games = { subjects: usedSubjects.map((s) => s.label), terms: {}, lessons: recallLessons.map((l) => l.t) };
  for (const s of usedSubjects) {
    const seenTerm = new Set();
    const seenDef = new Set();
    const list = [];
    for (const m of model.filter((x) => x.lesson.subject.slug === s.slug)) {
      for (const c of m.cards) {
        const key = norm(c.term);
        if (!key || seenTerm.has(key) || c.term.length > 34) continue;
        const def = shortDef(c.def);
        if (!def || seenDef.has(norm(def))) continue;
        seenTerm.add(key);
        seenDef.add(norm(def));
        list.push([c.term, def, TYPEABLE.test(c.term) ? 1 : 0, lessonIndex.get(m.lesson.id)]);
      }
    }
    games.terms[s.label] = list;
  }

  // -- exams ----------------------------------------------------------------
  const exams = { q: [] };
  const seenExam = new Set();
  for (const m of model) {
    for (const q of m.manual) {
      const k = norm(q.q);
      if (seenExam.has(k)) continue;
      seenExam.add(k);
      exams.q.push({
        q: plain(q.q),
        options: q.options.map(plain),
        correct: q.correct,
        d: q.d || 2,
        subject: m.lesson.subject.label,
        lesson: m.lesson.title,
      });
    }
  }

  return { recall, games, exams };
}

function chunk(key, payload) {
  const body = JSON.stringify(payload);
  const v = sha(body);
  return {
    v,
    text:
      `/* Curio Lab — generated by scripts/sync-learning.mjs. Do not edit by hand. */\n` +
      `window.CURIO_BANK=window.CURIO_BANK||{};window.CURIO_BANK.${key}=Object.assign({v:${JSON.stringify(v)}},${body.replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029")});\n`,
  };
}

function buildOutputs(state) {
  const banks = buildBanks(state);
  const out = new Map();
  const recallChunk = chunk("recall", banks.recall);
  const gamesChunk = chunk("games", banks.games);
  const examsChunk = chunk("exams", banks.exams);
  out.set(path.join(BANK_DIR, "bank-recall.js"), recallChunk.text);
  out.set(path.join(BANK_DIR, "bank-games.js"), gamesChunk.text);
  out.set(path.join(BANK_DIR, "bank-exams.js"), examsChunk.text);

  const manifest = {
    _note: "Generated by scripts/sync-learning.mjs. Do not edit by hand.",
    quizMin: QUIZ_MIN,
    versions: { recall: recallChunk.v, games: gamesChunk.v, exams: examsChunk.v },
    totals: {
      lessons: state.model.length,
      flashcards: state.model.reduce((n, m) => n + m.cards.length, 0),
      quizQuestions: state.model.reduce((n, m) => n + m.quizTotal, 0),
      recallPrompts: banks.recall.lessons.reduce((n, l) => n + l.c.length * 2 + l.r.length, 0),
      gameTerms: Object.values(banks.games.terms).reduce((n, l) => n + l.length, 0),
      examQuestions: banks.exams.q.length,
    },
    lessons: state.model.map((m) => ({
      id: m.lesson.id,
      title: m.lesson.title,
      href: m.lesson.href,
      flashcards: m.cards.length,
      slides: m.lesson.slideCount,
      quizHandWritten: m.manual.length,
      quizGenerated: m.autoCount,
      quizTotal: m.quizTotal,
    })),
  };
  out.set(path.join(DATA_DIR, "learning-index.json"), JSON.stringify(manifest, null, 2) + "\n");
  return { out, banks, manifest };
}

// ---------------------------------------------------- Consumer wiring check -
function checkWiring() {
  const wiring = [
    ["pages/active-recall.html", "js/bank/bank-recall.js"],
    ["pages/play.html", "js/bank/bank-games.js"],
    ["pages/exams.html", "js/bank/bank-exams.js"],
  ];
  for (const [page, script] of wiring) {
    const file = path.join(PUBLIC, page);
    if (!fs.existsSync(file)) continue;
    if (!fs.readFileSync(file, "utf8").includes(script)) warn(`${page} does not load ${script} — it will fall back to its built-in content`);
  }
}

// ------------------------------------------------------------ Run / report --
function runOnce() {
  errors.length = 0;
  warnings.length = 0;
  const state = buildModel();
  const { out, banks, manifest } = buildOutputs(state);
  checkWiring();

  const all = new Map([...state.writes, ...out]);
  const changed = [];
  for (const [file, text] of all) {
    const current = fs.existsSync(file) ? fs.readFileSync(file, "utf8") : null;
    if (current !== text) changed.push(file);
  }

  if (!QUIET) {
    const rows = state.subjects
      .map((s) => {
        const ms = state.model.filter((m) => m.lesson.subject.slug === s.slug);
        if (!ms.length) return null;
        const sum = (f) => ms.reduce((n, m) => n + f(m), 0);
        return {
          subject: s.label,
          lessons: ms.length,
          flashcards: sum((m) => m.cards.length),
          "quiz (hand)": sum((m) => m.manual.length),
          "quiz (auto)": sum((m) => m.autoCount),
          "game terms": banks.games.terms[s.label].length,
          "typeable": banks.games.terms[s.label].filter((t) => t[2]).length,
        };
      })
      .filter(Boolean);
    console.table(rows);
    const t = manifest.totals;
    log(`Totals: ${t.lessons} lessons · ${t.flashcards} flashcards · ${t.quizQuestions} quiz questions · ${t.recallPrompts} recall prompts · ${t.gameTerms} game terms · ${t.examQuestions} exam questions`);
  }

  for (const w of warnings) console.warn(`  warn  ${w}`);
  for (const e of errors) console.error(`  ERROR ${e}`);

  if (errors.length) { console.error(`\nSync aborted: ${errors.length} error(s). Nothing was written.`); return 1; }

  if (CHECK) {
    if (changed.length) {
      console.error(`\nStale generated content in ${changed.length} file(s):`);
      changed.forEach((f) => console.error("  - " + path.relative(ROOT, f)));
      console.error("Run: npm run sync:learning");
      return 1;
    }
    log("Learning content is up to date.");
    return 0;
  }

  for (const file of changed) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, all.get(file));
  }
  log(changed.length ? `Updated ${changed.length} file(s):` : "Already up to date.");
  if (!QUIET) changed.forEach((f) => log("  ~ " + path.relative(ROOT, f)));
  return 0;
}

if (WATCH) {
  let timer = null;
  const trigger = () => {
    clearTimeout(timer);
    timer = setTimeout(() => { try { runOnce(); } catch (e) { console.error(e); } }, 350);
  };
  runOnce();
  log(`\nWatching ${path.relative(ROOT, PAGES)} for lesson changes… (Ctrl+C to stop)`);
  fs.watch(PAGES, { recursive: true }, (_evt, name) => { if (name && name.endsWith(".html")) trigger(); });
} else {
  process.exit(runOnce());
}
