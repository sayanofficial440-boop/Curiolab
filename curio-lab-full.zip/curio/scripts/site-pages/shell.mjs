// Shared page chrome (head, header, footer, scripts) for the generated public-site pages.
// Mirrors the markup of pages/contact.html so the new pages inherit every theme, the command palette, auth widget, etc.

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
const CONFIG = JSON.parse(fs.readFileSync(path.join(ROOT, "site.config.json"), "utf8"));

// Values come from site.config.json; SITE_URL / CONTACT_EMAIL env vars override them for one-off builds.
export const SITE = {
  name: "Curio Lab",
  url: (process.env.SITE_URL || CONFIG.siteUrl || "").replace(/\/$/, ""),
  email: process.env.CONTACT_EMAIL || CONFIG.contactEmail || "",
  controllerName: (CONFIG.controllerName || "").trim(),
  controllerAddress: (CONFIG.controllerAddress || "").trim(),
};

// Once scripts/self-host-fonts.mjs has run (it writes public/css/fonts.css) generated pages use the local fonts
// instead of Google's servers, so a rebuild never re-introduces the Google requests.
export const FONTS_LOCAL = fs.existsSync(path.join(ROOT, "public", "css", "fonts.css"));

const FAVICON =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='20' fill='%2312213B'/%3E%3Cpath d='M40 20 h20 v22 l18 30 a8 8 0 0 1 -7 12 H29 a8 8 0 0 1 -7 -12 l18 -30 Z' fill='none' stroke='%23E9A93F' stroke-width='5' stroke-linejoin='round'/%3E%3Ccircle cx='50' cy='68' r='5' fill='%2356C2B2'/%3E%3C/svg%3E";

export const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

export function companyCols(L) {
  return `<div class="footer-col">
        <h5>Company</h5>
        <ul>
          <li><a href="${L}about.html">About Us</a></li>
          <li><a href="${L}careers.html">Careers</a></li>
          <li><a href="${L}press.html">Press</a></li>
          <li><a href="${L}partners.html">Partners</a></li>
          <li><a href="${L}changelog.html">Changelog</a></li>
          <li><a href="${L}contact.html">Contact Us</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h5>Help &amp; legal</h5>
        <ul>
          <li><a href="${L}help.html">Help Center</a></li>
          <li><a href="${L}faq.html">FAQ</a></li>
          <li><a href="${L}blog.html">Blog</a></li>
          <li><a href="${L}privacy.html">Privacy &amp; Security</a></li>
          <li><a href="${L}terms.html">Terms &amp; Conditions</a></li>
          <li><a href="${L}cookies.html">Cookie Policy</a></li>
          <li><a href="#" data-cookie-settings>Cookie settings</a></li>
        </ul>
      </div>`;
}

export function footer(L) {
  return `<footer class="site-footer-rich">
  <div class="wrap">
    <div class="footer-grid">
      <div class="footer-brand">
        <a class="logo" href="${L}../dashboard.html">Curio<span class="dot">·</span>Lab</a>
        <p>A curiosity-driven study platform for Physics, Chemistry, Biology, English, Mathematics, History, Geography and Computer Science.</p>
      </div>
      <div class="footer-col">
        <h5>Explore</h5>
        <ul>
          <li><a href="${L}physics.html">Physics</a></li>
          <li><a href="${L}chemistry.html">Chemistry</a></li>
          <li><a href="${L}biology.html">Biology</a></li>
          <li><a href="${L}english.html">English</a></li>
          <li><a href="${L}mathematics.html">Mathematics</a></li>
          <li><a href="${L}history.html">History</a></li>
          <li><a href="${L}geography.html">Geography</a></li>
          <li><a href="${L}computer-science.html">Computer Science</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h5>Tools</h5>
        <ul>
          <li><a href="${L}browse.html">Browse by Grade</a></li>
          <li><a href="${L}scoreboard.html">Progress</a></li>
          <li><a href="${L}glossary.html">Glossary</a></li>
          <li><a href="${L}play.html">Play &amp; Study</a></li>
          <li><a href="${L}exams.html">Exam Center</a></li>
          <li><a href="${L}todo.html">To-Do List</a></li>
          <li><a href="${L}certificates.html">Certificates</a></li>
          <li><a href="${L}pricing.html">Subscription</a></li>
        </ul>
      </div>
      ${companyCols(L)}
    </div>
    <div class="footer-bottom">
      <span>Curio Lab — a student-built study platform</span>
      <span>Made with curiosity</span>
    </div>
  </div>
</footer>`;
}

/**
 * @param {object} o
 * @param {string} o.file     output path relative to public/pages (e.g. "faq.html" or "blog/x.html")
 * @param {string} o.title    <title> (site name is appended)
 * @param {string} o.desc     meta description
 * @param {string} o.body     <main> inner HTML
 * @param {string} [o.accent] CSS var for --accent
 * @param {object[]} [o.jsonld]
 * @param {string} [o.ogType]
 */
export function page(o) {
  const depth = o.file.split("/").length; // 1 => pages/x.html, 2 => pages/blog/x.html
  const P = depth === 1 ? "../" : "../../"; // to /public
  const L = depth === 1 ? "" : "../"; // to /public/pages
  const url = `${SITE.url}/pages/${o.file}`;
  const title = `${o.title} — ${SITE.name}`;
  const fontsHead1 = FONTS_LOCAL
    ? `<link rel="stylesheet" href="${P}css/fonts.css" />`
    : `<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">`;
  const fontsHead2 = FONTS_LOCAL ? "" : `<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=Sora:wght@500;600;700&display=swap" rel="stylesheet">`;
  const extraHead = o.head || "";
  const ld = (o.jsonld || []).map((j) => `<script type="application/ld+json">${JSON.stringify(j)}</script>`).join("\n");
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<script src="${P}js/site-config.js"></script>
<script src="${P}js/monitor.js"></script>
<script src="${P}js/age-gate.js"></script>
<script src="${P}js/cookie-consent.js"></script>
<link rel="icon" href="${FAVICON}" type="image/svg+xml" />
<meta name="theme-color" content="#12213B" />
<meta name="curio-root" content="${P}" />
<title>${esc(title)}</title>
<meta name="description" content="${esc(o.desc)}" />
${o.noindex ? '<meta name="robots" content="noindex, nofollow" />\n' : ''}<link rel="canonical" href="${url}" />
<meta property="og:site_name" content="${SITE.name}" />
<meta property="og:title" content="${esc(title)}" />
<meta property="og:description" content="${esc(o.desc)}" />
<meta property="og:type" content="${o.ogType || "website"}" />
<meta property="og:url" content="${url}" />
<meta name="twitter:card" content="summary" />
${fontsHead1}
<link rel="stylesheet" href="${P}css/variables.css" />
<link rel="stylesheet" href="${P}css/styles.css" />
<link rel="stylesheet" href="${P}css/lesson.css" />
<link rel="stylesheet" href="${P}css/polish.css" />
<link rel="stylesheet" href="${P}css/auth.css" />
<link rel="stylesheet" href="${P}css/company-pages.css" />
<link rel="stylesheet" href="${P}css/site-pages.css" />
<script src="${P}js/toast.js"></script>
<script src="${P}js/command-palette.js"></script>
<link rel="stylesheet" href="${P}css/responsive-guard.css" />
<link rel="stylesheet" href="${P}css/nav-menu.css" />
${fontsHead2}<link rel="stylesheet" href="${P}css/modern-academic.css">
<link rel="stylesheet" href="${P}css/topbar.css">
<link rel="stylesheet" href="${P}css/site-themes.css" />
<script src="${P}js/site-themes.js"></script>
<script src="${P}js/a11y.js"></script>
<script src="${P}js/pwa.js" defer></script>
<script src="${P}js/study-time.js" defer></script>
${ld}
${extraHead}
</head>
<body style="--accent: var(${o.accent || "--color-teal"});">

<header class="site-header">
  <div class="wrap">
    <a class="logo" href="${L}../dashboard.html">Curio<span class="dot">·</span>Lab</a>
    <nav class="main-nav" aria-label="Subjects">
      <a href="${L}physics.html">PHY</a>
      <a href="${L}chemistry.html">CHM</a>
      <a href="${L}biology.html">BIO</a>
      <a href="${L}english.html">ENG</a>
      <a href="${L}mathematics.html">MATH</a>
      <a href="${L}history.html">HIST</a>
      <a href="${L}geography.html">GEO</a>
      <a href="${L}computer-science.html">CS</a>
    </nav>
    <button class="cmdk-trigger" data-cmdk-trigger type="button">🔍 Search <kbd>⌘K</kbd></button>
    <div class="auth-widget" data-auth-widget></div>
    <button class="sound-toggle" data-sound-toggle type="button" aria-label="Toggle sound effects" aria-pressed="true"><span class="icon-on">🔊</span><span class="icon-off">🔇</span></button>
    <button class="theme-toggle" data-theme-toggle type="button" aria-pressed="false">
      <span class="dial" aria-hidden="true"></span>
      <span class="theme-label">Daylight</span>
    </button>
  </div>
</header>

<main id="main">
${o.body.replaceAll("{{L}}", L).replaceAll("{{P}}", P).replaceAll("{{EMAIL}}", SITE.email)}
</main>

${footer(L)}

<script src="${P}js/side-rail.js"></script>
<script src="${P}js/auth.js"></script>
<script src="${P}js/auth-status.js"></script>
<script src="${P}js/motion.js"></script>
<script src="${P}js/custom-cursor.js"></script>
<script src="${P}js/nav-menu.js"></script>
<script src="${P}js/sound.js"></script>
<script src="${P}js/global-coach.js"></script>
<script src="${P}js/company-pages-fx.js"></script>
<script src="${P}js/site-pages.js"></script>
<script src="${P}js/modern-academic.js"></script>
<script src="${P}js/i18n.js"></script>
</body>
</html>
`;
}

export const hero = (eyebrow, h1, lede, extra = "") => `<section class="page-hero tool-hero">
    <div class="wrap">
      <p class="eyebrow">${eyebrow}</p>
      <h1>${h1}</h1>
      <p>${lede}</p>
      ${extra}
    </div>
  </section>`;
