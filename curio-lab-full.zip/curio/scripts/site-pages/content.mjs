// Editorial content for the generated public pages. Edit here, then run:  node scripts/build-site-pages.mjs
// Everything below is written to match what the product actually does today; keep it that way when you edit.

export const FAQ = [
  {
    id: "start", icon: "🚀", title: "Getting started",
    items: [
      ["Is Curio Lab free?", "Yes. All eight subjects, every lesson, quiz, flashcard deck, game and exam paper is free to use. The Pricing page shows ideas for paid tiers, but those are a concept demo only — nothing is charged and nothing is locked."],
      ["Do I need an account?", "No. Every learning tool works without signing up. An account is optional and is mainly there for features that need to know who you are, such as certificates and (later) syncing between devices."],
      ["Which subjects and grades are covered?", "Physics, Chemistry, Biology, Mathematics, English, History, Geography and Computer Science. Use <a href=\"{{L}}browse.html\">Browse by Grade</a> to filter lessons by level, or <a href=\"{{L}}courses.html\">Courses</a> for a suggested order inside each subject."],
      ["Where should I start?", "Pick a subject, open a lesson and work through its tabs: read, watch, listen, flip the cards, then take the quiz. If you are unsure, the dashboard's “Next for you” suggestion looks at your quiz results and Mistake Notebook and points you at the best lesson to do next."],
    ],
  },
  {
    id: "tools", icon: "🧪", title: "Lessons & study tools",
    items: [
      ["What is inside a lesson?", "Each lesson combines a written explanation, a video, an audio version, photo cards, a slide deck, flashcards and a quiz. Flagship lessons also have an interactive model, such as a 3D force simulation, a draggable graph or a live code playground."],
      ["How does the Mistake Notebook work?", "When you get a question wrong it is saved to the notebook and comes back for review on a growing schedule — first after about 10 minutes, then roughly a day later, then a few days, and so on. Cards you keep answering correctly drift out to longer gaps and eventually count as mastered. See <a href=\"{{L}}blog/spaced-review-mistake-notebook.html\">how spaced review works</a>."],
      ["What are Active Recall, the games and the Exam Center?", "Active Recall asks you to answer from memory before showing the answer. The games turn the same vocabulary and facts into short arcade rounds. The Exam Center builds timed papers from the question bank and shows a readiness score per subject. All of them draw on the same lesson content, so what you study is what you are tested on."],
      ["How do the quizzes get their questions?", "Every lesson has hand-written questions. Where a lesson has fewer than 20, extra questions are generated from its flashcards and marked as automatic. The totals shown on the home page come straight from the lesson data."],
      ["Can I use Curio Lab offline?", "Yes. Lessons you open are kept on your device automatically, and <a href=\"{{L}}accessibility.html\">Accessibility &amp; Offline</a> has a button to save every lesson at once and to install Curio Lab as an app. Videos still need a connection."],
      ["What is the AI Coach?", "A chat helper on each lesson that asks guiding questions and offers hints. By default it runs in demo mode with short pattern-matched answers about the lesson topic. If the site owner connects the optional backend it can use a live AI model. It is a study partner, not an answer key — see <a href=\"{{L}}blog/using-an-ai-coach-without-outsourcing-thinking.html\">how to use it well</a>."],
    ],
  },
  {
    id: "account", icon: "💳", title: "Accounts, plans & payments",
    items: [
      ["Do the Upgrade buttons charge me?", "No. The plans on the Pricing page are a concept demo. No payment is processed, no card details are collected and nothing is ever charged."],
      ["Will features I use today move behind a paywall?", "Nothing on the Free plan has been announced as going away. If paid plans ever launch they will be announced on the <a href=\"{{L}}changelog.html\">Changelog</a> first and the Terms page will be updated before anything changes."],
      ["How do I delete my account?", "Use <a href=\"{{L}}privacy.html#rights\">Your privacy rights</a> to erase everything stored in your browser, and <a href=\"{{L}}contact.html?topic=privacy\">contact us</a> to have any server-side account record deleted."],
    ],
  },
  {
    id: "privacy", icon: "🔒", title: "Privacy & data",
    items: [
      ["Where is my progress stored?", "In your own browser's local storage — quiz scores, trophies, notes, to-do list, theme and Mistake Notebook. Nothing is uploaded unless you sign up for features that need a server. Clearing your browser data, or switching browser or device, resets it."],
      ["Does Curio Lab use ads or analytics?", "No ads and no analytics today. If analytics are ever added they will be off until you opt in through the cookie settings."],
      ["What does the cookie banner control?", "It controls optional extras. At the moment that means embedded YouTube videos: they stay blocked until you allow them. Essential storage (your progress and settings) is always on because the site can't work without it. Details are on the <a href=\"{{L}}cookies.html\">Cookie Policy</a>."],
      ["How do I download or erase my data?", "On the <a href=\"{{L}}privacy.html#rights\">Privacy page</a> there are buttons to download everything stored on this device as a JSON file and to erase it. Both work instantly and don't need an account."],
      ["Is Curio Lab suitable for children?", "Yes. Everything works without an account. If a child under 13 wants one, they use a nickname (no real name, no email) and a parent or guardian has to approve it by email before certificates and reminders switch on. Children's accounts have no contact form, live AI chat or translation, and nothing is sold or used for ads. Parents can view, download and delete everything. See <a href=\"{{L}}privacy.html#children\">children's privacy</a>."],
      ["What is the community, and is it safe?", "The <a href=\"{{L}}community.html\">Community</a> is optional and for learners aged 13 and over: you pick a handle, earn XP and badges from quizzes, and can appear on leaderboards or add friends. Children's accounts can't join, learners under 16 start as friends-only, people are found only by their exact handle, and you can block, report or erase your profile at any time. No email or real name is shown. See <a href=\"{{L}}privacy.html#community\">what is stored</a>."],
      ["How is leaderboard XP worked out?", "Each quiz you take after joining earns 5–20 XP: 5 for trying plus up to 15 for accuracy. Our server grades the quiz itself rather than trusting a score sent by the browser, and counts at most 3 attempts per lesson and 40 per day. Exam Center papers and quizzes from before you joined don't count. Weekly boards reset every Monday at 00:00 UTC."],
      ["I lost my community profile. Can I get it back?", "Only with your device key, shown in Community → My profile. Paste it into “Restore” on the join screen on any device. We don't store an email for community profiles, so without the key a profile can't be recovered; you can make a new one."],
      ["How do I check a certificate?", "Every certificate has a link like <code>/verify/CL-ABCD-EFGH-JKMN</code>. Open it, or enter the code on the <a href=\"{{L}}verify.html\">verification page</a>. It shows whether Curio Lab issued the certificate, the name on it and the date, and nothing else."],
      ["Can I share a lesson?", "Yes. Every lesson has a Share button. The link opens the lesson with a proper preview in chat apps and social networks, and adding <code>#quiz</code> (or <code>#cards</code>, <code>#slides</code>) to the end opens that study mode."],

    ],
  },
  {
    id: "tech", icon: "⚙️", title: "Technical & accessibility",
    items: [
      ["Which browsers are supported?", "Current versions of Chrome, Edge, Firefox and Safari on desktop and mobile. Some 3D models need WebGL, which all current browsers include."],
      ["Is Curio Lab accessible?", "There are settings for text size, dyslexia-friendly fonts, line spacing, high contrast, underlined links, colour-blind-safe charts and reduced motion, plus keyboard navigation and a skip link. Open <a href=\"{{L}}accessibility.html\">Accessibility &amp; Offline</a>. If something doesn't work for you, tell us — we treat it as a bug."],
      ["Can I read it in another language?", "Yes. The language menu offers many languages using machine translation. Translations can be imperfect, especially for scientific terms, so check the English text if something looks odd. Choosing a language loads Google Translate."],
      ["A lesson, quiz or model is broken. What should I do?", "Please <a href=\"{{L}}contact.html?topic=bug\">report it</a> with the page name and what you were doing. A screenshot helps. Also try a hard refresh (Ctrl/Cmd + Shift + R) — old cached files are the most common cause."],
    ],
  },
  {
    id: "teachers", icon: "🧑‍🏫", title: "Teachers & schools",
    items: [
      ["Can I use Curio Lab in my classroom?", "Yes, no permission is needed to use the free lessons in class. Students can work without accounts, which keeps classroom setup quick and avoids collecting student data."],
      ["Can my school partner with you?", "We'd like that. See <a href=\"{{L}}partners.html\">Partners</a> for what we can do together — pilots, feedback on lessons, content contributions."],
    ],
  },
];

export const HELP = [
  { icon: "🧭", title: "Find and start a lesson", steps: ["Open a subject from the top bar (PHY, CHM, BIO …) or press <strong>Ctrl/⌘ + K</strong> to search every lesson.", "Choose a lesson. The tabs along the top — About, Video, Audio, Cards, Slides, Quiz — can be done in any order.", "Finish with the <strong>Quiz</strong> tab; your score is saved on this device and appears in <a href=\"{{L}}scoreboard.html\">Progress</a>."] },
  { icon: "🗂️", title: "Review mistakes with the notebook", steps: ["Answer quiz or exam questions. Wrong answers are added to the <a href=\"{{L}}review.html\">Mistake Notebook</a> automatically.", "Open the notebook when items are due and rate how well you remembered each one.", "Optional: switch on the review reminder on that page to be nudged when reviews are due (needs the push backend and browser permission)."] },
  { icon: "📝", title: "Take a timed exam", steps: ["Go to the <a href=\"{{L}}exams.html\">Exam Center</a> and choose subject and paper length.", "Answer in the timer; auto-marked questions are scored instantly and written answers are self-marked against marking points.", "Use <a href=\"{{L}}past-papers.html\">Past Papers</a> for full-length practice, and the readiness view to see where to focus."] },
  { icon: "📴", title: "Use Curio Lab offline", steps: ["Open <a href=\"{{L}}accessibility.html\">Accessibility &amp; Offline</a>.", "Press <strong>Save all lessons for offline</strong> while you are online.", "Optional: press <strong>Install app</strong> to add Curio Lab to your home screen or desktop."] },
  { icon: "♿", title: "Make text easier to read", steps: ["Open <a href=\"{{L}}accessibility.html\">Accessibility &amp; Offline</a>.", "Change text size, font (dyslexia-friendly options), line spacing, contrast or reduced motion.", "Changes apply on every page and are saved on this device."] },
  { icon: "🔐", title: "Manage cookies and your data", steps: ["Use <strong>Cookie settings</strong> in any page footer to change optional features such as YouTube embeds.", "Open <a href=\"{{L}}privacy.html#rights\">Privacy → Your rights</a> to download or erase what is stored on this device.", "For anything stored on a server, <a href=\"{{L}}contact.html?topic=privacy\">send us a request</a>."] },
  { icon: "🔄", title: "Lost progress or something looks old?", steps: ["Progress lives in one browser on one device. Check you are in the same browser and not a private window.", "Hard refresh with <strong>Ctrl/Cmd + Shift + R</strong> to load the newest files.", "Still stuck? <a href=\"{{L}}contact.html?topic=bug\">Report a bug</a> and tell us the page and browser."] },
];

const A = (slug, o) => ({ slug, ...o });
export const ARTICLES = [
  A("retrieval-practice-beats-rereading", {
    title: "Retrieval practice: why quizzing yourself beats rereading",
    desc: "Rereading feels productive but teaches less than trying to recall. Here is the evidence-backed way to turn notes into practice questions.",
    date: "2026-10-05", cat: "Study skills", mins: 5, icon: "🧠", color: "#0F7A6E",
    body: `
<p>Most of us study by rereading: highlight the chapter, read it again, feel good. The trouble is that familiarity is not the same as knowing. When text is in front of you, recognising it is easy. On exam day, the page is gone and only what you can <em>recall</em> remains.</p>
<h2>What retrieval practice is</h2>
<p>Retrieval practice means pulling an answer out of memory before you look at it. A flashcard, a closed-book quiz, or explaining a topic aloud without notes are all retrieval. Cognitive-science studies, including well-known experiments by Henry Roediger and Jeffrey Karpicke, found that students who spent study time testing themselves remembered more a week later than students who spent the same time rereading — even though the rereaders felt more confident.</p>
<div class="callout"><strong>The key idea:</strong> struggling a little to remember is not a sign that studying is failing. It is the part that makes memories stronger.</div>
<h2>How to do it in practice</h2>
<ol>
<li><strong>Read once, then close the page.</strong> Write down or say everything you can remember. Gaps show you what to restudy.</li>
<li><strong>Turn headings into questions.</strong> “Newton's second law” becomes “What links force, mass and acceleration, and in what units?”</li>
<li><strong>Use flashcards properly.</strong> Commit to an answer before you flip. If you flip first, you are rereading with extra steps.</li>
<li><strong>Mix topics.</strong> Jumping between related ideas is harder than doing one at a time, and it trains you to choose the right method, which is what exams ask for.</li>
<li><strong>Check, then fix.</strong> Feedback matters. Compare with the source and note exactly what you missed.</li>
</ol>
<h2>Using Curio Lab for it</h2>
<p>Every lesson ends with a quiz and has a flashcard deck, and <a href="{{L}}active-recall.html">Active Recall</a> asks you to answer from memory before the reveal. Questions you miss go to the <a href="{{L}}review.html">Mistake Notebook</a>, which brings them back later, when you are most likely to have started forgetting them.</p>
<h2>A simple weekly pattern</h2>
<p>After you learn something new, quiz yourself the same day, again after a day or two, then again at the end of the week. Short sessions of 10 to 20 minutes spread over days beat one long cram.</p>`,
  }),
  A("spaced-review-mistake-notebook", {
    title: "How spaced review works — and how the Mistake Notebook uses it",
    desc: "Forgetting follows a curve. Spacing your reviews flattens it. A plain-language guide to the schedule behind the Mistake Notebook.",
    date: "2026-10-05", cat: "Study skills", mins: 5, icon: "🗂️", color: "#12213B",
    body: `
<p>In the 1880s, Hermann Ebbinghaus memorised lists of nonsense syllables and measured how fast he forgot them. Forgetting was steep at first and then levelled off — and each time he relearned a list, it faded more slowly. That is the basis of <strong>spaced repetition</strong>: review something just as you are about to forget it, and the gap you can leave next time gets longer.</p>
<h2>Why spacing beats massing</h2>
<p>Studying a topic five times in one evening feels like progress, but the memory has no chance to fade, so there is nothing for the review to strengthen. Studying it five times across three weeks forces your brain to rebuild the memory each time, which is what makes it durable.</p>
<h2>The schedule in the Mistake Notebook</h2>
<p>When you answer a question wrong, Curio Lab saves it in the <a href="{{L}}review.html">Mistake Notebook</a>. It returns after about 10 minutes, then after about a day, then after a few days. Each time you remember it, the gap grows; if you get it wrong again, the gap resets. When an item's gap reaches 21 days it counts as <em>mastered</em>.</p>
<ul>
<li><strong>First 10 minutes:</strong> a quick check that the correction actually stuck.</li>
<li><strong>Day 1 to day 6:</strong> the critical window where most forgetting happens.</li>
<li><strong>Weeks:</strong> long gaps keep the item alive with very little effort.</li>
</ul>
<div class="callout">The notebook is stored on your device. Nothing about your questions is sent to a server; the optional reminder only shares when your next review is due.</div>
<h2>Making it work for you</h2>
<ol>
<li>Do the notebook in short daily sessions — five minutes is enough when items are due.</li>
<li>Rate honestly. Saying “easy” when you hesitated pushes the next review too far away.</li>
<li>Don't clear a hard item. Hard items are exactly what the schedule is for.</li>
</ol>
<p>Pair it with <a href="{{L}}blog/retrieval-practice-beats-rereading.html">retrieval practice</a> and you have the two most reliable study methods working together.</p>`,
  }),
  A("newtons-three-laws-plain-language", {
    title: "Newton's three laws of motion in plain language",
    desc: "Inertia, F = ma and action–reaction explained with everyday examples, plus the mistakes students most often make.",
    date: "2026-10-05", cat: "Physics", mins: 6, icon: "⚛️", color: "#E8563A",
    body: `
<p>Isaac Newton published his three laws of motion in 1687. They describe how forces change the way things move, and they still underpin engineering, sport and space flight.</p>
<h2>First law: inertia</h2>
<p>An object keeps doing what it is doing — staying still, or moving in a straight line at constant speed — unless a <strong>net</strong> force acts on it. That is why you lurch forward when a bus brakes: your body wants to keep moving at the old speed.</p>
<p><strong>Common mistake:</strong> thinking things need a force to keep moving. A puck on ice slows down because of friction, a force. Remove friction and it carries on.</p>
<h2>Second law: F = ma</h2>
<p>The net force on an object equals its mass times its acceleration. Force is measured in newtons: 1 N accelerates 1 kg at 1 m/s².</p>
<ul>
<li>Push twice as hard on the same trolley and it accelerates twice as much.</li>
<li>Push the same hard on a trolley with twice the mass and it accelerates half as much.</li>
</ul>
<p><strong>Worked example:</strong> a 1,200 kg car accelerates at 2 m/s². The net force is 1,200 × 2 = 2,400 N.</p>
<h2>Third law: action and reaction</h2>
<p>When object A pushes on object B, B pushes back on A with an equal force in the opposite direction. The two forces act on <em>different</em> objects, which is why they don't cancel.</p>
<p>A swimmer pushes water backwards; the water pushes the swimmer forwards. A rocket pushes exhaust gas down; the gas pushes the rocket up.</p>
<p><strong>Common mistake:</strong> saying the pair cancel out. They can't — each acts on a different body.</p>
<h2>Put it together</h2>
<p>Pushing a heavy box: you push on the box (action), the box pushes back on you (reaction, third law). The box moves only if your push beats friction; the leftover net force then gives acceleration according to F = ma (second law). If you stop pushing and friction is small, it keeps sliding (first law).</p>
<div class="callout">Ready to try it? The <a href="{{L}}physics/force.html">Force lesson</a> has a 3D model where you change the applied force and watch the arrows update, and a quiz to test yourself.</div>`,
  }),
  A("a-20-minute-study-session", {
    title: "A 20-minute study session that actually works",
    desc: "A simple structure — plan, learn, test, fix — you can repeat any day, whether you have twenty minutes or two hours.",
    date: "2026-10-05", cat: "Study skills", mins: 4, icon: "⏱️", color: "#C9962C",
    body: `
<p>Long study blocks are hard to start and easy to waste. Short, structured ones are easier to begin and tend to stick. Here is a template that fits into twenty minutes.</p>
<h2>The four parts</h2>
<ol>
<li><strong>Plan (2 min).</strong> Pick one narrow target: “explain how a series circuit shares voltage,” not “revise electricity.” Silence notifications.</li>
<li><strong>Learn (6 min).</strong> Read one section or watch one short video. Take notes in your own words, not copied.</li>
<li><strong>Test (8 min).</strong> Close everything and answer questions on what you just covered: a lesson quiz, flashcards, or explaining it aloud. This is where most of the learning happens.</li>
<li><strong>Fix (4 min).</strong> Look up what you missed and write the correct answer in one sentence. Missed items go in your <a href="{{L}}review.html">Mistake Notebook</a> to come back later.</li>
</ol>
<h2>Tips that help</h2>
<ul>
<li>Use the <a href="{{L}}todo.html">To-Do list</a> to write tomorrow's target before you stop. Starting is the hardest part, so remove the decision.</li>
<li>Take a real break of five minutes: stand up, drink water, don't scroll.</li>
<li>Stack two or three sessions with different subjects rather than three of the same.</li>
<li>Stop when the timer ends. Finishing on time makes tomorrow easier to begin.</li>
</ul>
<p>Over a week, five sessions of twenty minutes is more than 90 minutes of focused practice — and it will be spread across days, which helps memory more than one long evening.</p>`,
  }),
  A("using-an-ai-coach-without-outsourcing-thinking", {
    title: "Using an AI coach without outsourcing your thinking",
    desc: "AI can explain, quiz and give hints — or quietly do the work for you. Practical habits that keep you doing the learning.",
    date: "2026-10-05", cat: "Study skills", mins: 4, icon: "🤖", color: "#7A4FD3",
    body: `
<p>An AI helper can be a patient tutor at midnight. It can also let you skip the effort that makes you learn. The difference is how you use it.</p>
<h2>Try first, ask second</h2>
<p>Before you ask for help, write down what you think the answer is, even if you're unsure. Then ask the coach to check your reasoning. Struggling for a minute first makes the explanation stick far better than reading it cold.</p>
<h2>Ask for hints, not answers</h2>
<p>Good prompts: “Give me a hint for step two,” “What should I check first?” or “Where did my working go wrong?” The AI Coach on each lesson has a <em>Give me a hint</em> option for exactly this.</p>
<h2>Make it quiz you</h2>
<p>Reverse the roles: “Ask me three questions about photosynthesis, one at a time, and tell me what I got wrong.” That is retrieval practice with feedback — see <a href="{{L}}blog/retrieval-practice-beats-rereading.html">why it works</a>.</p>
<h2>Explain it back</h2>
<p>After a concept, tell the coach in your own words how it works and ask what you've missed. If you can teach it, you know it.</p>
<h2>Don't trust it blindly</h2>
<ul>
<li>AI can be confidently wrong. Check important facts against your lesson, textbook or teacher.</li>
<li>By default, the coach here runs in a limited demo mode that only knows common topics from the lesson. That's by design, so the answers stay tied to what you are studying.</li>
<li>Never paste personal information into any chat tool.</li>
</ul>
<div class="callout">A good rule: if you could not do a similar question alone afterwards, you used the coach as a crutch rather than a coach.</div>`,
  }),
  A("how-to-read-a-motion-graph", {
    title: "How to read a motion graph without guessing",
    desc: "Distance-time and velocity-time graphs follow a few simple rules. Learn what the slope and the area under the line really tell you.",
    date: "2026-10-05", cat: "Physics", mins: 5, icon: "📈", color: "#2F6FB3",
    body: `
<p>Motion graphs show up in almost every physics exam, and most lost marks come from reading the wrong thing off the line. The fix is to ask the same two questions every time: <em>what is on each axis?</em> and <em>what does the slope mean?</em></p>
<h2>Distance-time graphs</h2>
<ul>
<li><strong>Slope = speed.</strong> A steeper line means faster movement.</li>
<li><strong>A flat line means the object is at rest</strong>, because its distance is not changing.</li>
<li><strong>A curve that gets steeper</strong> means the object is speeding up. A curve that flattens means it is slowing down.</li>
</ul>
<h2>Velocity-time graphs</h2>
<ul>
<li><strong>Slope = acceleration.</strong> A flat line at a non-zero value is constant velocity, with zero acceleration.</li>
<li><strong>Area under the line = distance travelled</strong> (or displacement, if velocity can be negative). Split awkward shapes into rectangles and triangles.</li>
<li><strong>A line below the axis</strong> means moving in the opposite direction.</li>
</ul>
<div class="callout"><strong>Common trap:</strong> a flat line means <em>different things</em> on the two graphs. On a distance-time graph it is “stopped”. On a velocity-time graph it is “moving at a steady speed”.</div>
<h2>A quick method for exam questions</h2>
<ol>
<li>Read both axis labels and their units before anything else.</li>
<li>Decide whether the question wants a slope, an area or a single point reading.</li>
<li>For a slope, pick two points far apart on the line and show “change in y divided by change in x”, with units.</li>
<li>Check that your answer makes sense: a car should not be accelerating at 4000 m/s².</li>
</ol>
<h2>Where this connects</h2>
<p>Velocity-time slopes lead straight into <a href="{{L}}physics/force.html">Force</a>, because acceleration is what a resultant force produces. Try the lesson quiz afterwards to check that you can tell the two kinds of graph apart.</p>`,
  }),
  A("exam-command-words-explained", {
    title: "What exam command words really ask you to do",
    desc: "“State”, “describe”, “explain”, “evaluate”: each one asks for a different kind of answer. A short guide to matching your answer to the verb.",
    date: "2026-10-05", cat: "Exams", mins: 5, icon: "📝", color: "#8A4FB5",
    body: `
<p>Many students know the content but write the wrong <em>kind</em> of answer. The command word, the first verb in the question, tells you what sort of answer earns the marks. Exam boards publish their own exact definitions, so check your board's list, but the common ones work like this.</p>
<h2>The usual suspects</h2>
<ul>
<li><strong>State / Name / Give:</strong> a short fact, no explanation needed.</li>
<li><strong>Define:</strong> the precise meaning of a term, often one sentence.</li>
<li><strong>Describe:</strong> say what happens or what you can see, such as a pattern or a process, without saying why.</li>
<li><strong>Explain:</strong> give the reason. Use “because”, “so” and “therefore” to link cause and effect.</li>
<li><strong>Calculate:</strong> work it out and show the method. Include units.</li>
<li><strong>Compare:</strong> similarities <em>and</em> differences, with both sides mentioned in the same sentence.</li>
<li><strong>Evaluate / Discuss:</strong> weigh up points for and against, then reach a judgement.</li>
</ul>
<div class="callout"><strong>Rule of thumb:</strong> “describe” is <em>what</em>, “explain” is <em>why</em>. Writing a long description when the question says “explain” is one of the most common ways to lose marks.</div>
<h2>Use the marks as a guide</h2>
<p>A 1-mark question wants one point. A 4-mark “explain” question usually wants about four linked points. If you have written one sentence for four marks, there is almost certainly more to say.</p>
<h2>Practise it</h2>
<p>After any practice paper, circle the command word in each question you lost marks on and ask whether your answer matched it. The <a href="{{L}}exams.html">Exam Center</a> and <a href="{{L}}past-papers.html">Past Papers</a> are good places to build the habit, and misses are saved to the <a href="{{L}}review.html">Mistake Notebook</a>.</p>`,
  }),
  A("photosynthesis-in-plain-language", {
    title: "Photosynthesis in plain language",
    desc: "How plants turn light, water and carbon dioxide into food and oxygen, and the three factors that limit how fast it happens.",
    date: "2026-10-05", cat: "Biology", mins: 5, icon: "🌿", color: "#2E8B57",
    body: `
<p>Photosynthesis is how plants, algae and some bacteria make their own food using light energy. It is also the source of most of the oxygen in the air we breathe.</p>
<h2>The equation</h2>
<p><strong>carbon dioxide + water → glucose + oxygen</strong>, driven by light energy absorbed by chlorophyll. In symbols: 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂.</p>
<h2>Where and how</h2>
<ul>
<li>It happens in <strong>chloroplasts</strong>, the green structures in plant cells that contain chlorophyll. See <a href="{{L}}biology/cell.html">The Cell</a> for the full cell tour.</li>
<li>In the <strong>light-dependent stage</strong>, light energy is captured and water is split, releasing oxygen.</li>
<li>In the <strong>light-independent stage</strong> (the Calvin cycle), the captured energy is used to build glucose from carbon dioxide.</li>
</ul>
<h2>What limits the rate</h2>
<ol>
<li><strong>Light intensity:</strong> more light speeds things up until something else becomes the bottleneck.</li>
<li><strong>Carbon dioxide concentration:</strong> the raw material has to be available.</li>
<li><strong>Temperature:</strong> the reactions are controlled by enzymes, so the rate rises with warmth and then falls once the enzymes stop working properly.</li>
</ol>
<div class="callout"><strong>Exam tip:</strong> when a graph levels off, name the factor that is now limiting, not the one on the x-axis. Past the plateau, adding more of the plotted factor changes nothing.</div>
<h2>What happens to the glucose?</h2>
<p>Plants use it for respiration to release energy, convert it to starch for storage, and build cellulose for cell walls. Notice that plants respire <em>all the time</em>, not only at night.</p>`,
  }),
  A("first-week-of-python-plan", {
    title: "A realistic first week of learning Python",
    desc: "A seven-day plan for absolute beginners: what to learn each day, what to build, and the mistakes to expect along the way.",
    date: "2026-10-05", cat: "Computer science", mins: 6, icon: "🐍", color: "#C9A227",
    body: `
<p>You do not need a long course to start writing useful programs. You need short daily practice and a habit of typing the code yourself rather than only reading it. Here is a gentle plan; 30 to 45 minutes a day is plenty.</p>
<h2>The plan</h2>
<ol>
<li><strong>Day 1 – Output and variables.</strong> Print messages, store values in variables, and see what an error message looks like.</li>
<li><strong>Day 2 – Data types.</strong> Numbers, text (strings) and true/false values, plus simple arithmetic.</li>
<li><strong>Day 3 – Input and decisions.</strong> Ask the user a question and respond with <code>if</code> / <code>else</code>.</li>
<li><strong>Day 4 – Loops.</strong> Repeat actions with <code>for</code> and <code>while</code>. Our <a href="{{L}}computer-science/control-flow.html">Control Flow</a> lesson covers this.</li>
<li><strong>Day 5 – Lists.</strong> Store several values and loop through them.</li>
<li><strong>Day 6 – Functions.</strong> Package code you reuse, with parameters and return values.</li>
<li><strong>Day 7 – Build something small.</strong> A number-guessing game or a quiz that asks five questions and keeps score.</li>
</ol>
<div class="callout"><strong>Expect errors.</strong> Every programmer sees them constantly. Read the last line of the message first; it names the problem, and the line number shows where Python noticed it.</div>
<h2>Habits that help</h2>
<ul>
<li>Change one thing at a time and run the program again.</li>
<li>Predict what the code will print <em>before</em> you run it. That is retrieval practice for programmers.</li>
<li>When stuck for more than 15 minutes, explain the problem out loud or in writing; the answer often appears.</li>
</ul>
<p>Start with the <a href="{{L}}computer-science/python.html">Python lesson</a>, then use the quiz to check what stuck.</p>`,
  }),
  A("plan-revision-around-sleep-and-breaks", {
    title: "Planning revision around sleep and breaks",
    desc: "Late-night cramming costs more than it gives. How to build a revision timetable that protects sleep, uses breaks and still covers everything.",
    date: "2026-10-05", cat: "Study skills", mins: 5, icon: "🌙", color: "#3B5BA9",
    body: `
<p>When exams get close, sleep is usually the first thing students trade away. Research on learning generally finds that sleep helps the brain consolidate what you studied that day, so cutting it short tends to undermine the very hours you were trying to add. This is general study advice, not medical advice; if you are struggling with sleep or stress, talk to a parent, teacher or doctor.</p>
<h2>Build the timetable backwards</h2>
<ol>
<li><strong>Start with fixed things:</strong> school, meals, travel, sleep. Block a consistent bedtime and wake time first.</li>
<li><strong>List topics by weakness, not by liking.</strong> The Mistake Notebook and quiz scores show where marks are leaking.</li>
<li><strong>Give each study block one job:</strong> “Do ten questions on forces”, not “study physics”.</li>
<li><strong>Keep blocks short:</strong> about 25 to 50 minutes of focused work, then a real break away from your phone.</li>
<li><strong>Leave gaps.</strong> A timetable with no slack falls apart the first time something runs late.</li>
</ol>
<div class="callout"><strong>The evening rule:</strong> use the last hour before bed for light review such as flashcards, and leave new, difficult material for earlier in the day.</div>
<h2>Make breaks count</h2>
<ul>
<li>Stand up, drink water, look out of a window or walk around for a few minutes.</li>
<li>Avoid starting something with no natural end, such as a video feed, as your break.</li>
</ul>
<h2>Spread it out</h2>
<p>Return to each topic several times over the weeks rather than once for a long session. This is spaced practice, and <a href="{{L}}review.html">the Mistake Notebook</a> schedules it for you. For the underlying idea, read how <a href="{{L}}blog/spaced-review-mistake-notebook.html">spaced review works</a>.</p>`,
  }),
];

export const ROLES = [
  { title: "Lesson writer", type: "Volunteer · Remote", blurb: "Draft or improve lessons in a subject you know well, using our lesson template: explanation, 10+ flashcards, quiz questions and an optional interactive idea.", needs: ["Strong knowledge of one of the eight subjects (school or university level)", "Clear, friendly writing for students", "Care about getting facts right and citing sources"] },
  { title: "Subject reviewer / teacher advisor", type: "Volunteer · Remote", blurb: "Fact-check lessons and quiz questions for accuracy and fit with a curriculum, and tell us where students usually get stuck.", needs: ["Teaching or tutoring experience, or a degree in the subject", "A few hours a month", "Honest, specific feedback"] },
  { title: "Front-end developer", type: "Volunteer · Remote", blurb: "Help build interactive models and polish the site. The project is plain HTML, CSS and JavaScript with Three.js for 3D, plus a small Flask backend.", needs: ["Comfortable with vanilla JavaScript and CSS", "Interest in accessibility and performance", "Nice to have: Three.js or canvas experience"] },
  { title: "Translator & accessibility tester", type: "Volunteer · Remote", blurb: "Check machine translations of key pages in your language, or test the site with a screen reader, keyboard-only or dyslexia-friendly settings and report what breaks.", needs: ["Fluent in a language besides English, or experience with assistive technology", "Patience and attention to detail"] },
];
