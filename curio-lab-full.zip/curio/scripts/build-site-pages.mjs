#!/usr/bin/env node
// Generates the public-site pages (FAQ, Help, Blog, Careers, Press, Partners, Cookies, Contact) plus
// sitemap.xml (via build-seo.mjs) and the press-kit logos.  Run:  node scripts/build-site-pages.mjs
// Real values (site address, contact email, who is responsible for the data) live in site.config.json.
//   SITE_URL=https://yourdomain.org CONTACT_EMAIL=you@yourdomain.org node scripts/build-site-pages.mjs   (one-off override)
//   node scripts/build-site-pages.mjs --strict   exits 1 while any placeholder is still in site.config.json
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { page, hero, esc, SITE, FONTS_LOCAL } from "./site-pages/shell.mjs";
import { FAQ, HELP, ARTICLES, ROLES } from "./site-pages/content.mjs";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PUB = path.join(ROOT, "public");
const out = (rel, html) => {
  const f = path.join(PUB, "pages", rel);
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(f, html);
  written.push(rel);
};
const written = [];
const idx = JSON.parse(fs.readFileSync(path.join(PUB, "data/learning-index.json"), "utf8"));
const T = idx.totals;
const subjectCount = new Set(idx.lessons.map((l) => l.id.split("/")[0])).size;
const strip = (s) => s.replace(/\{\{[LP]\}\}/g, "").replace(/<[^>]+>/g, "").replace(/&amp;/g, "&");
const fmt = (n) => n.toLocaleString("en-US");
const dateLabel = (d) => new Date(d + "T00:00:00Z").toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });

/* ---------- reusable form ---------- */
const form = ({ topic = "general", topics = true, cta = "Send message", messageLabel = "What's on your mind?", extra = "" } = {}) => `
<form data-api-form data-topic="${topic}" data-mailto="{{EMAIL}}" novalidate>
  <div class="cl-field"><input id="f-name" name="name" type="text" placeholder=" " required maxlength="120" autocomplete="name" /><label for="f-name">Your name</label></div>
  <div class="cl-field"><input id="f-email" name="email" type="email" placeholder=" " required maxlength="200" autocomplete="email" /><label for="f-email">Email address</label></div>
  ${topics ? `<div class="cl-field"><select id="f-topic" name="topic" aria-label="Topic">
    <option value="general">General question</option><option value="bug">Report a bug</option><option value="feedback">Feedback or idea</option>
    <option value="teacher">Teacher or school</option><option value="partner">Partnership</option><option value="careers">Contributing / careers</option>
    <option value="press">Press</option><option value="privacy">Privacy request (access, delete, correct)</option></select></div>` : `<input type="hidden" name="topic" value="${topic}" />`}
  ${extra}
  <div class="cl-field"><textarea id="f-msg" name="message" placeholder=" " required minlength="5" maxlength="5000"></textarea><label for="f-msg">${messageLabel}</label></div>
  <div class="hp-field" aria-hidden="true"><label>Leave this empty <input type="text" name="website" tabindex="-1" autocomplete="off" /></label></div>
  <label class="consent-line"><input type="checkbox" name="consent" required />
    <span>I agree that Curio Lab stores my name, email and message so it can reply. It is kept for up to 12 months and not shared or used for marketing. See the <a href="{{L}}privacy.html">Privacy notice</a>.</span></label>
  <label class="consent-line"><input type="checkbox" name="age_ok" required />
    <span>I am 13 or older, or I am a parent or guardian writing for a child. (Children's accounts can't send messages; <a href="{{L}}privacy.html#children">why</a>.)</span></label>
  <div class="cl-error-note" data-child-block style="display:none" role="alert"></div>
  <button type="submit" class="cl-submit-btn" style="margin-top:var(--space-3)"><span class="spinner"></span><span class="btn-label">${cta}</span></button>
  <div class="cl-success-note" data-cl-success role="status"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/><path d="M7 12l3 3 7-7" stroke="currentColor" stroke-width="2" fill="none"/></svg><span>Thanks — your message is in. We usually reply within a few days.</span></div>
  <div class="cl-error-note" data-cl-error role="alert"></div>
</form>`;

/* ---------- FAQ ---------- */
{
  const groups = FAQ.map((g) => `
    <section class="faq-group" data-filter-group id="g-${g.id}">
      <h2><span aria-hidden="true">${g.icon}</span> ${g.title}</h2>
      ${g.items.map(([q, a], i) => `<details class="faq-item" id="fq-${g.id}-${i + 1}" data-search="${esc(strip(q + " " + a)).toLowerCase()}" data-cat="${g.id}"><summary>${q}</summary><div class="faq-a">${a}</div></details>`).join("\n      ")}
    </section>`).join("\n");
  const body = `
  ${hero("FAQ", "Frequently asked questions", "Quick answers about lessons, accounts, privacy and more. Can't find yours? Ask us.")}
  <section class="wrap sp-section" data-filter-root>
    <div class="sp-search"><input type="search" data-filter-input placeholder="Search questions, e.g. “offline”, “data”, “quiz”" aria-label="Search questions" /></div>
    <div class="sp-chips" role="group" aria-label="Topics">
      <button class="sp-chip" type="button" data-filter-chip="all" aria-pressed="true">All</button>
      ${FAQ.map((g) => `<button class="sp-chip" type="button" data-filter-chip="${g.id}" aria-pressed="false">${g.icon} ${g.title}</button>`).join("\n      ")}
    </div>
    <div style="max-width:820px">${groups}
      <p class="sp-empty" data-filter-empty hidden>No questions match that search. Try a shorter word, or <a href="{{L}}contact.html">ask us directly</a>.</p>
    </div>
    <div class="sp-strip" style="max-width:820px"><div><h3>Still stuck?</h3><p>Browse the <a href="{{L}}help.html">Help Center</a> for step-by-step guides, or send us a message.</p></div><a class="sp-btn" href="{{L}}contact.html">Contact us</a></div>
  </section>`;
  const faqLd = { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: FAQ.flatMap((g) => g.items).map(([q, a]) => ({ "@type": "Question", name: strip(q), acceptedAnswer: { "@type": "Answer", text: strip(a) } })) };
  out("faq.html", page({ file: "faq.html", title: "FAQ", desc: "Answers about Curio Lab lessons, free access, accounts, privacy, cookies, offline use and accessibility.", body, jsonld: [faqLd] }));
}

/* ---------- Help Center ---------- */
{
  const cards = HELP.map((h, i) => `
    <article class="sp-card" id="h-${i + 1}" data-search="${esc(strip(h.title + " " + h.steps.join(" "))).toLowerCase()}">
      <span class="sp-ico" aria-hidden="true">${h.icon}</span><h3>${h.title}</h3>
      <ol class="help-steps">${h.steps.map((s) => `<li>${s}</li>`).join("")}</ol>
    </article>`).join("\n");
  const body = `
  ${hero("Help Center", "How can we help?", "Step-by-step guides for the things people ask about most.")}
  <section class="wrap sp-section" data-filter-root>
    <div class="sp-search"><input type="search" data-filter-input placeholder="Search guides, e.g. “offline”, “exam”, “font”" aria-label="Search guides" /></div>
    <div class="sp-grid" style="margin-top:var(--space-3)">${cards}</div>
    <p class="sp-empty" data-filter-empty hidden>No guides match. Check the <a href="{{L}}faq.html">FAQ</a> or <a href="{{L}}contact.html">contact us</a>.</p>
  </section>
  <section class="wrap sp-section">
    <div class="sp-grid">
      <a class="sp-card" href="{{L}}faq.html"><span class="sp-ico">❓</span><h3>FAQ</h3><p>Short answers to common questions.</p></a>
      <a class="sp-card" href="{{L}}accessibility.html"><span class="sp-ico">♿</span><h3>Accessibility &amp; offline</h3><p>Text size, fonts, contrast, install, offline lessons.</p></a>
      <a class="sp-card" href="{{L}}contact.html?topic=bug"><span class="sp-ico">🐞</span><h3>Report a bug</h3><p>Tell us what broke and where.</p></a>
      <a class="sp-card" href="{{L}}contact.html"><span class="sp-ico">✉️</span><h3>Contact support</h3><p>A real person reads every message.</p></a>
    </div>
  </section>`;
  out("help.html", page({ file: "help.html", title: "Help Center", desc: "Step-by-step guides for Curio Lab: starting lessons, the Mistake Notebook, exams, offline use, accessibility and privacy controls.", body, jsonld: [{ "@context": "https://schema.org", "@graph": HELP.map((h, i) => ({ "@type": "HowTo", "@id": `${SITE.url}/pages/help.html#h-${i + 1}`, name: strip(h.title), step: h.steps.map((st, n) => ({ "@type": "HowToStep", position: n + 1, text: strip(st) })) })) }] }));
}

/* ---------- RSS feed (public/feed.xml) ---------- */
{
  const x = (t) => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const items = [...ARTICLES].sort((a, b) => (a.date < b.date ? 1 : -1)).map((a) => `  <item>
    <title>${x(strip(a.title))}</title>
    <link>${SITE.url}/pages/blog/${a.slug}.html</link>
    <guid isPermaLink="true">${SITE.url}/pages/blog/${a.slug}.html</guid>
    <pubDate>${new Date(a.date + "T09:00:00Z").toUTCString()}</pubDate>
    <category>${x(a.cat)}</category>
    <description>${x(strip(a.desc))}</description>
  </item>`).join("\n");
  fs.writeFileSync(path.join(PUB, "feed.xml"), `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"><channel>
  <title>${x(SITE.name)} Blog</title>
  <link>${SITE.url}/pages/blog.html</link>
  <description>Practical study-skills and science articles from ${x(SITE.name)}.</description>
  <language>en</language>
${items}
</channel></rss>
`);
}

/* ---------- Blog index + articles ---------- */
{
  const cats = [...new Set(ARTICLES.map((a) => a.cat))];
  const cards = ARTICLES.map((a) => `
    <a class="sp-card blog-card" href="{{L}}blog/${a.slug}.html" data-search="${esc(a.title + " " + a.desc + " " + a.cat).toLowerCase()}" data-cat="${a.cat}">
      <div class="blog-cover" style="background:${a.color}" aria-hidden="true">${a.icon}</div>
      <div class="blog-body"><span class="sp-tag">${a.cat}</span><h3>${a.title}</h3><p>${a.desc}</p><span class="sp-meta">${dateLabel(a.date)} · ${a.mins} min read</span></div>
    </a>`).join("\n");
  const body = `
  ${hero("Blog", "Study smarter, learn deeper", "Short, practical articles on how learning works and how to get more from every session.")}
  <section class="wrap sp-section" data-filter-root>
    <div class="sp-search"><input type="search" data-filter-input placeholder="Search articles" aria-label="Search articles" /></div>
    <div class="sp-chips" role="group" aria-label="Categories">
      <button class="sp-chip" type="button" data-filter-chip="all" aria-pressed="true">All</button>
      ${cats.map((c) => `<button class="sp-chip" type="button" data-filter-chip="${c}" aria-pressed="false">${c}</button>`).join("\n      ")}
    </div>
    <div class="sp-grid">${cards}</div>
    <p class="sp-empty" data-filter-empty hidden>No articles match that search.</p>
  </section>`;
  const ld = { "@context": "https://schema.org", "@type": "Blog", name: "Curio Lab Blog", url: `${SITE.url}/pages/blog.html`, blogPost: ARTICLES.map((a) => ({ "@type": "BlogPosting", headline: a.title, datePublished: a.date, url: `${SITE.url}/pages/blog/${a.slug}.html` })) };
  out("blog.html", page({ file: "blog.html", title: "Blog", desc: "Practical study-skills and science articles from Curio Lab: retrieval practice, spaced review, Newton's laws and using AI to learn.", body, jsonld: [ld], head: `<link rel="alternate" type="application/rss+xml" title="Curio Lab Blog" href="${SITE.url}/feed.xml" />` }));

  ARTICLES.forEach((a, i) => {
    const more = ARTICLES.filter((x) => x !== a).slice(0, 3);
    const body = `
  <section class="page-hero tool-hero"><div class="wrap">
    <p class="crumbs"><a href="{{L}}../index.html">Home</a> › <a href="{{L}}blog.html">Blog</a> › ${a.cat}</p>
    <h1>${a.title}</h1><p>${a.desc}</p>
    <div class="article-meta"><span>By the Curio Lab team</span><span>·</span><time datetime="${a.date}">${dateLabel(a.date)}</time><span>·</span><span>${a.mins} min read</span></div>
  </div></section>
  <section class="wrap sp-section"><article class="article">${a.body}</article>
    <div class="article-cta sp-strip"><div><h3>Put it into practice</h3><p>Open a lesson, take the quiz and let the Mistake Notebook handle the reviews.</p></div><a class="sp-btn" href="{{L}}../index.html#subjects">Start a lesson</a></div>
    <h2 class="sp-h2" style="max-width:720px;margin:var(--space-5) auto var(--space-2)">Keep reading</h2>
    <div class="sp-grid" style="max-width:1000px;margin:0 auto">${more.map((m) => `<a class="sp-card" href="{{L}}blog/${m.slug}.html"><span class="sp-tag">${m.cat}</span><h3>${m.title}</h3><span class="sp-meta">${m.mins} min read</span></a>`).join("")}</div>
  </section>`;
    const ld = { "@context": "https://schema.org", "@type": "BlogPosting", headline: a.title, description: a.desc, datePublished: a.date, dateModified: a.date, author: { "@type": "Organization", name: SITE.name }, publisher: { "@type": "Organization", name: SITE.name }, mainEntityOfPage: `${SITE.url}/pages/blog/${a.slug}.html` };
    out(`blog/${a.slug}.html`, page({ file: `blog/${a.slug}.html`, title: a.title, desc: a.desc, body, jsonld: [ld], ogType: "article" }));
  });
}

/* ---------- Careers ---------- */
{
  const roles = ROLES.map((r) => `
    <article class="sp-card role" id="${r.title.toLowerCase().replace(/[^a-z]+/g, "-")}">
      <div class="role-head"><h3>${r.title}</h3><span class="pill">${r.type}</span></div>
      <p>${r.blurb}</p><strong style="font-size:.85rem">What helps</strong>
      <ul>${r.needs.map((n) => `<li>${n}</li>`).join("")}</ul>
    </article>`).join("\n");
  const body = `
  ${hero("Careers", "Help build Curio Lab", "Curio Lab is a small, student-built project. We don't have paid jobs yet — but we do have real work, and we'd love your help.")}
  <section class="wrap sp-section">
    <h2 class="sp-h2">Be upfront: these are volunteer roles</h2>
    <p class="sp-lede">There is no payroll, no equity and no hidden hiring process. What you get is a real project to learn from and credit for your work, and a reference or letter of recommendation if you've contributed meaningfully. If paid roles ever exist, they'll be listed here first.</p>
    <div class="sp-grid">${roles}</div>
  </section>
  <section class="wrap sp-section">
    <h2 class="sp-h2">What we value</h2>
    <div class="sp-grid">
      <div class="sp-card"><span class="sp-ico">🎯</span><h3>Accuracy first</h3><p>A wrong fact in a study site does real harm. We would rather ship less and get it right.</p></div>
      <div class="sp-card"><span class="sp-ico">🤝</span><h3>Honest with learners</h3><p>No dark patterns, no inflated claims, no selling data.</p></div>
      <div class="sp-card"><span class="sp-ico">♿</span><h3>Everyone can use it</h3><p>Accessible by default, light enough for slow connections, usable offline.</p></div>
      <div class="sp-card"><span class="sp-ico">🌱</span><h3>Learning together</h3><p>Everyone is here to learn. Feedback is kind, specific and welcome.</p></div>
    </div>
  </section>
  <section class="wrap sp-section" id="apply">
    <h2 class="sp-h2">Tell us how you'd like to help</h2>
    <p class="sp-lede">Say which role interests you, what you've done that's relevant, and how many hours you could give. Links to your work help but aren't required.</p>
    <div class="contact-card" style="max-width:640px">${form({ topic: "careers", topics: false, cta: "Send my application", messageLabel: "Role, background and availability" })}</div>
  </section>`;
  const ld = { "@context": "https://schema.org", "@type": "WebPage", name: "Careers at Curio Lab", description: "Volunteer roles at Curio Lab." };
  out("careers.html", page({ file: "careers.html", title: "Careers", desc: "Volunteer to write lessons, review facts, build interactive models or test accessibility at Curio Lab, a student-built learning platform.", body, jsonld: [ld] }));
}

/* ---------- Press ---------- */
{
  const boiler = `Curio Lab is a free, curiosity-driven study platform for ${subjectCount} subjects — Physics, Chemistry, Biology, Mathematics, English, History, Geography and Computer Science. It offers ${fmt(T.lessons)} interactive lessons with ${fmt(T.flashcards)} flashcards, ${fmt(T.quizQuestions)} quiz questions, timed exam papers and study games, and works offline. Progress is saved on the learner's own device, with no ads and no tracking. Curio Lab is built by a student, for students.`;
  const body = `
  ${hero("Press", "Press &amp; media kit", "Everything you need to write about Curio Lab: a short description, current numbers, logos and a contact.")}
  <section class="wrap sp-section">
    <h2 class="sp-h2">About Curio Lab</h2>
    <div class="copy-box" id="boiler">${boiler}</div>
    <div class="sp-actions"><button class="sp-btn ghost" type="button" data-copy="#boiler">Copy description</button></div>
  </section>
  <section class="wrap sp-section">
    <h2 class="sp-h2">Fact sheet</h2>
    <table class="fact-table"><tbody>
      <tr><th scope="row">Name</th><td>Curio Lab (also written Curiolab)</td></tr>
      <tr><th scope="row">What it is</th><td>A free web learning platform with interactive lessons, quizzes, flashcards, games and exam practice</td></tr>
      <tr><th scope="row">Subjects</th><td><span data-stat="subjects">${subjectCount}</span></td></tr>
      <tr><th scope="row">Lessons</th><td><span data-stat="lessons">${fmt(T.lessons)}</span></td></tr>
      <tr><th scope="row">Flashcards</th><td><span data-stat="flashcards">${fmt(T.flashcards)}</span></td></tr>
      <tr><th scope="row">Quiz questions</th><td><span data-stat="quizQuestions">${fmt(T.quizQuestions)}</span></td></tr>
      <tr><th scope="row">Exam-center questions</th><td><span data-stat="examQuestions">${fmt(T.examQuestions)}</span></td></tr>
      <tr><th scope="row">Price</th><td>Free. Paid plans shown on the Pricing page are a concept demo.</td></tr>
      <tr><th scope="row">Privacy</th><td>No ads, no analytics. Progress stays in the learner's browser.</td></tr>
      <tr><th scope="row">Built with</th><td>HTML, CSS, JavaScript, Three.js; optional Python/Flask backend</td></tr>
      <tr><th scope="row">Founder</th><td>A school student (name available on request)</td></tr>
    </tbody></table>
    <p class="sp-meta" style="margin-top:.6rem">Numbers update from the live lesson data.</p>
  </section>
  <section class="wrap sp-section">
    <h2 class="sp-h2">Logos &amp; colours</h2>
    <div class="sp-grid" style="grid-template-columns:repeat(auto-fit,minmax(240px,1fr))">
      <div><div class="logo-tile light">Curio<span class="dot">·</span>Lab</div><p class="sp-actions" style="margin-top:.6rem"><a class="sp-btn ghost" href="{{P}}press/curio-lab-logo-light.svg" download>Download SVG</a></p></div>
      <div><div class="logo-tile dark">Curio<span class="dot">·</span>Lab</div><p class="sp-actions" style="margin-top:.6rem"><a class="sp-btn ghost" href="{{P}}press/curio-lab-logo-dark.svg" download>Download SVG</a></p></div>
      <div><div class="logo-tile light"><img src="{{P}}press/curio-lab-icon.svg" alt="Curio Lab flask icon" width="64" height="64" /></div><p class="sp-actions" style="margin-top:.6rem"><a class="sp-btn ghost" href="{{P}}press/curio-lab-icon.svg" download>Download icon</a></p></div>
    </div>
    <div class="swatches" style="margin-top:var(--space-3)">
      <span class="swatch"><i style="background:#12213B"></i>Navy #12213B</span>
      <span class="swatch"><i style="background:#E9A93F"></i>Amber #E9A93F</span>
      <span class="swatch"><i style="background:#56C2B2"></i>Teal #56C2B2</span>
    </div>
    <p class="sp-lede" style="margin-top:var(--space-2)">Please don't stretch, recolour or add effects to the logo, and keep clear space around it equal to the height of the “C”.</p>
  </section>
  <section class="wrap sp-section">
    <h2 class="sp-h2">Coverage</h2>
    <p class="sp-lede">No press coverage yet. If you've written about Curio Lab, tell us and we'll list it here.</p>
  </section>
  <section class="wrap sp-section" id="contact-press">
    <h2 class="sp-h2">Press enquiries</h2>
    <p class="sp-lede">For interviews, quotes or screenshots, write to <a href="mailto:{{EMAIL}}">{{EMAIL}}</a> or use the form.</p>
    <div class="contact-card" style="max-width:640px">${form({ topic: "press", topics: false, cta: "Send enquiry", messageLabel: "Outlet, deadline and what you need" })}</div>
  </section>`;
  const ld = { "@context": "https://schema.org", "@type": "Organization", name: SITE.name, url: SITE.url, description: boiler, logo: `${SITE.url}/press/curio-lab-icon.svg`, email: SITE.email };
  out("press.html", page({ file: "press.html", title: "Press & media kit", desc: "Curio Lab press kit: company description, fact sheet with live numbers, logos, brand colours and press contact.", body, jsonld: [ld] }));

  // press-kit logos
  const dir = path.join(PUB, "press");
  fs.mkdirSync(dir, { recursive: true });
  const word = (bg, fg) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 100" role="img" aria-label="Curio Lab">${bg ? `<rect width="360" height="100" rx="16" fill="${bg}"/>` : ""}<text x="180" y="64" text-anchor="middle" font-family="Space Grotesk, Inter, Arial, sans-serif" font-weight="700" font-size="48" fill="${fg}">Curio<tspan fill="#E9A93F">·</tspan>Lab</text></svg>\n`;
  fs.writeFileSync(path.join(dir, "curio-lab-logo-light.svg"), word("#FFFFFF", "#12213B"));
  fs.writeFileSync(path.join(dir, "curio-lab-logo-dark.svg"), word("#12213B", "#FFFFFF"));
  fs.writeFileSync(path.join(dir, "curio-lab-icon.svg"), `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" role="img" aria-label="Curio Lab"><rect width="100" height="100" rx="20" fill="#12213B"/><path d="M40 20 h20 v22 l18 30 a8 8 0 0 1 -7 12 H29 a8 8 0 0 1 -7 -12 l18 -30 Z" fill="none" stroke="#E9A93F" stroke-width="5" stroke-linejoin="round"/><circle cx="50" cy="68" r="5" fill="#56C2B2"/></svg>\n`);
}

/* ---------- Partners ---------- */
{
  const body = `
  ${hero("Partners", "Partner with Curio Lab", "We're a small project that works best alongside teachers, schools and people who care about learning.")}
  <section class="wrap sp-section">
    <div class="sp-grid">
      <div class="sp-card"><span class="sp-ico">🏫</span><h3>Schools &amp; teachers</h3><p>Try Curio Lab with a class. Tell us what's missing or confusing and we'll prioritise fixes. Students can use everything without accounts.</p></div>
      <div class="sp-card"><span class="sp-ico">✍️</span><h3>Educators &amp; creators</h3><p>Contribute lessons, diagrams, worked examples or videos. You keep credit for your work, and we review for accuracy together.</p></div>
      <div class="sp-card"><span class="sp-ico">🌍</span><h3>Non-profits &amp; communities</h3><p>Help us reach learners who benefit most: translations, offline use in low-bandwidth places, community study groups.</p></div>
      <div class="sp-card"><span class="sp-ico">🧩</span><h3>Tools &amp; platforms</h3><p>Open-source projects and edtech tools that could integrate with Curio Lab or share content under a clear licence.</p></div>
    </div>
  </section>
  <section class="wrap sp-section">
    <h2 class="sp-h2">What partnering looks like</h2>
    <ol class="help-steps" style="max-width:700px">
      <li><strong>Talk.</strong> Tell us who you are and what you'd like to try. No contracts to start.</li>
      <li><strong>Pilot.</strong> A small, time-boxed trial — one class, one subject or one lesson — with agreed goals.</li>
      <li><strong>Review.</strong> We look at what worked together, fix what didn't, and decide whether to keep going.</li>
    </ol>
    <p class="sp-lede" style="margin-top:var(--space-2)">We don't have current partners to list yet, and we won't show logos we haven't earned. Yours could be the first.</p>
  </section>
  <section class="wrap sp-section" id="apply">
    <h2 class="sp-h2">Start a conversation</h2>
    <div class="contact-card" style="max-width:640px">${form({ topic: "partner", topics: false, cta: "Send partnership enquiry", messageLabel: "Who you are and what you have in mind" })}</div>
  </section>`;
  out("partners.html", page({ file: "partners.html", title: "Partners", desc: "Partner with Curio Lab as a school, teacher, content creator, non-profit or tool maker. Start with a small pilot.", body }));
}

/* ---------- Cookie policy ---------- */
{
  const body = `
  ${hero("Legal", "Cookie &amp; storage policy", "What Curio Lab stores in your browser, what third parties can see, and how to change your choices.", `<span class="legal-updated-badge">🕓 Last updated: 5 October 2026</span>`)}
  <section class="wrap sp-section">
    <div style="max-width:820px">
      <div class="building-panel" style="border-style:solid" id="what"><h2>🍪 In short</h2>
        <p style="margin-top:.5rem;color:var(--color-ink-soft)">Curio Lab doesn't use advertising or analytics cookies. It stores your progress and settings on your device because the site can't work without them. Optional extras — currently embedded YouTube videos — only load after you allow them. Change your mind any time with <a href="#" data-cookie-settings>Cookie settings</a>.</p>
        <div class="sp-actions"><button class="sp-btn" type="button" data-cookie-settings>Open cookie settings</button></div>
      </div>

      <h2 class="sp-h2" style="margin-top:var(--space-4)">Essential — always on</h2>
      <p class="sp-lede">These are needed to deliver the features you ask for, so they don't need consent under ePrivacy rules. They never leave your device unless noted.</p>
      <table class="fact-table"><tbody>
        <tr><th scope="row">curiolab-scores, curiolab-exam-log, curiolab-recall-*</th><td>Quiz scores, exam history and Active Recall progress. Local storage, until you clear it.</td></tr>
        <tr><th scope="row">curiolab-theme, curiolab-a11y, curiolab-sound, curiolab-site-theme-v2</th><td>Your theme, accessibility and sound settings. Local storage.</td></tr>
        <tr><th scope="row">curiolab-profile-prefs, curiolab-chat-global</th><td>Profile preferences and AI Coach chat history. Local storage.</td></tr>
        <tr><th scope="row">curiolab-local-accounts, curiolab-local-session</th><td>Demo sign-in on this device when no server is connected. Local storage.</td></tr>
        <tr><th scope="row">curio.consent.v1</th><td>Remembers your cookie choice for 12 months. Local storage.</td></tr>
        <tr><th scope="row">Session cookie (server mode only)</th><td>HttpOnly cookie that keeps an admin or account holder signed in. Removed when the session ends.</td></tr>
        <tr><th scope="row">Offline cache</th><td>A service worker saves lessons you opened so they work without internet.</td></tr>
      </tbody></table>

      <h2 class="sp-h2" style="margin-top:var(--space-4)">Optional — only with your permission</h2>
      <table class="fact-table"><tbody>
        <tr><th scope="row">YouTube videos</th><td>Lessons embed videos from YouTube's privacy-enhanced player (youtube-nocookie.com). Until you allow it, a placeholder is shown and nothing is loaded from YouTube. Once allowed, YouTube (Google) receives your IP address and may set cookies when you play a video. <a href="https://policies.google.com/privacy" rel="noopener">Google's privacy policy</a>.</td></tr>
        <tr><th scope="row">Analytics</th><td>None today. If we ever add it, it will be off until you opt in here.</td></tr>
      </tbody></table>

      <h2 class="sp-h2" style="margin-top:var(--space-4)">Other third parties</h2>
      <table class="fact-table"><tbody>
        ${FONTS_LOCAL ? `<tr><th scope="row">Fonts</th><td>Typefaces are served from Curio Lab's own server, so opening a page does not send your IP address to Google or any other font provider.</td></tr>` : `<tr><th scope="row">Google Fonts</th><td>Pages load typefaces from Google's font servers, which means your IP address is sent to Google when a page opens. No cookies are set. Self-hosting these fonts would remove this; it's on our to-do list.</td></tr>`}
        <tr><th scope="row">Google Translate</th><td>Loaded only if you pick a language other than English and your browser can't translate natively. It then runs on Google's servers under Google's terms.</td></tr>
      </tbody></table>

      <h2 class="sp-h2" style="margin-top:var(--space-4)">Your choices</h2>
      <ul class="building-list" style="grid-template-columns:1fr">
        <li>Use <strong>Cookie settings</strong> in the footer of any page to accept or reject optional features. Rejecting is as easy as accepting.</li>
        <li>If your browser sends a Global Privacy Control signal, optional features start switched off.</li>
        <li>Delete everything stored on this device from <a href="{{L}}privacy.html#rights">Privacy → Your rights</a>, or from your browser's site settings.</li>
      </ul>
      <p class="sp-lede" style="margin-top:var(--space-3)">Questions about this policy? <a href="{{L}}contact.html?topic=privacy">Contact us</a>. Our wider data practices are in the <a href="{{L}}privacy.html">Privacy notice</a>.</p>
    </div>
  </section>`;
  out("cookies.html", page({ file: "cookies.html", title: "Cookie Policy", desc: "Which cookies and browser storage Curio Lab uses, which third parties are involved, and how to change your consent choices.", body }));
}

/* ---------- Contact (replaces the old demo form) ---------- */
{
  const body = `
  ${hero("Get in touch", "Contact Us", "Questions, feedback, bug reports, privacy requests — all welcome. A real person reads every message.")}
  <section class="wrap" style="padding-bottom: var(--space-6);">
    <div class="contact-grid-v2">
      <div class="contact-card">${form({ topic: "general" })}</div>
      <div class="contact-info-card">
        <h3>Other ways to reach us</h3>
        <div class="contact-info-row"><span class="ci-icon">✉️</span><span>Email: <a href="mailto:{{EMAIL}}">{{EMAIL}}</a></span></div>
        <div class="contact-info-row"><span class="ci-icon">❓</span><span>Quick answers are in the <a href="{{L}}faq.html">FAQ</a> and <a href="{{L}}help.html">Help Center</a>.</span></div>
        <div class="contact-info-row"><span class="ci-icon">🐞</span><span>Found a bug? Choose “Report a bug” and tell us the page and what you were doing — it helps a lot.</span></div>
        <div class="contact-info-row"><span class="ci-icon">🔐</span><span>For access, correction or deletion of your data, choose “Privacy request”. See <a href="{{L}}privacy.html#rights">your rights</a>.</span></div>
        <div class="contact-info-row"><span class="ci-icon">🗂️</span><span>Check the <a href="{{L}}changelog.html">Changelog</a> to see what's already been built.</span></div>
        <div class="contact-info-row"><span class="ci-icon">🤝</span><span>Teaching, writing or building? See <a href="{{L}}careers.html">Careers</a> and <a href="{{L}}partners.html">Partners</a>.</span></div>
      </div>
    </div>
  </section>`;
  out("contact.html", page({ file: "contact.html", title: "Contact Us", desc: "Contact Curio Lab: ask a question, report a bug, send feedback or make a privacy request.", body, accent: "--color-coral" }));
}

/* ---------- Parent page (consent + review/export/delete) and certificate verification entry ---------- */
{
  const parent = `
  ${hero("For parents and guardians", "Your child's Curio Lab account", "Review what we hold, approve or decline, download it, or delete it. This page works only with the private link we emailed you.")}
  <section class="wrap sp-section" style="padding-bottom:var(--space-6)">
    <div class="contact-card" data-parent-root aria-live="polite"><p>Loading…</p></div>
  </section>
  <script src="{{P}}js/parent-page.js" defer></script>`;
  out("parent.html", page({ file: "parent.html", title: "Parent controls", desc: "Approve, review, download or delete a child's Curio Lab account.", body: parent, noindex: true }));

  const verify = `
  ${hero("Certificates", "Verify a certificate", "Every Curio Lab certificate has a code like CL-ABCD-EFGH-JKMN and a link anyone can open. Enter a code to check it.")}
  <section class="wrap sp-section" style="padding-bottom:var(--space-6)">
    <div class="contact-card">
      <form data-verify-form novalidate>
        <div class="cl-field"><input id="v-code" name="code" type="text" placeholder=" " maxlength="24" autocomplete="off" autocapitalize="characters" spellcheck="false" required /><label for="v-code">Certificate code</label></div>
        <button type="submit" class="cl-submit-btn"><span class="btn-label">Check certificate</span></button>
        <div class="cl-error-note" data-verify-error role="alert"></div>
      </form>
      <p class="sp-lede" style="margin-top:var(--space-3)">Verification needs the Curio Lab server. A certificate confirms that Curio Lab issued it and has not withdrawn it; the page shows only the name, certificate and date.</p>
    </div>
  </section>
  <script>
  document.querySelector("[data-verify-form]").addEventListener("submit", function (e) {
    e.preventDefault();
    var c = document.getElementById("v-code").value.replace(/[^0-9a-z]/gi, "").toUpperCase().replace(/^CL/, "");
    var err = document.querySelector("[data-verify-error]");
    if (c.length !== 12) { err.textContent = "A code has 12 letters and numbers after CL-, for example CL-ABCD-EFGH-JKMN."; err.classList.add("is-visible"); return; }
    location.href = "/verify/CL-" + c.slice(0, 4) + "-" + c.slice(4, 8) + "-" + c.slice(8);
  });
  </script>`;
  out("verify.html", page({ file: "verify.html", title: "Verify a certificate", desc: "Check that a Curio Lab certificate is genuine.", body: verify, noindex: true }));
}

/* ---------- site.config.json -> hand-written pages (index.html, privacy.html) ---------- */
{
  const edit = (rel, fn) => {
    const f = path.join(PUB, rel);
    const before = fs.readFileSync(f, "utf8");
    const after = fn(before);
    if (after !== before) { fs.writeFileSync(f, after); written.push(rel + " (site config applied)"); }
  };
  const between = (s, tag, inner) => {
    const re = new RegExp(`(<!-- ${tag}:BEGIN[^>]*-->)[\\s\\S]*?(<!-- ${tag}:END -->)`);
    if (!re.test(s)) throw new Error(`marker ${tag} not found`);
    return s.replace(re, (_, a, b) => `${a}\n${inner}\n          ${b}`);
  };
  // landing page: canonical, og:url and the JSON-LD urls follow siteUrl
  edit("index.html", (s) =>
    s.replace(/(<meta property="og:url" content=")[^"]*(")/, `$1${SITE.url}/$2`)
     .replace(/(<link rel="canonical" href=")[^"]*(")/, `$1${SITE.url}/$2`)
     .replace(/("(?:url|logo)":\s*")https?:\/\/[^\/"]+/g, `$1${SITE.url}`));
  // privacy page: who is responsible for the data (GDPR Art. 13) + recipients wording
  edit("pages/privacy.html", (s) => {
    const mail = `<a href="mailto:${esc(SITE.email)}" style="color:var(--accent); text-decoration:underline;">${esc(SITE.email)}</a>`;
    const who = SITE.controllerName ? esc(SITE.controllerName) : "Curio Lab, a student-run project";
    const where = SITE.controllerAddress ? ` Postal address: ${esc(SITE.controllerAddress).replace(/\n/g, ", ")}.` : "";
    const todo = SITE.controllerName && SITE.controllerAddress ? "" : "          <!-- TODO: set controllerName and controllerAddress in site.config.json, then rebuild -->\n";
    s = between(s, "CONTROLLER", `${todo}          <p style="margin-top:0.5rem; color:var(--color-ink-soft);">\n            <strong>Controller (responsible for your data):</strong> ${who}.${where} Contact: ${mail}.\n          </p>`);
    const rec = FONTS_LOCAL
      ? "Recipients: our hosting provider, and Google (YouTube and Translate only if you use them), which may involve transfers outside the EU/UK under Google's own safeguards."
      : "Recipients: our hosting provider, and Google (fonts always; YouTube and Translate only if you use them), which may involve transfers outside the EU/UK under Google's own safeguards.";
    return between(s, "RECIPIENTS", `            <li>${rec}</li>`);
  });
  // warn (or fail with --strict) while placeholders remain
  const left = [];
  if (/\.example(\/|$)/.test(SITE.url)) left.push(`siteUrl is still the placeholder (${SITE.url})`);
  if (/\.example$/.test(SITE.email)) left.push(`contactEmail is still the placeholder (${SITE.email})`);
  if (!SITE.controllerName) left.push("controllerName is empty (Privacy page: who is responsible for the data)");
  if (!SITE.controllerAddress) left.push("controllerAddress is empty (Privacy page: postal address)");
  if (left.length) {
    console.warn("\n⚠ Placeholders left in site.config.json:\n  - " + left.join("\n  - "));
    if (process.argv.includes("--strict")) { console.error("\n--strict: not ready to publish."); process.exitCode = 1; }
  }
}

/* ---------- sitemap, robots, canonical + share tags ---------- */
// Owned by scripts/build-seo.mjs (also run by `npm run seo` and before every build).
{
  const { buildSeo } = await import("./build-seo.mjs");
  await buildSeo({ quiet: true });
  written.push("sitemap.xml, robots.txt, seo-manifest.json (scripts/build-seo.mjs)");
}

console.log("Generated:\n  " + written.join("\n  "));
