#!/usr/bin/env node
// Performance: adds `defer` to local classic <script src> tags so scripts stop blocking the first paint.
// Idempotent.   node scripts/defer-scripts.mjs [--check]
// Kept synchronous on purpose (they must run before the page is drawn or set up things other scripts read):
//   theme / appearance (no flash of the wrong theme), a11y settings, site-config + monitor (consent config), age gate, cookie consent.
// Deferred scripts still run in order, after the HTML is parsed and before DOMContentLoaded.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const PUB = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "public");
const check = process.argv.includes("--check");
const KEEP_SYNC = new Set(["site-themes.js", "theme.js", "theme-sync.js", "theme-engine.js", "a11y.js", "site-config.js", "monitor.js", "age-gate.js", "cookie-consent.js"]);
const SKIP_FILES = new Set(["500.html"]); // standalone, has no scripts
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : e.name.endsWith(".html") ? [path.join(d, e.name)] : []));
const TAG = /<script\b([^>]*?)\bsrc="([^"]+)"([^>]*)><\/script>/g;
let changed = 0, tags = 0;
for (const f of walk(PUB)) {
  if (SKIP_FILES.has(path.basename(f))) continue;
  const s = fs.readFileSync(f, "utf8");
  const out = s.replace(TAG, (m, a, src, b) => {
    const attrs = a + " " + b;
    if (/\b(defer|async)\b/.test(attrs) || /type="(?!text\/javascript)/.test(attrs) || /^(https?:)?\/\//.test(src)) return m;
    if (KEEP_SYNC.has(path.basename(src.split("?")[0]))) return m;
    tags++;
    return `<script${a}src="${src}"${b} defer></script>`;
  });
  if (out !== s) { changed++; if (!check) fs.writeFileSync(f, out); }
}
console.log(`${check ? "[check] " : ""}defer added to ${tags} script tags in ${changed} files`);
if (check && changed) process.exit(1);
