import { createFileRoute } from "@tanstack/react-router";

const MODEL = "gemini-3.8-flash";

type Msg = { text?: string; who?: string };

export const Route = createFileRoute("/api/coach")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env["GEMINI_API_KEY"];
        if (!key) return Response.json({ error: "AI is not configured" }, { status: 500 });
        let body: any;
        try {
          body = await request.json();
        } catch {
          return Response.json({ error: "Invalid request" }, { status: 400 });
        }
        const message = String(body?.message ?? "").slice(0, 4000).trim();
        if (!message) return Response.json({ error: "Empty message" }, { status: 400 });
        const topic = String(body?.topic ?? "this lesson").slice(0, 200);
        const debate = body?.mode === "debate";
        const ctx = body?.context && typeof body.context === "object" ? body.context : {};
        const history: Msg[] = Array.isArray(body?.history) ? body.history.slice(-20) : [];

        const system = [
          `You are Curio Lab's friendly AI coach for students, helping with "${topic}".`,
          ctx.subject ? `Subject: ${ctx.subject}.` : "",
          ctx.difficulty ? `Difficulty: ${ctx.difficulty}.` : "",
          ctx.activeSection ? `The student is in the "${ctx.activeSection}" section.` : "",
          ctx.sectionHeading ? `Current heading: ${ctx.sectionHeading}.` : "",
          debate
            ? "DEBATE MODE: respectfully challenge the student's position with clear counter-arguments and a probing question."
            : "Explain clearly and simply, use examples, and encourage the student. Keep answers short (under 150 words).",
          "Keep content age-appropriate.",
        ].filter(Boolean).join(" ");

        const contents = history
          .filter((m) => m?.text)
          .map((m) => ({ role: m.who === "user" ? "user" : "model", parts: [{ text: String(m.text).slice(0, 4000) }] }));
        // Gemini requires the conversation to start with a user turn
        while (contents.length && contents[0]?.role !== "user") contents.shift();
        contents.push({ role: "user", parts: [{ text: message }] });

        const res = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json", "x-goog-api-key": key },
            body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents }),
          },
        );
        if (!res.ok) {
          const err = await res.text();
          console.error("Gemini error", res.status, err);
          const msg = res.status === 429 ? "Too many requests, please wait a moment." : "The AI coach is unavailable right now.";
          return Response.json({ error: msg }, { status: res.status });
        }
        const data: any = await res.json();
        const reply = (data?.candidates?.[0]?.content?.parts ?? [])
          .map((p: any) => p.text ?? "")
          .join("")
          .trim();
        if (!reply) return Response.json({ error: "No answer was returned. Try rephrasing." }, { status: 502 });
        return Response.json({ reply });
      },
    },
  },
});
