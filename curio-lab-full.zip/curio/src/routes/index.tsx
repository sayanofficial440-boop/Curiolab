import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Curio Lab" },
      { name: "description", content: "Curio Lab — interactive lessons across science, maths, history and more." },
      { property: "og:title", content: "Curio Lab" },
      { property: "og:description", content: "Interactive lessons across science, maths, history and more." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  beforeLoad: () => {
    throw redirect({ href: "/index.html", reloadDocument: true });
  },
  component: () => null,
});
