import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  useEffect(() => {
    window.location.replace("/pages/login.html");
  }, []);
  return null;
}
