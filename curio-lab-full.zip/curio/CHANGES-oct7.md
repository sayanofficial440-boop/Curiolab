# Added: community and social
- Community page (pages/community.html): join with a handle, leaderboards (global, this week, per subject, friends), friends with requests, block/report, My profile (display name, bio, avatar colour, visibility, badges, XP by subject, device key, leave and erase).
- Public profile page: pages/u.html?h=<handle> and /u/<handle> (link previews). 17 badges, levels, XP, streaks.
- Backend: backend/community.py (+ tests/check_community.py). XP/badges are computed on the server. Children cannot join; under-16s start friends-only.
- Links: side menu, search palette, account menu, Profile page. Privacy page has a Community section. Service worker cache curio-v7.
- Not done: admin screen for reports (API only); UI is English only; weekly "league" promotion/relegation.

## Update: server-graded scores
- Leaderboard XP now comes only from quiz attempts the server graded (opened when the quiz starts, answers checked against the lesson file, minimum time per question, daily/lesson caps). Browser-reported scores are ignored.
- Exam Center papers no longer count toward community XP/badges (they are graded in the browser). Quizzes taken before joining don't count.
- quiz.js: records attempts for joined learners only; shows "+N community XP" and new community badges.
- Fixed: Community page crashed for returning members (a variable used before it was defined).

## Update: moderation screen
- Admin > Community (pages/admin/community.html): list of reports with Hide / Unhide / Delete / Mark handled, plus an "act on a handle" box. Sidebar link added on all admin pages.

## Update: Community in Hindi and Bengali
- All Community and profile text (labels, buttons, tabs, notices, privacy explanations, badge names and descriptions, toasts) is hand-written in Hindi and Bengali in js/lang/hi.js and js/lang/bn.js. NEEDS native-speaker review.
- js/i18n.js: the phrase matcher now accepts digits and sentence punctuation inside a phrase (it still only translates exact dictionary matches).
- Other languages use the existing automatic page translation. Not translated: placeholders, aria-labels, browser confirm/prompt dialogs and error messages that come from the server.
- Community text was reworded so changing parts (handle, numbers) sit in their own elements and the fixed text can be translated.
- Fixed stale wording that still mentioned exams counting toward XP.
- Fixed: placeholder/aria-label translation crash (invalid dataset key).

## Update: finishing touches
- Theme-aware buttons on Community (readable in all dark themes), placeholders and screen-reader labels translated, FAQ (3 community questions) and changelog entry added.

## Update: lesson discussions, study groups, quiz duels
- New `backend/discuss.py` (+ `tests/check_discuss.py`, 80+ checks): per-lesson Questions & Answers with upvotes and accepted answers, Comments with replies, study groups by invite code with a weekly goal, and asynchronous 1v1 quiz duels between friends. See backend/README.md for the rules and limits.
- `community.py`: two small hooks (`ERASE_HOOKS`, `ME_EXTRAS`) so erasing a profile also erases posts, groups and duels, and `/me` reports `duels_waiting`. `app.py` initialises and registers the module.
- Lesson pages: a "Discuss" tab is added by `js/discuss.js`, loaded from `js/lesson-ready.js` (no edits to the 92 lesson pages; new generated lessons get it automatically). Static lesson pages only, not the dynamic lesson page.
- Community page: new Groups and Duels tabs (`js/community-social.js`, CSS appended to `css/community.css`), a dot on Duels when a challenge or your turn is waiting.
- Admin > Community: "Reported posts & groups" section.
- Privacy page, changelog (Phase 26) and Hindi/Bengali strings for the new fixed labels updated. sw.js cache bumped to curio-v8.
- Decision: duels and groups give no XP, so friends can't farm the leaderboard.
- Needs a human: Hindi/Bengali wording review; `SUPPORT_LINE` helpline text; the word screen is English-only.
- Follow-up: edit your own post for 15 minutes, Rematch button on duels, duel question snapshots deleted when a duel ends.
