# Hosting Curio Lab

1. Install dependencies and build the site:

   ```powershell
   npm install
   npm run build
   ```

2. Upload the contents of `dist` to your web host. Configure the host to send unknown application routes (such as `/login`) to `index.html`; the static sign-in pages remain available at `/pages/login.html` and `/pages/signup.html`.

## Browser-only accounts

This version has no Supabase, backend database, or Google OAuth. Creating an account saves it only in the current browser. It then redirects to `dashboard.html`, and the user can sign in there again from that same browser.

If you need users to sign in from more than one device, recover passwords, or use Google login later, the site will need a secure authentication backend.

## Before going public (placeholders, privacy, fonts)

1. Edit `site.config.json`: real `siteUrl`, `contactEmail`, and the person or organisation responsible for the data (`controllerName`, `controllerAddress`).
2. Self-host the Google Fonts (needs internet once): `node scripts/self-host-fonts.mjs`. It downloads the fonts into `public/fonts/`, points every page at `css/fonts.css`, and rebuilds the generated pages. `node scripts/self-host-fonts.mjs --check` fails if any page still contacts Google's font servers.
3. Rebuild pages and sitemap: `node scripts/build-site-pages.mjs --strict` (fails while a placeholder is left).
4. Add real, permitted quotes to `public/data/testimonials.json` (only entries with `"verified": true` are shown).
5. Have the Privacy, Cookie and Terms text reviewed by someone qualified.

## SEO, children's accounts and certificates
- After editing lessons or `site.config.json`: `npm run seo` (also runs on `npm run build`, minus the images). Commit `public/og/`.
- The sitemap and every canonical/share URL come from `siteUrl` in `site.config.json`; set it before going public.
- Child sign-up and certificate verification need the Flask backend (`backend/README.md`), with SMTP settings for parent emails. On static-only hosting, children can still learn, but parents cannot be emailed, so certificates and reminders stay off.
- Forward `/verify/*` and `/api/*` to the backend if the static files are served by something else.

## Error pages, analytics, checks
- **404 / 500 pages:** `public/404.html` and `public/500.html` exist. The Flask backend serves them itself. On a static host or reverse proxy, point the server's error pages at them (nginx: `error_page 404 /404.html; error_page 500 502 503 504 /500.html;`).
- **Analytics (optional, off by default):** set `analytics.plausibleDomain` in `site.config.json`, then `npm run config`. This adds an opt-in "analytics" switch to the cookie banner; Plausible loads only after consent and never for children, admin pages or Do-Not-Track / Global Privacy Control visitors. Then update the Privacy and Cookie pages to name Plausible.
- **Before each release:** `npm run check` (content, SEO, sitemap, runtime config, page chrome) and `npm run test:backend`. The same run in CI (`.github/workflows/checks.yml`).
