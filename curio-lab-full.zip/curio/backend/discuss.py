"""Community, part 2: lesson discussions, study groups and friend quiz duels. Builds on community.py (same profiles, device keys, friends, blocks).

  Lesson discussion (Q&A + comments)         every call needs a community device key (Authorization: Bearer <key>)
  GET  /api/community/discuss?lesson=<id>&section=qa|comments&sort=top|new&unanswered=1&offset=0
  POST /api/community/discuss/post           {lesson, kind: question|comment, body}  or  {parent, kind: answer|reply, body}
  POST /api/community/discuss/vote           {post}  toggles my upvote (never on my own post)
  POST /api/community/discuss/accept         {post}  the asker marks (or unmarks) one answer as the accepted answer
  POST /api/community/discuss/delete         {post}  author deletes their own post (and the replies under it)
  POST /api/community/discuss/report         {post, reason}   hides it from the reporter; 3 different reporters hide it for everyone until an admin looks

  Study groups (invite-code only: there is no directory and no search)
  GET  /api/community/groups                 my groups
  POST /api/community/groups/create          {name, subject?, goal?}
  POST /api/community/groups/join            {code}
  GET  /api/community/groups/<gid>           members, weekly goal progress, invite code
  POST /api/community/groups/<gid>/leave | remove {handle} | rotate | update {name, subject, goal} | report {reason}
  DELETE /api/community/groups/<gid>         owner only

  Friend quiz duels (1v1, asynchronous: both play the same 10 questions any time within 72 hours)
  GET  /api/community/duels                  incoming, active, finished, my record
  POST /api/community/duels/create           {handle, lesson}   friends only
  POST /api/community/duels/<id>/respond     {accept}
  POST /api/community/duels/<id>/start       returns the questions (never the answers)
  POST /api/community/duels/<id>/finish      {answers: [{k, o}]}  the SERVER grades and decides the winner
  POST /api/community/duels/<id>/cancel
  Admin: GET /api/admin/community/content-reports, POST .../posts/<id>/hide|unhide|delete, .../groups/<gid>/hide|unhide|delete, .../content-reports/<id>/handled

Safety rules built in (same spirit as community.py):
  * Only joined learners (13+) can read or write. Children's accounts never reach these endpoints.
  * No direct messages anywhere. Free text exists only in lesson posts and group names, and is screened for links, emails,
    phone numbers, HTML, slurs/strong profanity, abuse phrases and first-person self-harm (which gets a supportive message, not a post).
  * A Private profile can read and vote but not post (posting would make the learner findable).
  * Blocked people never see each other's posts, groups' member lists or duels. Reports hide a post from the reporter at once.
  * Duels and groups award NO XP: leaderboard XP still comes only from quiz attempts the server graded, so two friends can't farm points.
"""
import re, json, time, secrets, random, logging, os
from flask import request, jsonify
from dbutil import db, too_many
import community as C
import moderation as M

log = logging.getLogger("curiolab.discuss")

KIND_MAX = {"question": 300, "answer": 800, "comment": 500, "reply": 300}
KIND_MIN = {"question": 10, "answer": 2, "comment": 2, "reply": 2}
PAGE = 20
AUTO_HIDE_AT = 3                  # distinct reporters that hide a post for everyone until an admin decides
EDIT_WINDOW = 900                 # an author can fix their own post for 15 minutes
DUP_WINDOW = 600                  # the same text from the same person on the same lesson within 10 minutes is a duplicate

MAX_OWNED, MAX_JOINED, MAX_MEMBERS = 3, 6, 25
GOAL_MIN, GOAL_MAX, GOAL_DEFAULT = 100, 10000, 500
CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"      # no I, O, 0, 1

DUEL_Q = 10
DUEL_TTL = 72 * 3600
DUEL_CAP = 20 * 60                # a player has 20 minutes from "start" to finish; later counts as a timeout (score 0)
DUEL_MIN_SECS_PER_Q = 2.5
DUEL_OPEN_MAX = 5
DUEL_KEEP_DAYS = 90

SUPPORT_LINE = os.environ.get("SUPPORT_LINE", "").strip()   # e.g. "In India you can call Tele-MANAS on 14416 (free, 24 hours)." Check any number before you set it.


def _now():
    return int(time.time())


# ---------------------------------------------------------------- text screening for posts
# community.clean_text() is deliberately strict for handles and bios (it matches inside squashed words). That would block normal
# schoolwork here ("skill", "Essex", "Dickens", the Nazi regime, Romeo and Juliet's suicide, the reproductive system), so posts
# use a word-level screen: links, contact details and HTML are refused outright, slurs and strong profanity are matched per word,
# and everything else is left to reports, auto-hide and the admin screen.
_LEET = str.maketrans({"1": "i", "!": "i", "0": "o", "3": "e", "$": "s", "5": "s", "@": "a", "4": "a", "7": "t"})
_STRONG_SUB = ("fuck", "bitch", "cunt", "whore", "motherfuck")
_WORD_RE = re.compile(r"^(shit(s|ty|head|ting)?|fck|fuk|sluts?|porn\w*|nigg(er|a|az|ers|as)|faggots?|retards?|kys)$")
_ABUSE_RE = re.compile(r"\b(kill\s+your\s*self|go\s+die|nobody\s+likes\s+you|hope\s+you\s+die)\b", re.I)
_SELF_HARM_RE = re.compile(r"\b(kill(ing)?\s+my\s*self|end(ing)?\s+my\s+(own\s+)?life|(want|wanna|going)\s+to\s+die|wanna\s+die|hurt(ing)?\s+my\s*self|harm(ing)?\s+my\s*self|"
                           r"(don'?t|do\s+not)\s+want\s+to\s+(live|be\s+alive)|no\s+reason\s+to\s+live|better\s+off\s+(dead|without\s+me))\b", re.I)
_LINK_RE = re.compile(r"https?:|www\.|\b[a-z0-9-]+\.(com|net|org|io|in|co|me|ly|gg|xyz|app|link|ru|cn)\b|[\w.+-]+@[\w-]+\.\w+", re.I)
_PHONE_RE = re.compile(r"(?:\+?\d[\s().-]?){10,}")
SELF_HARM_MSG = ("It sounds like things might be really hard right now. A lesson forum isn't the right place for that, but you matter and "
                 "there are people who want to help. Please talk to a parent, a teacher or another adult you trust. " + SUPPORT_LINE).strip()


def _tokens(s):
    toks = [t.translate(_LEET) for t in re.findall(r"[a-z0-9$@!]+", (s or "").lower())]
    out, run = [], []
    for t in toks + [""]:                      # "f u c k" -> "fuck"
        if len(t) == 1:
            run.append(t)
            continue
        if len(run) >= 3:
            out.append("".join(run))
        out.extend(run if len(run) < 3 else [])
        run = []
        if t:
            out.append(t)
    return out


def _abusive(s):
    if _ABUSE_RE.search(s or ""):
        return True
    for t in _tokens(s):
        if any(w in t for w in _STRONG_SUB) or _WORD_RE.match(t):
            return True
    return False


def screen(text, maxlen, what, minlen=1, multiline=False):
    """-> (clean_text, error, support). `support` is True when the text looks like first-person self-harm."""
    s = (text or "").replace("\r", "")
    if multiline:
        s = "\n".join(re.sub(r"[ \t]+", " ", ln).strip() for ln in s.split("\n"))
        s = re.sub(r"\n{3,}", "\n\n", s).strip()
        if s.count("\n") > 8:
            return None, f"{what} can have at most 9 lines.", False
    else:
        s = re.sub(r"\s+", " ", s).strip()
    if len(s) < minlen:
        return None, f"{what} needs at least {minlen} characters.", False
    if len(s) > maxlen:
        return None, f"{what} can be at most {maxlen} characters.", False
    if "<" in s or ">" in s:
        return None, f"{what} can't contain HTML. Write maths with words or plain symbols.", False
    if _LINK_RE.search(s):
        return None, f"{what} can't contain links or email addresses.", False
    if _PHONE_RE.search(s):
        return None, f"{what} can't contain phone numbers or very long digit strings. Write big numbers with commas or in powers of ten.", False
    if _SELF_HARM_RE.search(s):
        return None, SELF_HARM_MSG, True
    if _abusive(s):
        return None, f"Please reword your {what.lower()}: keep it kind and school-appropriate.", False
    return s, None, False


# ---------------------------------------------------------------- storage
def init(c):
    c.executescript("""
    CREATE TABLE IF NOT EXISTS cm_posts(
      id INTEGER PRIMARY KEY, lesson_id TEXT, kind TEXT, parent_id INTEGER, author INTEGER, body TEXT, created_at INTEGER,
      hidden INTEGER DEFAULT 0, accepted INTEGER DEFAULT 0, votes INTEGER DEFAULT 0);
    CREATE INDEX IF NOT EXISTS cm_posts_lesson ON cm_posts(lesson_id, kind, hidden, created_at);
    CREATE INDEX IF NOT EXISTS cm_posts_parent ON cm_posts(parent_id);
    CREATE INDEX IF NOT EXISTS cm_posts_author ON cm_posts(author);
    CREATE TABLE IF NOT EXISTS cm_post_votes(post_id INTEGER, voter INTEGER, created_at INTEGER, PRIMARY KEY(post_id, voter));
    CREATE INDEX IF NOT EXISTS cm_votes_voter ON cm_post_votes(voter);
    CREATE TABLE IF NOT EXISTS cm_content_reports(
      id INTEGER PRIMARY KEY, reporter INTEGER, kind TEXT, ref INTEGER, reason TEXT, created_at INTEGER, handled INTEGER DEFAULT 0, UNIQUE(reporter, kind, ref));
    CREATE TABLE IF NOT EXISTS cm_groups(
      id INTEGER PRIMARY KEY, gid TEXT UNIQUE, code TEXT UNIQUE, name TEXT, owner INTEGER, subject TEXT DEFAULT '', goal INTEGER DEFAULT 500,
      hidden INTEGER DEFAULT 0, created_at INTEGER);
    CREATE TABLE IF NOT EXISTS cm_group_members(group_id INTEGER, profile_id INTEGER, role TEXT, joined_at INTEGER, PRIMARY KEY(group_id, profile_id));
    CREATE INDEX IF NOT EXISTS cm_gm_profile ON cm_group_members(profile_id);
    CREATE TABLE IF NOT EXISTS cm_duels(
      id INTEGER PRIMARY KEY, code TEXT UNIQUE, lesson_id TEXT, ch INTEGER, op INTEGER, qs TEXT, n INTEGER, status TEXT,
      created_at INTEGER, expires_at INTEGER,
      ch_start INTEGER, ch_done INTEGER, ch_score INTEGER, ch_secs INTEGER,
      op_start INTEGER, op_done INTEGER, op_score INTEGER, op_secs INTEGER,
      winner INTEGER, forfeit INTEGER DEFAULT 0, settled_at INTEGER);
    CREATE INDEX IF NOT EXISTS cm_duels_ch ON cm_duels(ch, status);
    CREATE INDEX IF NOT EXISTS cm_duels_op ON cm_duels(op, status);
    """)
    if "edited_at" not in [r[1] for r in c.execute("PRAGMA table_info(cm_posts)").fetchall()]:
        c.execute("ALTER TABLE cm_posts ADD COLUMN edited_at INTEGER")
    C.ERASE_HOOKS.append(erase)
    C.ME_EXTRAS.append(me_extras)


def erase(c, pid):
    """Everything this module holds about one profile (called when they leave or an admin deletes them)."""
    c.execute("UPDATE cm_posts SET votes = votes - 1 WHERE id IN (SELECT post_id FROM cm_post_votes WHERE voter=?)", (pid,))
    c.execute("DELETE FROM cm_post_votes WHERE voter=?", (pid,))
    mine = [r[0] for r in c.execute("SELECT id FROM cm_posts WHERE author=?", (pid,)).fetchall()]
    for i in range(0, len(mine), 400):
        ids = mine[i:i + 400]
        q = ",".join("?" * len(ids))
        kids = [r[0] for r in c.execute(f"SELECT id FROM cm_posts WHERE parent_id IN ({q})", ids).fetchall()]
        for grp in (kids, ids):
            for j in range(0, len(grp), 400):
                g = grp[j:j + 400]
                qq = ",".join("?" * len(g))
                c.execute(f"DELETE FROM cm_post_votes WHERE post_id IN ({qq})", g)
                c.execute(f"DELETE FROM cm_content_reports WHERE kind='post' AND ref IN ({qq})", g)
                c.execute(f"DELETE FROM cm_posts WHERE id IN ({qq})", g)
    c.execute("DELETE FROM cm_content_reports WHERE reporter=?", (pid,))
    for g in c.execute("SELECT id FROM cm_groups WHERE owner=?", (pid,)).fetchall():
        _hand_over_or_delete(c, g["id"], pid)
    c.execute("DELETE FROM cm_group_members WHERE profile_id=?", (pid,))
    c.execute("DELETE FROM cm_duels WHERE ch=? OR op=?", (pid, pid))


def me_extras(c, pid):
    return dict(duels_waiting=_waiting(c, pid))


# ---------------------------------------------------------------- shared helpers
def _blocked_ids(c, me_id):
    return [r[0] for r in c.execute("SELECT blocked FROM cm_blocks WHERE blocker=? UNION SELECT blocker FROM cm_blocks WHERE blocked=?", (me_id, me_id)).fetchall()]


def _friend_ids(c, me_id):
    return {r[0] for r in c.execute("SELECT CASE WHEN a=? THEN b ELSE a END FROM cm_friends WHERE status='accepted' AND (a=? OR b=?)", (me_id, me_id, me_id)).fetchall()}


def _in(ids):
    return ",".join("?" * len(ids)) or "-1"      # "NOT IN (NULL)" would match nothing


def _person(r, friends=None, me_id=None, prefix=""):
    """The public bits of a profile row. `link` says whether the viewer may open that person's profile page."""
    g = (lambda k: r[prefix + k])
    vis = g("visibility")
    pid = g("id") if (prefix + "id") in r.keys() else None
    link = vis == "public" or (pid is not None and (pid == me_id or (vis == "friends" and friends is not None and pid in friends)))
    return dict(handle=g("handle"), name=g("display_name") or g("handle"), avatar=g("avatar"), link=bool(link))


def _hand_over_or_delete(c, group_id, leaving):
    nxt = c.execute("SELECT profile_id FROM cm_group_members WHERE group_id=? AND profile_id!=? ORDER BY joined_at, profile_id LIMIT 1", (group_id, leaving)).fetchone()
    if nxt:
        c.execute("UPDATE cm_groups SET owner=? WHERE id=?", (nxt[0], group_id))
        c.execute("UPDATE cm_group_members SET role='owner' WHERE group_id=? AND profile_id=?", (group_id, nxt[0]))
    else:
        c.execute("DELETE FROM cm_group_members WHERE group_id=?", (group_id,))
        c.execute("DELETE FROM cm_content_reports WHERE kind='group' AND ref=?", (group_id,))
        c.execute("DELETE FROM cm_groups WHERE id=?", (group_id,))


def _fmt_code(code):
    return code[:4] + "-" + code[4:]


def _norm_code(s):
    return re.sub(r"[^A-Z0-9]", "", (s or "").upper())


# ---------------------------------------------------------------- duel logic (pure, so it can be tested without HTTP)
def decide(ch_score, ch_secs, op_score, op_secs):
    """'ch' | 'op' | 'draw'. Higher score wins; equal scores go to the faster player unless they are within 2 seconds of each other."""
    if ch_score != op_score:
        return "ch" if ch_score > op_score else "op"
    if abs(ch_secs - op_secs) <= 2:
        return "draw"
    return "ch" if ch_secs < op_secs else "op"


def _finish_duel(c, d, forfeit=False):
    if d["ch_done"] and d["op_done"]:
        w = decide(d["ch_score"], d["ch_secs"], d["op_score"], d["op_secs"])
        win = d["ch"] if w == "ch" else (d["op"] if w == "op" else 0)
    elif d["ch_done"]:
        win = d["ch"]
    elif d["op_done"]:
        win = d["op"]
    else:
        win = None
    c.execute("UPDATE cm_duels SET status='finished', winner=?, forfeit=?, settled_at=? WHERE id=?", (win, 1 if forfeit else 0, _now(), d["id"]))


def _settle(c, d):
    """Apply what time and relationships have changed since the row was written. Safe to call on every read."""
    if d["status"] not in ("pending", "active"):
        if d["qs"] != "[]":
            c.execute("UPDATE cm_duels SET qs='[]' WHERE id=?", (d["id"],))     # the questions are only needed while a duel is open
        return d
    f = C._friendship(c, d["ch"], d["op"])
    if not f or f["status"] != "accepted" or C._blocked(c, d["ch"], d["op"]):
        c.execute("UPDATE cm_duels SET status='cancelled', settled_at=? WHERE id=?", (_now(), d["id"]))
    elif d["ch_done"] and d["op_done"]:
        _finish_duel(c, d)
    elif _now() > d["expires_at"]:
        if d["status"] == "active" and (d["ch_done"] or d["op_done"]):
            _finish_duel(c, d, forfeit=True)         # they accepted, played, and the other side never did
        else:
            c.execute("UPDATE cm_duels SET status='expired', settled_at=? WHERE id=?", (_now(), d["id"]))
    d = c.execute("SELECT * FROM cm_duels WHERE id=?", (d["id"],)).fetchone()
    if d["status"] not in ("pending", "active") and d["qs"] != "[]":
        c.execute("UPDATE cm_duels SET qs='[]' WHERE id=?", (d["id"],))
    return d


def _waiting(c, pid):
    n = 0
    for d in c.execute("SELECT * FROM cm_duels WHERE (ch=? OR op=?) AND status IN ('pending','active')", (pid, pid)).fetchall():
        d = _settle(c, d)
        if d["status"] == "pending" and d["op"] == pid:
            n += 1
        elif d["status"] in ("pending", "active"):
            mine_done = d["ch_done"] if d["ch"] == pid else d["op_done"]
            if not mine_done and (d["ch"] == pid or d["status"] == "active"):
                n += 1
    return n


# ---------------------------------------------------------------- routes
def register(app, admin_only, log_fn):
    def err(msg, code=400, **extra):
        return jsonify(error=msg, **extra), code

    def need_me():
        p = C._me()
        if not p:
            return None, err("Not signed in to the community. Join first, or restore your device key.", 401)
        if p["hidden"]:
            return None, err("This profile has been hidden by a moderator.", 403)
        return p, None

    def body():
        return request.get_json(silent=True) or {}

    # ================================================================ lesson discussion
    def _post_out(r, me_id, voted, helpful, friends):
        return dict(id=r["id"], kind=r["kind"], body=r["body"], created_at=r["created_at"], votes=r["votes"], voted=r["id"] in voted, mine=r["author"] == me_id,
                    accepted=bool(r["accepted"]), edited=bool(r["edited_at"]), can_edit=r["author"] == me_id and _now() - r["created_at"] <= EDIT_WINDOW,
                    author=dict(_person(r, friends, me_id, "a_"), helpful=helpful.get(r["author"], 0)))

    _SEL = ("SELECT p.*, a.id AS a_id, a.handle AS a_handle, a.display_name AS a_display_name, a.avatar AS a_avatar, a.visibility AS a_visibility "
            "FROM cm_posts p JOIN cm_profiles a ON a.id=p.author ")

    def _visible_clause(me_id, blocked):
        return (f" p.hidden=0 AND a.hidden=0 AND p.author NOT IN ({_in(blocked)}) "
                f"AND p.id NOT IN (SELECT ref FROM cm_content_reports WHERE reporter=? AND kind='post') "), list(blocked) + [me_id]

    @app.get("/api/community/discuss")
    def ds_list():
        me, e = need_me()
        if e:
            return e
        if too_many("cm-dlist", str(me["id"]), 400, 3600):
            return err("Slow down a little.", 429)
        les = C._lesson(str(request.args.get("lesson") or ""))
        if not les:
            return err("Unknown lesson.", 404)
        section = "comments" if request.args.get("section") == "comments" else "qa"
        sort = "new" if request.args.get("sort") == "new" else "top"
        unanswered = request.args.get("unanswered") == "1" and section == "qa"
        offset = C._i(request.args.get("offset"), 0, 100000)
        with db() as c:
            blocked = _blocked_ids(c, me["id"])
            vis, vp = _visible_clause(me["id"], blocked)
            kind = "question" if section == "qa" else "comment"
            child = "answer" if section == "qa" else "reply"
            where = f"WHERE p.lesson_id=? AND p.kind=? AND {vis}"
            params = [les["id"], kind] + vp
            if unanswered:
                where += " AND NOT EXISTS (SELECT 1 FROM cm_posts x WHERE x.parent_id=p.id AND x.kind='answer' AND x.hidden=0)"
            order = "p.votes DESC, p.created_at DESC, p.id DESC" if sort == "top" else "p.created_at DESC, p.id DESC"
            rows = c.execute(f"{_SEL}{where} ORDER BY {order} LIMIT ? OFFSET ?", params + [PAGE + 1, offset]).fetchall()
            more = len(rows) > PAGE
            rows = rows[:PAGE]
            ids = [r["id"] for r in rows]
            kids = []
            if ids:
                korder = "p.accepted DESC, p.votes DESC, p.created_at ASC" if section == "qa" else "p.created_at ASC"
                kids = c.execute(f"{_SEL}WHERE p.parent_id IN ({_in(ids)}) AND p.kind=? AND {vis} ORDER BY {korder}", ids + [child] + vp).fetchall()
            allrows = list(rows) + list(kids)
            pids = [r["id"] for r in allrows]
            voted = {r[0] for r in c.execute(f"SELECT post_id FROM cm_post_votes WHERE voter=? AND post_id IN ({_in(pids)})", [me["id"]] + pids).fetchall()} if pids else set()
            authors = list({r["author"] for r in allrows})
            helpful = {r[0]: r[1] for r in c.execute(f"SELECT author, COUNT(*) FROM cm_posts WHERE kind='answer' AND accepted=1 AND hidden=0 AND author IN ({_in(authors)}) GROUP BY author", authors).fetchall()} if authors else {}
            friends = _friend_ids(c, me["id"])
            by_parent = {}
            for k in kids:
                by_parent.setdefault(k["parent_id"], []).append(_post_out(k, me["id"], voted, helpful, friends))
            items = []
            for r in rows:
                o = _post_out(r, me["id"], voted, helpful, friends)
                o["children"] = by_parent.get(r["id"], [])[:40]
                o["has_accepted"] = any(k["accepted"] for k in o["children"])
                items.append(o)
            counts = {}
            for key, kd in (("questions", "question"), ("comments", "comment")):
                counts[key] = c.execute(f"SELECT COUNT(*) FROM cm_posts p JOIN cm_profiles a ON a.id=p.author WHERE p.lesson_id=? AND p.kind=? AND {vis}", [les["id"], kd] + vp).fetchone()[0]
            can_post, why = True, ""
            if me["visibility"] == "private":
                can_post, why = False, "Your profile is Private, so you can read and vote but not post. Change it to Friends only or Public in My profile to join in."
        return jsonify(lesson=dict(id=les["id"], title=les["title"]), section=section, sort=sort, items=items, more=more, next_offset=offset + PAGE, counts=counts,
                       can_post=can_post, why=why, limits=KIND_MAX)

    @app.post("/api/community/discuss/post")
    def ds_post():
        me, e = need_me()
        if e:
            return e
        d = body()
        kind = d.get("kind")
        if kind not in KIND_MAX:
            return err("Unknown post type.")
        if me["visibility"] == "private":
            return err("Your profile is Private, so you can read and vote but not post. Change it to Friends only or Public in My profile to join in.", 403)
        if too_many("cm-post", str(me["id"]), 20, 3600) or too_many("cm-post-day", str(me["id"]), 60, 86400):
            return err("You've posted a lot. Please wait a little before posting again.", 429)
        what = {"question": "Your question", "answer": "Your answer", "comment": "Your comment", "reply": "Your reply"}[kind]
        text, bad, support = screen(d.get("body"), KIND_MAX[kind], what, KIND_MIN[kind], multiline=True)
        if bad:
            return err(bad, 422 if support else 400, support=support)
        with db() as c:
            muted = M.muted_response(c, me)
            if muted:
                return muted
            parent = None
            if kind in ("answer", "reply"):
                want = "question" if kind == "answer" else "comment"
                parent = c.execute("SELECT p.*, a.hidden AS a_hidden FROM cm_posts p JOIN cm_profiles a ON a.id=p.author WHERE p.id=?", (C._i(d.get("parent"), 0, 2 ** 40),)).fetchone()
                if not parent or parent["kind"] != want or parent["hidden"] or parent["a_hidden"] or C._blocked(c, me["id"], parent["author"]):
                    return err("That post isn't available any more.", 404)
                lesson_id = parent["lesson_id"]
            else:
                les = C._lesson(str(d.get("lesson") or ""))
                if not les:
                    return err("Unknown lesson.", 404)
                lesson_id = les["id"]
            if c.execute("SELECT 1 FROM cm_posts WHERE author=? AND lesson_id=? AND body=? AND created_at>?", (me["id"], lesson_id, text, _now() - DUP_WINDOW)).fetchone():
                return err("You already posted that.")
            cur = c.execute("INSERT INTO cm_posts(lesson_id,kind,parent_id,author,body,created_at) VALUES(?,?,?,?,?,?)",
                            (lesson_id, kind, parent["id"] if parent else None, me["id"], text, _now()))
            r = c.execute(_SEL + "WHERE p.id=?", (cur.lastrowid,)).fetchone()
            out = _post_out(r, me["id"], set(), {}, set())
            out["children"] = []
        return jsonify(ok=True, post=out)

    def _open_post(c, me, pid, kinds=None):
        r = c.execute("SELECT p.*, a.hidden AS a_hidden FROM cm_posts p JOIN cm_profiles a ON a.id=p.author WHERE p.id=?", (C._i(pid, 0, 2 ** 40),)).fetchone()
        if not r or r["hidden"] or r["a_hidden"] or (kinds and r["kind"] not in kinds) or C._blocked(c, me["id"], r["author"]):
            return None
        if r["parent_id"]:
            par = c.execute("SELECT hidden FROM cm_posts WHERE id=?", (r["parent_id"],)).fetchone()
            if not par or par["hidden"]:
                return None
        return r

    @app.post("/api/community/discuss/vote")
    def ds_vote():
        me, e = need_me()
        if e:
            return e
        if too_many("cm-vote", str(me["id"]), 240, 3600):
            return err("Slow down a little.", 429)
        with db() as c:
            r = _open_post(c, me, body().get("post"))
            if not r:
                return err("That post isn't available any more.", 404)
            if r["author"] == me["id"]:
                return err("You can't upvote your own post.")
            had = c.execute("SELECT 1 FROM cm_post_votes WHERE post_id=? AND voter=?", (r["id"], me["id"])).fetchone()
            if had:
                c.execute("DELETE FROM cm_post_votes WHERE post_id=? AND voter=?", (r["id"], me["id"]))
                c.execute("UPDATE cm_posts SET votes=MAX(0, votes-1) WHERE id=?", (r["id"],))
            else:
                c.execute("INSERT INTO cm_post_votes(post_id,voter,created_at) VALUES(?,?,?)", (r["id"], me["id"], _now()))
                c.execute("UPDATE cm_posts SET votes=votes+1 WHERE id=?", (r["id"],))
            n = c.execute("SELECT votes FROM cm_posts WHERE id=?", (r["id"],)).fetchone()[0]
        return jsonify(ok=True, votes=n, voted=not had)

    @app.post("/api/community/discuss/accept")
    def ds_accept():
        me, e = need_me()
        if e:
            return e
        with db() as c:
            r = _open_post(c, me, body().get("post"), ("answer",))
            q = c.execute("SELECT * FROM cm_posts WHERE id=?", (r["parent_id"],)).fetchone() if r else None
            if not r or not q:
                return err("That answer isn't available any more.", 404)
            if q["author"] != me["id"]:
                return err("Only the person who asked can accept an answer.", 403)
            now_on = not r["accepted"]
            c.execute("UPDATE cm_posts SET accepted=0 WHERE parent_id=? AND kind='answer'", (q["id"],))
            if now_on:
                c.execute("UPDATE cm_posts SET accepted=1 WHERE id=?", (r["id"],))
        return jsonify(ok=True, accepted=now_on)

    def _delete_post(c, r):
        ids = [r["id"]] + [x[0] for x in c.execute("SELECT id FROM cm_posts WHERE parent_id=?", (r["id"],)).fetchall()]
        q = _in(ids)
        c.execute(f"DELETE FROM cm_post_votes WHERE post_id IN ({q})", ids)
        c.execute(f"DELETE FROM cm_content_reports WHERE kind='post' AND ref IN ({q})", ids)
        c.execute(f"DELETE FROM cm_posts WHERE id IN ({q})", ids)

    @app.post("/api/community/discuss/delete")
    def ds_delete():
        me, e = need_me()
        if e:
            return e
        with db() as c:
            r = c.execute("SELECT * FROM cm_posts WHERE id=? AND author=?", (C._i(body().get("post"), 0, 2 ** 40), me["id"])).fetchone()
            if not r:
                return err("That post isn't yours or is already gone.", 404)
            _delete_post(c, r)
        return jsonify(ok=True)

    @app.post("/api/community/discuss/edit")
    def ds_edit():
        me, e = need_me()
        if e:
            return e
        d = body()
        with db() as c:
            muted = M.muted_response(c, me)
            if muted:
                return muted
            r = c.execute("SELECT * FROM cm_posts WHERE id=? AND author=? AND hidden=0", (C._i(d.get("post"), 0, 2 ** 40), me["id"])).fetchone()
            if not r:
                return err("That post isn't yours or is already gone.", 404)
            if _now() - r["created_at"] > EDIT_WINDOW:
                return err("Posts can only be edited for 15 minutes. You can delete it and post again.", 409)
            what = {"question": "Your question", "answer": "Your answer", "comment": "Your comment", "reply": "Your reply"}[r["kind"]]
            text, bad, support = screen(d.get("body"), KIND_MAX[r["kind"]], what, KIND_MIN[r["kind"]], multiline=True)
            if bad:
                return err(bad, 422 if support else 400, support=support)
            c.execute("UPDATE cm_posts SET body=?, edited_at=? WHERE id=?", (text, _now(), r["id"]))
        return jsonify(ok=True, body=text)

    @app.post("/api/community/discuss/report")
    def ds_report():
        me, e = need_me()
        if e:
            return e
        if too_many("cm-preport", str(me["id"]), 15, 86400):
            return err("Too many reports today.", 429)
        d = body()
        cat, reason = M.report_fields(d)
        with db() as c:
            r = _open_post(c, me, d.get("post"))
            if not r or r["author"] == me["id"]:
                return err("That post isn't available.", 404)
            if not cat:
                return err("Please choose what is wrong.")
            c.execute("INSERT OR IGNORE INTO cm_content_reports(reporter,kind,ref,reason,category,created_at) VALUES(?,?,?,?,?,?)", (me["id"], "post", r["id"], reason, cat, _now()))
            n = c.execute("SELECT COUNT(DISTINCT reporter) FROM cm_content_reports WHERE kind='post' AND ref=?", (r["id"],)).fetchone()[0]
            if n >= AUTO_HIDE_AT:
                c.execute("UPDATE cm_posts SET hidden=1 WHERE id=?", (r["id"],))
                M.on_auto_hide(c, r["author"], "post", r["id"])
        return jsonify(ok=True)

    # ================================================================ study groups
    def _my_group(c, me, gid, owner=False):
        g = c.execute("SELECT * FROM cm_groups WHERE gid=?", (str(gid or ""),)).fetchone()
        if not g or g["hidden"]:
            return None, err("No such group.", 404)
        m = c.execute("SELECT * FROM cm_group_members WHERE group_id=? AND profile_id=?", (g["id"], me["id"])).fetchone()
        if not m:
            return None, err("No such group.", 404)
        if owner and m["role"] != "owner":
            return None, err("Only the group's owner can do that.", 403)
        return g, None

    def _group_members(c, g, me):
        wk = C.week_key()
        blocked = set(_blocked_ids(c, me["id"]))
        rows = c.execute("""SELECT m.role, m.joined_at, p.id, p.handle, p.display_name, p.avatar, p.hidden, s.xp, s.week_xp, s.week_key, s.streak_cur
                            FROM cm_group_members m JOIN cm_profiles p ON p.id=m.profile_id LEFT JOIN cm_stats s ON s.profile_id=p.id WHERE m.group_id=? ORDER BY m.joined_at""", (g["id"],)).fetchall()
        subj = {}
        if g["subject"]:
            for r in c.execute("SELECT profile_id, xp, week_xp, week_key FROM cm_subject_xp WHERE subject=? AND profile_id IN (SELECT profile_id FROM cm_group_members WHERE group_id=?)", (g["subject"], g["id"])).fetchall():
                subj[r["profile_id"]] = (r["xp"], r["week_xp"] if r["week_key"] == wk else 0)
        out, hidden_n = [], 0
        for r in rows:
            if r["hidden"] or (r["id"] in blocked and r["id"] != me["id"]):
                hidden_n += 1
                continue
            week = (r["week_xp"] if r["week_key"] == wk else 0) if r["week_xp"] is not None else 0
            total = r["xp"] or 0
            if g["subject"]:
                total, week = subj.get(r["id"], (0, 0))
            out.append(dict(handle=r["handle"], name=r["display_name"] or r["handle"], avatar=r["avatar"], role=r["role"], you=r["id"] == me["id"], week=week, total=total, streak=r["streak_cur"] or 0))
        out.sort(key=lambda x: (-x["week"], -x["total"], x["handle"]))
        return out, hidden_n

    def _group_out(c, g, me, detail=False):
        members, _ = _group_members(c, g, me)
        role = c.execute("SELECT role FROM cm_group_members WHERE group_id=? AND profile_id=?", (g["id"], me["id"])).fetchone()["role"]
        o = dict(id=g["gid"], name=g["name"], subject=g["subject"], goal=g["goal"], role=role, members=len(members), week_total=sum(m["week"] for m in members), created_at=g["created_at"])
        if detail:
            o.update(member_list=members, invite=_fmt_code(g["code"]), week_key=C.week_key(), limit=MAX_MEMBERS)
        return o

    @app.get("/api/community/groups")
    def gr_list():
        me, e = need_me()
        if e:
            return e
        with db() as c:
            gs = c.execute("SELECT g.* FROM cm_groups g JOIN cm_group_members m ON m.group_id=g.id WHERE m.profile_id=? AND g.hidden=0 ORDER BY m.joined_at", (me["id"],)).fetchall()
            return jsonify(groups=[_group_out(c, g, me) for g in gs], limits=dict(owned=MAX_OWNED, joined=MAX_JOINED, members=MAX_MEMBERS))

    @app.post("/api/community/groups/create")
    def gr_create():
        me, e = need_me()
        if e:
            return e
        if too_many("cm-gcreate", str(me["id"]), 5, 86400):
            return err("You've created several groups today. Try again tomorrow.", 429)
        d = body()
        name, bad, _ = screen(d.get("name"), 40, "Group name", 3)
        if bad:
            return err(bad)
        subject = d.get("subject") if d.get("subject") in C.SUBJECTS else ""
        goal = max(GOAL_MIN, min(GOAL_MAX, C._i(d.get("goal"), 0, 10 ** 6) or GOAL_DEFAULT))
        with db() as c:
            muted = M.muted_response(c, me)
            if muted:
                return muted
            if c.execute("SELECT COUNT(*) FROM cm_groups WHERE owner=?", (me["id"],)).fetchone()[0] >= MAX_OWNED:
                return err(f"You can own up to {MAX_OWNED} groups.")
            if c.execute("SELECT COUNT(*) FROM cm_group_members WHERE profile_id=?", (me["id"],)).fetchone()[0] >= MAX_JOINED:
                return err(f"You can be in up to {MAX_JOINED} groups.")
            gid = secrets.token_urlsafe(8)
            for _ in range(8):
                code = "".join(secrets.choice(CODE_ALPHABET) for _ in range(8))
                if not c.execute("SELECT 1 FROM cm_groups WHERE code=?", (code,)).fetchone():
                    break
            cur = c.execute("INSERT INTO cm_groups(gid,code,name,owner,subject,goal,created_at) VALUES(?,?,?,?,?,?,?)", (gid, code, name, me["id"], subject, goal, _now()))
            c.execute("INSERT INTO cm_group_members(group_id,profile_id,role,joined_at) VALUES(?,?,?,?)", (cur.lastrowid, me["id"], "owner", _now()))
            g = c.execute("SELECT * FROM cm_groups WHERE id=?", (cur.lastrowid,)).fetchone()
            return jsonify(ok=True, group=_group_out(c, g, me, True))

    @app.post("/api/community/groups/join")
    def gr_join():
        me, e = need_me()
        if e:
            return e
        if too_many("cm-gjoin", str(me["id"]), 20, 3600):
            return err("Too many tries. Please wait a while.", 429)
        code = _norm_code(body().get("code"))
        with db() as c:
            g = c.execute("SELECT * FROM cm_groups WHERE code=? AND hidden=0", (code,)).fetchone() if len(code) == 8 else None
            if not g:
                return err("That invite code doesn't work. Check it with the person who invited you.", 404)
            if c.execute("SELECT 1 FROM cm_group_members WHERE group_id=? AND profile_id=?", (g["id"], me["id"])).fetchone():
                return jsonify(ok=True, group=_group_out(c, g, me, True))
            member_ids = [r[0] for r in c.execute("SELECT profile_id FROM cm_group_members WHERE group_id=?", (g["id"],)).fetchall()]
            if any(C._blocked(c, me["id"], x) for x in member_ids):
                return err("That invite code doesn't work. Check it with the person who invited you.", 404)
            if len(member_ids) >= MAX_MEMBERS:
                return err(f"That group is full ({MAX_MEMBERS} members).")
            if c.execute("SELECT COUNT(*) FROM cm_group_members WHERE profile_id=?", (me["id"],)).fetchone()[0] >= MAX_JOINED:
                return err(f"You can be in up to {MAX_JOINED} groups. Leave one first.")
            c.execute("INSERT INTO cm_group_members(group_id,profile_id,role,joined_at) VALUES(?,?,?,?)", (g["id"], me["id"], "member", _now()))
            return jsonify(ok=True, group=_group_out(c, g, me, True))

    @app.get("/api/community/groups/<gid>")
    def gr_get(gid):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            g, e = _my_group(c, me, gid)
            if e:
                return e
            return jsonify(group=_group_out(c, g, me, True))

    @app.post("/api/community/groups/<gid>/leave")
    def gr_leave(gid):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            g, e = _my_group(c, me, gid)
            if e:
                return e
            if g["owner"] == me["id"]:
                _hand_over_or_delete(c, g["id"], me["id"])
            c.execute("DELETE FROM cm_group_members WHERE group_id=? AND profile_id=?", (g["id"], me["id"]))
        return jsonify(ok=True)

    @app.post("/api/community/groups/<gid>/remove")
    def gr_remove(gid):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            g, e = _my_group(c, me, gid, owner=True)
            if e:
                return e
            t = c.execute("SELECT id FROM cm_profiles WHERE handle=?", (str(body().get("handle") or "").strip().lower().lstrip("@"),)).fetchone()
            if not t or t["id"] == me["id"]:
                return err("Choose another member to remove.", 404)
            c.execute("DELETE FROM cm_group_members WHERE group_id=? AND profile_id=?", (g["id"], t["id"]))
        return jsonify(ok=True)

    @app.post("/api/community/groups/<gid>/rotate")
    def gr_rotate(gid):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            g, e = _my_group(c, me, gid, owner=True)
            if e:
                return e
            code = "".join(secrets.choice(CODE_ALPHABET) for _ in range(8))
            c.execute("UPDATE cm_groups SET code=? WHERE id=?", (code, g["id"]))
            g = c.execute("SELECT * FROM cm_groups WHERE id=?", (g["id"],)).fetchone()
            return jsonify(ok=True, group=_group_out(c, g, me, True))

    @app.post("/api/community/groups/<gid>/update")
    def gr_update(gid):
        me, e = need_me()
        if e:
            return e
        d = body()
        with db() as c:
            g, e = _my_group(c, me, gid, owner=True)
            if e:
                return e
            name, subject, goal = g["name"], g["subject"], g["goal"]
            if "name" in d:
                muted = M.muted_response(c, me)
                if muted:
                    return muted
                name, bad, _ = screen(d.get("name"), 40, "Group name", 3)
                if bad:
                    return err(bad)
            if "subject" in d:
                subject = d["subject"] if d["subject"] in C.SUBJECTS else ""
            if "goal" in d:
                goal = max(GOAL_MIN, min(GOAL_MAX, C._i(d.get("goal"), 0, 10 ** 6) or GOAL_DEFAULT))
            c.execute("UPDATE cm_groups SET name=?, subject=?, goal=? WHERE id=?", (name, subject, goal, g["id"]))
            g = c.execute("SELECT * FROM cm_groups WHERE id=?", (g["id"],)).fetchone()
            return jsonify(ok=True, group=_group_out(c, g, me, True))

    @app.delete("/api/community/groups/<gid>")
    def gr_delete(gid):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            g, e = _my_group(c, me, gid, owner=True)
            if e:
                return e
            c.execute("DELETE FROM cm_group_members WHERE group_id=?", (g["id"],))
            c.execute("DELETE FROM cm_content_reports WHERE kind='group' AND ref=?", (g["id"],))
            c.execute("DELETE FROM cm_groups WHERE id=?", (g["id"],))
        return jsonify(ok=True)

    @app.post("/api/community/groups/<gid>/report")
    def gr_report(gid):
        me, e = need_me()
        if e:
            return e
        if too_many("cm-greport", str(me["id"]), 10, 86400):
            return err("Too many reports today.", 429)
        cat, reason = M.report_fields(body())
        with db() as c:
            g, e = _my_group(c, me, gid)
            if e:
                return e
            if not cat:
                return err("Please choose what is wrong.")
            c.execute("INSERT OR IGNORE INTO cm_content_reports(reporter,kind,ref,reason,category,created_at) VALUES(?,?,?,?,?,?)", (me["id"], "group", g["id"], reason, cat, _now()))
        return jsonify(ok=True)

    # ================================================================ duels
    def _duel_for(c, me, code):
        d = c.execute("SELECT * FROM cm_duels WHERE code=? AND (ch=? OR op=?)", (str(code or ""), me["id"], me["id"])).fetchone()
        if not d:
            return None, err("No such duel.", 404)
        return _settle(c, d), None

    def _duel_out(c, d, me):
        mine = "ch" if d["ch"] == me["id"] else "op"
        theirs = "op" if mine == "ch" else "ch"
        other = c.execute("SELECT * FROM cm_profiles WHERE id=?", (d[theirs],)).fetchone()
        les = C._lesson(d["lesson_id"]) or dict(id=d["lesson_id"], title=d["lesson_id"], subject="")
        done = bool(d[mine + "_done"])
        finished = d["status"] == "finished"
        out = dict(id=d["code"], lesson=dict(id=les["id"], title=les["title"], subject=les["subject"]), n=d["n"], status=d["status"], created_at=d["created_at"], expires_at=d["expires_at"],
                   i_challenged=mine == "ch", opponent=dict(handle=other["handle"], name=other["display_name"] or other["handle"], avatar=other["avatar"]) if other else None,
                   my_done=done, opp_done=bool(d[theirs + "_done"]) if finished else None, started=bool(d[mine + "_start"]))
        if done:
            out["my_score"] = d[mine + "_score"]
        if finished:
            w = d["winner"]
            out["result"] = "draw" if w == 0 else ("win" if w == me["id"] else ("loss" if w else "none"))
            out["forfeit"] = bool(d["forfeit"])
            out["opp_score"] = d[theirs + "_score"] if d[theirs + "_done"] else None
            out["my_secs"], out["opp_secs"] = d[mine + "_secs"], (d[theirs + "_secs"] if d[theirs + "_done"] else None)
        if d["status"] == "pending" and mine == "op":
            out["can_respond"] = True
        out["can_play"] = (d["status"] == "active" or (d["status"] == "pending" and mine == "ch")) and not done
        out["can_cancel"] = d["status"] in ("pending", "active") and ((mine == "ch" and not d["op_start"]) or (mine == "op" and not d["op_start"] and d["status"] == "pending"))
        return out

    @app.get("/api/community/duels")
    def du_list():
        me, e = need_me()
        if e:
            return e
        with db() as c:
            rows = c.execute("SELECT * FROM cm_duels WHERE ch=? OR op=? ORDER BY created_at DESC, id DESC LIMIT 60", (me["id"], me["id"])).fetchall()
            active, finished = [], []
            w = l = dr = 0
            for r in rows:
                r = _settle(c, r)
                if r["status"] in ("cancelled", "declined", "expired") and _now() - (r["settled_at"] or 0) > 7 * 86400:
                    continue
                o = _duel_out(c, r, me)
                if r["status"] in ("pending", "active"):
                    active.append(o)
                else:
                    finished.append(o)
            for r in c.execute("SELECT winner FROM cm_duels WHERE (ch=? OR op=?) AND status='finished' AND winner IS NOT NULL", (me["id"], me["id"])).fetchall():
                if r["winner"] == 0: dr += 1
                elif r["winner"] == me["id"]: w += 1
                else: l += 1
            return jsonify(active=active, finished=finished[:20], record=dict(wins=w, losses=l, draws=dr), lessons=DUEL_Q)

    @app.post("/api/community/duels/create")
    def du_create():
        me, e = need_me()
        if e:
            return e
        if too_many("cm-dcreate", str(me["id"]), 10, 86400):
            return err("You've sent a lot of challenges today. Try again tomorrow.", 429)
        d = body()
        with db() as c:
            t = c.execute("SELECT * FROM cm_profiles WHERE handle=?", (str(d.get("handle") or "").strip().lower().lstrip("@"),)).fetchone()
            f = C._friendship(c, me["id"], t["id"]) if t and t["id"] != me["id"] else None
            if not t or t["hidden"] or not f or f["status"] != "accepted" or C._blocked(c, me["id"], t["id"]):
                return err("You can only challenge accepted friends.", 404)
            les = C._lesson(str(d.get("lesson") or ""))
            pool = C._quiz_pool(les) if les else []
            good = [q for q in pool if isinstance(q, dict) and isinstance(q.get("q"), str) and isinstance(q.get("options"), list) and len(q["options"]) >= 2
                    and isinstance(q.get("correct"), int) and 0 <= q["correct"] < len(q["options"])]
            if not les or len(good) < DUEL_Q:
                return err("Pick a lesson that has a quiz of at least 10 questions.", 404)
            lo, hi = sorted((me["id"], t["id"]))
            open_pair = c.execute("SELECT * FROM cm_duels WHERE status IN ('pending','active') AND ((ch=? AND op=?) OR (ch=? AND op=?))", (me["id"], t["id"], t["id"], me["id"])).fetchall()
            if any(_settle(c, x)["status"] in ("pending", "active") for x in open_pair):
                return err("You already have an open duel with this friend. Finish it first.")
            mine_open = [x for x in c.execute("SELECT * FROM cm_duels WHERE (ch=? OR op=?) AND status IN ('pending','active')", (me["id"], me["id"])).fetchall() if _settle(c, x)["status"] in ("pending", "active")]
            if len(mine_open) >= DUEL_OPEN_MAX:
                return err(f"You can have {DUEL_OPEN_MAX} open duels at once. Finish or cancel one first.")
            opp_open = [x for x in c.execute("SELECT * FROM cm_duels WHERE (ch=? OR op=?) AND status IN ('pending','active')", (t["id"], t["id"])).fetchall() if _settle(c, x)["status"] in ("pending", "active")]
            if len(opp_open) >= DUEL_OPEN_MAX:
                return err("That friend has a lot of open duels already. Try again later.")
            picks = random.SystemRandom().sample(range(len(good)), DUEL_Q)
            snap = [dict(q=good[i]["q"], o=[str(x) for x in good[i]["options"]], c=good[i]["correct"]) for i in picks]
            code = secrets.token_urlsafe(7)
            now = _now()
            c.execute("INSERT INTO cm_duels(code,lesson_id,ch,op,qs,n,status,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?)",
                      (code, les["id"], me["id"], t["id"], json.dumps(snap), DUEL_Q, "pending", now, now + DUEL_TTL))
            c.execute("DELETE FROM cm_duels WHERE status IN ('finished','expired','declined','cancelled') AND created_at<?", (now - DUEL_KEEP_DAYS * 86400,))
            row = c.execute("SELECT * FROM cm_duels WHERE code=?", (code,)).fetchone()
            return jsonify(ok=True, duel=_duel_out(c, row, me))

    @app.post("/api/community/duels/<code>/respond")
    def du_respond(code):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            d, e = _duel_for(c, me, code)
            if e:
                return e
            if d["op"] != me["id"] or d["status"] != "pending":
                return err("There's nothing to respond to.", 409)
            c.execute("UPDATE cm_duels SET status=?, settled_at=? WHERE id=?", ("active" if body().get("accept") else "declined", None if body().get("accept") else _now(), d["id"]))
            return jsonify(ok=True, duel=_duel_out(c, c.execute("SELECT * FROM cm_duels WHERE id=?", (d["id"],)).fetchone(), me))

    def _side(d, me):
        return "ch" if d["ch"] == me["id"] else "op"

    @app.post("/api/community/duels/<code>/start")
    def du_start(code):
        me, e = need_me()
        if e:
            return e
        if too_many("cm-dact", str(me["id"]), 200, 3600):
            return err("Slow down a little.", 429)
        with db() as c:
            d, e = _duel_for(c, me, code)
            if e:
                return e
            s = _side(d, me)
            if d["status"] == "pending" and s == "op":
                c.execute("UPDATE cm_duels SET status='active' WHERE id=?", (d["id"],))        # starting is accepting
            elif d["status"] not in ("pending", "active"):
                return err("This duel is over.", 409)
            if d[s + "_done"]:
                return err("You've already played this duel.", 409)
            began = d[s + "_start"] or _now()
            if not d[s + "_start"]:
                c.execute(f"UPDATE cm_duels SET {s}_start=? WHERE id=?", (began, d["id"]))
            qs = json.loads(d["qs"])
            left = max(5, DUEL_CAP - (_now() - began))
            return jsonify(ok=True, id=d["code"], n=d["n"], seconds_left=left,
                           questions=[dict(k=i, q=q["q"], options=q["o"]) for i, q in enumerate(qs)])

    @app.post("/api/community/duels/<code>/finish")
    def du_finish(code):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            d, e = _duel_for(c, me, code)
            if e:
                return e
            s = _side(d, me)
            if d["status"] not in ("pending", "active") or d[s + "_done"] or not d[s + "_start"]:
                return err("That duel isn't open for you.", 409)
            qs = json.loads(d["qs"])
            ans = body().get("answers")
            if not isinstance(ans, list) or len(ans) != len(qs):
                return err("Those answers don't match this duel.")
            seen, score = set(), 0
            for x in ans:
                if not isinstance(x, dict) or not isinstance(x.get("k"), int) or isinstance(x.get("k"), bool) or x["k"] in seen or not 0 <= x["k"] < len(qs) \
                        or not isinstance(x.get("o"), int) or isinstance(x.get("o"), bool) or not -1 <= x["o"] < len(qs[x["k"]]["o"]):
                    return err("Those answers don't match this duel.")
                seen.add(x["k"])
                score += 1 if x["o"] == qs[x["k"]]["c"] else 0
            secs = _now() - d[s + "_start"]
            if secs < DUEL_MIN_SECS_PER_Q * len(qs):
                return err("That was too quick to count. Take your time with each question.", 429)
            timed_out = secs > DUEL_CAP
            if timed_out:
                score, secs = 0, DUEL_CAP
            c.execute(f"UPDATE cm_duels SET {s}_done=?, {s}_score=?, {s}_secs=? WHERE id=?", (_now(), score, secs, d["id"]))
            d = _settle(c, c.execute("SELECT * FROM cm_duels WHERE id=?", (d["id"],)).fetchone())
            out = _duel_out(c, d, me)
            # Right/wrong per question for the player's own review. The correct answers themselves are only shown once the duel is over.
            review = [dict(k=x["k"], ok=x["o"] == qs[x["k"]]["c"], correct=(qs[x["k"]]["c"] if d["status"] == "finished" else None)) for x in sorted(ans, key=lambda y: y["k"])]
            return jsonify(ok=True, timed_out=timed_out, score=score, total=len(qs), secs=secs, review=review, duel=out)

    @app.post("/api/community/duels/<code>/cancel")
    def du_cancel(code):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            d, e = _duel_for(c, me, code)
            if e:
                return e
            o = _duel_out(c, d, me)
            if not o["can_cancel"]:
                return err("This duel can't be cancelled any more.", 409)
            if d["op"] == me["id"]:
                c.execute("UPDATE cm_duels SET status='declined', settled_at=? WHERE id=?", (_now(), d["id"]))
            else:
                c.execute("UPDATE cm_duels SET status='cancelled', settled_at=? WHERE id=?", (_now(), d["id"]))
        return jsonify(ok=True)

    # ================================================================ moderation (admin)
    # The unified queue (every kind of report, grouped by target) is in moderation.py; these are the per-report rows and the actions on posts and groups.
    @app.get("/api/admin/community/content-reports")
    @admin_only
    def ds_admin_reports():
        out = []
        c = db()
        for r in c.execute("SELECT r.*, f.handle AS reporter_handle FROM cm_content_reports r LEFT JOIN cm_profiles f ON f.id=r.reporter ORDER BY r.handled, r.id DESC LIMIT 300").fetchall():
            o = dict(id=r["id"], kind=r["kind"], ref=r["ref"], reason=r["reason"], category=r["category"] or "other", created_at=r["created_at"], handled=r["handled"], reporter=r["reporter_handle"])
            if r["kind"] == "post":
                p = c.execute("SELECT p.*, a.handle AS author_handle FROM cm_posts p LEFT JOIN cm_profiles a ON a.id=p.author WHERE p.id=?", (r["ref"],)).fetchone()
                o["target"] = dict(id=p["id"], body=p["body"], post_kind=p["kind"], lesson=p["lesson_id"], author=p["author_handle"], hidden=p["hidden"]) if p else None
            elif r["kind"] == "room":
                x = c.execute("SELECT r.*, o.handle AS owner_handle, (SELECT COUNT(*) FROM cm_room_members m WHERE m.room_id=r.id) AS n FROM cm_rooms r LEFT JOIN cm_profiles o ON o.id=r.owner WHERE r.id=?", (r["ref"],)).fetchone()
                o["target"] = dict(rid=x["rid"], name=x["name"], owner=x["owner_handle"], members=x["n"], hidden=x["hidden"]) if x else None
            else:
                g = c.execute("SELECT g.*, p.handle AS owner_handle, (SELECT COUNT(*) FROM cm_group_members m WHERE m.group_id=g.id) AS n FROM cm_groups g LEFT JOIN cm_profiles p ON p.id=g.owner WHERE g.id=?", (r["ref"],)).fetchone()
                o["target"] = dict(gid=g["gid"], name=g["name"], owner=g["owner_handle"], members=g["n"], hidden=g["hidden"]) if g else None
            out.append(o)
        return jsonify(reports=out)

    @app.post("/api/admin/community/content-reports/<int:rid>/handled")
    @admin_only
    def ds_admin_handled(rid):
        with db() as c:
            c.execute("UPDATE cm_content_reports SET handled=1 WHERE id=?", (rid,))
        return jsonify(ok=True)

    @app.post("/api/admin/community/posts/<int:pid>/<action>")
    @admin_only
    def ds_admin_post(pid, action):
        if action not in ("hide", "unhide", "delete"):
            return err("Unknown action.", 404)
        with db() as c:
            r = c.execute("SELECT * FROM cm_posts WHERE id=?", (pid,)).fetchone()
            if not r:
                return err("No such post.", 404)
            M.on_content_action(c, r["author"], "post", action, pid)
            if action == "delete":
                _delete_post(c, r)
            else:
                c.execute("UPDATE cm_posts SET hidden=? WHERE id=?", (1 if action == "hide" else 0, pid))
        log_fn("community_post_" + action, "-", "-", f"post={pid}")
        return jsonify(ok=True)

    @app.post("/api/admin/community/groups/<gid>/<action>")
    @admin_only
    def ds_admin_group(gid, action):
        if action not in ("hide", "unhide", "delete"):
            return err("Unknown action.", 404)
        with db() as c:
            g = c.execute("SELECT * FROM cm_groups WHERE gid=?", (gid,)).fetchone()
            if not g:
                return err("No such group.", 404)
            M.on_content_action(c, g["owner"], "group", action, gid)
            if action == "delete":
                c.execute("DELETE FROM cm_group_members WHERE group_id=?", (g["id"],))
                c.execute("DELETE FROM cm_content_reports WHERE kind='group' AND ref=?", (g["id"],))
                c.execute("DELETE FROM cm_groups WHERE id=?", (g["id"],))
            else:
                c.execute("UPDATE cm_groups SET hidden=? WHERE id=?", (1 if action == "hide" else 0, g["id"]))
        log_fn("community_group_" + action, "-", "-", f"group={gid}")
        return jsonify(ok=True)
