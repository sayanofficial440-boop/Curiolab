# Admin backend
    pip install -r requirements.txt
    ADMIN_EMAIL=admin@curiolab.app ADMIN_NAME="Curio Admin" ADMIN_PASSWORD="<your password>" SECRET_KEY="<long random string>" COOKIE_SECURE=1 python app.py
    # production: gunicorn -b 0.0.0.0:8000 app:app (behind HTTPS)
The admin is created on first start (password stored hashed). Open /pages/admin/login.html.
To change the password: delete curiolab.db and restart with a new ADMIN_PASSWORD.


## Review reminders (web push)
Installed with `pip install -r requirements.txt` (adds `pywebpush`). VAPID keys are generated on first start and stored in the DB (set `VAPID_SUBJECT=mailto:you@example.com`).
The server stores only a browser's push endpoint, its next-review time and due count -- never question text. Push needs HTTPS and one gunicorn worker (`gunicorn -w 1 ...`), or set `PUSH_WORKER=0` and call `push_tick()` from a cron job.
Static hosting without this backend still works: the app falls back to reminders while the site is open.


## Contact messages and privacy requests
Admin > **Messages & Privacy** (`/pages/admin/messages.html`) lists contact-form messages (mark handled / delete) and handles privacy requests:
`GET /api/admin/privacy/lookup?email=` exports everything held for an address (account, subscriptions, messages, audit entries);
`POST /api/admin/privacy/erase {"email": ...}` deletes the account, subscriptions and messages, and anonymises audit entries. Admin addresses are refused.
Each action is written to the audit log with a hashed reference, never the raw address. Verify the requester by replying to their email first; answer within one month.


## Children's accounts (COPPA-style) and parent consent
Endpoints: `POST /api/coppa/request`, `GET /api/coppa/status/<child_ref>`, and the parent's private-link endpoints under `/api/coppa/consent/<token>` (view, `/decision`, `/export`, `/delete`). The parent page is `/pages/parent.html`.
- **Email is required for consent.** Set `SMTP_HOST` (+ `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`). Without it nothing can be sent: the API answers `delivery: "unconfigured"`, the child stays in the restricted mode, and the sign-up screen says so. For local testing only, `COPPA_DEV_SHOW_LINK=1` returns the parent link in the API response. Never set it in production.
- Also set `SITE_URL` (links in emails), `CONTROLLER_NAME` and `CONTACT_EMAIL` (shown to parents).
- Unanswered requests are deleted after `COPPA_PENDING_DAYS` (default 7); declining erases the parent's address at once. Admin > Messages & Privacy lookup/erase also covers child records by parent email.
- Stored: nickname, parent email, status, timestamps. Not stored: birth date, age, IP address, real name, free text.
- The server can only trust what the browser says about age. The age screen is neutral and locks the answer per browser, but a child can still type a false year. That limit is stated on the Privacy page.

## Certificates and verification URLs
`POST /api/certificates/issue`, `GET /api/certificates/tiers`, `GET /api/certificates/verify/<code>` (JSON), `GET /verify/<code>` (shareable page with Open Graph tags, `noindex`), `GET /verify/<code>/image.png`. Admin: `GET /api/admin/certificates`, `POST /api/admin/certificates/<code>/revoke`.
Codes look like `CL-ABCD-EFGH-JKMN` (60 random bits). A certificate stores only a display name, tier and date (a child's is always the parent-approved nickname). **What "verified" means:** this server issued it and hasn't revoked it. Quiz and streak results live in the browser, so eligibility is self-reported; add server-side quiz recording if certificates must withstand a determined cheater.
Fonts for the images are in `backend/fonts` (Inter, SIL OFL). Tests: `python backend/tests/check_certificates_coppa.py`.


## Backups
A verified, compressed backup of the database is taken every `BACKUP_EVERY_HOURS` (default 24) into `BACKUP_DIR` (default `backend/backups/`); the newest `BACKUP_KEEP` (default 14) are kept. It uses SQLite's online backup API and an integrity check, so it is safe while the site runs.
- Several workers? Set `BACKUP_EVERY_HOURS=0` and run `python backup.py` from cron instead.
- A backup on the same disk does not survive losing the disk: set `BACKUP_COPY_DIR` to other storage or copy `BACKUP_DIR` off the machine.
- Check a backup: `python backup.py --verify backups/curiolab-<stamp>.db.gz`. Restore (stop the app first): `python backup.py --restore backups/curiolab-<stamp>.db.gz`.
- Backups contain personal data (parent emails, messages). They are written owner-only; keep them private. An erased person's data leaves backups as old copies are replaced (the privacy page says so).

## Admin login lockout and rate limits
5 wrong passwords for one account, or 20 from one address, in 15 minutes locks sign-in for the rest of the window (stored in the database, so a restart does not reset it; each lock is written to the audit log). Public endpoints (certificates, child accounts, contact, error reports) are rate-limited per address in memory, per process. For a public launch also rate-limit at the web server or CDN.

## Error monitoring and error pages
- Browser errors are reported to `POST /api/client-error` by `public/js/monitor.js` (message, short stack, page path only; no cookies, IP or user agent), grouped with a counter, capped at `CLIENT_ERROR_MAX_ROWS` (2000) and `CLIENT_ERROR_KEEP_DAYS` (30). Admins read them at `GET /api/admin/errors`. Turn off with `"errorReporting": false` in `site.config.json`.
- Server crashes return the branded `public/500.html` (JSON for `/api/*`), unknown pages return `public/404.html`; no internals are shown.
- Optional Sentry for the server: `pip install "sentry-sdk[flask]"` and set `SENTRY_DSN` (also `SENTRY_ENV`). Personal data is not sent (`send_default_pii=False`).
- Tests: `python backend/tests/check_hardening.py`.

## Certificate checks
The browser reports quiz scores, so a certificate can never be fully tamper-proof. The server now ignores any reported score that does not name a real lesson (matched against `public/data/learning-index.json`; override the folder with `PUBLIC_DIR`) or that claims a quiz longer than that lesson's real quiz. "Well-rounded" needs three real subjects. Someone who copies a real lesson name can still claim a perfect score, so treat certificates as "earned on Curio Lab", not proctored.
Rate limits are stored in the database (hashed keys, purged after a day), so they survive restarts and are shared by workers.


## AI coach (Gemini)
`coach.py` serves `GET /api/health` and `POST /api/coach` so the coach is live when the site runs on this Flask backend. Set `GEMINI_API_KEY` in the server environment (optional `GEMINI_MODEL`); locally it also reads `../.dev.vars` / `../.env.local`. The key never reaches the browser. Requests are limited to 60 per hour per visitor. Children's accounts stay in practice mode by design (see `public/js/age-gate.js`).


## Community (profiles, leaderboards, friends)
`community.py` serves `/api/community/*` and the shareable `/u/<handle>` page; the pages are `pages/community.html` and `pages/u.html` (scripts `js/community-core.js`, `community.js`, `profile-public.js`).
- **Opt-in, 13+ only.** Children's accounts and the under-13 age band are refused by the server and hidden in the UI. 13-15 year olds start "friends only". Visibility: public / friends / private; private profiles can't be found or friended; people are found only by exact handle (no directory).
- **Identity is a device key** (random, stored hashed; shown once in My profile, used to restore on another device). No email, name or IP is stored. Leaving erases everything (`DELETE /api/community/me`).
- **Server-graded scores.** The browser never reports a score. When a joined learner starts a lesson quiz, `quiz.js` opens an attempt (`/api/community/attempt/start`); on finishing it sends the answers it picked and the server grades them against the lesson file's `data-quiz-data`. An attempt must be open, used once, and take at least 2.5 s per question; made-up lessons are refused; at most 3 attempts per lesson and 40 per day earn XP (quiz = 5-20 XP). Stats are rebuilt from `cm_attempts`; `/sync` ignores whatever the browser claims. Weekly boards reset Monday 00:00 UTC.
  Only quizzes taken **after joining** count, and Exam Center papers don't (they are graded in the browser), so the six exam badges were removed. Honest limit: lesson files (with answers) are public, so a script could still submit correct answers slowly. The checks make that effortful and cap the gain; for real proctoring, quiz questions would need to be served from the server without answers.
- **Moderation.** Handles/names/bios are screened (links, emails, phone numbers, a small word list). Users can block and report; admin endpoints: `GET /api/admin/community/reports`, `POST /api/admin/community/<handle>/hide|unhide`, `DELETE /api/admin/community/<handle>`. Admin screen: `pages/admin/community.html` (Admin sidebar > Community): review reports, hide/unhide, delete, or act on a handle.
- Rate limits: joins, syncs, friend requests (20/day), reports. Tests: `python backend/tests/check_community.py`.
- Without this backend (static hosting) the Community page says it is unavailable; the rest of the site is unaffected.

## Community, part 2: lesson discussions, study groups, quiz duels
`discuss.py` (same `/api/community/*` prefix, same device key). Tables `cm_posts`, `cm_post_votes`, `cm_content_reports`, `cm_groups`, `cm_group_members`, `cm_duels`. Front end: `js/discuss.js` + `css/discuss.css` (the **Discuss** tab on lesson pages, loaded by `lesson-ready.js` so generated lessons get it too) and `js/community-social.js` (the **Groups** and **Duels** tabs on the Community page).
- **Discussions.** Per lesson: Questions (with answers, upvotes, the asker can accept one answer) and Comments (with replies). Only joined learners 13+ can read or write; a Private profile can read/vote but not post. No self-votes. 20 posts/hour, 60/day. Posts are screened by `discuss.screen()` (links, emails, phone numbers/very long digit strings, HTML, slurs and strong profanity per word, abuse phrases). It is deliberately *not* the substring blocklist used for handles, which would block "skill", "Dickens", the Nazi regime or Romeo and Juliet's suicide. Screening is English-only: Hindi/Bengali abuse is caught by reports. First-person self-harm wording is refused with a supportive message (set `SUPPORT_LINE` to add a helpline, e.g. `SUPPORT_LINE="In India you can call Tele-MANAS on 14416 (free, 24 hours)."`, and check the number first). Reporting hides a post from the reporter at once; 3 different reporters hide it for everyone until an admin decides.
- **Study groups.** Invite-code only (8 characters, no directory or search), up to 25 members, 3 owned and 6 joined per person. Members see each other's name, avatar and points. Weekly shared goal (owner sets 100-10000; optional subject focus uses that subject's weekly XP). Owner can remove members, rotate the code, edit or delete; leaving as owner hands the group to the longest-standing member. Blocked people are hidden from each other's member lists and can't join each other's groups.
- **Duels.** Friends only. The server picks 10 questions from the lesson's quiz and **stores a snapshot** (so later lesson edits can't break a duel). Each player starts, answers and finishes on their own within 72 hours; the server grades. Scores stay hidden until both have played. Higher score wins; equal scores go to the faster player unless within 2 seconds (draw). A player who accepted and played while the other never did wins by forfeit; an unanswered challenge just expires. 20 minutes per player from start (later counts as 0), at least 2.5 s per question, 5 open duels each, 10 challenges/day, one open duel per pair. Blocking or unfriending cancels open duels. Finished duels are deleted after 90 days.
- Authors can edit a post for 15 minutes (re-screened, shown as "edited"); a duel's question snapshot is dropped the moment it ends; finished duels have a one-tap Rematch.
- **No XP from any of this**, so two accounts can't farm points; leaderboard XP still comes only from server-graded quiz attempts.
- Erasing a profile (or an admin delete) removes their posts (and replies beneath), votes, reports, memberships, owned groups (handed on or deleted) and duels via `community.ERASE_HOOKS`.
- Admin: `GET /api/admin/community/content-reports`, `POST .../posts/<id>/hide|unhide|delete`, `POST .../groups/<gid>/hide|unhide|delete`, `POST .../content-reports/<id>/handled`; the UI is the new "Reported posts & groups" section of `pages/admin/community.html`.
- Tests: `python backend/tests/check_discuss.py`.


## Community, part 3: study rooms and moderation tools
`rooms.py` (live "study with me" rooms, shared Pomodoro timer) and `moderation.py` (report categories, warnings, mutes, notices, one admin queue). Same `/api/community/*` prefix and device key. Front end: `js/community-rooms.js` (the **Rooms** tab and the moderator-notices banner), `js/report-dialog.js` (one report form for profiles, posts, groups and rooms). Tests: `python backend/tests/check_rooms_moderation.py`.
- **Shared timer.** The server owns the clock. A room stores phase (focus / break / long break), start time and length; every response includes the server's time, so browsers draw `ends_at - server_now` and agree to the second whatever their device clock says. Phases roll over by themselves (long break after every N focus blocks) and are computed from the stored times on each request, so there is no background job and a late poll never drifts the timer. Host controls: start, pause, resume, skip (a skipped focus block isn't counted), reset. Lengths: focus 10-90, break 3-20, long 10-45, 2-8 blocks per round; lengths can only change while the timer is stopped.
- **Rooms are private and temporary.** Invite code (or a room linked to one of your study groups: one per group, members see it live). No directory. Up to 20 people, one room at a time per person. A room nobody polled for 15 minutes is deleted; people unseen for 10 minutes are dropped; if the host leaves the room passes to the longest-standing person there.
- **No chat, no free text.** The only text is the room name (screened like a group name). "What I'm working on" is picked from a fixed list; reactions are five preset emoji (1 per 3 s). Blocked people can't enter the same room or see each other. Host tools: lock, remove (can't return), new code, close. Rooms give no XP; "focus blocks" is a friendly counter for people present at the end of a block.
- **Polling, not websockets.** Clients poll `/rooms/<id>/state` every 5 s (20 s in a hidden tab). That is fine for hundreds of concurrent learners on one machine with SQLite; for thousands, replace polling with SSE/websockets and move to a real database. Heartbeats are rate-limited in memory (40/min), not in the database.
- **Reports.** `category` (spam, bullying, inappropriate, personal, selfharm, wrong, other) plus an optional note, on profiles, posts, groups and rooms; older clients that send only `reason` still work. 3 different reporters hide a post or close a room until a moderator decides. The author/host is told.
- **Moderator tools** (Admin > Community): one queue grouped by target (urgent categories first, reporter count, owner's history); Close with "action taken" / "no action" tells each reporter a human looked (never who or what); hide / restore / delete tell the owner; warn and mute (1 hour to 30 days: no posting, asking, answering, creating groups or rooms, reacting; reading and joining still work); per-person history; live room list.
- **Limits, stated plainly.** Identity is a device key and nothing else is stored, so a muted person can leave and rejoin as a new profile (leaving erases the history). Hide the profile if that matters. Screening is English-only; other languages rely on reports. Hindi/Bengali strings for the new labels are hand-written and need native-speaker review.
