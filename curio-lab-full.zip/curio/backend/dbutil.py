"""Small helpers shared by app.py, certificates.py and coppa.py (kept separate to avoid circular imports)."""
import os, sqlite3, time, hashlib, secrets

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.environ.get("DB_PATH", os.path.join(ROOT, "curiolab.db"))


def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


def sha256(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def new_token(nbytes=24):
    return secrets.token_urlsafe(nbytes)


_hits = {}
_last_purge = [0.0]


def too_many(bucket, key, limit, window):
    """True when `key` already made `limit` calls to `bucket` in the last `window` seconds. Counted in the database, so it
    survives restarts and is shared by every worker. Only a hash of the key is stored (never a raw IP or email); rows
    older than a day are purged. Falls back to an in-memory count if the database is busy, so a hiccup cannot lock people out."""
    now = time.time()
    h = hashlib.sha256(f"{bucket}|{key}".encode("utf-8")).hexdigest()[:24]
    try:
        c = sqlite3.connect(DB, timeout=3)
        try:
            with c:
                c.execute("CREATE TABLE IF NOT EXISTS rate_hits(h TEXT, bucket TEXT, ts REAL)")
                c.execute("CREATE INDEX IF NOT EXISTS rate_hits_h ON rate_hits(h, ts)")
                if now - _last_purge[0] > 600:
                    c.execute("DELETE FROM rate_hits WHERE ts<?", (now - 86400,)); _last_purge[0] = now
                n = c.execute("SELECT COUNT(*) FROM rate_hits WHERE h=? AND ts>?", (h, now - window)).fetchone()[0]
                if n >= limit:
                    return True
                c.execute("INSERT INTO rate_hits(h,bucket,ts) VALUES(?,?,?)", (h, bucket, now))
                return False
        finally:
            c.close()
    except sqlite3.Error:
        k = (bucket, key)
        _hits[k] = [t for t in _hits.get(k, []) if now - t < window]
        if len(_hits[k]) >= limit:
            return True
        _hits[k].append(now)
        return False


def reset_rate_limits():
    """Forget all rate-limit counters (used by tests; also handy after a false alarm)."""
    _hits.clear()
    try:
        c = sqlite3.connect(DB, timeout=3)
        with c:
            c.execute("CREATE TABLE IF NOT EXISTS rate_hits(h TEXT, bucket TEXT, ts REAL)")
            c.execute("DELETE FROM rate_hits")
        c.close()
    except sqlite3.Error:
        pass


def client_ip(request):
    return request.headers.get("X-Forwarded-For", request.remote_addr or "?").split(",")[0].strip()


def site_url(request):
    return (os.environ.get("SITE_URL") or request.url_root).rstrip("/")
