"""Community: opt-in public profiles with badges and stats, leaderboards (global, weekly, per-subject, friends) and friends.

  GET  /api/community/meta                      badges, subjects, rules, current week
  GET  /api/community/handle-check?h=           is a handle free and allowed?
  POST /api/community/join                      create a profile; returns a private device key (shown once)
  GET  /api/community/me                        my profile, stats and friend counts      (Authorization: Bearer <key>)
  POST /api/community/me                        update display name, bio, avatar colour, visibility
  DELETE /api/community/me                      erase my profile, stats, friendships and reports I filed
  POST /api/community/attempt/start|finish     the server grades each quiz attempt (answers are checked against the lesson file)
  POST /api/community/sync                      rebuild my numbers from the attempts the server graded
  GET  /api/community/leaderboard               board=global|subject|friends  period=all|week  subject=<name>
  GET  /api/community/profile/<handle>          a public (or friends-only) profile
  GET  /api/community/friends                   my friends, incoming and outgoing requests
  POST /api/community/friends/request|respond|remove
  POST /api/community/block | /unblock | /report
  GET  /u/<handle>                              shareable profile page (Open Graph tags for link previews)
  Admin: GET /api/admin/community/reports, POST /api/admin/community/<handle>/hide|unhide, DELETE /api/admin/community/<handle>

Privacy and safety rules built in:
  * Children's accounts (and anyone who says they are under 13) can NOT join. Nothing about a child is ever listed.
  * Joining is an explicit opt-in. A profile is a pseudonymous handle: no email, no IP, no real name is required or stored.
    13-15 year olds start as "friends only" (not on public boards, profile visible to accepted friends only).
  * Visibility: public (boards + profile page) | friends (friends only) | private (only me). Private profiles cannot be
    found or friended. Learners are found only by exact handle: there is no directory to browse and no free-text search.
  * Free text is limited to a handle, an optional display name and a short bio, all screened for links, emails, phone numbers
    and a basic word list. Anyone can block or report a profile; admins can hide or delete one.

How scores are protected: the browser never reports a score. When a joined learner starts a quiz the server opens an attempt; when
they finish, the browser sends the answers it picked and the SERVER grades them against the lesson file. An attempt must be open,
used once, and take at least 2.5 s per question; XP is capped per lesson and per day. Exam Center papers are graded in the browser,
so they do not count. Honest limit: the lesson file (with its answers) is public, so someone who writes a script can still submit
correct answers slowly. The checks make that effortful and cap the gain; they do not make it impossible. Boards mean "earned on
Curio Lab", not proctored. Identity is a device key (random, stored hashed): lose it and the profile is lost.
"""
import os, re, json, time, secrets, logging
from datetime import datetime, timezone, timedelta
from flask import request, jsonify, Response
from dbutil import db, sha256, too_many, client_ip, site_url, ROOT
import certificates

log = logging.getLogger("curiolab.community")

# Other modules (discuss.py) register here so erasing a profile also erases what they hold, and /me can carry their counters.
ERASE_HOOKS = []
ME_EXTRAS = []

SUBJECTS = ["Physics", "Chemistry", "Biology", "Mathematics", "English", "History", "Geography", "Computer Science"]
BADGES = [
    # id, name, icon, description  (the first group mirrors the trophies on the Achievements page)
    ("first-quiz", "First Steps", "🥉", "Complete your first quiz."),
    ("five-attempts", "Building Momentum", "🥈", "Complete 5 quiz attempts."),
    ("ten-attempts", "Dedicated Scholar", "🎖️", "Complete 10 quiz attempts."),
    ("perfect-score", "Perfect Score", "🏆", "Score 100% on a quiz."),
    ("three-subjects", "Well Rounded", "🌐", "Quiz in 3 different subjects."),
    ("six-subjects", "Wide Explorer", "🧭", "Quiz in 6 different subjects."),
    ("all-subjects", "Renaissance Learner", "⭐", "Quiz in all 8 subjects."),
    ("streak-7", "Week Warrior", "🔥", "Study on 7 days in a row."),
    ("streak-30", "Habit Builder", "🌋", "Study on 30 days in a row."),
    ("xp-1000", "Rising Star", "🌟", "Earn 1,000 XP."),
    ("xp-5000", "Luminary", "💫", "Earn 5,000 XP."),
]
BADGE_IDS = [b[0] for b in BADGES]

HANDLE_RE = re.compile(r"^[a-z0-9_]{3,20}$")
RESERVED = {"admin", "administrator", "curio", "curiolab", "curio_lab", "support", "staff", "moderator", "mod", "official", "help", "team",
            "null", "none", "root", "system", "anonymous", "me", "you", "api", "u", "about", "contact"}
# A deliberately small screen (substring match after removing separators). It is a first line, not a guarantee: reports + admin hide are the rest.
BLOCKWORDS = ("fuck", "shit", "bitch", "cunt", "nigg", "fagg", "whore", "slut", "rape", "nazi", "hitler", "porn", "sex", "dick", "cock", "pussy", "penis", "vagina", "kill", "suicide", "terror")
AVATARS = ["#12213B", "#D68C1F", "#2E8E80", "#C94A38", "#5F7A34", "#7C5CBF"]
VISIBILITY = ("public", "friends", "private")

DAILY_QUIZ_CAP = 40        # quiz attempts that earn XP per day
PER_LESSON_DAY_CAP = 3     # attempts at one lesson that earn XP per day
DAILY_EXAM_CAP = 3
MAX_FRIENDS = 200


def _now():
    return int(time.time())


def week_key(dt=None):
    """Monday (UTC) of the week, e.g. '2026-10-05'. Weekly boards reset Monday 00:00 UTC."""
    dt = dt or datetime.now(timezone.utc)
    return (dt - timedelta(days=dt.weekday())).strftime("%Y-%m-%d")


def level_for(xp):
    lvl = 1 + int((max(0, xp) / 50) ** 0.5)
    return dict(level=lvl, floor=50 * (lvl - 1) ** 2, next=50 * lvl ** 2)


# ---------------------------------------------------------------- text screening
def _squash(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower().replace("1", "i").replace("0", "o").replace("3", "e").replace("$", "s").replace("@", "a"))


def _bad_text(s):
    q = _squash(s)
    return any(w in q for w in BLOCKWORDS)


def clean_handle(h):
    h = (h or "").strip().lower().lstrip("@")
    if not HANDLE_RE.match(h):
        return None, "A handle is 3-20 characters: letters, numbers and underscores only."
    if h in RESERVED or h.startswith(("curio_", "admin_", "staff_")):
        return None, "That handle is reserved. Please choose another."
    if _bad_text(h):
        return None, "Please choose a different handle."
    if re.search(r"\d{6,}", h):
        return None, "Please don't use phone numbers in a handle."
    return h, None


def clean_text(s, maxlen, what):
    s = re.sub(r"\s+", " ", (s or "")).strip()
    if len(s) > maxlen:
        return None, f"{what} can be at most {maxlen} characters."
    if s and (re.search(r"https?:|www\.|\.(com|net|org|io|in|co|me|ly|gg)\b|@\S+\.\S+|\d{6,}", s, re.I) or "<" in s or ">" in s):
        return None, f"{what} can't contain links, emails, phone numbers or HTML."
    if s and _bad_text(s):
        return None, f"Please reword your {what.lower()}."
    return s, None


# ---------------------------------------------------------------- stats computed on the server
def _parse(s):
    try:
        d = datetime.fromisoformat(str(s).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return d.astimezone(timezone.utc)


def _i(v, lo=0, hi=10 ** 6):
    try:
        return max(lo, min(hi, int(v)))
    except (TypeError, ValueError):
        return 0


def compute(summary, now=None):
    """Turn the browser's quiz/exam summary into XP, streaks and badges. Nothing the browser says about XP is trusted.

    Input is the list of attempts the SERVER graded (cm_attempts), never a browser-supplied score.
    Quiz attempt  : 5 + round(15 * score/total) XP (5-20). At most 3 attempts per lesson per day and 40 per day count.
    Exam papers are graded in the browser, so they do not count here.
    Badges        : recomputed from the same attempts.   Level: 1 + floor(sqrt(xp / 50)).
    Weekly XP     : the part earned since Monday 00:00 UTC.
    """
    now = now or datetime.now(timezone.utc)
    wk = week_key(now)
    s = summary if isinstance(summary, dict) else {}
    scores = s.get("scores") if isinstance(s.get("scores"), list) else []
    horizon, future = now - timedelta(days=400), now + timedelta(days=1)

    quiz, exams, seen = [], [], set()
    for x in scores[-3000:]:
        if not isinstance(x, dict):
            continue
        d = _parse(x.get("date"))
        if not d or d < horizon or d > future:
            continue
        subj = str(x.get("subject", "")).strip()
        total, score = _i(x.get("total"), 0, 1000), _i(x.get("score"), 0, 1000)
        if subj == "Exam":
            continue
        if subj not in SUBJECTS or not (0 < total and score <= total):
            continue
        if not certificates._real(dict(subject=subj, lesson=x.get("lesson"), total=total)):
            continue
        key = (str(x.get("lesson")), d.isoformat())
        if key in seen:
            continue
        seen.add(key)
        quiz.append(dict(day=d.strftime("%Y-%m-%d"), dt=d, subject=subj, lesson=str(x.get("lesson")).strip().lower(), score=score, total=total))

    xp = week_xp = 0
    subj_xp = {n: [0, 0] for n in SUBJECTS}
    per_lesson, per_day, kept_quiz = {}, {}, []
    for q in sorted(quiz, key=lambda r: r["dt"]):
        a = per_lesson.get((q["day"], q["lesson"]), 0)
        b = per_day.get(q["day"], 0)
        if a >= PER_LESSON_DAY_CAP or b >= DAILY_QUIZ_CAP:
            continue
        per_lesson[(q["day"], q["lesson"])], per_day[q["day"]] = a + 1, b + 1
        pts = 5 + round(15 * q["score"] / q["total"])
        in_week = week_key(q["dt"]) == wk
        xp += pts
        subj_xp[q["subject"]][0] += pts
        if in_week:
            week_xp += pts
            subj_xp[q["subject"]][1] += pts
        kept_quiz.append(q)
    kept_exams = []
    days = sorted({r["day"] for r in kept_quiz + kept_exams})
    nums = [datetime.strptime(d, "%Y-%m-%d").toordinal() for d in days]
    best = run = 0
    prev = None
    for n in nums:
        run = run + 1 if prev is not None and n == prev + 1 else 1
        best = max(best, run)
        prev = n
    today = now.toordinal()
    cur = 0
    if nums and nums[-1] >= today - 1:
        cur, prev = 1, nums[-1]
        for n in reversed(nums[:-1]):
            if n != prev - 1:
                break
            cur, prev = cur + 1, n

    lessons = {r["lesson"] for r in kept_quiz}
    quiz_subjects = {r["subject"] for r in kept_quiz}
    avg = round(100 * sum(r["score"] / r["total"] for r in kept_quiz) / len(kept_quiz)) if kept_quiz else 0
    earned = set()
    nq, ne = len(kept_quiz), 0
    if nq >= 1: earned.add("first-quiz")
    if nq >= 5: earned.add("five-attempts")
    if nq >= 10: earned.add("ten-attempts")
    if any(r["score"] == r["total"] for r in kept_quiz): earned.add("perfect-score")
    if len(quiz_subjects) >= 3: earned.add("three-subjects")
    if len(quiz_subjects) >= 6: earned.add("six-subjects")
    if len(quiz_subjects) >= 8: earned.add("all-subjects")
    if best >= 7: earned.add("streak-7")
    if best >= 30: earned.add("streak-30")
    if xp >= 1000: earned.add("xp-1000")
    if xp >= 5000: earned.add("xp-5000")
    return dict(xp=xp, week_xp=week_xp, week_key=wk, quizzes=nq, lessons=len(lessons), avg_pct=avg, streak_cur=cur, streak_best=best,
                exams=0, badges=[b for b in BADGE_IDS if b in earned], subjects={k: v for k, v in subj_xp.items() if v[0]})


# ---------------------------------------------------------------- storage
def init(c):
    c.executescript("""
    CREATE TABLE IF NOT EXISTS cm_profiles(
      id INTEGER PRIMARY KEY, handle TEXT UNIQUE COLLATE NOCASE, display_name TEXT DEFAULT '', bio TEXT DEFAULT '', avatar TEXT DEFAULT '#12213B',
      key_hash TEXT UNIQUE, visibility TEXT DEFAULT 'public', band TEXT DEFAULT 'adult', hidden INTEGER DEFAULT 0, created_at INTEGER, updated_at INTEGER);
    CREATE TABLE IF NOT EXISTS cm_stats(
      profile_id INTEGER PRIMARY KEY, xp INTEGER DEFAULT 0, week_xp INTEGER DEFAULT 0, week_key TEXT DEFAULT '', quizzes INTEGER DEFAULT 0,
      lessons INTEGER DEFAULT 0, avg_pct INTEGER DEFAULT 0, streak_cur INTEGER DEFAULT 0, streak_best INTEGER DEFAULT 0, exams INTEGER DEFAULT 0,
      badges TEXT DEFAULT '[]', synced_at INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS cm_subject_xp(profile_id INTEGER, subject TEXT, xp INTEGER DEFAULT 0, week_xp INTEGER DEFAULT 0, week_key TEXT DEFAULT '', PRIMARY KEY(profile_id, subject));
    CREATE INDEX IF NOT EXISTS cm_subject_board ON cm_subject_xp(subject, xp DESC);
    CREATE TABLE IF NOT EXISTS cm_friends(a INTEGER, b INTEGER, status TEXT, requested_by INTEGER, created_at INTEGER, PRIMARY KEY(a, b));
    CREATE INDEX IF NOT EXISTS cm_friends_b ON cm_friends(b);
    CREATE TABLE IF NOT EXISTS cm_blocks(blocker INTEGER, blocked INTEGER, created_at INTEGER, PRIMARY KEY(blocker, blocked));
    CREATE TABLE IF NOT EXISTS cm_attempts(id INTEGER PRIMARY KEY, token TEXT UNIQUE, profile_id INTEGER, lesson_id TEXT, started_at INTEGER, finished_at INTEGER, score INTEGER, total INTEGER);
    CREATE INDEX IF NOT EXISTS cm_attempts_p ON cm_attempts(profile_id, finished_at);
    CREATE TABLE IF NOT EXISTS cm_reports(id INTEGER PRIMARY KEY, reporter INTEGER, target INTEGER, reason TEXT, created_at INTEGER, handled INTEGER DEFAULT 0);
    """)


def _pair(x, y):
    return (x, y) if x < y else (y, x)


def _me():
    h = request.headers.get("Authorization", "")
    if not h.lower().startswith("bearer ") or len(h) < 20:
        return None
    return db().execute("SELECT * FROM cm_profiles WHERE key_hash=?", (sha256(h[7:].strip()),)).fetchone()


def _blocked(c, x, y):
    return bool(c.execute("SELECT 1 FROM cm_blocks WHERE (blocker=? AND blocked=?) OR (blocker=? AND blocked=?)", (x, y, y, x)).fetchone())


def _friendship(c, x, y):
    r = c.execute("SELECT * FROM cm_friends WHERE a=? AND b=?", _pair(x, y)).fetchone()
    return r


def _badges_out(raw):
    have = set(json.loads(raw or "[]"))
    return [dict(id=b[0], name=b[1], icon=b[2], desc=b[3]) for b in BADGES if b[0] in have]


def _stats_row(c, pid):
    return c.execute("SELECT * FROM cm_stats WHERE profile_id=?", (pid,)).fetchone()


def _public(c, p, viewer_id=None, rank=True):
    """The shape every client sees. week_xp reads 0 once its week is over."""
    s = _stats_row(c, p["id"])
    wk = week_key()
    xp = s["xp"] if s else 0
    out = dict(handle=p["handle"], display_name=p["display_name"] or p["handle"], bio=p["bio"], avatar=p["avatar"], joined=p["created_at"], visibility=p["visibility"],
               xp=xp, week_xp=(s["week_xp"] if s and s["week_key"] == wk else 0), quizzes=s["quizzes"] if s else 0, lessons=s["lessons"] if s else 0,
               avg_pct=s["avg_pct"] if s else 0, streak_cur=s["streak_cur"] if s else 0, streak_best=s["streak_best"] if s else 0, exams=s["exams"] if s else 0,
               badges=_badges_out(s["badges"] if s else "[]"), **level_for(xp))
    subs = c.execute("SELECT subject, xp, week_xp, week_key FROM cm_subject_xp WHERE profile_id=? ORDER BY xp DESC", (p["id"],)).fetchall()
    out["subjects"] = [dict(subject=r["subject"], xp=r["xp"], week_xp=r["week_xp"] if r["week_key"] == wk else 0) for r in subs]
    if rank and p["visibility"] == "public" and not p["hidden"] and xp > 0:
        out["rank"] = 1 + c.execute(_BOARD_COUNT, (xp,)).fetchone()[0]
    if viewer_id:
        if viewer_id == p["id"]:
            out["relation"] = "self"
        else:
            f = _friendship(c, viewer_id, p["id"])
            out["relation"] = "none" if not f else ("friend" if f["status"] == "accepted" else ("pending_out" if f["requested_by"] == viewer_id else "pending_in"))
    return out


_BOARD_COUNT = ("SELECT COUNT(*) FROM cm_profiles p JOIN cm_stats s ON s.profile_id=p.id "
                "WHERE p.visibility='public' AND p.hidden=0 AND s.xp > ?")


# ---------------------------------------------------------------- server-graded quiz attempts
MIN_SECS_PER_QUESTION = 2.5
_QUIZ = {}
_LESSONS = {}


def _public_dir():
    return os.environ.get("PUBLIC_DIR") or os.path.join(ROOT, "..", "public")


def _lesson(lid):
    """{id, title, subject, href} from the published learning index, or None."""
    if not _LESSONS:
        try:
            idx = json.load(open(os.path.join(_public_dir(), "data", "learning-index.json"), encoding="utf8"))
            for l in idx.get("lessons", []):
                _LESSONS[l["id"]] = dict(id=l["id"], title=str(l["title"]), href=l["href"], subject=l["id"].split("/")[0].replace("-", " ").title())
        except (OSError, ValueError, KeyError):
            log.warning("learning-index.json not found: community quiz attempts cannot be graded")
    return _LESSONS.get(lid)


def _quiz_pool(lesson):
    """The lesson's quiz questions exactly as the page ships them (the lesson HTML is the source of truth)."""
    path = os.path.join(_public_dir(), "pages", lesson["href"])
    try:
        m = os.path.getmtime(path)
        if _QUIZ.get(path, (0, None))[0] != m:
            html_ = open(path, encoding="utf8").read()
            blk = re.search(r"data-quiz-data[^>]*>(.*?)</script>", html_, re.S)
            _QUIZ[path] = (m, json.loads(blk.group(1)) if blk else [])
        return _QUIZ[path][1]
    except (OSError, ValueError):
        return []


def _recompute(c, pid):
    """Rebuild a profile's stats from the attempts the server graded. Idempotent."""
    rows = c.execute("SELECT id, lesson_id, score, total, finished_at FROM cm_attempts WHERE profile_id=? AND finished_at IS NOT NULL ORDER BY finished_at", (pid,)).fetchall()
    scores = []
    for r in rows:
        les = _lesson(r["lesson_id"])
        if les:
            scores.append(dict(subject=les["subject"], lesson=les["title"], score=r["score"], total=r["total"],
                               date=datetime.fromtimestamp(r["finished_at"] + r["id"] / 1e6, timezone.utc).isoformat()))   # id keeps same-second attempts distinct
    st = compute(dict(scores=scores))
    old = json.loads((_stats_row(c, pid) or {"badges": "[]"})["badges"] or "[]")
    c.execute("""UPDATE cm_stats SET xp=?,week_xp=?,week_key=?,quizzes=?,lessons=?,avg_pct=?,streak_cur=?,streak_best=?,exams=?,badges=?,synced_at=? WHERE profile_id=?""",
              (st["xp"], st["week_xp"], st["week_key"], st["quizzes"], st["lessons"], st["avg_pct"], st["streak_cur"], st["streak_best"], 0,
               json.dumps(st["badges"]), _now(), pid))
    c.execute("DELETE FROM cm_subject_xp WHERE profile_id=?", (pid,))
    c.executemany("INSERT INTO cm_subject_xp(profile_id,subject,xp,week_xp,week_key) VALUES(?,?,?,?,?)",
                  [(pid, k, v[0], v[1], st["week_key"]) for k, v in st["subjects"].items()])
    return [b for b in st["badges"] if b not in old]


# ---------------------------------------------------------------- routes
def register(app, admin_only, log_fn):
    def err(msg, code=400):
        return jsonify(error=msg), code

    def need_me():
        p = _me()
        if not p:
            return None, err("Not signed in to the community. Join first, or restore your device key.", 401)
        if p["hidden"]:
            return None, err("This profile has been hidden by a moderator.", 403)
        return p, None

    @app.get("/api/community/meta")
    def cm_meta():
        return jsonify(badges=[dict(id=b[0], name=b[1], icon=b[2], desc=b[3]) for b in BADGES], subjects=SUBJECTS, avatars=AVATARS, week_key=week_key(),
                       rules=dict(quiz="5-20 XP per quiz attempt (5 for trying + up to 15 for accuracy)", exam="Quizzes only: results are graded by the server. Exam Center papers are graded in your browser, so they don't count",
                                  caps="Up to 3 attempts per lesson and 40 attempts per day earn XP", weekly="Weekly boards reset every Monday 00:00 UTC",
                                  level="Level = 1 + floor(sqrt(XP / 50))"))

    @app.get("/api/community/handle-check")
    def cm_handle_check():
        if too_many("cm-handle", client_ip(request), 120, 3600):
            return err("Slow down.", 429)
        h, bad = clean_handle(request.args.get("h"))
        if bad:
            return jsonify(ok=False, reason=bad)
        taken = db().execute("SELECT 1 FROM cm_profiles WHERE handle=?", (h,)).fetchone()
        return jsonify(ok=not taken, handle=h, reason="That handle is taken." if taken else "")

    @app.post("/api/community/join")
    def cm_join():
        if too_many("cm-join", client_ip(request), 8, 3600):
            return err("Too many sign-ups from this network. Try again later.", 429)
        d = request.get_json(silent=True) or {}
        if d.get("child") or d.get("band") == "child":
            return err("Community profiles, leaderboards and friends are for learners aged 13 and over. Children's accounts stay private by design.", 403)
        if not d.get("agree"):
            return err("Please confirm you understand what a public profile shares.")
        h, bad = clean_handle(d.get("handle"))
        if bad:
            return err(bad)
        name, bad = clean_text(d.get("display_name"), 30, "Display name")
        if bad:
            return err(bad)
        avatar = d.get("avatar") if d.get("avatar") in AVATARS else AVATARS[0]
        band = "teen" if d.get("band") == "teen" else "adult"
        vis = d.get("visibility") if d.get("visibility") in VISIBILITY else ("friends" if band == "teen" else "public")
        if band == "teen" and vis == "public":
            vis = "friends"     # 13-15: public needs a deliberate later change by a parent/guardian-aware learner; never the default
        key = "clk_" + secrets.token_urlsafe(30)
        try:
            with db() as c:
                cur = c.execute("INSERT INTO cm_profiles(handle,display_name,avatar,key_hash,visibility,band,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                                (h, name or "", avatar, sha256(key), vis, band, _now(), _now()))
                c.execute("INSERT INTO cm_stats(profile_id) VALUES(?)", (cur.lastrowid,))
        except Exception as e:                      # UNIQUE(handle)
            if "UNIQUE" in str(e):
                return err("That handle is taken.", 409)
            raise
        with db() as c:
            p = c.execute("SELECT * FROM cm_profiles WHERE handle=?", (h,)).fetchone()
            return jsonify(ok=True, key=key, profile=_public(c, p, p["id"]))

    @app.get("/api/community/me")
    def cm_me_get():
        p, e = need_me()
        if e:
            return e
        with db() as c:
            inc = c.execute("SELECT COUNT(*) FROM cm_friends WHERE status='pending' AND requested_by!=? AND (a=? OR b=?)", (p["id"], p["id"], p["id"])).fetchone()[0]
            fr = c.execute("SELECT COUNT(*) FROM cm_friends WHERE status='accepted' AND (a=? OR b=?)", (p["id"], p["id"])).fetchone()[0]
            extra = {}
            for fn in ME_EXTRAS:
                extra.update(fn(c, p["id"]))
            return jsonify(profile=_public(c, p, p["id"]), band=p["band"], friends=fr, incoming=inc, **extra)

    @app.post("/api/community/me")
    def cm_me_set():
        p, e = need_me()
        if e:
            return e
        d = request.get_json(silent=True) or {}
        if "display_name" in d or "bio" in d:          # free text: a moderator's mute covers it too
            import moderation as M
            with db() as c:
                muted = M.muted_response(c, p)
            if muted:
                return muted
        sets, vals = [], []
        if "display_name" in d:
            v, bad = clean_text(d.get("display_name"), 30, "Display name")
            if bad: return err(bad)
            sets.append("display_name=?"); vals.append(v)
        if "bio" in d:
            v, bad = clean_text(d.get("bio"), 140, "Bio")
            if bad: return err(bad)
            sets.append("bio=?"); vals.append(v)
        if "avatar" in d and d["avatar"] in AVATARS:
            sets.append("avatar=?"); vals.append(d["avatar"])
        if d.get("visibility") in VISIBILITY:
            sets.append("visibility=?"); vals.append(d["visibility"])
        if sets:
            with db() as c:
                c.execute(f"UPDATE cm_profiles SET {', '.join(sets)}, updated_at=? WHERE id=?", (*vals, _now(), p["id"]))
        with db() as c:
            return jsonify(ok=True, profile=_public(c, c.execute("SELECT * FROM cm_profiles WHERE id=?", (p["id"],)).fetchone(), p["id"]))

    @app.delete("/api/community/me")
    def cm_me_delete():
        p, e = need_me()
        if e:
            return e
        with db() as c:
            for sql in ("DELETE FROM cm_attempts WHERE profile_id=?", "DELETE FROM cm_subject_xp WHERE profile_id=?", "DELETE FROM cm_stats WHERE profile_id=?", "DELETE FROM cm_friends WHERE a=? OR b=?",
                        "DELETE FROM cm_blocks WHERE blocker=? OR blocked=?", "DELETE FROM cm_reports WHERE reporter=? OR target=?", "DELETE FROM cm_profiles WHERE id=?"):
                c.execute(sql, (p["id"],) * sql.count("?"))
            for fn in ERASE_HOOKS:
                fn(c, p["id"])
        return jsonify(ok=True)

    @app.post("/api/community/sync")
    def cm_sync():
        """Rebuilds my numbers from the attempts the server graded. The request body is ignored: the browser can't set a score."""
        p, e = need_me()
        if e:
            return e
        if too_many("cm-sync", str(p["id"]), 60, 3600):
            return err("Syncing too often. Try again in a little while.", 429)
        d = request.get_json(silent=True) or {}
        if d.get("band") == "child" or d.get("child"):
            return err("Children's accounts can't use the community.", 403)
        with db() as c:
            _recompute(c, p["id"])
            return jsonify(ok=True, new_badges=[], profile=_public(c, p, p["id"]))

    @app.post("/api/community/attempt/start")
    def cm_attempt_start():
        p, e = need_me()
        if e:
            return e
        if too_many("cm-astart", str(p["id"]), 80, 3600):
            return err("Too many quiz starts. Try again later.", 429)
        les = _lesson(str((request.get_json(silent=True) or {}).get("lesson") or ""))
        pool = _quiz_pool(les) if les else []
        if not les or len(pool) < 5:
            return err("Unknown lesson.", 404)
        tok = secrets.token_urlsafe(16)
        with db() as c:
            c.execute("INSERT INTO cm_attempts(token,profile_id,lesson_id,started_at) VALUES(?,?,?,?)", (tok, p["id"], les["id"], _now()))
            c.execute("DELETE FROM cm_attempts WHERE finished_at IS NULL AND started_at<?", (_now() - 86400,))   # abandoned starts
        return jsonify(ok=True, attempt=tok, questions=min(10, len(pool)))

    @app.post("/api/community/attempt/finish")
    def cm_attempt_finish():
        p, e = need_me()
        if e:
            return e
        d = request.get_json(silent=True) or {}
        with db() as c:
            a = c.execute("SELECT * FROM cm_attempts WHERE token=? AND profile_id=?", (str(d.get("attempt") or ""), p["id"])).fetchone()
            if not a or a["finished_at"]:
                return err("That quiz attempt isn't open.", 404)
            les = _lesson(a["lesson_id"]); pool = _quiz_pool(les) if les else []
            ans = d.get("answers") if isinstance(d.get("answers"), list) else []
            seen, score = set(), 0
            for x in ans[:20]:
                if not isinstance(x, dict) or not isinstance(x.get("i"), int) or x["i"] in seen or not 0 <= x["i"] < len(pool):
                    return err("Those answers don't match this quiz.")
                seen.add(x["i"])
                q = pool[x["i"]]
                try:
                    score += 1 if str(x.get("p")) == str(q["options"][q["correct"]]) else 0
                except (KeyError, IndexError, TypeError):
                    return err("Those answers don't match this quiz.")
            n = len(seen)
            if not 5 <= n <= min(10, len(pool)):
                return err("Those answers don't match this quiz.")
            elapsed = _now() - a["started_at"]
            if elapsed < MIN_SECS_PER_QUESTION * n:
                return err("That was too quick to count. Take your time with each question.", 429)
            if elapsed > 6 * 3600:
                return err("That attempt expired. Start the quiz again.", 410)
            c.execute("UPDATE cm_attempts SET finished_at=?, score=?, total=? WHERE id=?", (_now(), score, n, a["id"]))
            new = _recompute(c, p["id"])
            return jsonify(ok=True, score=score, total=n, xp_gained=5 + round(15 * score / n), new_badges=_badges_out(json.dumps(new)), profile=_public(c, p, p["id"]))

    # ---- boards
    def _board(c, board, period, subject, me, limit):
        wk, week = week_key(), period == "week"
        params = []                     # placeholders appear in SQL order: SELECT list (week), FROM (subject), WHERE
        if board == "subject":
            frm = "cm_profiles p JOIN cm_stats s ON s.profile_id=p.id JOIN cm_subject_xp x ON x.profile_id=p.id AND x.subject=?"
            pts = "(CASE WHEN x.week_key=? THEN x.week_xp ELSE 0 END)" if week else "x.xp"
        else:
            frm = "cm_profiles p JOIN cm_stats s ON s.profile_id=p.id"
            pts = "(CASE WHEN s.week_key=? THEN s.week_xp ELSE 0 END)" if week else "s.xp"
        if week:
            params.append(wk)
        if board == "subject":
            params.append(subject)
        if board == "friends":
            where = ("p.hidden=0 AND (p.id=? OR (p.visibility!='private' AND p.id IN (SELECT CASE WHEN a=? THEN b ELSE a END FROM cm_friends WHERE status='accepted' AND (a=? OR b=?))))")
            wparams = [me["id"]] * 4
        else:
            where = ("p.visibility='public' AND p.hidden=0 AND p.id NOT IN (SELECT blocked FROM cm_blocks WHERE blocker=? UNION SELECT blocker FROM cm_blocks WHERE blocked=?)")
            wparams = [me["id"] if me else 0] * 2
        base = f"SELECT p.id, p.handle, p.display_name, p.avatar, s.xp AS total, s.streak_cur, {pts} AS pts, s.synced_at FROM {frm} WHERE {where}"
        bp = params + wparams
        rows = c.execute(f"SELECT * FROM ({base}) WHERE pts>0 ORDER BY pts DESC, synced_at ASC, id ASC LIMIT ?", bp + [limit]).fetchall()
        out, prev, rank = [], None, 0
        for i, r in enumerate(rows):
            if r["pts"] != prev:
                rank, prev = i + 1, r["pts"]
            out.append(dict(rank=rank, handle=r["handle"], name=r["display_name"] or r["handle"], avatar=r["avatar"], pts=r["pts"], xp=r["total"], streak=r["streak_cur"],
                            me=bool(me and r["id"] == me["id"])))
        mine = None
        if me:
            m = c.execute(f"SELECT pts FROM ({base}) WHERE id=?", bp + [me["id"]]).fetchone()
            if m is not None:
                mine = dict(pts=m["pts"], on_board=True)
                if m["pts"] > 0:
                    mine["rank"] = 1 + c.execute(f"SELECT COUNT(*) FROM ({base}) WHERE pts>?", bp + [m["pts"]]).fetchone()[0]
            else:
                mine = dict(on_board=False)       # hidden from public boards by their own visibility setting
        return out, mine

    @app.get("/api/community/leaderboard")
    def cm_board():
        me = _me()
        board = request.args.get("board", "global")
        period = "week" if request.args.get("period") == "week" else "all"
        subject = request.args.get("subject", "")
        if board not in ("global", "subject", "friends") or (board == "subject" and subject not in SUBJECTS):
            return err("Unknown leaderboard.")
        if board == "friends" and not me:
            return err("Join the community to see your friends' board.", 401)
        if too_many("cm-board", client_ip(request), 240, 3600):
            return err("Slow down.", 429)
        limit = _i(request.args.get("limit"), 1, 100) or 50
        with db() as c:
            rows, mine = _board(c, board, period, subject, me, limit)
        return jsonify(board=board, period=period, subject=subject if board == "subject" else "", week_key=week_key(), rows=rows, me=mine)

    # ---- profiles
    def _visible(c, viewer, p):
        if p["hidden"]:
            return False
        if viewer and viewer["id"] == p["id"]:
            return True
        if viewer and _blocked(c, viewer["id"], p["id"]):
            return False
        if p["visibility"] == "public":
            return True
        if p["visibility"] == "friends" and viewer:
            f = _friendship(c, viewer["id"], p["id"])
            return bool(f and f["status"] == "accepted")
        return False

    @app.get("/api/community/profile/<handle>")
    def cm_profile(handle):
        if too_many("cm-profile", client_ip(request), 240, 3600):
            return err("Slow down.", 429)
        viewer = _me()
        with db() as c:
            p = c.execute("SELECT * FROM cm_profiles WHERE handle=?", ((handle or "").lower(),)).fetchone()
            if not p or not _visible(c, viewer, p):
                return err("No profile found. It may not exist, or it may be private.", 404)
            return jsonify(profile=_public(c, p, viewer["id"] if viewer else None))

    # ---- friends
    def _target(c, me, handle):
        t = c.execute("SELECT * FROM cm_profiles WHERE handle=?", ((handle or "").strip().lower().lstrip("@"),)).fetchone()
        if not t or t["hidden"] or t["id"] == me["id"] or _blocked(c, me["id"], t["id"]):
            return None
        return t

    @app.get("/api/community/friends")
    def cm_friends():
        p, e = need_me()
        if e:
            return e
        with db() as c:
            rows = c.execute("""SELECT f.status, f.requested_by, f.created_at, o.* FROM cm_friends f JOIN cm_profiles o ON o.id = CASE WHEN f.a=? THEN f.b ELSE f.a END
                                WHERE (f.a=? OR f.b=?) AND o.hidden=0 ORDER BY f.created_at DESC""", (p["id"],) * 3).fetchall()
            out = dict(friends=[], incoming=[], outgoing=[])
            for r in rows:
                if r["status"] == "accepted":
                    s = _stats_row(c, r["id"])
                    out["friends"].append(dict(handle=r["handle"], name=r["display_name"] or r["handle"], avatar=r["avatar"], xp=s["xp"] if s else 0,
                                               streak=s["streak_cur"] if s else 0, private=r["visibility"] == "private"))
                else:
                    k = "outgoing" if r["requested_by"] == p["id"] else "incoming"
                    out[k].append(dict(handle=r["handle"], name=r["display_name"] or r["handle"], avatar=r["avatar"]))
            return jsonify(**out)

    @app.post("/api/community/friends/request")
    def cm_friend_request():
        p, e = need_me()
        if e:
            return e
        if too_many("cm-freq", str(p["id"]), 20, 86400):
            return err("You've sent a lot of requests today. Try again tomorrow.", 429)
        with db() as c:
            t = _target(c, p, (request.get_json(silent=True) or {}).get("handle"))
            if not t or t["visibility"] == "private":
                return err("No learner with that exact handle can receive requests.", 404)
            f = _friendship(c, p["id"], t["id"])
            if f and f["status"] == "accepted":
                return jsonify(ok=True, status="friend")
            if f and f["requested_by"] != p["id"]:      # they already asked me: accept
                c.execute("UPDATE cm_friends SET status='accepted' WHERE a=? AND b=?", _pair(p["id"], t["id"]))
                return jsonify(ok=True, status="friend")
            if f:
                return jsonify(ok=True, status="pending_out")
            if c.execute("SELECT COUNT(*) FROM cm_friends WHERE (a=? OR b=?) AND status='accepted'", (p["id"], p["id"])).fetchone()[0] >= MAX_FRIENDS:
                return err(f"You can have up to {MAX_FRIENDS} friends.")
            a, b = _pair(p["id"], t["id"])
            c.execute("INSERT INTO cm_friends(a,b,status,requested_by,created_at) VALUES(?,?, 'pending', ?, ?)", (a, b, p["id"], _now()))
        return jsonify(ok=True, status="pending_out")

    @app.post("/api/community/friends/respond")
    def cm_friend_respond():
        p, e = need_me()
        if e:
            return e
        d = request.get_json(silent=True) or {}
        with db() as c:
            t = _target(c, p, d.get("handle"))
            f = _friendship(c, p["id"], t["id"]) if t else None
            if not f or f["status"] != "pending" or f["requested_by"] == p["id"]:
                return err("No request from that learner.", 404)
            if d.get("accept"):
                c.execute("UPDATE cm_friends SET status='accepted' WHERE a=? AND b=?", _pair(p["id"], t["id"]))
            else:
                c.execute("DELETE FROM cm_friends WHERE a=? AND b=?", _pair(p["id"], t["id"]))
        return jsonify(ok=True)

    @app.post("/api/community/friends/remove")
    def cm_friend_remove():
        p, e = need_me()
        if e:
            return e
        with db() as c:
            t = c.execute("SELECT id FROM cm_profiles WHERE handle=?", (((request.get_json(silent=True) or {}).get("handle") or "").strip().lower(),)).fetchone()
            if t:
                c.execute("DELETE FROM cm_friends WHERE a=? AND b=?", _pair(p["id"], t["id"]))
        return jsonify(ok=True)

    @app.post("/api/community/block")
    def cm_block():
        p, e = need_me()
        if e:
            return e
        with db() as c:
            t = c.execute("SELECT id FROM cm_profiles WHERE handle=?", (((request.get_json(silent=True) or {}).get("handle") or "").strip().lower(),)).fetchone()
            if not t or t["id"] == p["id"]:
                return err("No such learner.", 404)
            c.execute("INSERT OR IGNORE INTO cm_blocks(blocker,blocked,created_at) VALUES(?,?,?)", (p["id"], t["id"], _now()))
            c.execute("DELETE FROM cm_friends WHERE a=? AND b=?", _pair(p["id"], t["id"]))
        return jsonify(ok=True)

    @app.post("/api/community/unblock")
    def cm_unblock():
        p, e = need_me()
        if e:
            return e
        with db() as c:
            t = c.execute("SELECT id FROM cm_profiles WHERE handle=?", (((request.get_json(silent=True) or {}).get("handle") or "").strip().lower(),)).fetchone()
            if t:
                c.execute("DELETE FROM cm_blocks WHERE blocker=? AND blocked=?", (p["id"], t["id"]))
        return jsonify(ok=True)

    @app.post("/api/community/report")
    def cm_report():
        import moderation as M              # imported here: moderation imports this module
        p, e = need_me()
        if e:
            return e
        if too_many("cm-report", str(p["id"]), 10, 86400):
            return err("Too many reports today.", 429)
        d = request.get_json(silent=True) or {}
        cat, reason = M.report_fields(d)
        with db() as c:
            t = c.execute("SELECT id FROM cm_profiles WHERE handle=?", ((d.get("handle") or "").strip().lower(),)).fetchone()
            if not t or t["id"] == p["id"] or not cat:
                return err("Choose a profile and say what is wrong.")
            c.execute("INSERT INTO cm_reports(reporter,target,reason,category,created_at) VALUES(?,?,?,?,?)", (p["id"], t["id"], reason, cat, _now()))
            c.execute("INSERT OR IGNORE INTO cm_blocks(blocker,blocked,created_at) VALUES(?,?,?)", (p["id"], t["id"], _now()))   # reporting also hides them from you
        return jsonify(ok=True)

    # ---- share page
    @app.get("/u/<handle>")
    def cm_share(handle):
        import html as H
        path = os.path.join(os.environ.get("PUBLIC_DIR") or os.path.join(ROOT, "..", "public"), "pages", "u.html")
        try:
            page = open(path, encoding="utf8").read()
        except OSError:
            return Response("Not found", status=404, mimetype="text/plain")
        with db() as c:
            p = c.execute("SELECT * FROM cm_profiles WHERE handle=?", ((handle or "").lower(),)).fetchone()
            pub = p and not p["hidden"] and p["visibility"] == "public"
            info = _public(c, p, None, rank=False) if pub else None
        base = site_url(request)
        if info:
            title = f"{info['display_name']} (@{info['handle']}) on Curio Lab"
            desc = f"Level {info['level']} · {info['xp']:,} XP · {info['streak_best']}-day best streak · {len(info['badges'])} badges"
        else:
            title, desc = "Curio Lab profile", "Learn by experimenting on Curio Lab."
        e_title, e_desc = H.escape(title, quote=True), H.escape(desc, quote=True)
        for pat, val in ((r'(<meta property="og:title" content=")[^"]*"', e_title), (r'(<meta property="og:description" content=")[^"]*"', e_desc),
                         (r'(<meta name="description" content=")[^"]*"', e_desc), (r'(<meta name="twitter:title" content=")[^"]*"', e_title)):
            page = re.sub(pat, lambda m, v=val: m.group(1) + v + '"', page)
        tags = f'<meta property="og:url" content="{H.escape(base)}/u/{H.escape(handle)}"><meta name="twitter:card" content="summary">'
        page = page.replace("<!--OG-->", tags).replace("<title>Profile — Curio Lab</title>", f"<title>{e_title}</title>")
        page = page.replace("<head>", '<head><base href="/pages/">', 1)   # the URL is /u/<handle>, the page's relative links expect /pages/
        resp = Response(page, mimetype="text/html")
        resp.headers["Cache-Control"] = "no-store"
        return resp

    # ---- moderation (admin)
    @app.get("/api/admin/community/reports")
    @admin_only
    def cm_admin_reports():
        rows = db().execute("""SELECT r.id, r.reason, r.created_at, r.handled, t.handle AS target, t.hidden AS target_hidden, t.display_name, t.bio, f.handle AS reporter
                               FROM cm_reports r LEFT JOIN cm_profiles t ON t.id=r.target LEFT JOIN cm_profiles f ON f.id=r.reporter ORDER BY r.handled, r.id DESC LIMIT 300""").fetchall()
        return jsonify(reports=[dict(r) for r in rows])

    @app.post("/api/admin/community/reports/<int:rid>/handled")
    @admin_only
    def cm_admin_handled(rid):
        with db() as c:
            c.execute("UPDATE cm_reports SET handled=1 WHERE id=?", (rid,))
        return jsonify(ok=True)

    def _admin_target(handle):
        return db().execute("SELECT id, handle FROM cm_profiles WHERE handle=?", ((handle or "").lower(),)).fetchone()

    @app.post("/api/admin/community/<handle>/<action>")
    @admin_only
    def cm_admin_hide(handle, action):
        if action not in ("hide", "unhide"):
            return err("Unknown action.", 404)
        t = _admin_target(handle)
        if not t:
            return err("No such profile.", 404)
        import moderation as M
        with db() as c:
            c.execute("UPDATE cm_profiles SET hidden=? WHERE id=?", (1 if action == "hide" else 0, t["id"]))
            M.on_content_action(c, t["id"], "profile", action, t["handle"])
        log_fn("community_" + action, "-", "-", f"handle={t['handle']}")
        return jsonify(ok=True)

    @app.delete("/api/admin/community/<handle>")
    @admin_only
    def cm_admin_delete(handle):
        t = _admin_target(handle)
        if not t:
            return err("No such profile.", 404)
        with db() as c:
            for sql in ("DELETE FROM cm_attempts WHERE profile_id=?", "DELETE FROM cm_subject_xp WHERE profile_id=?", "DELETE FROM cm_stats WHERE profile_id=?", "DELETE FROM cm_friends WHERE a=? OR b=?",
                        "DELETE FROM cm_blocks WHERE blocker=? OR blocked=?", "DELETE FROM cm_reports WHERE reporter=? OR target=?", "DELETE FROM cm_profiles WHERE id=?"):
                c.execute(sql, (t["id"],) * sql.count("?"))
            for fn in ERASE_HOOKS:
                fn(c, t["id"])
        log_fn("community_delete", "-", "-", f"handle={t['handle']}")
        return jsonify(ok=True)
