"""Image cards drawn with Pillow: lesson share previews (Open Graph) and certificate images.

Used by scripts/seo/og_images.py (build time) and backend/app.py (certificates, at request time).
Fonts are bundled in ./fonts (Inter, SIL OFL) so the output looks the same on every machine.
"""
import os
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_DIR = os.path.join(HERE, "fonts")

NAVY, CREAM, INK, MUTED, GOLD, TEAL = "#12213B", "#F3EFE3", "#1B1B18", "#5C594E", "#E9A93F", "#56C2B2"

SUBJECT_ACCENT = {
    "physics": "#4C6FFF", "chemistry": "#2FA37C", "biology": "#D9663F", "english": "#9B6BD3",
    "mathematics": "#E9A93F", "history": "#B5733A", "geography": "#2F9BB5", "computer-science": "#56C2B2",
}


def font(weight, size):
    name = {"regular": "Inter-Regular.otf", "semibold": "Inter-SemiBold.otf", "bold": "Inter-Bold.otf"}[weight]
    return ImageFont.truetype(os.path.join(FONT_DIR, name), size)


def wrap(draw, text, fnt, max_w, max_lines):
    """Greedy word wrap; the last line gets an ellipsis if the text does not fit."""
    words, lines, cur = text.split(), [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if draw.textlength(trial, font=fnt) <= max_w or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        last = lines[-1]
        while draw.textlength(last + "…", font=fnt) > max_w and " " in last:
            last = last.rsplit(" ", 1)[0]
        lines[-1] = last + "…"
    return lines


def _logo(draw, x, y, scale=1.0):
    """Small flask mark + wordmark."""
    s = scale
    draw.rounded_rectangle((x, y, x + 56 * s, y + 56 * s), radius=12 * s, fill=NAVY)
    pts = [(x + 22 * s, y + 11 * s), (x + 34 * s, y + 11 * s), (x + 34 * s, y + 24 * s), (x + 44 * s, y + 42 * s),
           (x + 41 * s, y + 46 * s), (x + 15 * s, y + 46 * s), (x + 12 * s, y + 42 * s), (x + 22 * s, y + 24 * s)]
    draw.line(pts + [pts[0]], fill=GOLD, width=max(2, int(3 * s)), joint="curve")
    draw.ellipse((x + 25 * s, y + 35 * s, x + 31 * s, y + 41 * s), fill=TEAL)
    draw.text((x + 72 * s, y + 6 * s), "Curio·Lab", font=font("bold", int(34 * s)), fill=NAVY)


def og_card(path, title, subject_label, accent, chips, footer="curiolab"):
    """1200x630 share card for a lesson (or a generic page when subject_label is empty)."""
    W, H = 1200, 630
    img = Image.new("RGB", (W, H), CREAM)
    d = ImageDraw.Draw(img)
    # graph-paper grid, very light
    for gx in range(0, W, 40):
        d.line((gx, 0, gx, H), fill="#EBE6D6", width=1)
    for gy in range(0, H, 40):
        d.line((0, gy, W, gy), fill="#EBE6D6", width=1)
    d.rectangle((0, 0, 22, H), fill=accent)
    d.rectangle((W - 360, 0, W, H), fill=NAVY)
    # accent shapes on the navy panel
    d.ellipse((W - 330, 70, W - 70, 330), outline=accent, width=6)
    d.ellipse((W - 250, 150, W - 150, 250), fill=accent)
    d.polygon([(W - 300, 520), (W - 160, 380), (W - 40, 520)], outline=GOLD, width=5)
    _logo(d, 70, 56)
    if subject_label:
        label = subject_label.upper()
        f = font("semibold", 26)
        tw = d.textlength(label, font=f)
        d.rounded_rectangle((70, 170, 70 + tw + 40, 218), radius=24, fill=accent)
        d.text((90, 177), label, font=f, fill="white")
    tf = font("bold", 76)
    lines = wrap(d, title, tf, W - 360 - 70 - 60, 3)
    size = 76
    if len(lines) == 3:
        size = 64
        tf = font("bold", size)
        lines = wrap(d, title, tf, W - 360 - 70 - 60, 3)
    y = 250
    for ln in lines:
        d.text((70, y), ln, font=tf, fill=INK)
        y += int(size * 1.14)
    cf = font("semibold", 28)
    x = 70
    for chip in chips[:3]:
        tw = d.textlength(chip, font=cf)
        d.rounded_rectangle((x, 520, x + tw + 36, 568), radius=10, outline=MUTED, width=2)
        d.text((x + 18, 527), chip, font=cf, fill=MUTED)
        x += tw + 36 + 14
    # flat-colour card: a 128-colour palette is visually identical and about half the size
    img.convert("P", palette=Image.ADAPTIVE, colors=128, dither=Image.NONE).save(path, "PNG", optimize=True)


TIER_STYLE = {1: ("BRONZE", "#B87333"), 2: ("SILVER", "#8E9AA6"), 3: ("GOLD", "#D4A017"), 4: ("PLATINUM", "#5AA9C9")}


def cert_card(path_or_buf, name, tier_label, level, headline, issued, verify_url, code, fmt="PNG"):
    """1200x800 certificate. Draws the public verification URL + code on it. Never draws an email."""
    W, H = 1200, 800
    img = Image.new("RGB", (W, H), CREAM)
    d = ImageDraw.Draw(img)
    badge, col = TIER_STYLE.get(level, ("CERTIFICATE", GOLD))
    d.rectangle((24, 24, W - 24, H - 24), outline=col, width=10)
    d.rectangle((52, 52, W - 52, H - 52), outline=NAVY, width=2)
    _logo(d, W // 2 - 110, 86)
    sub = font("semibold", 22)
    t = "CERTIFICATE OF ACHIEVEMENT"
    d.text(((W - d.textlength(t, font=sub)) / 2, 190), t, font=sub, fill=MUTED)
    t = "This certifies that"
    f = font("regular", 26)
    d.text(((W - d.textlength(t, font=f)) / 2, 250), t, font=f, fill=MUTED)
    nf_size = 74
    nf = font("bold", nf_size)
    while d.textlength(name, font=nf) > W - 220 and nf_size > 32:
        nf_size -= 4
        nf = font("bold", nf_size)
    d.text(((W - d.textlength(name, font=nf)) / 2, 300), name, font=nf, fill=INK)
    d.line((220, 400, W - 220, 400), fill=col, width=3)
    t = "has earned"
    d.text(((W - d.textlength(t, font=f)) / 2, 425), t, font=f, fill=MUTED)
    hf = font("bold", 44)
    lines = wrap(d, tier_label, hf, W - 260, 2)
    y = 470
    for ln in lines:
        d.text(((W - d.textlength(ln, font=hf)) / 2, y), ln, font=hf, fill="#C94A38")
        y += 56
    df = font("regular", 26)
    for ln in wrap(d, headline, df, W - 300, 2):
        d.text(((W - d.textlength(ln, font=df)) / 2, y + 6), ln, font=df, fill=MUTED)
        y += 34
    bf = font("bold", 26)
    bw = d.textlength(badge, font=bf)
    d.rounded_rectangle((W / 2 - bw / 2 - 24, 620, W / 2 + bw / 2 + 24, 666), radius=23, fill=col)
    d.text((W / 2 - bw / 2, 626), badge, font=bf, fill="white")
    sm = font("regular", 20)
    d.text((90, 684), f"Issued {issued}", font=sm, fill=MUTED)
    code_t = f"Code {code}"
    d.text((W - 90 - d.textlength(code_t, font=sm), 684), code_t, font=sm, fill=MUTED)
    vt = f"Verify: {verify_url}"
    vf = font("semibold", 20)
    while d.textlength(vt, font=vf) > W - 200 and len(vt) > 20:
        vt = vt[:-2]
    d.text(((W - d.textlength(vt, font=vf)) / 2, 712), vt, font=vf, fill=NAVY)
    img.save(path_or_buf, fmt, optimize=True)
