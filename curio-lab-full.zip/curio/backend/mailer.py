"""Optional SMTP sender. Configure with SMTP_HOST, SMTP_PORT (587), SMTP_USER, SMTP_PASSWORD, SMTP_FROM.
Without SMTP_HOST nothing is sent and send() returns False; callers must say so honestly to the user."""
import os, smtplib, ssl, logging
from email.message import EmailMessage

log = logging.getLogger("curiolab.mail")


def configured():
    return bool(os.environ.get("SMTP_HOST"))


def send(to, subject, body):
    if not configured():
        log.warning("SMTP not configured; email to %s not sent (subject: %s)", "<redacted>", subject)
        return False
    msg = EmailMessage()
    msg["From"] = os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USER") or "no-reply@localhost"
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)
    try:
        port = int(os.environ.get("SMTP_PORT", 587))
        if port == 465:
            s = smtplib.SMTP_SSL(os.environ["SMTP_HOST"], port, timeout=15, context=ssl.create_default_context())
        else:
            s = smtplib.SMTP(os.environ["SMTP_HOST"], port, timeout=15)
            s.starttls(context=ssl.create_default_context())
        if os.environ.get("SMTP_USER"):
            s.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASSWORD", ""))
        s.send_message(msg)
        s.quit()
        return True
    except Exception as e:  # network / auth problems must never crash a request
        log.error("email send failed: %s", type(e).__name__)
        return False
