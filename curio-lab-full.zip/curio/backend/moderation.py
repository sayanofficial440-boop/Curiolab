"""Community moderation tools. Builds on community.py (profiles, reports of profiles) and discuss.py (reports of posts and groups).

  Learners (every call needs a community device key, Authorization: Bearer <key>)
  GET  /api/community/report-options            the report categories (the same list is used for profiles, posts, groups and study rooms)
  GET  /api/community/notices                   messages from moderators and replies to my reports (newest first)
  POST /api/community/notices/seen              mark them all read

  Admin
  GET  /api/admin/community/queue[?all=1]       ONE queue for every report: profiles, posts, groups and rooms, grouped by target,
                                                 urgent first, with who reported it, why, and the owner's moderation history
  POST /api/admin/community/queue/resolve       {kind: profile|post|group|room, ref, outcome: actioned|no_action}  closes every open report
                                                 on that target and tells each reporter (without naming anyone)
  GET  /api/admin/community/people/<handle>/history
  POST /api/admin/community/people/<handle>/warn    {reason}            a visible warning
  POST /api/admin/community/people/<handle>/mute    {reason, hours}     can't post, ask, answer, create groups/rooms or react for 1 hour to 30 days
  POST /api/admin/community/people/<handle>/unmute

Design rules (same spirit as community.py):
  * A mute is the step between "nothing" and "hide the whole profile": reading, voting and joining by code still work.
  * People are always told what happened to their content and why, and a wrongly hidden post is restored with an apology.
  * Reporters learn that a human looked, never what happened to the other person.
  * Nothing here stores more than the community already did: no IP, email or name. Leaving the community erases the history too, so a
    muted person can leave and join again as a new profile. That is a limit of device-key identity, not a bug; hide the profile if it matters.
"""
import re, time, logging, sqlite3
from flask import request, jsonify
from dbutil import db, too_many
import community as C

log = logging.getLogger("curiolab.moderation")

CATEGORIES = [
    ("spam", "Spam or advertising"),
    ("bullying", "Bullying, hate or threats"),
    ("inappropriate", "Not suitable for school"),
    ("personal", "Shares personal details"),
    ("selfharm", "Someone may need help"),
    ("wrong", "Wrong or misleading"),
    ("other", "Something else"),
]
CAT_LABEL = dict(CATEGORIES)
URGENT = {"selfharm", "bullying"}          # shown first in the queue
MUTE_MAX_HOURS = 24 * 30
NOTICE_KEEP = 30                           # per person
NOTICE_DAYS = 60
WHAT = {"post": "post", "group": "study group", "room": "study room", "profile": "profile"}


def _now():
    return int(time.time())


def _add_col(c, table, col, ddl):
    if col not in [r[1] for r in c.execute(f"PRAGMA table_info({table})").fetchall()]:
        c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")


def report_fields(d):
    """-> (category, reason) from a report request body, or (None, None) when neither was given.
    Older clients send only a free-text reason; newer ones send a category and an optional note."""
    cat = str(d.get("category") or "").strip().lower()
    reason = re.sub(r"\s+", " ", str(d.get("reason") or "")).strip()[:300]
    if cat and cat not in CAT_LABEL:
        cat = "other"
    if not cat and not reason:
        return None, None
    if not cat:
        cat = "other"
    if not reason:
        reason = CAT_LABEL[cat]
    return cat, reason


# ---------------------------------------------------------------- storage
def init(c):
    c.executescript("""
    CREATE TABLE IF NOT EXISTS cm_mod_actions(
      id INTEGER PRIMARY KEY, profile_id INTEGER, action TEXT, reason TEXT DEFAULT '', ref_kind TEXT DEFAULT '', ref_id TEXT DEFAULT '',
      created_at INTEGER, expires_at INTEGER DEFAULT 0);
    CREATE INDEX IF NOT EXISTS cm_mod_actions_p ON cm_mod_actions(profile_id, created_at);
    CREATE TABLE IF NOT EXISTS cm_notices(
      id INTEGER PRIMARY KEY, profile_id INTEGER, kind TEXT, text TEXT, created_at INTEGER, seen INTEGER DEFAULT 0);
    CREATE INDEX IF NOT EXISTS cm_notices_p ON cm_notices(profile_id, seen, created_at);
    """)
    for table in ("cm_content_reports", "cm_reports"):
        _add_col(c, table, "category", "TEXT DEFAULT ''")
        _add_col(c, table, "outcome", "TEXT DEFAULT ''")
    C.ERASE_HOOKS.append(erase)
    C.ME_EXTRAS.append(me_extras)


def erase(c, pid):
    c.execute("DELETE FROM cm_notices WHERE profile_id=?", (pid,))
    c.execute("DELETE FROM cm_mod_actions WHERE profile_id=?", (pid,))


def me_extras(c, pid):
    n = c.execute("SELECT COUNT(*) FROM cm_notices WHERE profile_id=? AND seen=0", (pid,)).fetchone()[0]
    m = mute_state(c, pid)
    return dict(notices=n, muted_until=m["expires_at"] if m else None)


# ---------------------------------------------------------------- notices, history, mutes (used by discuss.py and rooms.py too)
def notify(c, pid, kind, text):
    if not pid:
        return
    c.execute("INSERT INTO cm_notices(profile_id,kind,text,created_at) VALUES(?,?,?,?)", (pid, kind, text, _now()))
    c.execute("DELETE FROM cm_notices WHERE profile_id=? AND id NOT IN (SELECT id FROM cm_notices WHERE profile_id=? ORDER BY id DESC LIMIT ?)", (pid, pid, NOTICE_KEEP))
    c.execute("DELETE FROM cm_notices WHERE profile_id=? AND created_at<?", (pid, _now() - NOTICE_DAYS * 86400))


def record(c, pid, action, reason="", ref_kind="", ref_id="", expires_at=0):
    c.execute("INSERT INTO cm_mod_actions(profile_id,action,reason,ref_kind,ref_id,created_at,expires_at) VALUES(?,?,?,?,?,?,?)",
              (pid, action, (reason or "")[:300], ref_kind, str(ref_id), _now(), expires_at))


def mute_state(c, pid):
    return c.execute("SELECT * FROM cm_mod_actions WHERE profile_id=? AND action='mute' AND expires_at>? ORDER BY expires_at DESC LIMIT 1", (pid, _now())).fetchone()


def muted_response(c, me):
    """None when `me` may post; otherwise a ready (response, 403) pair for the route to return."""
    m = mute_state(c, me["id"])
    if not m:
        return None
    left = m["expires_at"] - _now()
    when = f"{max(1, round(left / 3600))} hour{'s' if round(left / 3600) != 1 else ''}" if left < 48 * 3600 else f"{round(left / 86400)} days"
    return jsonify(error=f"A moderator has paused your posting for about {when}. You can still read, vote and study. See your notices for why.",
                   muted_until=m["expires_at"]), 403


def on_content_action(c, owner_id, kind, action, ref):
    """Called when an admin hides, restores or deletes something a learner made. Records it and tells the owner."""
    what = WHAT.get(kind, "content")
    if action == "hide":
        record(c, owner_id, "hide", "", kind, ref)
        notify(c, owner_id, "hidden", f"A moderator hid your {what} while it is reviewed. You don't need to do anything.")
    elif action == "delete":
        record(c, owner_id, "delete", "", kind, ref)
        notify(c, owner_id, "removed", f"A moderator removed your {what} because it didn't follow the community rules (kind, school-appropriate, no personal details or links). You can still use the community.")
    elif action == "unhide":
        record(c, owner_id, "restore", "", kind, ref)
        notify(c, owner_id, "restored", f"A moderator looked again and put your {what} back. Sorry about the interruption.")


def on_auto_hide(c, owner_id, kind, ref):
    record(c, owner_id, "auto-hide", "", kind, ref)
    notify(c, owner_id, "hidden", f"Your {WHAT.get(kind, 'content')} was hidden after several learners reported it. A moderator will review it soon.")


def _counts(c, pid):
    rows = c.execute("SELECT action, COUNT(*) FROM cm_mod_actions WHERE profile_id=? GROUP BY action", (pid,)).fetchall()
    d = {r[0]: r[1] for r in rows}
    m = mute_state(c, pid)
    return dict(warnings=d.get("warn", 0), mutes=d.get("mute", 0), removed=d.get("delete", 0) + d.get("hide", 0) + d.get("auto-hide", 0),
                muted_until=m["expires_at"] if m else None)


# ---------------------------------------------------------------- routes
def register(app, admin_only, log_fn):
    def err(msg, code=400, **extra):
        return jsonify(error=msg, **extra), code

    def need_me():
        p = C._me()
        if not p:
            return None, err("Not signed in to the community. Join first, or restore your device key.", 401)
        return p, None          # a hidden profile can still read why (notices), it just can't do anything else

    def body():
        return request.get_json(silent=True) or {}

    @app.get("/api/community/report-options")
    def md_options():
        return jsonify(categories=[dict(id=k, label=v) for k, v in CATEGORIES])

    @app.get("/api/community/notices")
    def md_notices():
        me, e = need_me()
        if e:
            return e
        with db() as c:
            rows = c.execute("SELECT id, kind, text, created_at, seen FROM cm_notices WHERE profile_id=? ORDER BY id DESC LIMIT ?", (me["id"], NOTICE_KEEP)).fetchall()
            m = mute_state(c, me["id"])
        return jsonify(notices=[dict(r) for r in rows], muted_until=m["expires_at"] if m else None)

    @app.post("/api/community/notices/seen")
    def md_seen():
        me, e = need_me()
        if e:
            return e
        with db() as c:
            c.execute("UPDATE cm_notices SET seen=1 WHERE profile_id=?", (me["id"],))
        return jsonify(ok=True)

    # ================================================================ admin: the queue
    def _target(c, kind, ref):
        """-> dict(preview..., owner_id, owner, hidden) or None when the target is gone. Never raises on a missing optional table."""
        try:
            if kind == "post":
                p = c.execute("SELECT p.*, a.handle AS ah FROM cm_posts p LEFT JOIN cm_profiles a ON a.id=p.author WHERE p.id=?", (ref,)).fetchone()
                return dict(title=f"{p['kind']} on {p['lesson_id']}", text=p["body"], owner=p["ah"], owner_id=p["author"], hidden=p["hidden"], key=p["id"]) if p else None
            if kind == "group":
                g = c.execute("SELECT g.*, o.handle AS oh, (SELECT COUNT(*) FROM cm_group_members m WHERE m.group_id=g.id) AS n FROM cm_groups g LEFT JOIN cm_profiles o ON o.id=g.owner WHERE g.id=?", (ref,)).fetchone()
                return dict(title="Study group", text=g["name"], extra=f"{g['n']} members", owner=g["oh"], owner_id=g["owner"], hidden=g["hidden"], key=g["gid"]) if g else None
            if kind == "room":
                r = c.execute("SELECT r.*, o.handle AS oh, (SELECT COUNT(*) FROM cm_room_members m WHERE m.room_id=r.id) AS n FROM cm_rooms r LEFT JOIN cm_profiles o ON o.id=r.owner WHERE r.id=?", (ref,)).fetchone()
                return dict(title="Study room", text=r["name"], extra=f"{r['n']} in the room", owner=r["oh"], owner_id=r["owner"], hidden=r["hidden"], key=r["rid"]) if r else None
            if kind == "profile":
                t = c.execute("SELECT * FROM cm_profiles WHERE id=?", (ref,)).fetchone()
                return dict(title="Profile", text=(t["display_name"] or t["handle"]) + ("\n" + t["bio"] if t["bio"] else ""), owner=t["handle"], owner_id=t["id"], hidden=t["hidden"], key=t["handle"]) if t else None
        except sqlite3.OperationalError:
            return None
        return None

    @app.get("/api/admin/community/queue")
    @admin_only
    def md_queue():
        show_all = request.args.get("all") == "1"
        items = []
        c = db()
        groups = []
        for kind in ("post", "group", "room"):
            try:
                rows = c.execute("SELECT ref, COUNT(DISTINCT reporter) AS n, MIN(created_at) AS first_at, MAX(created_at) AS last_at, MAX(handled) AS handled FROM cm_content_reports "
                                 "WHERE kind=? GROUP BY ref HAVING " + ("1" if show_all else "MIN(handled)=0") + " ORDER BY MAX(id) DESC LIMIT 200", (kind,)).fetchall()
            except sqlite3.OperationalError:
                rows = []
            for r in rows:
                groups.append((kind, r["ref"], r))
        for r in c.execute("SELECT target AS ref, COUNT(DISTINCT reporter) AS n, MIN(created_at) AS first_at, MAX(created_at) AS last_at, MAX(handled) AS handled FROM cm_reports "
                           "GROUP BY target HAVING " + ("1" if show_all else "MIN(handled)=0") + " ORDER BY MAX(id) DESC LIMIT 200").fetchall():
            groups.append(("profile", r["ref"], r))
        for kind, ref, r in groups:
            table = "cm_reports" if kind == "profile" else "cm_content_reports"
            where = "target=?" if kind == "profile" else "kind=? AND ref=?"
            args = (ref,) if kind == "profile" else (kind, ref)
            rep = c.execute(f"SELECT x.category, x.reason, x.created_at, x.handled, x.outcome, f.handle AS who FROM {table} x LEFT JOIN cm_profiles f ON f.id=x.reporter WHERE {where} ORDER BY x.id DESC LIMIT 8", args).fetchall()
            cats = {}
            for k, n in c.execute(f"SELECT category, COUNT(*) FROM {table} WHERE {where} AND handled=0 GROUP BY category", args).fetchall():
                cats[k or "other"] = n
            t = _target(c, kind, ref)
            open_n = c.execute(f"SELECT COUNT(*) FROM {table} WHERE {where} AND handled=0", args).fetchone()[0]
            items.append(dict(kind=kind, ref=(t or {}).get("key", ref), reporters=r["n"], first_at=r["first_at"], last_at=r["last_at"], open=open_n > 0,
                              categories=cats, urgent=any(k in URGENT for k in cats), target=t and {k: v for k, v in t.items() if k != "owner_id"},
                              history=_counts(c, t["owner_id"]) if t and t.get("owner_id") else None,
                              reports=[dict(category=x["category"] or "other", reason=x["reason"], created_at=x["created_at"], reporter=x["who"], handled=x["handled"], outcome=x["outcome"]) for x in rep]))
        items.sort(key=lambda i: (not i["open"], not i["urgent"], -i["reporters"], -i["last_at"]))
        return jsonify(items=items, categories=[dict(id=k, label=v) for k, v in CATEGORIES], open=sum(1 for i in items if i["open"]))

    @app.post("/api/admin/community/queue/resolve")
    @admin_only
    def md_resolve():
        d = body()
        kind, outcome = str(d.get("kind") or ""), str(d.get("outcome") or "")
        if kind not in WHAT or outcome not in ("actioned", "no_action"):
            return err("Say what to close and how.")
        with db() as c:
            ref = d.get("ref")
            if kind == "profile":
                t = c.execute("SELECT id FROM cm_profiles WHERE handle=?", (str(ref or "").strip().lower(),)).fetchone()
                if not t:
                    return err("No such profile.", 404)
                ref = t["id"]
                table, where, args = "cm_reports", "target=?", (ref,)
            else:
                if kind == "group":
                    g = c.execute("SELECT id FROM cm_groups WHERE gid=?", (str(ref or ""),)).fetchone()
                    ref = g["id"] if g else None
                elif kind == "room":
                    try:
                        g = c.execute("SELECT id FROM cm_rooms WHERE rid=?", (str(ref or ""),)).fetchone()
                    except sqlite3.OperationalError:
                        g = None
                    ref = g["id"] if g else None
                else:
                    ref = C._i(ref, 0, 2 ** 40) or None
                if ref is None:
                    return err("That target is already gone. Its reports were removed with it.", 404)
                table, where, args = "cm_content_reports", "kind=? AND ref=?", (kind, ref)
            who = [r[0] for r in c.execute(f"SELECT DISTINCT reporter FROM {table} WHERE {where} AND handled=0", args).fetchall()]
            c.execute(f"UPDATE {table} SET handled=1, outcome=? WHERE {where} AND handled=0", (outcome,) + args)
            text = ("Thanks for your report. A moderator looked at it and took action." if outcome == "actioned"
                    else "Thanks for your report. A moderator looked at it and decided no action was needed. If something still feels wrong, you can report again or talk to a trusted adult.")
            for pid in who:
                notify(c, pid, "report-" + outcome, text)
        log_fn("community_report_" + outcome, "-", "-", f"{kind}={d.get('ref')}")
        return jsonify(ok=True, notified=len(who))

    # ================================================================ admin: people
    def _person(c, handle):
        return c.execute("SELECT * FROM cm_profiles WHERE handle=?", (str(handle or "").strip().lower().lstrip("@"),)).fetchone()

    @app.get("/api/admin/community/people/<handle>/history")
    @admin_only
    def md_history(handle):
        with db() as c:
            t = _person(c, handle)
            if not t:
                return err("No such profile.", 404)
            rows = c.execute("SELECT action, reason, ref_kind, ref_id, created_at, expires_at FROM cm_mod_actions WHERE profile_id=? ORDER BY id DESC LIMIT 50", (t["id"],)).fetchall()
            reports_on = c.execute("SELECT COUNT(*) FROM cm_reports WHERE target=?", (t["id"],)).fetchone()[0]
            return jsonify(handle=t["handle"], hidden=bool(t["hidden"]), visibility=t["visibility"], joined=t["created_at"], reports_on_profile=reports_on,
                           summary=_counts(c, t["id"]), actions=[dict(r) for r in rows])

    @app.post("/api/admin/community/people/<handle>/<action>")
    @admin_only
    def md_person(handle, action):
        if action not in ("warn", "mute", "unmute"):
            return err("Unknown action.", 404)
        d = body()
        reason = re.sub(r"\s+", " ", str(d.get("reason") or "")).strip()[:200]
        with db() as c:
            t = _person(c, handle)
            if not t:
                return err("No such profile.", 404)
            if action in ("warn", "mute") and not reason:
                return err("Write a short reason. The learner will read it.")
            if action == "warn":
                record(c, t["id"], "warn", reason)
                notify(c, t["id"], "warning", f"A moderator sent you a warning: {reason}")
            elif action == "mute":
                hours = max(1, min(MUTE_MAX_HOURS, C._i(d.get("hours"), 0, 10 ** 6) or 24))
                until = _now() + hours * 3600
                record(c, t["id"], "mute", reason, expires_at=until)
                notify(c, t["id"], "muted", f"A moderator has paused your posting for {hours} hour{'s' if hours != 1 else ''}: {reason}. You can still read, vote and study.")
            else:
                c.execute("UPDATE cm_mod_actions SET expires_at=? WHERE profile_id=? AND action='mute' AND expires_at>?", (_now(), t["id"], _now()))
                record(c, t["id"], "unmute", reason)
                notify(c, t["id"], "unmuted", "A moderator lifted the pause on your posting. Thanks for your patience.")
        log_fn("community_" + action, "-", "-", f"handle={handle}")
        return jsonify(ok=True)
