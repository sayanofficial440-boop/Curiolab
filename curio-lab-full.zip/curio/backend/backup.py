"""Automatic SQLite backups.

Uses SQLite's online backup API, so it is safe while the site is running (a plain file copy of a live database can be
corrupt). Each backup is integrity-checked, gzip-compressed, written with owner-only permissions, and old ones are pruned.

  python backup.py                 take a backup now (use this from cron if you run several workers)
  python backup.py --verify FILE   check that a backup opens and passes PRAGMA integrity_check
  python backup.py --restore FILE  copy a backup over the live database (stop the app first!)

Environment: BACKUP_DIR (default <db folder>/backups), BACKUP_KEEP (default 14), BACKUP_EVERY_HOURS (default 24, 0 = off),
BACKUP_COPY_DIR (optional second location, e.g. a mounted drive; backups are copied there too).
A backup on the same disk does not protect you from losing the disk: point BACKUP_COPY_DIR at other storage or copy
BACKUP_DIR off the machine.
"""
import os, sys, time, glob, gzip, shutil, sqlite3, threading, logging, tempfile

from dbutil import DB

log = logging.getLogger("curiolab.backup")
PREFIX = "curiolab-"


def backup_dir():
    return os.environ.get("BACKUP_DIR") or os.path.join(os.path.dirname(os.path.abspath(DB)), "backups")


def _files(d=None):
    return sorted(glob.glob(os.path.join(d or backup_dir(), PREFIX + "*.db.gz")))


def backup_now():
    """Create one verified, compressed backup. Returns its path. Raises on failure (never leaves a half-written file)."""
    d = backup_dir()
    os.makedirs(d, mode=0o700, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    final = os.path.join(d, f"{PREFIX}{stamp}.db.gz")
    tmp_db = tempfile.NamedTemporaryFile(dir=d, suffix=".tmp", delete=False).name
    try:
        src = sqlite3.connect(DB)
        dst = sqlite3.connect(tmp_db)
        try:
            src.backup(dst)
        finally:
            dst.close(); src.close()
        chk = sqlite3.connect(tmp_db)
        try:
            res = chk.execute("PRAGMA integrity_check").fetchone()[0]
        finally:
            chk.close()
        if res != "ok":
            raise RuntimeError("integrity check failed on new backup: " + str(res))
        with open(tmp_db, "rb") as f_in, gzip.open(final + ".part", "wb", compresslevel=6) as f_out:
            shutil.copyfileobj(f_in, f_out)
        os.chmod(final + ".part", 0o600)
        os.replace(final + ".part", final)
    finally:
        for p in (tmp_db, final + ".part"):
            try: os.remove(p)
            except OSError: pass
    extra = os.environ.get("BACKUP_COPY_DIR")
    if extra:
        try:
            os.makedirs(extra, mode=0o700, exist_ok=True)
            shutil.copy2(final, os.path.join(extra, os.path.basename(final)))
            prune(extra)
        except Exception:
            log.exception("could not copy backup to BACKUP_COPY_DIR")
    prune(d)
    log.info("backup written: %s", final)
    return final


def prune(d=None):
    keep = max(1, int(os.environ.get("BACKUP_KEEP", "14")))
    for old in _files(d)[:-keep]:
        try: os.remove(old)
        except OSError: pass


def verify(path):
    """True when the backup decompresses, opens as SQLite and passes integrity_check."""
    with tempfile.TemporaryDirectory() as t:
        out = os.path.join(t, "v.db")
        with gzip.open(path, "rb") as f_in, open(out, "wb") as f_out:
            shutil.copyfileobj(f_in, f_out)
        c = sqlite3.connect(out)
        try:
            return c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        finally:
            c.close()


def restore(path):
    if not verify(path):
        raise RuntimeError("refusing to restore: backup failed verification")
    with gzip.open(path, "rb") as f_in, open(DB + ".restoring", "wb") as f_out:
        shutil.copyfileobj(f_in, f_out)
    os.replace(DB + ".restoring", DB)


def due():
    every = float(os.environ.get("BACKUP_EVERY_HOURS", "24"))
    if every <= 0:
        return False
    fs = _files()
    return not fs or time.time() - os.path.getmtime(fs[-1]) >= every * 3600


def _loop():
    while True:
        try:
            if due():
                backup_now()
        except Exception:
            log.exception("scheduled backup failed")
        time.sleep(3600)  # check hourly; a restart never skips or repeats a backup because 'due' looks at the newest file


def start():
    """Start the background scheduler (single-worker setups). With several workers set BACKUP_EVERY_HOURS=0 and use cron."""
    if float(os.environ.get("BACKUP_EVERY_HOURS", "24")) > 0:
        threading.Thread(target=_loop, daemon=True, name="curiolab-backup").start()


if __name__ == "__main__":
    a = sys.argv[1:]
    if a[:1] == ["--verify"] and len(a) == 2:
        good = verify(a[1]); print("OK" if good else "BAD"); sys.exit(0 if good else 1)
    elif a[:1] == ["--restore"] and len(a) == 2:
        restore(a[1]); print("restored", a[1])
    else:
        print(backup_now())
