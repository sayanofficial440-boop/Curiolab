"""Community, part 3: live "study with me" rooms with a shared Pomodoro timer. Builds on community.py (profiles, device keys, blocks),
discuss.py (study groups, text screening) and moderation.py (reports, mutes).

  GET  /api/community/rooms                        the room I'm in, plus live rooms of the study groups I belong to
  POST /api/community/rooms/create                 {name, subject?, focus?, break?, long?, rounds?, group?}   I become the host
  POST /api/community/rooms/join                   {code}  or  {room}  (a room linked to one of my study groups)
  GET  /api/community/rooms/<rid>/state?since=<n>  heartbeat + everything the screen needs (timer, people, reactions). Poll every ~5 s
  POST /api/community/rooms/<rid>/control          {action: start|pause|resume|skip|reset}            host only
  POST /api/community/rooms/<rid>/settings         {name, subject, focus, break, long, rounds}        host only (timer lengths only while the timer is idle)
  POST /api/community/rooms/<rid>/me               {task, subject}      what I'm working on, chosen from a fixed list (no free text)
  POST /api/community/rooms/<rid>/react            {kind}               cheer | fire | coffee | clap | water
  POST /api/community/rooms/<rid>/kick             {handle}             host only; they can't come back to this room
  POST /api/community/rooms/<rid>/lock             {locked}             host only; nobody new can join
  POST /api/community/rooms/<rid>/rotate           host only; new invite code
  POST /api/community/rooms/<rid>/report           {category, reason?}
  POST /api/community/rooms/<rid>/leave   |   DELETE /api/community/rooms/<rid>   (close it; host only)
  Admin: GET /api/admin/community/rooms, POST /api/admin/community/rooms/<rid>/hide|unhide|delete

How the shared timer works
  The SERVER owns the clock. A room stores the phase (focus / break / long break), when it started and how long it lasts. Each response says what
  time the server thinks it is, so a browser shows `ends_at - server_now` and everyone sees the same seconds, whatever their device clock says.
  Phases roll over by themselves (focus -> break -> focus ... a long break after every N focus blocks), computed from the stored times each time
  anyone asks, so nothing needs a background job and a slow poll never drifts the timer. The host can start, pause, resume, skip or reset.

Safety rules built in (same spirit as community.py and discuss.py)
  * Joined learners 13+ only. Invite code only (or a study group you are in): there is no directory and no search.
  * No chat and no free text from members. A room has a name (screened like a group name); everyone else says what they're doing by picking from
    a fixed list, and cheers each other with five preset emoji. There is nothing to type, so there is nothing to bully with.
  * Blocked people can't join the same room or see each other in it. The host can lock the room, remove people and change the code.
  * Rooms give NO XP, so they can't be farmed. "Focus blocks done" is just a friendly counter.
  * Reports use the same categories as everywhere else. 3 different reporters close a room until a moderator looks at it.
  * Rooms are temporary: a room nobody has touched for 15 minutes is deleted, and so is anything it held. Leaving the community erases the rest.
"""
import re, time, secrets, logging, sqlite3
from collections import deque
from flask import request, jsonify
from dbutil import db, too_many
import community as C
import discuss as D
import moderation as M

log = logging.getLogger("curiolab.rooms")

ROOM_MAX = 20
PRESENT_SECS = 45                  # seen this recently = "here"; a hidden browser tab polls more slowly, so be generous
AWAY_DROP_SECS = 10 * 60           # not seen for this long = left the room
DEAD_SECS = 15 * 60                # a room nobody has polled for this long is deleted
GRACE = 30                         # a focus block counts for people seen within this many seconds of its end
AUTO_CLOSE_AT = 3                  # distinct reporters that close a room until a moderator decides
LIMITS = dict(focus=(10, 90, 25), short=(3, 20, 5), long=(10, 45, 15), rounds=(2, 8, 4))
TASKS = ["Reading", "Practising problems", "Revising notes", "Writing", "Quiz prep", "Just being here"]
REACTS = {"cheer": "🎉", "fire": "🔥", "coffee": "☕", "clap": "👏", "water": "💧"}
CODE_ALPHABET = D.CODE_ALPHABET


def _now():
    return time.time()


# ---------------------------------------------------------------- the timer (pure functions, so they can be tested without HTTP)
def phase_len(st, phase):
    return {"focus": st["focus_min"], "break": st["break_min"], "long": st["long_min"]}[phase] * 60


def advance(st, now):
    """Roll the timer forward to `now`. `st` needs: phase, started_at, length, paused_left, cycle, total_focus, rounds, focus_min, break_min, long_min.
    Returns (new_state, [end times of focus blocks that completed]). A paused or idle timer doesn't move."""
    st = dict(st)
    ends = []
    if st["phase"] == "idle" or st["paused_left"] is not None:
        return st, ends
    for _ in range(300):
        end = st["started_at"] + st["length"]
        if now < end:
            return st, ends
        if st["phase"] == "focus":
            st["cycle"] += 1
            st["total_focus"] += 1
            ends.append(end)
            nxt = "long" if st["cycle"] % st["rounds"] == 0 else "break"
        else:
            nxt = "focus"
        st.update(phase=nxt, started_at=end, length=phase_len(st, nxt))
    st["started_at"] = now          # hopelessly behind (a room nobody asked about for hours): start the current phase afresh
    return st, ends


def control(st, action, now):
    """Host controls. -> (new_state, error_message_or_None)."""
    st = dict(st)
    idle, paused = st["phase"] == "idle", st["paused_left"] is not None
    if action == "start":
        if not idle:
            return st, "The timer is already running."
        st.update(phase="focus", started_at=now, length=phase_len(st, "focus"), paused_left=None)
    elif action == "pause":
        if idle or paused:
            return st, "The timer isn't running."
        st["paused_left"] = max(1.0, st["started_at"] + st["length"] - now)
    elif action == "resume":
        if not paused:
            return st, "The timer isn't paused."
        st.update(started_at=now - (st["length"] - st["paused_left"]), paused_left=None)
    elif action == "skip":
        if idle:
            return st, "Start the timer first."
        nxt = "focus" if st["phase"] != "focus" else "break"      # skipping a focus block doesn't count it
        st.update(phase=nxt, started_at=now, length=phase_len(st, nxt), paused_left=None)
    elif action == "reset":
        st.update(phase="idle", started_at=0, length=0, paused_left=None, cycle=0)
    else:
        return st, "Unknown action."
    return st, None


# ---------------------------------------------------------------- storage
def init(c):
    c.executescript("""
    CREATE TABLE IF NOT EXISTS cm_rooms(
      id INTEGER PRIMARY KEY, rid TEXT UNIQUE, code TEXT UNIQUE, name TEXT, owner INTEGER, group_id INTEGER DEFAULT 0, subject TEXT DEFAULT '',
      focus_min INTEGER DEFAULT 25, break_min INTEGER DEFAULT 5, long_min INTEGER DEFAULT 15, rounds INTEGER DEFAULT 4,
      phase TEXT DEFAULT 'idle', started_at REAL DEFAULT 0, length INTEGER DEFAULT 0, paused_left REAL, cycle INTEGER DEFAULT 0, total_focus INTEGER DEFAULT 0,
      locked INTEGER DEFAULT 0, hidden INTEGER DEFAULT 0, created_at INTEGER, last_active REAL);
    CREATE INDEX IF NOT EXISTS cm_rooms_group ON cm_rooms(group_id);
    CREATE TABLE IF NOT EXISTS cm_room_members(
      room_id INTEGER, profile_id INTEGER, role TEXT, joined_at REAL, last_seen REAL, task TEXT DEFAULT '', subject TEXT DEFAULT '', blocks INTEGER DEFAULT 0,
      PRIMARY KEY(room_id, profile_id));
    CREATE INDEX IF NOT EXISTS cm_rm_profile ON cm_room_members(profile_id);
    CREATE TABLE IF NOT EXISTS cm_room_bans(room_id INTEGER, profile_id INTEGER, PRIMARY KEY(room_id, profile_id));
    CREATE TABLE IF NOT EXISTS cm_room_reacts(id INTEGER PRIMARY KEY, room_id INTEGER, profile_id INTEGER, kind TEXT, created_at REAL);
    CREATE INDEX IF NOT EXISTS cm_rr_room ON cm_room_reacts(room_id, id);
    """)
    C.ERASE_HOOKS.append(erase)


def _delete_room(c, room_id):
    for t in ("cm_room_members", "cm_room_bans", "cm_room_reacts"):
        c.execute(f"DELETE FROM {t} WHERE room_id=?", (room_id,))
    c.execute("DELETE FROM cm_content_reports WHERE kind='room' AND ref=?", (room_id,))
    c.execute("DELETE FROM cm_rooms WHERE id=?", (room_id,))


def _leave(c, r, pid):
    """Remove one person; if they were the host, hand the room to the longest-standing person who's here, or close it."""
    if r["owner"] == pid:
        nxt = c.execute("SELECT profile_id FROM cm_room_members WHERE room_id=? AND profile_id!=? ORDER BY (last_seen>=?) DESC, joined_at, profile_id LIMIT 1",
                        (r["id"], pid, _now() - PRESENT_SECS)).fetchone()
        if not nxt:
            _delete_room(c, r["id"])
            return
        c.execute("UPDATE cm_rooms SET owner=? WHERE id=?", (nxt[0], r["id"]))
        c.execute("UPDATE cm_room_members SET role='owner' WHERE room_id=? AND profile_id=?", (r["id"], nxt[0]))
    c.execute("DELETE FROM cm_room_members WHERE room_id=? AND profile_id=?", (r["id"], pid))


def erase(c, pid):
    for r in c.execute("SELECT r.* FROM cm_rooms r JOIN cm_room_members m ON m.room_id=r.id WHERE m.profile_id=?", (pid,)).fetchall():
        _leave(c, r, pid)
    c.execute("DELETE FROM cm_room_members WHERE profile_id=?", (pid,))
    c.execute("DELETE FROM cm_room_bans WHERE profile_id=?", (pid,))
    c.execute("DELETE FROM cm_room_reacts WHERE profile_id=?", (pid,))
    for r in c.execute("SELECT id FROM cm_rooms WHERE owner=?", (pid,)).fetchall():       # owner with nobody else in it (defensive)
        _delete_room(c, r["id"])


def _sweep(c):
    for r in c.execute("SELECT id FROM cm_rooms WHERE last_active<?", (_now() - DEAD_SECS,)).fetchall():
        _delete_room(c, r["id"])


def _clamp(v, key, default=None):
    lo, hi, dflt = LIMITS[key]
    try:
        n = int(v)
    except (TypeError, ValueError):
        n = dflt if default is None else default
    return max(lo, min(hi, n))


_polls = {}        # profile id -> recent poll times (in memory on purpose: a heartbeat every 5 s must not write a rate-limit row)


def _poll_limited(pid):
    now = time.time()
    q = _polls.setdefault(pid, deque())
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= 40:
        return True
    q.append(now)
    if len(_polls) > 5000:
        for k in [k for k, v in _polls.items() if not v or now - v[-1] > 60]:
            _polls.pop(k, None)
    return False


_last_react = {}


def _react_limited(pid):
    now = time.time()
    if now - _last_react.get(pid, 0) < 3:
        return True
    _last_react[pid] = now
    if len(_last_react) > 5000:
        for k in [k for k, v in _last_react.items() if now - v > 60]:
            _last_react.pop(k, None)
    return False


# ---------------------------------------------------------------- routes
def register(app, admin_only, log_fn):
    def err(msg, code=400, **extra):
        return jsonify(error=msg, **extra), code

    def need_me():
        p = C._me()
        if not p:
            return None, err("Not signed in to the community. Join first, or restore your device key.", 401)
        if p["hidden"]:
            return None, err("This profile has been hidden by a moderator.", 403)
        return p, None

    def body():
        return request.get_json(silent=True) or {}

    def _state_of(r):
        return dict(phase=r["phase"], started_at=r["started_at"], length=r["length"], paused_left=r["paused_left"], cycle=r["cycle"], total_focus=r["total_focus"],
                    rounds=r["rounds"], focus_min=r["focus_min"], break_min=r["break_min"], long_min=r["long_min"])

    def _settle(c, r, now):
        """Apply the clock to a room row, give credit for finished focus blocks, save, and return the fresh row."""
        st, ends = advance(_state_of(r), now)
        if st != _state_of(r):
            c.execute("UPDATE cm_rooms SET phase=?, started_at=?, length=?, paused_left=?, cycle=?, total_focus=? WHERE id=?",
                      (st["phase"], st["started_at"], st["length"], st["paused_left"], st["cycle"], st["total_focus"], r["id"]))
            for end in ends:
                c.execute("UPDATE cm_room_members SET blocks=blocks+1 WHERE room_id=? AND last_seen>=? AND joined_at<=?", (r["id"], end - GRACE, end - r["focus_min"] * 30))
            r = c.execute("SELECT * FROM cm_rooms WHERE id=?", (r["id"],)).fetchone()
        return r

    def _timer_out(r):
        paused = r["paused_left"] is not None
        running = r["phase"] != "idle" and not paused
        return dict(phase=r["phase"], length=r["length"], ends_at=(r["started_at"] + r["length"]) if running else None, paused=paused, left=r["paused_left"] if paused else None,
                    cycle=r["cycle"] % r["rounds"], rounds=r["rounds"], total=r["total_focus"], focus=r["focus_min"], short=r["break_min"], long=r["long_min"])

    def _members(c, r, me):
        now = _now()
        blocked = set(D._blocked_ids(c, me["id"]))
        friends = D._friend_ids(c, me["id"])
        rows = c.execute("""SELECT m.role, m.last_seen, m.task, m.subject AS m_subject, m.blocks, m.joined_at, p.id, p.handle, p.display_name, p.avatar, p.visibility, p.hidden
                            FROM cm_room_members m JOIN cm_profiles p ON p.id=m.profile_id WHERE m.room_id=? ORDER BY m.joined_at""", (r["id"],)).fetchall()
        out, away_hidden = [], 0
        for x in rows:
            if x["hidden"] or (x["id"] in blocked and x["id"] != me["id"]):
                away_hidden += 1
                continue
            person = D._person(x, friends, me["id"])
            out.append(dict(person, role=x["role"], you=x["id"] == me["id"], here=now - x["last_seen"] <= PRESENT_SECS, task=x["task"], subject=x["m_subject"], blocks=x["blocks"]))
        out.sort(key=lambda m: (not m["here"], m["role"] != "owner", m["name"].lower()))
        return out

    def _room_out(c, r, me, detail=True):
        g = c.execute("SELECT gid, name FROM cm_groups WHERE id=?", (r["group_id"],)).fetchone() if r["group_id"] else None
        o = dict(id=r["rid"], name=r["name"], subject=r["subject"], role="owner" if r["owner"] == me["id"] else "member", locked=bool(r["locked"]),
                 group=dict(id=g["gid"], name=g["name"]) if g else None, timer=_timer_out(r), now=_now(), limit=ROOM_MAX)
        if detail:
            o.update(members=_members(c, r, me), invite=D._fmt_code(r["code"]), tasks=TASKS, reacts=REACTS)
        return o

    def _my_room(c, me):
        return c.execute("SELECT r.* FROM cm_rooms r JOIN cm_room_members m ON m.room_id=r.id WHERE m.profile_id=? ORDER BY m.last_seen DESC LIMIT 1", (me["id"],)).fetchone()

    def _open(c, me, rid, host=False):
        """-> (room_row, error). The caller must be a member. A moderator-closed room says so to the people inside it."""
        r = c.execute("SELECT * FROM cm_rooms WHERE rid=?", (str(rid or ""),)).fetchone()
        m = c.execute("SELECT * FROM cm_room_members WHERE room_id=? AND profile_id=?", (r["id"], me["id"])).fetchone() if r else None
        if not r or not m:
            return None, err("That room has closed. Rooms close when nobody has been in them for a while.", 404, closed=True)
        if r["hidden"]:
            return None, err("This room was closed by a moderator.", 410, closed=True)
        if host and r["owner"] != me["id"]:
            return None, err("Only the host can do that.", 403)
        return r, None

    def _can_enter(c, me, r):
        """Why `me` can't join `r`, or None. Blocked pairs, kicked people, locked and full rooms all look like 'no such room' where it matters."""
        if r["hidden"] or c.execute("SELECT 1 FROM cm_room_bans WHERE room_id=? AND profile_id=?", (r["id"], me["id"])).fetchone():
            return "That room code doesn't work. Check it with the person who invited you."
        ids = [x[0] for x in c.execute("SELECT profile_id FROM cm_room_members WHERE room_id=?", (r["id"],)).fetchall()]
        if any(C._blocked(c, me["id"], x) for x in ids):
            return "That room code doesn't work. Check it with the person who invited you."
        if r["locked"]:
            return "The host has locked this room, so nobody new can come in right now."
        if len(ids) >= ROOM_MAX:
            return f"That room is full ({ROOM_MAX} people)."
        return None

    def _enter(c, me, r):
        for old in c.execute("SELECT r.* FROM cm_rooms r JOIN cm_room_members m ON m.room_id=r.id WHERE m.profile_id=? AND r.id!=?", (me["id"], r["id"])).fetchall():
            _leave(c, old, me["id"])               # one room at a time
        if not c.execute("SELECT 1 FROM cm_room_members WHERE room_id=? AND profile_id=?", (r["id"], me["id"])).fetchone():
            c.execute("INSERT INTO cm_room_members(room_id,profile_id,role,joined_at,last_seen) VALUES(?,?,?,?,?)", (r["id"], me["id"], "owner" if r["owner"] == me["id"] else "member", _now(), _now()))
        c.execute("UPDATE cm_rooms SET last_active=? WHERE id=?", (_now(), r["id"]))

    # ---------------------------------------------------------------- lobby
    @app.get("/api/community/rooms")
    def rm_home():
        me, e = need_me()
        if e:
            return e
        with db() as c:
            _sweep(c)
            cur = _my_room(c, me)
            current = None
            if cur and not cur["hidden"]:
                cur = _settle(c, cur, _now())
                current = _room_out(c, cur, me)
            live = []
            blocked = set(D._blocked_ids(c, me["id"]))
            for r in c.execute("""SELECT r.*, g.gid AS g_gid, g.name AS g_name FROM cm_rooms r JOIN cm_groups g ON g.id=r.group_id
                                  JOIN cm_group_members gm ON gm.group_id=g.id AND gm.profile_id=? WHERE r.hidden=0 AND g.hidden=0 ORDER BY r.created_at DESC LIMIT 20""", (me["id"],)).fetchall():
                if r["owner"] in blocked:
                    continue
                n = c.execute("SELECT COUNT(*) FROM cm_room_members WHERE room_id=? AND last_seen>=?", (r["id"], _now() - PRESENT_SECS)).fetchone()[0]
                if n:
                    live.append(dict(id=r["rid"], name=r["name"], group=dict(id=r["g_gid"], name=r["g_name"]), here=n, phase=r["phase"], locked=bool(r["locked"]), mine=bool(current and current["id"] == r["rid"])))
            mute = M.mute_state(c, me["id"])
            groups = [dict(id=g["gid"], name=g["name"]) for g in c.execute("SELECT g.gid, g.name FROM cm_groups g JOIN cm_group_members m ON m.group_id=g.id WHERE m.profile_id=? AND g.hidden=0 ORDER BY m.joined_at", (me["id"],)).fetchall()]
        return jsonify(current=current, group_rooms=live, groups=groups, subjects=C.SUBJECTS, limits=dict(focus=LIMITS["focus"], short=LIMITS["short"], long=LIMITS["long"], rounds=LIMITS["rounds"], people=ROOM_MAX),
                       muted_until=mute["expires_at"] if mute else None)

    @app.post("/api/community/rooms/create")
    def rm_create():
        me, e = need_me()
        if e:
            return e
        d = body()
        name, bad, _ = D.screen(d.get("name"), 40, "Room name", 3)
        if bad:
            return err(bad)
        subject = d.get("subject") if d.get("subject") in C.SUBJECTS else ""
        with db() as c:                                    # read-only checks first, so a refused attempt doesn't use up today's allowance
            m = M.muted_response(c, me)
            if m:
                return m
            gid = 0
            if d.get("group"):
                g = c.execute("SELECT g.* FROM cm_groups g JOIN cm_group_members m ON m.group_id=g.id WHERE g.gid=? AND m.profile_id=? AND g.hidden=0", (str(d.get("group")), me["id"])).fetchone()
                if not g:
                    return err("You can only open a room for a study group you're in.", 404)
                if c.execute("SELECT 1 FROM cm_rooms WHERE group_id=? AND hidden=0 AND last_active>=?", (g["id"], _now() - DEAD_SECS)).fetchone():
                    return err("That group already has a room open. Join it from the Rooms tab.")
                gid = g["id"]
        if too_many("cm-rcreate", str(me["id"]), 6, 86400):
            return err("You've opened several rooms today. Try again tomorrow.", 429)
        with db() as c:
            _sweep(c)
            rid = secrets.token_urlsafe(8)
            for _ in range(8):
                code = "".join(secrets.choice(CODE_ALPHABET) for _ in range(8))
                if not c.execute("SELECT 1 FROM cm_rooms WHERE code=?", (code,)).fetchone():
                    break
            cur = c.execute("INSERT INTO cm_rooms(rid,code,name,owner,group_id,subject,focus_min,break_min,long_min,rounds,created_at,last_active) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                            (rid, code, name, me["id"], gid, subject, _clamp(d.get("focus"), "focus"), _clamp(d.get("break"), "short"), _clamp(d.get("long"), "long"), _clamp(d.get("rounds"), "rounds"), int(_now()), _now()))
            r = c.execute("SELECT * FROM cm_rooms WHERE id=?", (cur.lastrowid,)).fetchone()
            _enter(c, me, r)
            return jsonify(ok=True, room=_room_out(c, r, me))

    @app.post("/api/community/rooms/join")
    def rm_join():
        me, e = need_me()
        if e:
            return e
        if too_many("cm-rjoin", str(me["id"]), 30, 3600):
            return err("Too many tries. Please wait a while.", 429)
        d = body()
        with db() as c:
            _sweep(c)
            if d.get("room"):
                r = c.execute("SELECT r.* FROM cm_rooms r JOIN cm_group_members gm ON gm.group_id=r.group_id AND gm.profile_id=? WHERE r.rid=?", (me["id"], str(d.get("room")))).fetchone()
            else:
                code = D._norm_code(d.get("code"))
                r = c.execute("SELECT * FROM cm_rooms WHERE code=?", (code,)).fetchone() if len(code) == 8 else None
            if not r or r["hidden"]:
                return err("That room code doesn't work. Check it with the person who invited you.", 404)
            if not c.execute("SELECT 1 FROM cm_room_members WHERE room_id=? AND profile_id=?", (r["id"], me["id"])).fetchone():
                why = _can_enter(c, me, r)
                if why:
                    return err(why, 404 if "doesn't work" in why else 403)
            _enter(c, me, r)
            r = _settle(c, r, _now())
            return jsonify(ok=True, room=_room_out(c, r, me))

    # ---------------------------------------------------------------- inside a room
    @app.get("/api/community/rooms/<rid>/state")
    def rm_state(rid):
        me, e = need_me()
        if e:
            return e
        if _poll_limited(me["id"]):
            return err("Slow down a little.", 429)
        try:
            since = max(-1, min(2 ** 40, int(request.args.get("since"))))
        except (TypeError, ValueError):
            since = -1                  # first poll: don't replay old reactions
        with db() as c:
            r, e = _open(c, me, rid)
            if e:
                return e
            now = _now()
            c.execute("UPDATE cm_room_members SET last_seen=? WHERE room_id=? AND profile_id=?", (now, r["id"], me["id"]))
            c.execute("UPDATE cm_rooms SET last_active=? WHERE id=?", (now, r["id"]))
            for x in c.execute("SELECT profile_id FROM cm_room_members WHERE room_id=? AND last_seen<? AND profile_id!=?", (r["id"], now - AWAY_DROP_SECS, me["id"])).fetchall():
                _leave(c, r, x[0])
                r = c.execute("SELECT * FROM cm_rooms WHERE id=?", (r["id"],)).fetchone()
            r = _settle(c, r, now)
            c.execute("DELETE FROM cm_room_reacts WHERE room_id=? AND created_at<?", (r["id"], now - 120))
            top = c.execute("SELECT COALESCE(MAX(id), 0) FROM cm_room_reacts WHERE room_id=?", (r["id"],)).fetchone()[0]
            reacts = []
            if since >= 0:
                blocked = set(D._blocked_ids(c, me["id"]))
                for x in c.execute("SELECT x.id, x.kind, x.profile_id, p.display_name, p.handle FROM cm_room_reacts x JOIN cm_profiles p ON p.id=x.profile_id WHERE x.room_id=? AND x.id>? ORDER BY x.id LIMIT 20", (r["id"], since)).fetchall():
                    if x["profile_id"] not in blocked and x["kind"] in REACTS:
                        reacts.append(dict(id=x["id"], kind=x["kind"], emoji=REACTS[x["kind"]], name=x["display_name"] or x["handle"], you=x["profile_id"] == me["id"]))
            out = _room_out(c, r, me)
            out.update(reacts=reacts, last_react=top, reacts_legend=REACTS)
            return jsonify(room=out)

    @app.post("/api/community/rooms/<rid>/control")
    def rm_control(rid):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            r, e = _open(c, me, rid, host=True)
            if e:
                return e
            now = _now()
            r = _settle(c, r, now)
            st, bad = control(_state_of(r), str(body().get("action") or ""), now)
            if bad:
                return err(bad, 409)
            c.execute("UPDATE cm_rooms SET phase=?, started_at=?, length=?, paused_left=?, cycle=?, last_active=? WHERE id=?",
                      (st["phase"], st["started_at"], st["length"], st["paused_left"], st["cycle"], now, r["id"]))
            r = c.execute("SELECT * FROM cm_rooms WHERE id=?", (r["id"],)).fetchone()
            return jsonify(ok=True, room=_room_out(c, r, me))

    @app.post("/api/community/rooms/<rid>/settings")
    def rm_settings(rid):
        me, e = need_me()
        if e:
            return e
        d = body()
        with db() as c:
            r, e = _open(c, me, rid, host=True)
            if e:
                return e
            r = _settle(c, r, _now())
            name, subject = r["name"], r["subject"]
            if "name" in d:
                muted = M.muted_response(c, me)
                if muted:
                    return muted
                name, bad, _ = D.screen(d.get("name"), 40, "Room name", 3)
                if bad:
                    return err(bad)
            if "subject" in d:
                subject = d["subject"] if d["subject"] in C.SUBJECTS else ""
            lengths = ("focus" in d or "break" in d or "long" in d or "rounds" in d)
            if lengths and r["phase"] != "idle":
                return err("Timer lengths can only change while the timer is stopped. Reset it first.", 409)
            c.execute("UPDATE cm_rooms SET name=?, subject=?, focus_min=?, break_min=?, long_min=?, rounds=? WHERE id=?",
                      (name, subject, _clamp(d.get("focus", r["focus_min"]), "focus"), _clamp(d.get("break", r["break_min"]), "short"), _clamp(d.get("long", r["long_min"]), "long"), _clamp(d.get("rounds", r["rounds"]), "rounds"), r["id"]))
            r = c.execute("SELECT * FROM cm_rooms WHERE id=?", (r["id"],)).fetchone()
            return jsonify(ok=True, room=_room_out(c, r, me))

    @app.post("/api/community/rooms/<rid>/me")
    def rm_me(rid):
        me, e = need_me()
        if e:
            return e
        d = body()
        with db() as c:
            r, e = _open(c, me, rid)
            if e:
                return e
            task = d.get("task") if d.get("task") in TASKS else ""
            subject = d.get("subject") if d.get("subject") in C.SUBJECTS else ""
            c.execute("UPDATE cm_room_members SET task=?, subject=? WHERE room_id=? AND profile_id=?", (task, subject, r["id"], me["id"]))
        return jsonify(ok=True)

    @app.post("/api/community/rooms/<rid>/react")
    def rm_react(rid):
        me, e = need_me()
        if e:
            return e
        kind = body().get("kind")
        if kind not in REACTS:
            return err("Unknown reaction.")
        if _react_limited(me["id"]):
            return err("Easy! One cheer every few seconds.", 429)
        with db() as c:
            m = M.muted_response(c, me)
            if m:
                return m
            r, e = _open(c, me, rid)
            if e:
                return e
            c.execute("INSERT INTO cm_room_reacts(room_id,profile_id,kind,created_at) VALUES(?,?,?,?)", (r["id"], me["id"], kind, _now()))
        return jsonify(ok=True)

    @app.post("/api/community/rooms/<rid>/kick")
    def rm_kick(rid):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            r, e = _open(c, me, rid, host=True)
            if e:
                return e
            t = c.execute("SELECT id FROM cm_profiles WHERE handle=?", (str(body().get("handle") or "").strip().lower().lstrip("@"),)).fetchone()
            if not t or t["id"] == me["id"] or not c.execute("SELECT 1 FROM cm_room_members WHERE room_id=? AND profile_id=?", (r["id"], t["id"])).fetchone():
                return err("Choose someone else in the room.", 404)
            c.execute("DELETE FROM cm_room_members WHERE room_id=? AND profile_id=?", (r["id"], t["id"]))
            c.execute("INSERT OR IGNORE INTO cm_room_bans(room_id,profile_id) VALUES(?,?)", (r["id"], t["id"]))
        return jsonify(ok=True)

    @app.post("/api/community/rooms/<rid>/lock")
    def rm_lock(rid):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            r, e = _open(c, me, rid, host=True)
            if e:
                return e
            c.execute("UPDATE cm_rooms SET locked=? WHERE id=?", (1 if body().get("locked") else 0, r["id"]))
        return jsonify(ok=True)

    @app.post("/api/community/rooms/<rid>/rotate")
    def rm_rotate(rid):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            r, e = _open(c, me, rid, host=True)
            if e:
                return e
            c.execute("UPDATE cm_rooms SET code=? WHERE id=?", ("".join(secrets.choice(CODE_ALPHABET) for _ in range(8)), r["id"]))
            r = c.execute("SELECT * FROM cm_rooms WHERE id=?", (r["id"],)).fetchone()
            return jsonify(ok=True, room=_room_out(c, r, me))

    @app.post("/api/community/rooms/<rid>/leave")
    def rm_leave(rid):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            r = c.execute("SELECT * FROM cm_rooms WHERE rid=?", (str(rid or ""),)).fetchone()
            if r and c.execute("SELECT 1 FROM cm_room_members WHERE room_id=? AND profile_id=?", (r["id"], me["id"])).fetchone():
                _leave(c, r, me["id"])
        return jsonify(ok=True)

    @app.delete("/api/community/rooms/<rid>")
    def rm_close(rid):
        me, e = need_me()
        if e:
            return e
        with db() as c:
            r, e = _open(c, me, rid, host=True)
            if e:
                return e
            _delete_room(c, r["id"])
        return jsonify(ok=True)

    @app.post("/api/community/rooms/<rid>/report")
    def rm_report(rid):
        me, e = need_me()
        if e:
            return e
        if too_many("cm-rreport", str(me["id"]), 10, 86400):
            return err("Too many reports today.", 429)
        cat, reason = M.report_fields(body())
        if not cat:
            return err("Please choose what is wrong.")
        with db() as c:
            r, e = _open(c, me, rid)
            if e:
                return e
            if r["owner"] == me["id"]:
                return err("You're the host. You can change the name in settings or close the room.")
            c.execute("INSERT OR IGNORE INTO cm_content_reports(reporter,kind,ref,reason,category,created_at) VALUES(?,?,?,?,?,?)", (me["id"], "room", r["id"], reason, cat, int(_now())))
            n = c.execute("SELECT COUNT(DISTINCT reporter) FROM cm_content_reports WHERE kind='room' AND ref=?", (r["id"],)).fetchone()[0]
            if n >= AUTO_CLOSE_AT and not r["hidden"]:
                c.execute("UPDATE cm_rooms SET hidden=1 WHERE id=?", (r["id"],))
                M.on_auto_hide(c, r["owner"], "room", r["rid"])
        return jsonify(ok=True)

    # ================================================================ moderation (admin)
    @app.get("/api/admin/community/rooms")
    @admin_only
    def rm_admin_list():
        c = db()
        rows = c.execute("""SELECT r.rid, r.name, r.hidden, r.locked, r.group_id, r.created_at, r.phase, o.handle AS owner,
                            (SELECT COUNT(*) FROM cm_room_members m WHERE m.room_id=r.id) AS members,
                            (SELECT COUNT(DISTINCT reporter) FROM cm_content_reports x WHERE x.kind='room' AND x.ref=r.id) AS reports
                            FROM cm_rooms r LEFT JOIN cm_profiles o ON o.id=r.owner ORDER BY r.created_at DESC LIMIT 200""").fetchall()
        return jsonify(rooms=[dict(r) for r in rows])

    @app.post("/api/admin/community/rooms/<rid>/<action>")
    @admin_only
    def rm_admin_act(rid, action):
        if action not in ("hide", "unhide", "delete"):
            return err("Unknown action.", 404)
        with db() as c:
            r = c.execute("SELECT * FROM cm_rooms WHERE rid=?", (rid,)).fetchone()
            if not r:
                return err("No such room.", 404)
            M.on_content_action(c, r["owner"], "room", action, r["rid"])
            if action == "delete":
                _delete_room(c, r["id"])
            else:
                c.execute("UPDATE cm_rooms SET hidden=? WHERE id=?", (1 if action == "hide" else 0, r["id"]))
        log_fn("community_room_" + action, "-", "-", f"room={rid}")
        return jsonify(ok=True)
