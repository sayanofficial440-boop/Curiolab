"""Children's privacy (COPPA-style) endpoints: verifiable parental consent, parent review/export/deletion.

Design, in plain words
  * A child under 13 never gives us an email address or real name. They pick a nickname; a parent's email is
    collected only to ask for permission.
  * We use the FTC's "email plus" method (valid because we never disclose a child's data to third parties): the
    parent gets an email with a private link, approves there, and gets a confirmation email with the same link so
    they can review or delete everything at any time. Unanswered requests are deleted after COPPA_PENDING_DAYS.
  * We store: nickname, parent email, status, timestamps. Never the child's birth date, age, IP address or free text.
    The server only learns "under 13" because the child's browser told it so; see README for the limits of that.
  * Without SMTP settings no email can be sent. The API says so (delivery="unconfigured") and the child stays in the
    restricted mode until a parent approves, so the feature fails closed.

Everything is registered by register(app, ...) from app.py.
"""
import os, re, time, json, logging
from flask import request, jsonify
from dbutil import db, sha256, new_token, too_many, client_ip, site_url
import mailer

log = logging.getLogger("curiolab.coppa")
PENDING_DAYS = int(os.environ.get("COPPA_PENDING_DAYS", 7))
DECIDED_KEEP_DAYS = 30           # a declined tombstone (no email) is kept this long so the parent page still loads
CONTROLLER = os.environ.get("CONTROLLER_NAME", "the Curio Lab team")
CONTACT = os.environ.get("CONTACT_EMAIL", "")
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}\.[^@\s.]{2,}$")

COLLECTED = [
    "Your child's nickname (not a real name).",
    "Quiz scores, streaks and progress. These stay in your child's own browser and are not sent to us.",
    "If a certificate is issued: the nickname, which certificate, and the date. Anyone with the certificate's link can see those three things.",
    "Your email address, only so we can ask for and confirm your permission. It is never used for marketing.",
]
NOT_COLLECTED = ["No real name, birth date, address, phone number, photo, location or school.",
                 "No advertising, no analytics, no data sold or shared with third parties.",
                 "No free-text chat with an AI model, no contact form and no public profile while an account is a child account."]


def init(c):
    c.executescript("""
    CREATE TABLE IF NOT EXISTS coppa_consents(
      id INTEGER PRIMARY KEY, child_ref TEXT UNIQUE, nickname TEXT, parent_email TEXT, token_hash TEXT UNIQUE,
      status TEXT DEFAULT 'pending', created_at INTEGER, decided_at INTEGER, expires_at INTEGER);
    CREATE INDEX IF NOT EXISTS coppa_email ON coppa_consents(parent_email);
    """)


def consent_for_ref(child_ref):
    if not child_ref or len(child_ref) > 100:
        return None
    return db().execute("SELECT * FROM coppa_consents WHERE child_ref=?", (child_ref,)).fetchone()


def _by_token(token):
    if not token or len(token) > 100:
        return None
    return db().execute("SELECT * FROM coppa_consents WHERE token_hash=?", (sha256(token),)).fetchone()


def valid_nickname(n):
    n = (n or "").strip()
    if not 2 <= len(n) <= 20:
        return None, "Pick a nickname between 2 and 20 characters."
    if not re.fullmatch(r"[A-Za-z0-9 _.\-]+", n):
        return None, "Use letters, numbers, spaces, dots, dashes or underscores only."
    if re.search(r"\d{5,}", n) or re.search(r"https?|www|\.com|\.net|\.org", n, re.I):
        return None, "Please don't use phone numbers or web addresses in a nickname."
    return n, None


def _owner_mail(link):
    return (
        f"Hello,\n\nSomeone using the nickname shown on this page asked to create a Curio Lab account and said you are their "
        f"parent or guardian. Curio Lab is a free study site run by {CONTROLLER}. Because the child may be under 13, we need "
        f"your permission before we create the account.\n\nReview what we collect and approve or decline here (private link, "
        f"valid {PENDING_DAYS} days):\n{link}\n\nIf you do nothing, the request and your email address are deleted automatically. "
        f"If you don't know what this is about, ignore this email or decline on the page.\n"
        + (f"\nQuestions: {CONTACT}\n" if CONTACT else ""))


def _confirm_mail(link):
    return (
        f"Hello,\n\nYou approved a Curio Lab account for your child. You can review what is stored, download it, or delete the "
        f"account and everything linked to it at any time using the same private link:\n{link}\n\nKeep this email. Anyone with "
        f"the link can manage the account, so don't forward it.\n" + (f"\nQuestions: {CONTACT}\n" if CONTACT else ""))


def purge():
    now = int(time.time())
    with db() as c:
        a = c.execute("DELETE FROM coppa_consents WHERE status='pending' AND expires_at<?", (now,)).rowcount
        b = c.execute("DELETE FROM coppa_consents WHERE status='declined' AND decided_at<?", (now - DECIDED_KEEP_DAYS * 86400,)).rowcount
    return a + b


def erase_by_email(c, email):
    """Used by the admin privacy tools: delete every child record tied to a parent address."""
    refs = [r["child_ref"] for r in c.execute("SELECT child_ref FROM coppa_consents WHERE lower(parent_email)=?", (email,))]
    certs = 0
    for ref in refs:
        try:
            certs += c.execute("DELETE FROM certificates WHERE holder_hash=?", (sha256(ref),)).rowcount
        except Exception:
            pass
    n = c.execute("DELETE FROM coppa_consents WHERE lower(parent_email)=?", (email,)).rowcount
    return dict(coppa_consents=n, child_certificates=certs)


def lookup_by_email(c, email):
    return [dict(r) for r in c.execute("SELECT id,nickname,parent_email,status,created_at,decided_at FROM coppa_consents WHERE lower(parent_email)=?", (email,))]


def _certs_for(c, child_ref, base):
    try:
        rows = c.execute("SELECT code,tier_label,issued_at,revoked FROM certificates WHERE holder_hash=? ORDER BY id", (sha256(child_ref),)).fetchall()
    except Exception:
        return []
    return [dict(code=r["code"], tier=r["tier_label"], issued_at=r["issued_at"], revoked=bool(r["revoked"]), url=f"{base}/verify/{r['code']}") for r in rows]


def register(app):
    last = {"t": 0}

    @app.before_request
    def _hourly_purge():
        if time.time() - last["t"] > 3600:
            last["t"] = time.time()
            try:
                purge()
            except Exception as e:
                log.error("purge failed: %s", type(e).__name__)

    @app.post("/api/coppa/request")
    def coppa_request():
        d = request.get_json(silent=True) or {}
        ip = client_ip(request)
        if too_many("coppa-ip", ip, 4, 3600):
            return jsonify(error="Too many requests from this device. Please try again later."), 429
        nick, err = valid_nickname(d.get("nickname"))
        if err:
            return jsonify(error=err), 400
        email = (d.get("parent_email") or "").strip().lower()
        if not EMAIL_RE.match(email):
            return jsonify(error="Please enter your parent or guardian's email address."), 400
        if too_many("coppa-mail", email, 5, 86400):
            return jsonify(error="That address already has several requests today."), 429
        token, ref = new_token(), new_token(18)
        now = int(time.time())
        with db() as c:
            c.execute("INSERT INTO coppa_consents(child_ref,nickname,parent_email,token_hash,status,created_at,expires_at) VALUES(?,?,?,?, 'pending', ?,?)",
                      (ref, nick, email, sha256(token), now, now + PENDING_DAYS * 86400))
        link = f"{site_url(request)}/pages/parent.html?t={token}"
        sent = mailer.send(email, "Please confirm: Curio Lab account for your child", _owner_mail(link))
        out = dict(ok=True, child_ref=ref, status="pending", delivery="email" if sent else ("unconfigured" if not mailer.configured() else "failed"))
        if os.environ.get("COPPA_DEV_SHOW_LINK") == "1":   # local testing only; never enable in production
            out["dev_link"] = link
        return jsonify(out)

    @app.get("/api/coppa/status/<child_ref>")
    def coppa_status(child_ref):
        if too_many("coppa-status", client_ip(request), 120, 3600):
            return jsonify(error="Slow down."), 429
        r = consent_for_ref(child_ref)
        if not r:
            return jsonify(status="gone")
        return jsonify(status=r["status"], nickname=r["nickname"])

    def _info(r):
        base = site_url(request)
        with db() as c:
            certs = _certs_for(c, r["child_ref"], base)
        return dict(nickname=r["nickname"], status=r["status"], created_at=r["created_at"], decided_at=r["decided_at"], expires_at=r["expires_at"],
                    controller=CONTROLLER, contact=CONTACT, collected=COLLECTED, not_collected=NOT_COLLECTED, certificates=certs)

    @app.get("/api/coppa/consent/<token>")
    def coppa_view(token):
        if too_many("coppa-view", client_ip(request), 60, 3600):
            return jsonify(error="Slow down."), 429
        r = _by_token(token)
        if not r:
            return jsonify(error="This link is not valid any more. It may have expired or the account was deleted."), 404
        return jsonify(_info(r))

    @app.post("/api/coppa/consent/<token>/decision")
    def coppa_decide(token):
        r = _by_token(token)
        if not r:
            return jsonify(error="This link is not valid any more."), 404
        decision = (request.get_json(silent=True) or {}).get("decision")
        if decision not in ("approve", "decline"):
            return jsonify(error="Choose approve or decline."), 400
        if r["status"] != "pending":
            return jsonify(error=f"This request was already {r['status']}."), 409
        now = int(time.time())
        if decision == "approve":
            with db() as c:
                c.execute("UPDATE coppa_consents SET status='granted', decided_at=?, expires_at=NULL WHERE id=?", (now, r["id"]))
            link = f"{site_url(request)}/pages/parent.html?t={token}"
            mailer.send(r["parent_email"], "Confirmed: Curio Lab account for your child", _confirm_mail(link))
        else:
            with db() as c:   # forget the parent's address immediately
                c.execute("UPDATE coppa_consents SET status='declined', decided_at=?, parent_email=NULL WHERE id=?", (now, r["id"]))
        return jsonify(ok=True, status="granted" if decision == "approve" else "declined")

    @app.get("/api/coppa/consent/<token>/export")
    def coppa_export(token):
        r = _by_token(token)
        if not r:
            return jsonify(error="This link is not valid any more."), 404
        out = _info(r)
        out["parent_email"] = r["parent_email"]
        out["exported_at"] = int(time.time())
        resp = jsonify(out)
        resp.headers["Content-Disposition"] = "attachment; filename=curiolab-child-data.json"
        return resp

    @app.post("/api/coppa/consent/<token>/delete")
    def coppa_delete(token):
        r = _by_token(token)
        if not r:
            return jsonify(error="Nothing to delete: this link is not valid any more."), 404
        with db() as c:
            try:
                certs = c.execute("DELETE FROM certificates WHERE holder_hash=?", (sha256(r["child_ref"]),)).rowcount
            except Exception:
                certs = 0
            c.execute("DELETE FROM coppa_consents WHERE id=?", (r["id"],))
        return jsonify(ok=True, deleted=dict(account=1, certificates=certs))
