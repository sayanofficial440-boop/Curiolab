"""Certificates with public verification URLs.

  POST /api/certificates/issue          issue a certificate (needs the tier's evidence, see TIERS)
  GET  /api/certificates/tiers          list of tiers
  GET  /api/certificates/verify/<code>  JSON: is this certificate real?
  GET  /verify/<code>                   shareable page (server-rendered Open Graph tags, so link previews work)
  GET  /verify/<code>/image.png         the certificate as an image (also the Open Graph image)
  POST /api/admin/certificates/<code>/revoke   (admin) mark a certificate revoked; the page then says so

What "verified" means: the code proves THIS server issued this certificate to this name on this date and has not
revoked it. Eligibility is computed from the quiz/streak summary the browser sends, because quiz attempts are stored
in the browser, not on the server. That makes it honest proof of issuance, not proof that nobody edited their own
local storage. Say so in your wording if you use the certificates for anything that matters.

Privacy: a certificate stores a display name, the tier and the date. No email, no IP, no account id. For child
accounts the display name is the nickname the parent approved, and issuing requires granted parental consent.
"""
import os, json, html, io, re, secrets, time, logging
from dbutil import ROOT
from flask import request, jsonify, Response
from dbutil import db, sha256, too_many, client_ip, site_url
import coppa
import imaging

log = logging.getLogger("curiolab.certs")
ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"   # Crockford base32: no I, L, O, U

TIERS = [
    dict(id="perfect-score", level=1, label="Perfect Score", description="Score 100% on a quiz of at least 5 questions.",
         headline="a perfect score on a Curio Lab quiz"),
    dict(id="well-rounded", level=2, label="Well Rounded", description="Score 100% in quizzes from 3 different subjects.",
         headline="perfect quiz scores in three different subjects"),
    dict(id="streak-master", level=3, label="Streak Master", description="Win 10 mini-games in a row.",
         headline="a 10-game winning streak in the Curio Lab arcade"),
    dict(id="compiler-streak", level=4, label="Compiler Streak", description="Run code in the playground 10 times in a row without an error.",
         headline="10 clean code runs in a row in the Curio Lab playground"),
]
TIER_BY_ID = {t["id"]: t for t in TIERS}


def _num(v, lo=0, hi=100000):
    try:
        n = int(v)
    except (TypeError, ValueError):
        return 0
    return max(lo, min(hi, n))


_CAT = {}


def _catalog():
    """{(subject, lesson title): quiz length} from the published learning index. Empty when the file is missing."""
    if not _CAT:
        try:
            idx = json.load(open(os.path.join(os.environ.get("PUBLIC_DIR") or os.path.join(ROOT, "..", "public"), "data", "learning-index.json"), encoding="utf8"))
            for l in idx.get("lessons", []):
                subj = l["id"].split("/")[0].replace("-", " ").lower()
                _CAT[(subj, str(l["title"]).strip().lower())] = int(l.get("quizTotal") or 0)
        except (OSError, ValueError, KeyError):
            log.warning("learning-index.json not found: certificate scores cannot be checked against real lessons (set PUBLIC_DIR)")
    return _CAT


def _real(x):
    """A reported score only counts when it names a real lesson and a quiz length that lesson can have. This stops made-up
    lessons and subjects; it cannot stop someone who copies a real lesson name (the quiz runs in the browser)."""
    cat = _catalog()
    if not cat:
        return True  # no catalogue available: fall back to the old behaviour rather than block everyone
    n = cat.get((str(x.get("subject", "")).strip().lower(), str(x.get("lesson", "")).strip().lower()))
    return bool(n) and 5 <= _num(x.get("total")) <= n


def eligible(tier_id, summary):
    s = summary if isinstance(summary, dict) else {}
    scores = s.get("scores") if isinstance(s.get("scores"), list) else []
    perfect = [x for x in scores[:2000] if isinstance(x, dict) and _num(x.get("total")) >= 5 and _num(x.get("score")) == _num(x.get("total")) and _real(x)]
    subjects = {str(x.get("subject", "")).strip().lower()[:40] for x in perfect if str(x.get("subject", "")) not in ("", "Exam")}
    if tier_id == "perfect-score":
        return len(perfect) >= 1
    if tier_id == "well-rounded":
        return len(subjects) >= 3
    if tier_id == "streak-master":
        return _num(s.get("streak_best")) >= 10
    if tier_id == "compiler-streak":
        return _num(s.get("playground_streak_best")) >= 10
    return False


def clean_name(n):
    n = re.sub(r"\s+", " ", (n or "")).strip()
    if not 1 <= len(n) <= 60:
        return None, "Enter the name to print on the certificate (up to 60 characters)."
    if "@" in n or re.search(r"https?:|www\.|\d{6,}", n, re.I):
        return None, "Please don't put emails, web addresses or phone numbers on a certificate."
    return n, None


def new_code():
    s = "".join(secrets.choice(ALPHABET) for _ in range(12))
    return f"CL-{s[:4]}-{s[4:8]}-{s[8:]}"


def normalise(code):
    c = re.sub(r"[^0-9A-Za-z]", "", (code or "").upper())
    if c.startswith("CL"):
        c = c[2:]
    c = c.replace("O", "0").replace("I", "1").replace("L", "1")
    if len(c) != 12 or any(ch not in ALPHABET for ch in c):
        return None
    return f"CL-{c[:4]}-{c[4:8]}-{c[8:]}"


def init(c):
    c.executescript("""
    CREATE TABLE IF NOT EXISTS certificates(
      id INTEGER PRIMARY KEY, code TEXT UNIQUE, tier_id TEXT, level INTEGER, tier_label TEXT, headline TEXT,
      name TEXT, holder_hash TEXT, child INTEGER DEFAULT 0, issued_at INTEGER, revoked INTEGER DEFAULT 0, revoked_reason TEXT);
    CREATE INDEX IF NOT EXISTS cert_holder ON certificates(holder_hash);
    """)


def _get(code):
    code = normalise(code)
    if not code:
        return None
    return db().execute("SELECT * FROM certificates WHERE code=?", (code,)).fetchone()


def _date(ts):
    return time.strftime("%d %B %Y", time.gmtime(ts))


def _public(r, base):
    return dict(valid=not r["revoked"], revoked=bool(r["revoked"]), code=r["code"], name=r["name"], tier=r["tier_label"], level=r["level"],
                achievement=r["headline"], issued_at=r["issued_at"], issued_date=_date(r["issued_at"]), issuer="Curio Lab",
                url=f"{base}/verify/{r['code']}", image=f"{base}/verify/{r['code']}/image.png")


PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title><meta name="robots" content="noindex, nofollow"><meta name="referrer" content="no-referrer">
<meta name="description" content="{desc}"><link rel="canonical" href="{url}">
<meta property="og:type" content="website"><meta property="og:site_name" content="Curio Lab"><meta property="og:title" content="{title}">
<meta property="og:description" content="{desc}"><meta property="og:url" content="{url}">{img}
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{title}"><meta name="twitter:description" content="{desc}">{twimg}
<style>:root{{--navy:#12213b;--cream:#f3efe3;--ink:#1b1b18;--muted:#5c594e;--ok:#1f7a4d;--bad:#b3261e}}
@media (prefers-color-scheme:dark){{:root{{--cream:#0f1a2e;--ink:#f3efe3;--muted:#b9b4a4;--navy:#f3efe3}}}}
*{{box-sizing:border-box}}body{{margin:0;font:16px/1.55 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:var(--cream);color:var(--ink)}}
main{{max-width:640px;margin:0 auto;padding:32px 16px 64px}}a{{color:inherit}}.logo{{font-weight:800;font-size:1.3rem;text-decoration:none;color:var(--navy)}}
.card{{margin-top:24px;padding:28px 24px;border:2px solid var(--navy);border-radius:18px;background:color-mix(in srgb,var(--cream) 70%,white)}}
.status{{display:inline-flex;align-items:center;gap:.5rem;font-weight:700;padding:.35rem .8rem;border-radius:999px;color:#fff}}.ok{{background:var(--ok)}}.bad{{background:var(--bad)}}
h1{{font-size:1.9rem;line-height:1.2;margin:.9rem 0 .2rem}}dl{{display:grid;grid-template-columns:max-content 1fr;gap:.4rem 1rem;margin:1.2rem 0 0}}dt{{color:var(--muted)}}dd{{margin:0;font-weight:600}}
code{{font:600 .95rem ui-monospace,monospace}}img.cert{{width:100%;height:auto;border-radius:12px;margin-top:20px;border:1px solid #0002}}
.row{{display:flex;flex-wrap:wrap;gap:.6rem;margin-top:1.2rem}}button,.btn{{min-height:44px;padding:0 1rem;border-radius:999px;border:1px solid var(--navy);background:none;color:var(--ink);font:600 .95rem inherit;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center}}
small{{color:var(--muted)}}</style></head><body><main><a class="logo" href="{home}">Curio·Lab</a>{body}
<p><small>Anyone with this link can see the name, certificate and date shown here, and nothing else. Curio Lab does not publish email addresses or any other personal details on certificates.</small></p></main></body></html>"""


def register(app, admin_only, log_fn, current_admin):
    @app.get("/api/certificates/tiers")
    def cert_tiers():
        return jsonify(tiers=[{k: t[k] for k in ("id", "level", "label", "description")} for t in TIERS])

    @app.post("/api/certificates/issue")
    def cert_issue():
        d = request.get_json(silent=True) or {}
        if too_many("cert-issue", client_ip(request), 10, 3600):
            return jsonify(error="Too many requests from this device. Please try again later."), 429
        tier = TIER_BY_ID.get(d.get("tier_id"))
        if not tier:
            return jsonify(error="Unknown certificate."), 400
        holder_key = str(d.get("holder_key") or "")
        if not 16 <= len(holder_key) <= 100:
            return jsonify(error="Missing device key. Reload the page and try again."), 400
        child_ref = str(d.get("child_ref") or "")
        child = False
        if d.get("child") and not child_ref:
            return jsonify(error="A parent has to approve this account before certificates can be issued.", code="parental_consent_required"), 403
        if child_ref:
            r = coppa.consent_for_ref(child_ref)
            if not r or r["status"] != "granted":
                return jsonify(error="A parent has to approve this account before certificates can be issued.", code="parental_consent_required"), 403
            name, child, holder_key = r["nickname"], True, child_ref   # a child's certificate always carries the approved nickname
        else:
            name, err = clean_name(d.get("name"))
            if err:
                return jsonify(error=err), 400
        if not eligible(tier["id"], d.get("summary")):
            return jsonify(error="Not eligible yet: " + tier["description"]), 403
        holder = sha256(holder_key)
        base = site_url(request)
        with db() as c:
            old = c.execute("SELECT * FROM certificates WHERE holder_hash=? AND tier_id=? AND revoked=0", (holder, tier["id"])).fetchone()
            if old:
                return jsonify(certificate=_public(old, base), existing=True)
            for _ in range(5):
                code = new_code()
                try:
                    c.execute("INSERT INTO certificates(code,tier_id,level,tier_label,headline,name,holder_hash,child,issued_at) VALUES(?,?,?,?,?,?,?,?,?)",
                              (code, tier["id"], tier["level"], tier["label"], tier["headline"], name, holder, int(child), int(time.time())))
                    break
                except Exception:
                    continue
            else:
                return jsonify(error="Could not create a code. Please try again."), 500
        r = _get(code)
        return jsonify(certificate=_public(r, base))

    @app.get("/api/certificates/verify/<code>")
    def cert_verify_json(code):
        if too_many("cert-verify", client_ip(request), 60, 60):
            return jsonify(error="Slow down."), 429
        r = _get(code)
        if not r:
            return jsonify(valid=False, error="No certificate matches that code."), 404
        resp = jsonify(_public(r, site_url(request)))
        resp.headers["X-Robots-Tag"] = "noindex"
        return resp

    def _html(status, title, desc, body, url, image=None):
        img = f'<meta property="og:image" content="{html.escape(image)}"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="800">' if image else ""
        tw = f'<meta name="twitter:image" content="{html.escape(image)}">' if image else ""
        out = PAGE.format(title=html.escape(title), desc=html.escape(desc), url=html.escape(url), img=img, twimg=tw, body=body, home=html.escape(site_url(request) + "/"))
        resp = Response(out, status=status, mimetype="text/html")
        resp.headers["X-Robots-Tag"] = "noindex, nofollow"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["Cache-Control"] = "public, max-age=300"
        return resp

    @app.get("/verify/")
    def verify_index():
        return Response(status=302, headers={"Location": "/pages/verify.html"})

    @app.get("/verify/<code>")
    def verify_page(code):
        base = site_url(request)
        if too_many("cert-verify", client_ip(request), 60, 60):
            return _html(429, "Slow down - Curio Lab", "Too many lookups.", "<div class='card'><h1>Too many lookups</h1><p>Please wait a minute and try again.</p></div>", base)
        r = _get(code)
        if not r:
            body = ("<div class='card'><span class='status bad'>✕ Not found</span><h1>No certificate matches this code</h1>"
                    "<p>Check the code for typos (it looks like <code>CL-ABCD-EFGH-JKMN</code>), or ask the person who shared it to send the link again.</p>"
                    "<div class='row'><a class='btn' href='/pages/verify.html'>Try another code</a></div></div>")
            return _html(404, "Certificate not found - Curio Lab", "No certificate matches this code.", body, f"{base}/verify/")
        p = _public(r, base)
        name, tier, ach, date = (html.escape(p[k]) for k in ("name", "tier", "achievement", "issued_date"))
        url = html.escape(p["url"])
        if r["revoked"]:
            body = (f"<div class='card'><span class='status bad'>✕ Revoked</span><h1>This certificate is no longer valid</h1>"
                    f"<p>Curio Lab issued code <code>{html.escape(r['code'])}</code> but later withdrew it.</p></div>")
            return _html(200, "Certificate revoked - Curio Lab", "This certificate has been revoked.", body, p["url"])
        body = (f"<div class='card'><span class='status ok'>✓ Verified by Curio Lab</span><h1>{name}</h1>"
                f"<p>earned <strong>{tier}</strong>: {ach}.</p>"
                f"<dl><dt>Issued</dt><dd>{date}</dd><dt>Issuer</dt><dd>Curio Lab</dd><dt>Code</dt><dd><code>{html.escape(r['code'])}</code></dd></dl>"
                f"<img class='cert' src='{html.escape(p['image'])}' width='1200' height='800' alt='Certificate for {name}: {tier}'>"
                f"<div class='row'><button type='button' onclick=\"navigator.clipboard&&navigator.clipboard.writeText('{url}').then(()=>this.textContent='Copied')\">Copy link</button>"
                f"<a class='btn' href='{html.escape(p['image'])}' download='curiolab-certificate.png'>Download image</a></div></div>")
        title = f"{p['name']} - {p['tier']} certificate | Curio Lab"
        return _html(200, title, f"{p['name']} earned {p['tier']} on Curio Lab ({p['issued_date']}). Verified certificate.", body, p["url"], p["image"])

    @app.get("/verify/<code>/image.png")
    def verify_image(code):
        r = _get(code)
        if not r or r["revoked"]:
            return Response("Not found", status=404, mimetype="text/plain")
        base = site_url(request)
        buf = io.BytesIO()
        imaging.cert_card(buf, r["name"], r["tier_label"], r["level"], r["headline"], _date(r["issued_at"]), f"{base}/verify/{r['code']}".replace("https://", "").replace("http://", ""), r["code"])
        resp = Response(buf.getvalue(), mimetype="image/png")
        resp.headers["Cache-Control"] = "public, max-age=86400"
        resp.headers["X-Robots-Tag"] = "noindex"
        return resp

    @app.get("/api/admin/certificates")
    @admin_only
    def admin_certs():
        rows = db().execute("SELECT code,tier_label,name,child,issued_at,revoked,revoked_reason FROM certificates ORDER BY id DESC LIMIT 500").fetchall()
        return jsonify(certificates=[dict(r) for r in rows])

    @app.post("/api/admin/certificates/<code>/revoke")
    @admin_only
    def admin_revoke(code):
        r = _get(code)
        if not r:
            return jsonify(error="No such certificate."), 404
        reason = ((request.get_json(silent=True) or {}).get("reason") or "")[:200]
        with db() as c:
            c.execute("UPDATE certificates SET revoked=1, revoked_reason=? WHERE id=?", (reason, r["id"]))
        a = current_admin()
        log_fn("certificate_revoked", a["name"], a["email"], f"code={r['code']}")
        return jsonify(ok=True)
