"""AI coach endpoints for the Flask backend (same contract as src/routes/api/coach.ts).
GET /api/health -> {ok, live}   POST /api/coach -> {reply}
The Gemini key stays on the server: set GEMINI_API_KEY in the environment (or in ../.dev.vars / ../.env.local for local runs)."""
import os, json, urllib.request, urllib.error
from flask import request, jsonify
from dbutil import too_many, client_ip

MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.8-flash")

def _key():
    k = os.environ.get("GEMINI_API_KEY")
    if k: return k
    root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
    for name in (".dev.vars", ".env.local"):
        try:
            for line in open(os.path.join(root, name), encoding="utf-8"):
                if line.startswith("GEMINI_API_KEY="): return line.split("=", 1)[1].strip().strip("\"'")
        except OSError: pass
    return ""

def register(app):
    @app.get("/api/health")
    def coach_health(): return jsonify(ok=True, live=bool(_key()))

    @app.post("/api/coach")
    def coach():
        key = _key()
        if not key: return jsonify(error="AI is not configured"), 500
        if too_many("coach", client_ip(request), 60, 3600): return jsonify(error="Too many requests, please wait a moment."), 429
        body = request.get_json(silent=True)
        if not isinstance(body, dict): return jsonify(error="Invalid request"), 400
        message = str(body.get("message") or "")[:4000].strip()
        if not message: return jsonify(error="Empty message"), 400
        topic = str(body.get("topic") or "this lesson")[:200]
        ctx = body.get("context") if isinstance(body.get("context"), dict) else {}
        history = body.get("history") if isinstance(body.get("history"), list) else []
        system = " ".join(s for s in [
            f'You are Curio Lab\'s friendly AI coach for students, helping with "{topic}".',
            f"Subject: {ctx['subject']}." if ctx.get("subject") else "",
            f"Difficulty: {ctx['difficulty']}." if ctx.get("difficulty") else "",
            f'The student is in the "{ctx["activeSection"]}" section.' if ctx.get("activeSection") else "",
            f"Current heading: {ctx['sectionHeading']}." if ctx.get("sectionHeading") else "",
            "DEBATE MODE: respectfully challenge the student's position with clear counter-arguments and a probing question."
            if body.get("mode") == "debate" else
            "Explain clearly and simply, use examples, and encourage the student. Keep answers short (under 150 words).",
            "Keep content age-appropriate."] if s)
        contents = [{"role": "user" if (m or {}).get("who") == "user" else "model", "parts": [{"text": str(m["text"])[:4000]}]}
                    for m in history[-20:] if isinstance(m, dict) and m.get("text")]
        while contents and contents[0]["role"] != "user": contents.pop(0)  # Gemini needs a user turn first
        contents.append({"role": "user", "parts": [{"text": message}]})
        req = urllib.request.Request(
            f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent",
            data=json.dumps({"systemInstruction": {"parts": [{"text": system}]}, "contents": contents}).encode(),
            headers={"Content-Type": "application/json", "x-goog-api-key": key}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=30) as r: data = json.load(r)
        except urllib.error.HTTPError as e:
            app.logger.error("Gemini error %s", e.code)
            return jsonify(error="Too many requests, please wait a moment." if e.code == 429 else "The AI coach is unavailable right now."), e.code
        except Exception:
            app.logger.exception("Gemini request failed")
            return jsonify(error="The AI coach is unavailable right now."), 502
        parts = ((data.get("candidates") or [{}])[0].get("content") or {}).get("parts") or []
        reply = "".join(p.get("text", "") for p in parts).strip()
        if not reply: return jsonify(error="No answer was returned. Try rephrasing."), 502
        return jsonify(reply=reply)
