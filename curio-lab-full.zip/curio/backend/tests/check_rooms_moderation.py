"""Run: python backend/tests/check_rooms_moderation.py  Covers study rooms (shared Pomodoro timer) and the moderation tools (report categories, mutes, notices, queue)."""
import os, sys, tempfile, json, time
tmp = tempfile.mkdtemp()
os.environ.update(DB_PATH=os.path.join(tmp, "test.db"), BACKUP_DIR=os.path.join(tmp, "bk"), BACKUP_EVERY_HOURS="0", PUSH_WORKER="0",
                  SITE_URL="https://curiolab.test", ADMIN_EMAIL="a@x.io", ADMIN_PASSWORD="pw-pw-pw-pw", SECRET_KEY="k")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import app as A, community as C, discuss as D, rooms as R, moderation as M
from dbutil import reset_rate_limits, db
FAILS = []
def ok(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond: FAILS.append(msg)

# ---------------------------------------------------------------- the timer, without HTTP
base = dict(phase="idle", started_at=0, length=0, paused_left=None, cycle=0, total_focus=0, rounds=4, focus_min=25, break_min=5, long_min=15)
st, bad = R.control(base, "start", 1000.0)
ok(bad is None and st["phase"] == "focus" and st["length"] == 1500, "start: idle -> a 25 minute focus block")
ok(R.control(st, "start", 1000.0)[1] is not None, "start twice is refused")
s2, ends = R.advance(st, 1000.0 + 1499)
ok(s2["phase"] == "focus" and not ends, "one second early: still focus")
s2, ends = R.advance(st, 1000.0 + 1501)
ok(s2["phase"] == "break" and s2["cycle"] == 1 and s2["total_focus"] == 1 and ends == [2500.0] and s2["started_at"] == 2500.0 and s2["length"] == 300, "focus ends -> short break, started at the exact end (no drift)")
s3, ends = R.advance(st, 1000.0 + 1500 + 300 + 10)
ok(s3["phase"] == "focus" and s3["started_at"] == 2800.0, "break ends -> focus again")
# a slow poll that missed several phases catches up to the right place
far, ends = R.advance(st, 1000.0 + 4 * 1800 + 100)       # 4 full (focus+break) cycles, but the 4th focus is followed by a long break
ok(far["total_focus"] == 4 and len(ends) == 4 and far["phase"] == "long" and far["cycle"] == 4, "catches up over several phases; the 4th block earns the long break")
far2, _ = R.advance(far, far["started_at"] + 15 * 60 + 5)
ok(far2["phase"] == "focus" and far2["cycle"] == 4, "long break -> focus")
# pause / resume keeps the remaining time exactly
p, _ = R.control(st, "pause", 1000.0 + 600)
ok(p["paused_left"] == 900.0, "pause remembers 15 minutes left")
ok(R.advance(p, 1000.0 + 99999)[0]["phase"] == "focus", "a paused timer never moves")
r, bad = R.control(p, "resume", 5000.0)
ok(bad is None and r["started_at"] + r["length"] == 5900.0 and r["paused_left"] is None, "resume: ends 900 s after resuming")
ok(R.control(r, "resume", 5000.0)[1] is not None and R.control(base, "pause", 1.0)[1] is not None, "resume/pause in the wrong state are refused")
sk, _ = R.control(st, "skip", 1200.0)
ok(sk["phase"] == "break" and sk["total_focus"] == 0 and sk["cycle"] == 0, "skipping a focus block doesn't count it")
sk2, _ = R.control(sk, "skip", 1300.0)
ok(sk2["phase"] == "focus", "skipping a break goes to focus")
rs, _ = R.control(far, "reset", 9.0)
ok(rs["phase"] == "idle" and rs["cycle"] == 0 and rs["total_focus"] == 4, "reset stops the timer, keeps the day's count")
ok(R._clamp(5, "focus") == 10 and R._clamp(500, "focus") == 90 and R._clamp("x", "focus") == 25 and R._clamp(None, "rounds") == 4, "timer settings are clamped")

# ---------------------------------------------------------------- report fields
ok(M.report_fields({}) == (None, None), "a report with neither category nor reason is refused")
ok(M.report_fields({"category": "spam"}) == ("spam", "Spam or advertising"), "category alone is enough; the label becomes the reason")
ok(M.report_fields({"reason": "rude"}) == ("other", "rude"), "old clients (reason only) still work")
ok(M.report_fields({"category": "made-up", "reason": "x"})[0] == "other", "unknown category -> other")

# ---------------------------------------------------------------- HTTP
c = A.app.test_client(); reset_rate_limits()
def join(h, **kw):
    b = dict(handle=h, agree=True, band="adult"); b.update(kw)
    return c.post("/api/community/join", json=b).get_json().get("key")
H = lambda k: {"Authorization": "Bearer " + k}
def P(k, path, **j): return c.post("/api/community/" + path, json=j, headers=H(k))
def G(k, path): return c.get("/api/community/" + path, headers=H(k))
ka, kb, kc, kd, ke = join("alice"), join("bob"), join("cara"), join("dev"), join("eve")
LES = json.load(open(os.path.join(os.path.dirname(A.__file__), "..", "public", "data", "learning-index.json")))["lessons"][0]["id"]

# admin session
r = c.post("/api/admin/login", json=dict(email="a@x.io", password="pw-pw-pw-pw"))
ADMIN = r.status_code == 200
ok(ADMIN, "admin can sign in for the moderation checks")
def AP(path, **j): return c.post("/api/admin/community/" + path, json=j)
def AG(path): return c.get("/api/admin/community/" + path)

# --- lobby / create / join
ok(c.get("/api/community/rooms").status_code == 401, "rooms need a device key")
j = G(ka, "rooms").get_json()
ok(j["current"] is None and j["group_rooms"] == [] and j["limits"]["people"] == 20, "empty lobby")
ok(P(ka, "rooms/create", name="hi").status_code == 400, "room name too short")
ok(P(ka, "rooms/create", name="fuck room").status_code == 400, "room name is screened")
ok(P(ka, "rooms/create", name="see www.x.com").status_code == 400, "links in a room name are refused")
r = P(ka, "rooms/create", name="Quiet Physics Hour", subject="Physics", focus=2, brk=1)
rm = r.get_json()["room"]; RID = rm["id"]
ok(r.status_code == 200 and rm["role"] == "owner" and rm["timer"]["phase"] == "idle" and rm["timer"]["focus"] == 10, "create a room (focus clamped to the 10 minute minimum)")
code = rm["invite"]; ok(len(code) == 9 and code[4] == "-", "invite code looks like ABCD-EFGH")
ok(len(rm["members"]) == 1 and rm["members"][0]["you"] and rm["members"][0]["here"], "host is in the room")
ok(P(ka, "rooms/join", code=code).status_code == 200, "host joining their own room again is fine")
ok(P(kb, "rooms/join", code="ZZZZZZZZ").status_code == 404, "wrong code")
r = P(kb, "rooms/join", code=code.lower().replace("-", " "))
ok(r.status_code == 200 and len(r.get_json()["room"]["members"]) == 2, "join by code (case/dashes don't matter)")
ok(G(kb, f"rooms/{RID}/state").status_code == 200 and G(kc, f"rooms/{RID}/state").status_code == 404, "state is for members only")

# --- timer through the API, host only
ok(P(kb, f"rooms/{RID}/control", action="start").status_code == 403, "only the host controls the timer")
r = P(ka, f"rooms/{RID}/control", action="start"); t = r.get_json()["room"]["timer"]
ok(r.status_code == 200 and t["phase"] == "focus" and t["ends_at"] - r.get_json()["room"]["now"] > 599 and t["ends_at"] - r.get_json()["room"]["now"] <= 600, "start -> a 10 minute focus block with an absolute end time")
tb = G(kb, f"rooms/{RID}/state").get_json()["room"]["timer"]
ok(abs(tb["ends_at"] - t["ends_at"]) < 0.01, "everyone sees the same end time")
r = P(ka, f"rooms/{RID}/control", action="pause"); t = r.get_json()["room"]["timer"]
ok(t["paused"] and 598 < t["left"] <= 600 and t["ends_at"] is None, "pause")
ok(P(ka, f"rooms/{RID}/settings", focus=30).status_code == 409, "timer lengths are locked while a timer exists")
ok(P(ka, f"rooms/{RID}/control", action="resume").get_json()["room"]["timer"]["paused"] is False, "resume")
# make the room's clock run ahead: finish the focus block and check credit
with db() as cx:
    cx.execute("UPDATE cm_rooms SET started_at=started_at-600 WHERE rid=?", (RID,))
    cx.execute("UPDATE cm_room_members SET joined_at=joined_at-1000")
G(ka, f"rooms/{RID}/state"); jb = G(kb, f"rooms/{RID}/state").get_json()["room"]
ok(jb["timer"]["phase"] == "break" and jb["timer"]["total"] == 1 and jb["timer"]["cycle"] == 1, "the block finishes by itself; the room moves on to a break")
ok(all(m["blocks"] == 1 for m in jb["members"]), "everyone who was there at the end gets the block counted")
ok(P(ka, f"rooms/{RID}/control", action="reset").get_json()["room"]["timer"]["phase"] == "idle", "reset")
r = P(ka, f"rooms/{RID}/settings", name="Evening physics", focus=15, short=5, rounds=3, **{"break": 5, "long": 20}); rr = r.get_json()["room"]
ok(r.status_code == 200 and rr["name"] == "Evening physics" and rr["timer"]["focus"] == 15 and rr["timer"]["rounds"] == 3 and rr["timer"]["long"] == 20, "settings change while idle")

# --- what I'm working on (no free text) and reactions
ok(P(kb, f"rooms/{RID}/me", task="Writing", subject="English").status_code == 200, "set my task from the fixed list")
m = [x for x in G(ka, f"rooms/{RID}/state").get_json()["room"]["members"] if x["handle"] == "bob"][0]
ok(m["task"] == "Writing" and m["subject"] == "English", "others see it")
P(kb, f"rooms/{RID}/me", task="<script>", subject="Physics")
m = [x for x in G(ka, f"rooms/{RID}/state").get_json()["room"]["members"] if x["handle"] == "bob"][0]
ok(m["task"] == "" and m["subject"] == "Physics", "anything not on the list is dropped")
first = G(ka, f"rooms/{RID}/state").get_json()["room"]
ok(first["reacts"] == [] and first["last_react"] == 0, "first poll replays no reactions")
ok(P(kb, f"rooms/{RID}/react", kind="boo").status_code == 400, "unknown reaction refused")
ok(P(kb, f"rooms/{RID}/react", kind="fire").status_code == 200, "send a reaction")
ok(P(kb, f"rooms/{RID}/react", kind="fire").status_code == 429, "reactions are rate limited")
jr = G(ka, f"rooms/{RID}/state?since=0").get_json()["room"]
ok(len(jr["reacts"]) == 1 and jr["reacts"][0]["emoji"] == "🔥" and jr["reacts"][0]["name"] == "bob", "the host sees the reaction once")
ok(G(ka, f"rooms/{RID}/state?since={jr['last_react']}").get_json()["room"]["reacts"] == [], "...and not again")

# --- blocks, kicks, locks
P(kc, "block", handle="alice")
ok(P(kc, "rooms/join", code=code).status_code == 404, "someone blocked with a member can't join (looks like a wrong code)")
P(kc, "unblock", handle="alice")
ok(P(kc, "rooms/join", code=code).status_code == 200, "...until the block is lifted")
ok(P(ka, f"rooms/{RID}/kick", handle="cara").status_code == 200, "host removes cara")
ok(G(kc, f"rooms/{RID}/state").status_code == 404 and P(kc, "rooms/join", code=code).status_code == 404, "a kicked person can't come back")
ok(P(kb, f"rooms/{RID}/kick", handle="alice").status_code == 403, "members can't kick")
ok(P(ka, f"rooms/{RID}/lock", locked=True).status_code == 200, "lock the room")
ok(P(kd, "rooms/join", code=code).status_code == 403, "nobody new can join a locked room")
ok(P(kb, "rooms/join", code=code).status_code == 200, "...but members can come back to it")
P(ka, f"rooms/{RID}/lock", locked=False)
old = code; code2 = P(ka, f"rooms/{RID}/rotate").get_json()["room"]["invite"]
ok(code2 != old and P(kd, "rooms/join", code=old).status_code == 404 and P(kd, "rooms/join", code=code2).status_code == 200, "a new code retires the old one")
P(kd, f"rooms/{RID}/leave")

# --- one room at a time; host handover
r2 = P(kb, "rooms/create", name="Bob's own room").get_json()["room"]
ok(G(kb, "rooms").get_json()["current"]["id"] == r2["id"], "creating a room leaves the old one")
ok(G(ka, f"rooms/{RID}/state").status_code == 200, "...and the old room carries on")
P(kb, f"rooms/{r2['id']}/leave")
ok(G(ka, "rooms").get_json()["current"]["id"] == RID, "leaving the only seat closes that room")
P(kb, "rooms/join", code=code2)
P(ka, f"rooms/{RID}/leave")
jb = G(kb, f"rooms/{RID}/state").get_json()["room"]
ok(jb["role"] == "owner", "when the host leaves, the room passes to the next person")
P(kb, f"rooms/{RID}/leave")
ok(G(kb, f"rooms/{RID}/state").status_code == 404, "an empty room is gone")

# --- group-linked rooms
g = P(ka, "groups/create", name="Class 9 Physics").get_json()["group"]
P(kb, "groups/join", code=g["invite"])
ok(P(kc, "rooms/create", name="Not my group", group=g["id"]).status_code == 404, "can't open a room for a group you're not in")
gr = P(ka, "rooms/create", name="Group study", group=g["id"]).get_json()["room"]
ok(gr["group"]["name"] == "Class 9 Physics", "room linked to a group")
ok(P(ka, "rooms/create", name="Another", group=g["id"]).status_code == 400, "one open room per group")
lobby = G(kb, "rooms").get_json()
ok(len(lobby["group_rooms"]) == 1 and lobby["group_rooms"][0]["here"] == 1, "group members see it live in the lobby")
ok(G(kc, "rooms").get_json()["group_rooms"] == [], "others don't")
ok(P(kb, "rooms/join", room=gr["id"]).status_code == 200, "a group member joins without a code")
ok(P(kc, "rooms/join", room=gr["id"]).status_code == 404, "a non-member can't")
P(kb, f"rooms/{gr['id']}/leave"); P(ka, f"rooms/{gr['id']}/leave")

# --- stale rooms and presence
r3 = P(ka, "rooms/create", name="Ghost room").get_json()["room"]
with db() as cx: cx.execute("UPDATE cm_rooms SET last_active=? WHERE rid=?", (time.time() - 3600, r3["id"]))
ok(G(ka, "rooms").get_json()["current"] is None, "a room nobody touched for 15 minutes is deleted")
r4 = P(ka, "rooms/create", name="Presence room").get_json()["room"]; P(kb, "rooms/join", code=r4["invite"])
with db() as cx: cx.execute("UPDATE cm_room_members SET last_seen=? WHERE profile_id=(SELECT id FROM cm_profiles WHERE handle='bob')", (time.time() - 120,))
bm = [x for x in G(ka, f"rooms/{r4['id']}/state").get_json()["room"]["members"] if x["handle"] == "bob"][0]
ok(bm["here"] is False, "someone who stopped polling shows as away")
with db() as cx: cx.execute("UPDATE cm_room_members SET last_seen=? WHERE profile_id=(SELECT id FROM cm_profiles WHERE handle='bob')", (time.time() - 3600,))
ok(all(x["handle"] != "bob" for x in G(ka, f"rooms/{r4['id']}/state").get_json()["room"]["members"]), "...and is dropped after ten minutes")

# --- leaving the community erases rooms
r5 = P(kb, "rooms/create", name="Bob erasing").get_json()["room"]
c.delete("/api/community/me", headers=H(kb))
with db() as cx:
    ok(cx.execute("SELECT COUNT(*) FROM cm_rooms WHERE rid=?", (r5["id"],)).fetchone()[0] == 0, "erasing a profile closes the rooms it hosted")
kb = join("bob")

# ---------------------------------------------------------------- reports, categories, auto-close
opts = c.get("/api/community/report-options").get_json()["categories"]
ok([o["id"] for o in opts][:2] == ["spam", "bullying"] and len(opts) == 7, "report categories are served")
q = P(ka, "discuss/post", lesson=LES, kind="question", body="Why does friction oppose motion?").get_json()["post"]["id"]
ok(P(kb, "discuss/report", post=q).status_code == 400, "a report needs a category or a reason")
ok(P(kb, "discuss/report", post=q, category="spam").status_code == 200, "report a post by category")
ok(P(kb, "discuss/report", post=q, category="spam").status_code == 200 and all(i["id"] != q for i in G(kb, "discuss?lesson=" + LES).get_json()["items"]), "reporting twice is harmless, and the post is gone from the reporter's view")
P(ke, "discuss/report", post=q, category="selfharm", reason="seems upset")
if ADMIN:
    qq = AG("queue").get_json()
    it = [i for i in qq["items"] if i["kind"] == "post"][0]
    ok(it["reporters"] == 2 and it["categories"] == {"spam": 1, "selfharm": 1} and it["urgent"] and it["target"]["owner"] == "alice", "the queue groups reports by target and flags urgent ones")
    ok(qq["open"] == 1, "one open item")

# room reports: 3 distinct reporters close the room
rr = P(ka, "rooms/create", name="Bad room").get_json()["room"]
for k in (kb, kc, kd):
    P(k, "rooms/join", code=rr["invite"])
ok(P(ka, f"rooms/{rr['id']}/report", category="spam").status_code == 400, "the host can't report their own room")
ok(P(kb, f"rooms/{rr['id']}/report").status_code == 400, "room report needs a category")
P(kb, f"rooms/{rr['id']}/report", category="inappropriate"); P(kc, f"rooms/{rr['id']}/report", category="inappropriate")
ok(G(ka, f"rooms/{rr['id']}/state").status_code == 200, "2 reports don't close it")
P(kd, f"rooms/{rr['id']}/report", category="bullying")
ok(G(ka, f"rooms/{rr['id']}/state").status_code == 410 and G(kb, f"rooms/{rr['id']}/state").status_code == 410, "3 reporters close the room for everyone inside")
ok(P(ke, "rooms/join", code=rr["invite"]).status_code == 404, "...and for anyone joining")
ok(any("hidden after several" in n["text"] for n in G(ka, "notices").get_json()["notices"]), "the host is told why")

if ADMIN:
    qq = AG("queue").get_json()
    room_item = [i for i in qq["items"] if i["kind"] == "room"][0]
    ok(room_item["urgent"] and room_item["target"]["hidden"] and room_item["target"]["owner"] == "alice", "reported rooms show up in the same queue, urgent first")
    ok(qq["items"][0]["urgent"], "urgent items sort first")
    ok(len(AG("rooms").get_json()["rooms"]) >= 1, "admin can list rooms")
    ok(AP(f"rooms/{rr['id']}/unhide").status_code == 200 and G(ka, f"rooms/{rr['id']}/state").status_code == 200, "a moderator can reopen a room")
    ok(any("put your study room back" in n["text"] for n in G(ka, "notices").get_json()["notices"]), "...and the host is told, with an apology")
    # resolve with feedback to reporters
    r = c.post("/api/admin/community/queue/resolve", json=dict(kind="post", ref=q, outcome="no_action"))
    ok(r.status_code == 200 and r.get_json()["notified"] == 2, "closing an item tells each reporter")
    nb = G(kb, "notices").get_json()["notices"]
    ok(any("decided no action" in n["text"] for n in nb) and not any("alice" in n["text"] for n in nb), "reporters hear the outcome, never who or what")
    ok(G(kb, "me").get_json()["notices"] >= 1, "/me carries the unread count")
    P(kb, "notices/seen"); ok(G(kb, "me").get_json()["notices"] == 0, "marking seen clears it")
    ok(AG("queue").get_json()["open"] == 0 or all(not i["open"] for i in AG("queue").get_json()["items"] if i["kind"] == "post"), "the post item is closed")
    ok(c.post("/api/admin/community/queue/resolve", json=dict(kind="post", ref=q, outcome="maybe")).status_code == 400, "outcome must be actioned or no_action")

    # hide / delete tell the author
    r = AP(f"posts/{q}/hide"); ok(r.status_code == 200 and any("hid your post" in n["text"] for n in G(ka, "notices").get_json()["notices"]), "hiding a post tells the author")
    AP(f"posts/{q}/unhide")
    ok(any("put your post back" in n["text"] for n in G(ka, "notices").get_json()["notices"]), "restoring tells them too")

    # warnings and mutes
    ok(AP("people/alice/warn", reason="").status_code == 400, "a warning needs a reason")
    ok(AP("people/alice/warn", reason="Please keep answers kind").status_code == 200, "warn")
    ok(any(n["kind"] == "warning" and "keep answers kind" in n["text"] for n in G(ka, "notices").get_json()["notices"]), "the learner reads the warning")
    ok(AP("people/alice/mute", reason="Repeated rude replies", hours=2).status_code == 200, "mute for 2 hours")
    r = P(ka, "discuss/post", lesson=LES, kind="comment", body="trying to post while muted")
    ok(r.status_code == 403 and r.get_json()["muted_until"] > time.time(), "a muted learner can't post")
    ok(P(ka, "groups/create", name="Muted group").status_code == 403, "...or create a group")
    ok(P(ka, "rooms/create", name="Muted room").status_code == 403, "...or a room")
    ok(P(ka, "me", bio="muted bio change").status_code == 403 and P(ka, "me", avatar=C.AVATARS[0]).status_code == 200, "...or change their bio or name (avatar is fine)")
    gm = P(kb, "groups/create", name="Bob group").get_json()["group"]["id"]; AP("people/bob/mute", reason="x", hours=1)
    ok(P(kb, f"groups/{gm}/update", name="Renamed while muted").status_code == 403, "...or rename a group (muting closes the rename loophole)")
    AP("people/bob/unmute")
    ok(P(kb, "rooms/join", code=P(kb, "rooms/create", name="Bobs").get_json()["room"]["invite"]).status_code == 200, "(other people are unaffected)")
    ok(G(ka, "discuss?lesson=" + LES).status_code == 200 and G(ka, "me").get_json()["muted_until"] > time.time(), "...but can still read, and /me says until when")
    hist = AG("people/alice/history").get_json()
    ok(hist["summary"]["warnings"] == 1 and hist["summary"]["mutes"] == 1 and hist["summary"]["muted_until"], "the history counts warnings and mutes")
    ok(AG("people/nobody/history").status_code == 404, "unknown handle")
    ok(AP("people/alice/unmute").status_code == 200 and P(ka, "discuss/post", lesson=LES, kind="comment", body="back again, thanks").status_code == 200, "unmute lets them post again")
    ok(AP("people/alice/mute", reason="x", hours=999999).status_code == 200 and G(ka, "me").get_json()["muted_until"] - time.time() <= 30 * 86400 + 5, "mutes are capped at 30 days")
    AP("people/alice/unmute")
    # hiding a whole profile also tells them (they can still read why)
    AP("dev/hide"); ok(any("hid your profile" in n["text"] for n in G(kd, "notices").get_json()["notices"]), "a hidden profile can still read why")
    ok(G(kd, "rooms").status_code == 403, "...but can't use the rest")
    AP("dev/unhide")
    # old endpoints still there
    ok(AG("content-reports").status_code == 200 and AG("reports").status_code == 200, "the older report lists still work (with category)")
    ok(all("category" in x for x in AG("content-reports").get_json()["reports"]), "content reports carry their category")
    # profile reports use the same categories and land in the same queue
    P(kc, "report", handle="eve", category="personal", reason="posted a phone number")
    it = [i for i in AG("queue").get_json()["items"] if i["kind"] == "profile"]
    ok(it and it[0]["target"]["owner"] == "eve" and it[0]["categories"] == {"personal": 1}, "profile reports are in the queue too")
    ok(c.post("/api/admin/community/queue/resolve", json=dict(kind="profile", ref="eve", outcome="actioned")).get_json()["notified"] == 1, "close a profile report")
    ok(any("took action" in n["text"] for n in G(kc, "notices").get_json()["notices"]), "reporter is thanked")
    # non-admin can't reach admin routes
    c2 = A.app.test_client()
    ok(c2.get("/api/admin/community/queue").status_code == 401 and c2.post("/api/admin/community/people/alice/mute", json=dict(reason="x")).status_code == 401, "admin routes need an admin session")

ok(c.get("/api/community/notices").status_code == 401, "notices need a device key")
print("\n%d failed" % len(FAILS))
sys.exit(1 if FAILS else 0)
