"""Run: python backend/tests/check_community.py  (needs flask + Pillow). Covers profiles, server-side XP, boards, friends, privacy."""
import os, sys, tempfile
tmp = tempfile.mkdtemp()
os.environ.update(DB_PATH=os.path.join(tmp, "test.db"), BACKUP_DIR=os.path.join(tmp, "bk"), BACKUP_EVERY_HOURS="0", PUSH_WORKER="0",
                  SITE_URL="https://curiolab.test", ADMIN_EMAIL="a@x.io", ADMIN_PASSWORD="pw-pw-pw-pw", SECRET_KEY="k")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import app as A, community as C
from datetime import datetime, timezone, timedelta
from dbutil import reset_rate_limits
FAILS = []
def ok(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond: FAILS.append(msg)

NOW = datetime.now(timezone.utc)
iso = lambda d: d.strftime("%Y-%m-%dT%H:%M:%S.000Z")
_n = [0]
def attempt(subject, lesson, score, total, days_ago=0):
    _n[0] += 1
    return dict(subject=subject, lesson=lesson, score=score, total=total, date=iso(NOW - timedelta(days=days_ago, seconds=_n[0] * 7)))
import json
IDX = json.load(open(os.path.join(os.path.dirname(A.__file__), "..", "public", "data", "learning-index.json")))["lessons"]
def real(subj_folder):  # first real lesson title of a subject
    return next(l["title"] for l in IDX if l["id"].startswith(subj_folder + "/"))
PHY, CHM, BIO = real("physics"), real("chemistry"), real("biology")

def join(c, handle, **kw):
    body = dict(handle=handle, agree=True, band="adult"); body.update(kw)
    r = c.post("/api/community/join", json=body)
    return r, (r.get_json() or {}).get("key")
def H(key): return {"Authorization": "Bearer " + key}

# --- pure scoring
st = C.compute(dict(scores=[attempt("Physics", PHY, 10, 10), attempt("Physics", PHY, 5, 10), attempt("Chemistry", CHM, 8, 10)]))
ok(st["xp"] == 20 + 13 + 17 and st["quizzes"] == 3 and st["lessons"] == 2, "quiz XP = 5 + 15*accuracy per attempt")
ok("perfect-score" in st["badges"] and "first-quiz" in st["badges"], "badges are recomputed from attempts")
fake = C.compute(dict(scores=[attempt("Physics", "Made Up Lesson", 10, 10), attempt("Underwater Basket Weaving", PHY, 10, 10), attempt("Physics", PHY, 99, 10)]))
ok(fake["xp"] == 0, "made-up lessons, subjects and impossible scores earn nothing")
many = C.compute(dict(scores=[dict(attempt("Physics", PHY, 10, 10), date=iso(NOW - timedelta(seconds=i))) for i in range(30)]))
ok(many["xp"] == 60 and many["quizzes"] == 3, "at most 3 attempts per lesson per day count")
old = C.compute(dict(scores=[attempt("Physics", PHY, 10, 10, days_ago=20)]))
ok(old["xp"] == 20 and old["week_xp"] == 0, "old attempts count for all-time but not this week")
fut = C.compute(dict(scores=[dict(attempt("Physics", PHY, 10, 10), date=iso(NOW + timedelta(days=30)))]))
ok(fut["xp"] == 0, "future-dated attempts are ignored")
s5 = C.compute(dict(scores=[attempt("Physics", PHY, 10, 10, days_ago=d) for d in range(6, -1, -1)]))
ok(s5["streak_cur"] == 7 and s5["streak_best"] == 7 and "streak-7" in s5["badges"], "7 days in a row gives a 7-day streak and its badge")
ex = C.compute(dict(scores=[dict(lesson="Paper", subject="Exam", score=9, total=10, date=iso(NOW), exam=dict(id="e1", max=80, pct=95))]))
ok(ex["xp"] == 0 and not ex["badges"], "Exam Center papers (graded in the browser) earn nothing")
ok(C.compute(None)["xp"] == 0 and C.compute("x")["xp"] == 0, "garbage summaries are harmless")

# --- handles and text
ok(C.clean_handle("Ab")[0] is None and C.clean_handle("admin")[0] is None and C.clean_handle("f_u_c_k_er")[0] is None and C.clean_handle("sam_9")[0] == "sam_9", "handle rules")
ok(C.clean_text("see www.x.com", 140, "Bio")[0] is None and C.clean_text("call 9876543210", 140, "Bio")[0] is None and C.clean_text("Loves chemistry", 140, "Bio")[0], "bio screening")

c = A.app.test_client()
reset_rate_limits()
r, _ = join(c, "kid", child=True); ok(r.status_code == 403, "children can't join")
r, _ = join(c, "kid2", band="child"); ok(r.status_code == 403, "under-13 age band can't join")
r, _ = join(c, "x1", agree=False); ok(r.status_code == 400, "joining needs explicit agreement")
r, ka = join(c, "alice"); ok(r.status_code == 200 and ka and r.get_json()["profile"]["visibility"] == "public", "adult joins public by default")
ok(join(c, "Alice")[0].status_code == 409, "handles are unique, case-insensitively")
reset_rate_limits()
r, kt = join(c, "teen_tom", band="teen", visibility="public"); ok(r.get_json()["profile"]["visibility"] == "friends", "13-15 year olds can't start public")
r, kb = join(c, "bob"); r, kc = join(c, "carol"); r, kp = join(c, "pat_private", visibility="private")
ok(c.get("/api/community/me").status_code == 401 and c.get("/api/community/me", headers=H("clk_nope_nope_nope_nope")).status_code == 401, "wrong or missing key is refused")
ok(c.get("/api/community/me", headers=H(ka)).get_json()["profile"]["handle"] == "alice", "key identifies the profile")

def lesson_id(folder): return next(l["id"] for l in IDX if l["id"].startswith(folder + "/"))
def pool_of(lid):
    les = C._lesson(lid); return C._quiz_pool(les)
def play(key, lid, right, age_secs=60, n=10, days_ago=0):
    """Start an attempt, answer `right` of `n` correctly, finish. Back-dates the start so the minimum-time rule is met."""
    r = c.post("/api/community/attempt/start", headers=H(key), json=dict(lesson=lid)); tok = r.get_json()["attempt"]
    pool = pool_of(lid); ans = []
    for k in range(n):
        q = pool[k]; good = q["options"][q["correct"]]; bad = next(o for o in q["options"] if o != good)
        ans.append(dict(i=k, p=good if k < right else bad))
    import sqlite3
    with sqlite3.connect(os.environ["DB_PATH"]) as db: db.execute("UPDATE cm_attempts SET started_at=started_at-? WHERE token=?", (age_secs, tok))
    r = c.post("/api/community/attempt/finish", headers=H(key), json=dict(attempt=tok, answers=ans))
    if days_ago and r.status_code == 200:
        with sqlite3.connect(os.environ["DB_PATH"]) as db: db.execute("UPDATE cm_attempts SET finished_at=finished_at-? WHERE token=?", (days_ago * 86400, tok))
        c.post("/api/community/sync", headers=H(key), json={})
    return r
LP, LC, LB = lesson_id("physics"), lesson_id("chemistry"), lesson_id("biology")
r = play(ka, LP, 10); ok(r.status_code == 200 and r.get_json()["score"] == 10 and r.get_json()["profile"]["xp"] == 20, "server grades the attempt and awards XP")
ok({b["id"] for b in r.get_json()["new_badges"]} >= {"first-quiz", "perfect-score"}, "finishing reports newly earned badges")
play(ka, LC, 10); r = play(ka, LP, 10); ok(r.get_json()["profile"]["xp"] == 60, "XP adds up across attempts")
# --- cheating attempts
r = c.post("/api/community/attempt/start", headers=H(ka), json=dict(lesson=LP)); tok = r.get_json()["attempt"]
pool = pool_of(LP); good = [dict(i=k, p=pool[k]["options"][pool[k]["correct"]]) for k in range(10)]
ok(c.post("/api/community/attempt/finish", headers=H(ka), json=dict(attempt=tok, answers=good)).status_code == 429, "a finish that is too fast is refused")
ok(c.post("/api/community/attempt/finish", headers=H(kb), json=dict(attempt=tok, answers=good)).status_code == 404, "someone else's attempt can't be finished")
ok(c.post("/api/community/attempt/start", headers=H(ka), json=dict(lesson="physics/not-a-lesson")).status_code == 404, "unknown lessons can't be started")
import sqlite3
with sqlite3.connect(os.environ["DB_PATH"]) as db: db.execute("UPDATE cm_attempts SET started_at=started_at-100 WHERE token=?", (tok,))
ok(c.post("/api/community/attempt/finish", headers=H(ka), json=dict(attempt=tok, answers=good + [good[0]])).status_code == 400, "duplicate question answers are refused")
ok(c.post("/api/community/attempt/finish", headers=H(ka), json=dict(attempt=tok, answers=good[:3])).status_code == 400, "too few answers are refused")
ok(c.post("/api/community/attempt/finish", headers=H(ka), json=dict(attempt=tok, answers=good)).status_code == 200, "a genuine finish still works after refusals")
ok(c.post("/api/community/attempt/finish", headers=H(ka), json=dict(attempt=tok, answers=good)).status_code == 404, "an attempt can only be finished once")
r = c.post("/api/community/sync", headers=H(ka), json=dict(summary=dict(scores=[dict(subject="Physics", lesson="x", score=10, total=10, date=iso(NOW))] * 50), xp=99999))
ok(r.status_code == 200 and r.get_json()["profile"]["xp"] == 80, "sync ignores anything the browser claims about its score")
ok(c.post("/api/community/sync", headers=H(ka), json=dict(child=True)).status_code == 403, "sync refuses a child flag")
ka_xp = 80
play(kb, LP, 5); play(kb, LB, 10); play(kc, LB, 6, days_ago=30); play(kp, LP, 10); play(kt, LP, 10)

# --- boards
g = c.get("/api/community/leaderboard").get_json()
names = [x["handle"] for x in g["rows"]]
ok(names == ["alice", "bob", "carol"], "global board: public learners only, highest XP first (private and friends-only hidden)")
ok(g["rows"][0]["rank"] == 1 and g["rows"][0]["pts"] == 80, "ranks and points")
w = c.get("/api/community/leaderboard?period=week").get_json()
ok([x["handle"] for x in w["rows"]] == ["alice", "bob"], "weekly board ignores old activity")
s = c.get("/api/community/leaderboard?board=subject&subject=Biology").get_json()
ok([x["handle"] for x in s["rows"]] == ["bob", "carol"] and s["rows"][0]["pts"] == 20, "per-subject board")
ok(c.get("/api/community/leaderboard?board=subject&subject=Nope").status_code == 400 and c.get("/api/community/leaderboard?board=friends").status_code == 401, "bad board / friends board needs sign-in")
m = c.get("/api/community/leaderboard", headers=H(kp)).get_json()
ok(m["me"]["on_board"] is False, "a private learner is told they are not on public boards")
m = c.get("/api/community/leaderboard", headers=H(kb)).get_json()
ok(m["me"]["rank"] == 2, "my rank is reported")

# --- friends
ok(c.post("/api/community/friends/request", headers=H(ka), json=dict(handle="pat_private")).status_code == 404, "private profiles can't be friended or found")
ok(c.post("/api/community/friends/request", headers=H(ka), json=dict(handle="ghost")).status_code == 404, "unknown handle looks the same as private")
ok(c.post("/api/community/friends/request", headers=H(ka), json=dict(handle="bob")).get_json()["status"] == "pending_out", "friend request sent")
ok(c.get("/api/community/friends", headers=H(kb)).get_json()["incoming"][0]["handle"] == "alice", "request arrives")
ok(c.post("/api/community/friends/respond", headers=H(ka), json=dict(handle="bob", accept=True)).status_code == 404, "the sender can't accept their own request")
ok(c.post("/api/community/friends/respond", headers=H(kb), json=dict(handle="alice", accept=True)).status_code == 200, "recipient accepts")
fb = c.get("/api/community/leaderboard?board=friends", headers=H(ka)).get_json()
ok([x["handle"] for x in fb["rows"]] == ["alice", "bob"] and fb["rows"][0]["me"], "friends board = me + accepted friends")
# friends-only profile
ok(c.get("/api/community/profile/teen_tom").status_code == 404, "friends-only profile is hidden from strangers")
c.post("/api/community/friends/request", headers=H(kt), json=dict(handle="alice")); c.post("/api/community/friends/respond", headers=H(ka), json=dict(handle="teen_tom", accept=True))
ok(c.get("/api/community/profile/teen_tom", headers=H(ka)).status_code == 200, "...and visible to an accepted friend")
ok(c.get("/api/community/profile/alice").get_json()["profile"]["badges"] and "email" not in json.dumps(c.get("/api/community/profile/alice").get_json()), "public profile shows badges and no private fields")
ok(c.get("/api/community/profile/pat_private", headers=H(ka)).status_code == 404, "private profile is not viewable by others")
ok(c.get("/api/community/profile/pat_private", headers=H(kp)).status_code == 200, "...but is viewable by its owner")

# --- block / report / admin
c.post("/api/community/block", headers=H(kc), json=dict(handle="alice"))
ok(c.get("/api/community/profile/alice", headers=H(kc)).status_code == 404 and c.get("/api/community/profile/carol", headers=H(ka)).status_code == 404, "blocking hides both ways")
ok("alice" not in [x["handle"] for x in c.get("/api/community/leaderboard", headers=H(kc)).get_json()["rows"]], "blocked learners leave my boards")
ok(c.post("/api/community/report", headers=H(kb), json=dict(handle="carol", reason="Inappropriate bio")).status_code == 200, "report filed")
adm = A.app.test_client()
ok(adm.get("/api/admin/community/reports").status_code == 401, "reports need admin")
adm.post("/api/admin/login", json={"email": "a@x.io", "password": "pw-pw-pw-pw"})
ok(adm.get("/api/admin/community/reports").get_json()["reports"][0]["target"] == "carol", "admin sees the report")
ok(adm.post("/api/admin/community/carol/hide").status_code == 200 and "carol" not in [x["handle"] for x in c.get("/api/community/leaderboard").get_json()["rows"]], "hidden profile leaves boards")
ok(c.get("/api/community/profile/carol").status_code == 404 and c.post("/api/community/sync", headers=H(kc), json=dict(summary={})).status_code == 403, "hidden profile is gone and locked")
adm.post("/api/admin/community/carol/unhide")
import sqlite3
ok(adm.delete("/api/admin/community/pat_private").status_code == 200 and sqlite3.connect(os.environ["DB_PATH"]).execute("SELECT COUNT(*) FROM cm_profiles WHERE handle='pat_private'").fetchone()[0] == 0, "admin delete erases the profile")
ok(adm.post("/api/admin/community/ghost/hide").status_code == 404, "admin action on unknown handle is a 404")

# --- settings and deletion
r = c.post("/api/community/me", headers=H(ka), json=dict(bio="Loves physics", display_name="Alice A.", visibility="friends"))
ok(r.get_json()["profile"]["visibility"] == "friends", "settings update")
ok(c.post("/api/community/me", headers=H(ka), json=dict(bio="visit http://spam.example")).status_code == 400, "links in a bio are refused")
ok("alice" not in [x["handle"] for x in c.get("/api/community/leaderboard").get_json()["rows"]], "switching to friends-only leaves public boards at once")
ok(c.delete("/api/community/me", headers=H(kb)).status_code == 200 and c.get("/api/community/profile/bob").status_code == 404, "deleting a profile removes it")
ok(not c.get("/api/community/friends", headers=H(ka)).get_json()["friends"] or all(f["handle"] != "bob" for f in c.get("/api/community/friends", headers=H(ka)).get_json()["friends"]), "...and its friendships")
ok(c.get("/api/community/me", headers=H(kb)).status_code == 401, "...and its key stops working")
ok(c.get("/api/community/meta").get_json()["badges"], "meta lists badges")
page = c.get("/u/teen_tom"); ok(page.status_code in (200, 404), "share route answers")
print("\n%d failed" % len(FAILS)); sys.exit(1 if FAILS else 0)
