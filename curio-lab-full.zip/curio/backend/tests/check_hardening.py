"""Run: python backend/tests/check_hardening.py  (needs flask + Pillow). Covers backups, admin lockout, error pages, error reports."""
import os, sys, tempfile, glob
tmp = tempfile.mkdtemp()
os.environ.update(DB_PATH=os.path.join(tmp, "test.db"), BACKUP_DIR=os.path.join(tmp, "bk"), BACKUP_KEEP="2", BACKUP_EVERY_HOURS="0",
                  PUSH_WORKER="0", SITE_URL="https://curiolab.test", ADMIN_EMAIL="a@x.io", ADMIN_PASSWORD="pw-pw-pw-pw", SECRET_KEY="k")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import app as A, backup, time
FAILS = []
def ok(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond: FAILS.append(msg)

@A.app.get("/__boom")
def _boom(): raise RuntimeError("test explosion")

c = A.app.test_client()
# --- error pages
r = c.get("/definitely/not/here"); ok(r.status_code == 404 and b"catalogued" in r.data and r.headers.get("X-Robots-Tag") == "noindex", "unknown page -> branded 404 page")
r = c.get("/api/nope"); ok(r.status_code == 404 and r.is_json, "unknown API path -> JSON 404")
r = c.get("/__boom"); ok(r.status_code == 500 and b"Something went wrong on our side" in r.data and b"test explosion" not in r.data, "crash -> branded 500 page, no internals leaked")
# --- browser error reports
body = {"message": "x is not a function", "stack": "at a (b.js:1:1)", "page": "https://h.test/pages/physics/force.html?email=a@b.c#quiz", "source": "https://h.test/js/quiz.js?v=3", "line": 12}
ok(c.post("/api/client-error", json=body).status_code == 202, "error report accepted")
c.post("/api/client-error", json=body)
ok(c.post("/api/client-error", json={"message": ""}).status_code == 202, "empty report ignored")
a = A.app.test_client()
ok(a.get("/api/admin/errors").status_code == 401, "error list needs admin")
ok(a.post("/api/admin/login", json={"email": "a@x.io", "password": "pw-pw-pw-pw"}).status_code == 200, "admin login ok")
rows = a.get("/api/admin/errors").get_json()["errors"]
ok(len(rows) == 1 and rows[0]["count"] == 2, "identical errors are folded into one row with a count")
ok("?" not in rows[0]["page"] and "#" not in rows[0]["page"] and "@" not in rows[0]["page"] and "h.test" not in rows[0]["page"], "page stored as a path only (no query, hash or host)")
# --- admin lockout
b = A.app.test_client()
for i in range(5):
    r = b.post("/api/admin/login", json={"email": "a@x.io", "password": "wrong"}); ok(r.status_code == 401, f"bad password {i+1} -> 401")
r = b.post("/api/admin/login", json={"email": "a@x.io", "password": "wrong"}); ok(r.status_code == 429, "6th attempt locked (429)")
r = b.post("/api/admin/login", json={"email": "a@x.io", "password": "pw-pw-pw-pw"}); ok(r.status_code == 429, "correct password still refused while locked")
with A.db() as d: d.execute("UPDATE login_fail SET ts=ts-1000"); 
r = b.post("/api/admin/login", json={"email": "a@x.io", "password": "pw-pw-pw-pw"}); ok(r.status_code == 200, "lock expires after the window")
# --- persistent rate limiting
from dbutil import too_many
ok(not any(too_many("t-bucket", "1.2.3.4", 3, 60) for _ in range(3)) and too_many("t-bucket", "1.2.3.4", 3, 60), "limiter blocks the 4th call")
ok(not too_many("t-bucket", "9.9.9.9", 3, 60), "other addresses unaffected")
ok(A.db().execute("SELECT COUNT(*) FROM rate_hits WHERE h LIKE '%1.2.3.4%'").fetchone()[0] == 0, "raw address is not stored (hashed)")
import importlib, dbutil
ok(too_many("t-bucket", "1.2.3.4", 3, 60), "limit survives a 'restart' (state is in the database)")
cc = A.app.test_client()
codes = [cc.post("/api/contact", json={"name": "N", "email": "a@b.co", "message": "hello there", "consent": 1, "age_ok": 1}).status_code for _ in range(7)]
ok(codes[:5] == [200]*5 and codes[5:] == [429, 429], "contact form: 5 per hour, then 429")
# --- backups
p1 = backup.backup_now(); ok(os.path.exists(p1) and backup.verify(p1), "backup is created and verifies")
ok(oct(os.stat(p1).st_mode & 0o777) == "0o600", "backup is owner-only")
for _ in range(3): time.sleep(1.1); backup.backup_now()
ok(len(glob.glob(os.path.join(tmp, "bk", "curiolab-*.db.gz"))) == 2, "old backups pruned to BACKUP_KEEP")
ok(not glob.glob(os.path.join(tmp, "bk", "*.tmp")) and not glob.glob(os.path.join(tmp, "bk", "*.part")), "no temp files left behind")
bad = os.path.join(tmp, "bad.db.gz"); open(bad, "wb").write(b"not a backup")
try: backup.verify(bad); bad_ok = False
except Exception: bad_ok = True
ok(bad_ok, "corrupt backup is rejected")
newest = sorted(glob.glob(os.path.join(tmp, "bk", "curiolab-*.db.gz")))[-1]
with A.db() as d: d.execute("DELETE FROM messages")
backup.restore(newest)
ok(A.db().execute("SELECT COUNT(*) FROM admins").fetchone()[0] == 1, "restore brings the database back")
print("FAILED: %d" % len(FAILS)); sys.exit(1 if FAILS else 0)
