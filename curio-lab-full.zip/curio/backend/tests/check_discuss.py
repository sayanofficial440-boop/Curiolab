"""Run: python backend/tests/check_discuss.py  Covers lesson discussions, study groups and friend quiz duels."""
import os, sys, tempfile, json, time
tmp = tempfile.mkdtemp()
os.environ.update(DB_PATH=os.path.join(tmp, "test.db"), BACKUP_DIR=os.path.join(tmp, "bk"), BACKUP_EVERY_HOURS="0", PUSH_WORKER="0",
                  SITE_URL="https://curiolab.test", ADMIN_EMAIL="a@x.io", ADMIN_PASSWORD="pw-pw-pw-pw", SECRET_KEY="k")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import app as A, community as C, discuss as D
from dbutil import reset_rate_limits, db
FAILS = []
def ok(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond: FAILS.append(msg)

# --- screening
s = lambda t, **k: D.screen(t, 500, "Post", **k)
ok(s("Why did Dickens write A Tale of Two Cities about the Nazi-era? no, the skill of Essex")[1] is None, "words like Dickens/skill/Essex are fine")
ok(s("The speed of light is 299,792,458 m/s")[1] is None, "big numbers with commas are fine")
ok(s("call me 98765 43210")[1] is not None and s("see www.x.com")[1] and s("mail a@b.io")[1] and s("<b>hi</b>")[1], "phones, links, emails, HTML refused")
ok(s("this hit the wall")[1] is None, "words don't join across spaces ('this hit')")
ok(s("you are a f u c k")[1] and s("sh1t")[1] and s("go die")[1], "strong profanity and abuse refused, even spaced or leet")
ok(s("Why does Romeo die by suicide in the play?")[1] is None, "academic mention of suicide is allowed")
r = s("i want to die")
ok(r[1] and r[2] is True, "first-person self-harm gets a supportive refusal, flagged")
ok(s("a\n\n\n\nb", multiline=True)[0] == "a\n\nb", "blank lines collapse")

# --- decide()
ok(D.decide(8, 100, 7, 10) == "ch" and D.decide(6, 50, 6, 60) == "ch" and D.decide(6, 50, 6, 51) == "draw" and D.decide(6, 90, 6, 30) == "op", "duel winner: score, then speed, draw if within 2s")

c = A.app.test_client(); reset_rate_limits()
def join(h, **kw):
    b = dict(handle=h, agree=True, band="adult"); b.update(kw)
    r = c.post("/api/community/join", json=b); return r.get_json().get("key")
H = lambda k: {"Authorization": "Bearer " + k}
def P(k, path, **j): return c.post("/api/community/" + path, json=j, headers=H(k))
def G(k, path): return c.get("/api/community/" + path, headers=H(k))
ka, kb, kc, kt = join("alice"), join("bob"), join("cara"), join("teeny", band="teen")
kp = join("privy", visibility="private")
LES = json.load(open(os.path.join(os.path.dirname(A.__file__), "..", "public", "data", "learning-index.json")))["lessons"][0]["id"]

# --- discussion
ok(c.get("/api/community/discuss?lesson=" + LES).status_code == 401, "reading needs a device key")
r = P(ka, "discuss/post", lesson=LES, kind="question", body="Why does friction oppose motion?"); ok(r.status_code == 200, "ask a question")
qid = r.get_json()["post"]["id"]
ok(P(ka, "discuss/post", lesson=LES, kind="question", body="Why does friction oppose motion?").status_code == 400, "duplicate refused")
ok(P(ka, "discuss/post", lesson=LES, kind="question", body="short").status_code == 400, "question too short")
ok(P(ka, "discuss/post", lesson="nope/nope", kind="question", body="Is this a real lesson?").status_code == 404, "unknown lesson")
ok(P(kp, "discuss/post", lesson=LES, kind="comment", body="private posting").status_code == 403, "private profile can't post")
ok(G(kp, "discuss?lesson=" + LES).status_code == 200, "...but can read")
a1 = P(kb, "discuss/post", parent=qid, kind="answer", body="Surfaces are rough at a tiny scale.").get_json()["post"]["id"]
a2 = P(kc, "discuss/post", parent=qid, kind="answer", body="Because of interlocking bumps.").get_json()["post"]["id"]
ok(P(ka, "discuss/vote", post=qid).get_json().get("error", "").startswith("You can't"), "no self-votes")
ok(P(ka, "discuss/vote", post=a2).get_json()["votes"] == 1 and P(kb, "discuss/vote", post=a2).get_json()["votes"] == 2, "upvotes count")
ok(P(ka, "discuss/vote", post=a2).get_json() == dict(ok=True, votes=1, voted=False), "vote toggles off")
ok(P(ka, "discuss/vote", post=a2).get_json()["votes"] == 2, "...and on again")
j = G(ka, "discuss?lesson=" + LES).get_json()
ok(j["counts"]["questions"] == 1 and len(j["items"][0]["children"]) == 2 and j["items"][0]["children"][0]["id"] == a2, "answers sorted by votes")
ok(P(kb, "discuss/accept", post=a1).status_code == 403, "only the asker accepts")
ok(P(ka, "discuss/accept", post=a1).get_json()["accepted"] is True, "asker accepts an answer")
j = G(ka, "discuss?lesson=" + LES).get_json()
ok(j["items"][0]["children"][0]["id"] == a1 and j["items"][0]["has_accepted"] and j["items"][0]["children"][0]["author"]["helpful"] == 1, "accepted answer floats to top and counts as helpful")
ok(G(ka, "discuss?lesson=" + LES + "&unanswered=1").get_json()["items"] == [], "unanswered filter")
cm = P(kt, "discuss/post", lesson=LES, kind="comment", body="Great lesson!").get_json()["post"]
ok(P(ka, "discuss/post", parent=cm["id"], kind="reply", body="Agreed!").status_code == 200, "reply to a comment")
ok(P(ka, "discuss/post", parent=qid, kind="reply", body="wrong parent type").status_code == 404, "reply can't target a question")
cj = G(ka, "discuss?lesson=" + LES + "&section=comments").get_json()
ok(cj["items"][0]["author"]["link"] is False, "friends-only teen byline has no profile link for strangers")
ok(cj["items"][0]["author"]["name"] == "teeny" and "band" not in json.dumps(cj), "no age band is exposed")
ok(P(ka, "discuss/edit", post=a1, body="Hijacked").status_code == 404, "only the author can edit")
ep = P(kb, "discuss/edit", post=a1, body="Surfaces are rough, even when they look smooth.")
ok(ep.status_code == 200 and G(ka, "discuss?lesson=" + LES).get_json()["items"][0]["children"][0]["edited"], "author edits within the window and it's marked edited")
ok(P(kb, "discuss/edit", post=a1, body="see www.spam.com").status_code == 400, "edits are screened too")
with db() as cx: cx.execute("UPDATE cm_posts SET created_at=created_at-1000 WHERE id=?", (a1,))
ok(P(kb, "discuss/edit", post=a1, body="Too late to change this").status_code == 409, "edit window closes after 15 minutes")
# blocking
P(kb, "block", handle="cara")
ok(all(x["id"] != a2 for x in G(kb, "discuss?lesson=" + LES).get_json()["items"][0]["children"]), "blocked people's posts disappear")
P(kb, "unblock", handle="cara")
# reports
for k in (ka, kt, kp):
    P(k, "discuss/report", post=a2, reason="rude")
ok(all(x["id"] != a2 for x in G(kt, "discuss?lesson=" + LES).get_json()["items"][0]["children"]), "3 reports auto-hide a post for everyone")
ok(P(kc, "discuss/delete", post=a1).status_code == 404 and P(kb, "discuss/delete", post=a1).status_code == 200, "only authors delete")
ok(P(ka, "discuss/delete", post=qid).status_code == 200 and G(ka, "discuss?lesson=" + LES).get_json()["counts"]["questions"] == 0, "deleting a question removes it")

# --- admin
ar = A.app.test_client(); ar.post("/api/admin/login", json=dict(email="a@x.io", password="pw-pw-pw-pw"))
ok(A.app.test_client().get("/api/admin/community/content-reports").status_code == 401, "content reports need admin")
pid = P(ka, "discuss/post", lesson=LES, kind="comment", body="A comment for the admin to moderate").get_json()["post"]["id"]
P(kt, "discuss/report", post=pid, reason="test")
rows = ar.get("/api/admin/community/content-reports").get_json()["reports"]
ok(rows and rows[0]["kind"] == "post" and rows[0]["target"]["body"].startswith("A comment") and rows[0]["target"]["author"] == "alice", "admin sees the reported post")
ok(ar.post("/api/admin/community/posts/%d/hide" % pid).status_code == 200 and all(x["id"] != pid for x in G(kb, "discuss?lesson=" + LES + "&section=comments").get_json()["items"]), "admin hide removes it from the thread")
ok(ar.post("/api/admin/community/posts/%d/unhide" % pid).status_code == 200 and any(x["id"] == pid for x in G(kb, "discuss?lesson=" + LES + "&section=comments").get_json()["items"]), "unhide brings it back")
ok(ar.post("/api/admin/community/content-reports/%d/handled" % rows[0]["id"]).status_code == 200, "mark handled")
ok(ar.post("/api/admin/community/posts/%d/delete" % pid).status_code == 200 and db().execute("SELECT COUNT(*) FROM cm_posts WHERE id=?", (pid,)).fetchone()[0] == 0, "admin delete removes it")

# --- groups
r = P(ka, "groups/create", name="Physics Squad", subject="Physics", goal=300); ok(r.status_code == 200, "create group")
g = r.get_json()["group"]; gid, inv = g["id"], g["invite"]
ok(P(ka, "groups/create", name="x").status_code == 400 and P(ka, "groups/create", name="Skill builders club").status_code == 200, "group name rules ('Skill' is fine)")
ok(P(kb, "groups/join", code="ZZZZ-ZZZZ").status_code == 404, "bad code")
ok(P(kb, "groups/join", code=inv.lower().replace("-", " ")).status_code == 200, "join with a sloppy-typed code")
ok(G(kc, "groups/" + gid).status_code == 404, "non-members can't open a group")
gj = G(ka, "groups/" + gid).get_json()["group"]
ok(gj["members"] == 2 and gj["goal"] == 300 and gj["invite"] == inv, "group detail")
ok(P(kb, "groups/" + gid + "/rotate").status_code == 403 and P(kb, "groups/" + gid + "/remove", handle="alice").status_code == 403, "members can't manage")
new = P(ka, "groups/" + gid + "/rotate").get_json()["group"]["invite"]
ok(new != inv and P(kc, "groups/join", code=inv).status_code == 404 and P(kc, "groups/join", code=new).status_code == 200, "rotating invalidates the old code")
P(kc, "block", handle="alice")
ok(all(m["handle"] != "alice" for m in G(kc, "groups/" + gid).get_json()["group"]["member_list"]), "blocked members are hidden from the list")
P(kc, "unblock", handle="alice")
ok(P(ka, "groups/" + gid + "/remove", handle="cara").status_code == 200 and G(kc, "groups/" + gid).status_code == 404, "owner removes a member")
gg = P(kb, "groups/create", name="Reportable").get_json()["group"]
P(kb, "groups/" + gg["id"] + "/report", reason="bad name")
gr = [r for r in ar.get("/api/admin/community/content-reports").get_json()["reports"] if r["kind"] == "group"]
ok(gr and gr[0]["target"]["name"] == "Reportable", "admin sees the reported group")
ok(ar.post("/api/admin/community/groups/%s/hide" % gg["id"]).status_code == 200 and G(kb, "groups/" + gg["id"]).status_code == 404 and G(kb, "groups").get_json()["groups"][0]["name"] != "Reportable", "admin hide closes the group for members")
ok(ar.post("/api/admin/community/groups/%s/delete" % gg["id"]).status_code == 200, "admin deletes a group")
ok(P(ka, "groups/" + gid + "/leave").status_code == 200 and G(kb, "groups/" + gid).get_json()["group"]["role"] == "owner", "owner leaving hands the group over")
ok(P(kb, "groups/" + gid + "/leave").status_code == 200 and G(kb, "groups").get_json()["groups"] == [], "last member leaving deletes it")

# --- duels
P(ka, "friends/request", handle="bob"); P(kb, "friends/respond", handle="alice", accept=True)
ok(P(ka, "duels/create", handle="cara", lesson=LES).status_code == 404, "duels need an accepted friend")
ok(P(ka, "duels/create", handle="bob", lesson="nope/x").status_code == 404, "duel needs a real lesson")
r = P(ka, "duels/create", handle="bob", lesson=LES); ok(r.status_code == 200, "challenge a friend")
did = r.get_json()["duel"]["id"]
ok(P(ka, "duels/create", handle="bob", lesson=LES).status_code == 400, "one open duel per pair")
ok(G(kc, "duels").get_json()["active"] == [] and P(kc, "duels/%s/start" % did).status_code == 404, "outsiders can't see or play a duel")
ok(G(kb, "me").get_json()["duels_waiting"] == 1, "/me reports a duel waiting")
st = P(ka, "duels/%s/start" % did).get_json()
ok(len(st["questions"]) == 10 and "correct" not in json.dumps(st) and all(len(q["options"]) >= 2 for q in st["questions"]), "start returns 10 questions, never the answers")
ok(P(ka, "duels/%s/finish" % did, answers=[dict(k=i, o=0) for i in range(10)]).status_code == 429, "too-fast finish refused")
with db() as cx: cx.execute("UPDATE cm_duels SET ch_start=ch_start-60 WHERE code=?", (did,))
d0 = json.loads(db().execute("SELECT qs FROM cm_duels WHERE code=?", (did,)).fetchone()[0])
perfect = [dict(k=i, o=q["c"]) for i, q in enumerate(d0)]
ok(P(ka, "duels/%s/finish" % did, answers=perfect[:5]).status_code == 400, "partial answers refused")
fj = P(ka, "duels/%s/finish" % did, answers=perfect).get_json()
ok(fj["score"] == 10 and fj["duel"]["status"] == "pending" and "opp_score" not in fj["duel"] and all(x["correct"] is None for x in fj["review"]), "challenger scores 10; nothing revealed yet")
ok(P(ka, "duels/%s/finish" % did, answers=perfect).status_code == 409, "can't finish twice")
ok(P(kb, "duels/%s/finish" % did, answers=perfect).status_code == 409, "can't finish without starting")
P(kb, "duels/%s/start" % did)
with db() as cx: cx.execute("UPDATE cm_duels SET op_start=op_start-60 WHERE code=?", (did,))
bad = [dict(k=i, o=(d0[i]["c"] + 1) % len(d0[i]["o"])) for i in range(10)]
fb = P(kb, "duels/%s/finish" % did, answers=bad).get_json()
ok(fb["score"] == 0 and fb["duel"]["status"] == "finished" and fb["duel"]["result"] == "loss" and fb["duel"]["opp_score"] == 10, "opponent loses 0-10 and sees the result")
ok(all(x["correct"] is not None for x in fb["review"]), "correct answers shown once the duel is over")
G(ka, "duels")
ok(db().execute("SELECT qs FROM cm_duels WHERE code=?", (did,)).fetchone()[0] == "[]", "question snapshot is dropped once the duel ends")
dl = G(ka, "duels").get_json()
ok(dl["record"] == dict(wins=1, losses=0, draws=0) and dl["finished"][0]["result"] == "win", "record counts the win")
# forfeit + expiry + decline
r = P(ka, "duels/create", handle="bob", lesson=LES).get_json()["duel"]["id"]
ok(P(kb, "duels/%s/respond" % r, accept=False).status_code == 200 and G(kb, "duels").get_json()["active"] == [], "decline closes the duel")
r = P(ka, "duels/create", handle="bob", lesson=LES).get_json()["duel"]["id"]
P(kb, "duels/%s/respond" % r, accept=True); P(ka, "duels/%s/start" % r)
with db() as cx: cx.execute("UPDATE cm_duels SET ch_start=ch_start-60, expires_at=? WHERE code=?", (int(time.time()) - 5, r))
with db() as cx: cx.execute("UPDATE cm_duels SET ch_done=1, ch_score=7, ch_secs=60 WHERE code=?", (r,))
ok(G(kb, "duels").get_json()["finished"][0]["result"] == "loss" and G(kb, "duels").get_json()["finished"][0]["forfeit"], "no-show after accepting forfeits")
r = P(ka, "duels/create", handle="bob", lesson=LES).get_json()["duel"]["id"]
with db() as cx: cx.execute("UPDATE cm_duels SET expires_at=? WHERE code=?", (int(time.time()) - 5, r))
ok(G(ka, "duels").get_json()["finished"][0]["status"] == "expired", "unanswered challenge expires without a result")
r = P(ka, "duels/create", handle="bob", lesson=LES).get_json()["duel"]["id"]
P(ka, "block", handle="bob")
ok(G(ka, "duels").get_json()["active"] == [], "blocking cancels open duels")

# --- erase
P(kb, "discuss/post", lesson=LES, kind="comment", body="Erase me please")
P(kb, "groups/create", name="Temp group")
ok(c.delete("/api/community/me", headers=H(kb)).status_code == 200, "bob erases his profile")
n = lambda q: db().execute(q).fetchone()[0]
ok(n("SELECT COUNT(*) FROM cm_posts WHERE author=2") == 0 and n("SELECT COUNT(*) FROM cm_groups WHERE name='Temp group'") == 0 and n("SELECT COUNT(*) FROM cm_duels") == 0, "erasing a profile removes posts, groups and duels")

print("\n%d failed" % len(FAILS)); sys.exit(1 if FAILS else 0)
