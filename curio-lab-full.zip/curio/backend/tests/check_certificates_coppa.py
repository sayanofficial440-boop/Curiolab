"""Run: python backend/tests/check_certificates_coppa.py  (needs flask + Pillow). Exits 1 on any FAIL."""
import os, sys, json, re
import tempfile
os.environ.update(DB_PATH=os.path.join(tempfile.mkdtemp(), "test.db"), PUSH_WORKER="0",
                  COPPA_DEV_SHOW_LINK="1", SITE_URL="https://curiolab.test", ADMIN_EMAIL="a@x.io", ADMIN_PASSWORD="pw-pw-pw-pw", SECRET_KEY="k")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import app as A
c = A.app.test_client()
FAILS = []
def ok(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond: FAILS.append(msg)

# --- adult certificate
import json as _json, os as _os
_IDX = _json.load(open(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", "..", "public", "data", "learning-index.json")))["lessons"]
def real(subject, n=10):
    l = next(x for x in _IDX if x["id"].split("/")[0].replace("-", " ") == subject.lower())
    return {"subject": subject, "lesson": l["title"], "score": n, "total": n}
summ = {"scores": [real(x) for x in ("Physics", "Chemistry", "Biology")], "streak_best": 3}
r = c.post("/api/certificates/issue", json={"tier_id": "well-rounded", "name": "Asha Rao", "holder_key": "x"*20, "summary": summ})
ok(r.status_code == 200, "issue well-rounded"); cert = r.get_json()["certificate"]; print(cert["url"])
ok(re.fullmatch(r"CL-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}", cert["code"]), "code format")
r2 = c.post("/api/certificates/issue", json={"tier_id": "well-rounded", "name": "Asha Rao", "holder_key": "x"*20, "summary": summ})
ok(r2.get_json().get("existing") and r2.get_json()["certificate"]["code"] == cert["code"], "idempotent per device+tier")
ok(c.post("/api/certificates/issue", json={"tier_id": "streak-master", "name": "A", "holder_key": "x"*20, "summary": summ}).status_code == 403, "ineligible streak refused")
ok(c.post("/api/certificates/issue", json={"tier_id": "perfect-score", "name": "me@x.com", "holder_key": "y"*20, "summary": summ}).status_code == 400, "email in name refused")
ok(c.post("/api/certificates/issue", json={"tier_id": "perfect-score", "name": "Bo", "holder_key": "z"*20, "summary": {"scores": [real("Physics", 5)]}}).status_code == 200, "perfect-score ok")
ok(c.post("/api/certificates/issue", json={"tier_id": "perfect-score", "name": "Bo", "holder_key": "w"*20, "summary": {"scores": [{**real("Physics", 5), "score": 2, "total": 2}]}}).status_code == 403, "tiny quiz refused")
v = c.get("/verify/" + cert["code"].lower().replace("-", " "))
html = v.get_data(as_text=True)
ok(v.status_code == 200 and "Verified by Curio Lab" in html and 'property="og:image" content="https://curiolab.test/verify/' in html, "verify page + og:image")
ok("noindex" in v.headers.get("X-Robots-Tag", ""), "verify page noindex header")
ok("@" not in re.sub(r"<[^>]+>", "", re.sub(r"<style>.*?</style>", "", html, flags=re.S)), "no email-like text on verify page")
im = c.get(f"/verify/{cert['code']}/image.png"); ok(im.status_code == 200 and im.data[:4] == b"\x89PNG", "certificate image png")
ok(c.get("/verify/CL-AAAA-AAAA-AAAA").status_code == 404, "unknown code 404")
ok(c.get("/api/certificates/verify/" + cert["code"]).get_json()["valid"] is True, "json verify valid")
# --- revoke
a = A.app.test_client(); ok(a.post("/api/admin/login", json={"email": "a@x.io", "password": "pw-pw-pw-pw"}).status_code == 200, "admin login")
ok(c.post(f"/api/admin/certificates/{cert['code']}/revoke").status_code == 401, "revoke needs admin")
ok(a.post(f"/api/admin/certificates/{cert['code']}/revoke", json={"reason": "test"}).status_code == 200, "revoke")
ok("Revoked" in c.get("/verify/" + cert["code"]).get_data(as_text=True), "revoked page")
ok(c.get(f"/verify/{cert['code']}/image.png").status_code == 404, "revoked image 404")

# --- child consent
r = c.post("/api/coppa/request", json={"nickname": "Star Fox", "parent_email": "parent@example.org"}); j = r.get_json()
ok(r.status_code == 200 and j["status"] == "pending" and j["delivery"] == "unconfigured", "request pending, honest delivery status")
ref, link = j["child_ref"], j["dev_link"]; tok = link.split("t=")[1]
ok(c.post("/api/coppa/request", json={"nickname": "a@b.c", "parent_email": "parent@example.org"}).status_code == 400, "bad nickname")
ok(c.post("/api/coppa/request", json={"nickname": "Kid", "parent_email": "nope"}).status_code == 400, "bad parent email")
cs = {"scores": [real("Physics", 6)]}
ok(c.post("/api/certificates/issue", json={"tier_id": "perfect-score", "holder_key": "k"*20, "child_ref": ref, "summary": cs}).status_code == 403, "child cert blocked before consent")
ok(c.post("/api/certificates/issue", json={"tier_id": "perfect-score", "holder_key": "k"*20, "child": True, "name": "Real Name", "summary": cs}).status_code == 403, "child claiming no ref blocked")
info = c.get("/api/coppa/consent/" + tok).get_json(); ok(info["status"] == "pending" and info["nickname"] == "Star Fox" and "child_ref" not in json.dumps(info), "parent view, no child_ref leaked")
ok(c.get("/api/coppa/consent/bad").status_code == 404, "bad token 404")
ok(c.post(f"/api/coppa/consent/{tok}/decision", json={"decision": "approve"}).get_json()["status"] == "granted", "approve")
ok(c.get(f"/api/coppa/status/{ref}").get_json()["status"] == "granted", "child sees granted")
r = c.post("/api/certificates/issue", json={"tier_id": "perfect-score", "holder_key": "k"*20, "child_ref": ref, "name": "Spoofed", "summary": cs})
ok(r.status_code == 200 and r.get_json()["certificate"]["name"] == "Star Fox", "child cert uses approved nickname only")
ex = c.get(f"/api/coppa/consent/{tok}/export").get_json(); ok(len(ex["certificates"]) == 1 and ex["parent_email"] == "parent@example.org", "export includes cert + email")
ok(c.post(f"/api/coppa/consent/{tok}/decision", json={"decision": "decline"}).status_code == 409, "cannot flip decision")
d = c.post(f"/api/coppa/consent/{tok}/delete").get_json(); ok(d["ok"] and d["deleted"]["certificates"] == 1, "parent delete removes certs")
ok(c.get(f"/api/coppa/status/{ref}").get_json()["status"] == "gone", "child status gone")
ok(c.get("/verify/" + r.get_json()["certificate"]["code"]).status_code == 404, "child cert page gone after delete")
import dbutil; dbutil.reset_rate_limits()
# decline path wipes email
j = c.post("/api/coppa/request", json={"nickname": "Kid Two", "parent_email": "p2@example.org"}).get_json(); t2 = j["dev_link"].split("t=")[1]
c.post(f"/api/coppa/consent/{t2}/decision", json={"decision": "decline"})
row = A.db().execute("select parent_email,status from coppa_consents where child_ref=?", (j["child_ref"],)).fetchone()
ok(row["status"] == "declined" and row["parent_email"] is None, "decline erases parent email")
# purge
j = c.post("/api/coppa/request", json={"nickname": "Kid Three", "parent_email": "p3@example.org"}).get_json()
with A.db() as cx: cx.execute("update coppa_consents set expires_at=1 where child_ref=?", (j["child_ref"],))
import coppa; ok(coppa.purge() >= 1 and c.get(f"/api/coppa/status/{j['child_ref']}").get_json()["status"] == "gone", "expired pending request purged")
# contact needs age_ok
ok(c.post("/api/contact", json={"name": "N", "email": "n@x.io", "message": "hello world", "consent": True}).status_code == 400, "contact requires age confirmation")
ok(c.post("/api/contact", json={"name": "N", "email": "n@x.io", "message": "hello world", "consent": True, "age_ok": True}).status_code == 200, "contact ok with age confirmation")
# admin privacy erase covers parent email
j = c.post("/api/coppa/request", json={"nickname": "Kid Four", "parent_email": "p4@example.org"}).get_json()
lk = a.get("/api/admin/privacy/lookup?email=p4@example.org").get_json(); ok(len(lk["child_accounts"]) == 1, "admin lookup finds child account")
er = a.post("/api/admin/privacy/erase", json={"email": "p4@example.org"}).get_json(); ok(er["deleted"]["coppa_consents"] == 1, "admin erase removes child account")

# --- forged scores naming made-up lessons / impossible quiz lengths are rejected
fake = {"scores": [{"subject": "Physics", "lesson": "Totally Invented Lesson", "score": 9, "total": 9}]}
ok(c.post("/api/certificates/issue", json={"tier_id": "perfect-score", "name": "Fx", "holder_key": "f"*20, "summary": fake}).status_code == 403, "made-up lesson name is not eligible")
huge = {"scores": [{**real("Physics", 5), "score": 500, "total": 500}]}
ok(c.post("/api/certificates/issue", json={"tier_id": "perfect-score", "name": "Fx", "holder_key": "g"*20, "summary": huge}).status_code == 403, "quiz longer than the lesson's real quiz is not eligible")
fake3 = {"scores": [{"subject": s, "lesson": "Nope", "score": 10, "total": 10} for s in ("Physics", "Chemistry", "Biology")]}
ok(c.post("/api/certificates/issue", json={"tier_id": "well-rounded", "name": "Fx", "holder_key": "h"*20, "summary": fake3}).status_code == 403, "well-rounded needs three REAL perfect lessons")
print("FAILED:", len(FAILS))
sys.exit(1 if FAILS else 0)

