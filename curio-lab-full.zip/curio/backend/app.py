"""Curio Lab admin backend (Flask + SQLite). Serves ../public and the /api/admin/* endpoints the admin pages call.
Run:  pip install flask   &&   ADMIN_EMAIL=... ADMIN_PASSWORD=... ADMIN_NAME=... SECRET_KEY=... python app.py
The admin is created from those env vars on first start (password stored hashed, never in the repo)."""
import os, sqlite3, time, secrets, json, base64, threading, logging, hashlib
from functools import wraps
from flask import Flask, request, jsonify, session, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash

from dbutil import ROOT, DB, db, too_many, client_ip   # shared with certificates.py / coppa.py
import coppa, certificates, monitoring, backup, coach, community, discuss, moderation, rooms
monitoring.init_sentry()  # only when SENTRY_DSN is set
app = Flask(__name__, static_folder=None)
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1")

def init():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY, name TEXT, email TEXT UNIQUE, password_hash TEXT, role TEXT DEFAULT 'admin', is_active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, email TEXT UNIQUE, provider TEXT DEFAULT 'email', created_at INTEGER);
        CREATE TABLE IF NOT EXISTS subscriptions(id INTEGER PRIMARY KEY, user_id INTEGER, name TEXT, email TEXT, plan TEXT, amount REAL, status TEXT);
        CREATE TABLE IF NOT EXISTS push_subs(endpoint TEXT PRIMARY KEY, sub TEXT, next_due INTEGER DEFAULT 0, due_count INTEGER DEFAULT 0, tz_offset INTEGER DEFAULT 0, last_sent INTEGER DEFAULT 0, created_at INTEGER);
        CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT);
        CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, topic TEXT, name TEXT, email TEXT, message TEXT, consent INTEGER DEFAULT 0, created_at INTEGER, handled INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, action TEXT, user_name TEXT, user_email TEXT, detail TEXT, created_at INTEGER);
        """)
        coppa.init(c); certificates.init(c); monitoring.init(c); community.init(c); discuss.init(c); moderation.init(c); rooms.init(c)
        c.execute("CREATE TABLE IF NOT EXISTS login_fail(id INTEGER PRIMARY KEY, k TEXT, ts INTEGER)")
        c.execute("CREATE INDEX IF NOT EXISTS login_fail_k ON login_fail(k, ts)")
        e, p = os.environ.get("ADMIN_EMAIL"), os.environ.get("ADMIN_PASSWORD")
        if e and p and not c.execute("SELECT 1 FROM admins WHERE email=?", (e.lower(),)).fetchone():
            c.execute("INSERT INTO admins(name,email,password_hash,role) VALUES(?,?,?,'superadmin')",
                      (os.environ.get("ADMIN_NAME", "Admin"), e.lower(), generate_password_hash(p)))

def log(action, name="-", email="-", detail="-"):
    with db() as c: c.execute("INSERT INTO audit(action,user_name,user_email,detail,created_at) VALUES(?,?,?,?,?)", (action, name, email, detail, int(time.time())))

def current():
    aid = session.get("admin_id")
    if not aid: return None
    r = db().execute("SELECT * FROM admins WHERE id=? AND is_active=1", (aid,)).fetchone()
    return r

def admin_only(f):
    @wraps(f)
    def w(*a, **k):
        if not current(): return jsonify(error="Not signed in."), 401
        return f(*a, **k)
    return w

def pub(r): return {"id": r["id"], "name": r["name"], "email": r["email"], "role": r["role"]}

LOGIN_WINDOW, LOGIN_MAX_PER_ACCOUNT, LOGIN_MAX_PER_IP = 900, 5, 20
def login_failures(key):
    with db() as c:
        c.execute("DELETE FROM login_fail WHERE ts<?", (int(time.time()) - LOGIN_WINDOW,))
        return c.execute("SELECT COUNT(*) FROM login_fail WHERE k=?", (key,)).fetchone()[0]

@app.post("/api/admin/login")
def login():
    d = request.get_json(silent=True) or {}
    email = (d.get("email") or "").lower().strip()[:200]
    ip = request.headers.get("X-Forwarded-For", request.remote_addr or "?").split(",")[0].strip()
    k_em, k_ip = "em:" + hashlib.sha256(email.encode()).hexdigest()[:20], "ip:" + ip
    # Lockout survives restarts (stored in the DB): 5 bad passwords per account or 20 per address in 15 minutes.
    if login_failures(k_em) >= LOGIN_MAX_PER_ACCOUNT or login_failures(k_ip) >= LOGIN_MAX_PER_IP:
        log("admin_login_locked", "-", "-", "ref=" + k_em[3:11])
        return jsonify(error="Too many failed attempts. Please wait 15 minutes and try again."), 429
    r = db().execute("SELECT * FROM admins WHERE email=?", (email,)).fetchone()
    time.sleep(0.4)  # slow down guessing
    if not r or not r["is_active"] or not check_password_hash(r["password_hash"], d.get("password") or ""):
        with db() as c:
            c.executemany("INSERT INTO login_fail(k,ts) VALUES(?,?)", [(k_em, int(time.time())), (k_ip, int(time.time()))])
        log("failed_admin_login", "-", email, "bad credentials"); return jsonify(error="Incorrect email or password."), 401
    with db() as c: c.execute("DELETE FROM login_fail WHERE k=?", (k_em,))
    session.clear(); session["admin_id"] = r["id"]; log("admin_login", r["name"], r["email"])
    return jsonify(admin=pub(r))

@app.post("/api/admin/logout")
def logout():
    a = current()
    if a: log("admin_logout", a["name"], a["email"])
    session.clear(); return jsonify(ok=True)

@app.get("/api/admin/me")
def me():
    a = current(); return (jsonify(admin=pub(a)) if a else (jsonify(error="Not signed in."), 401))

@app.post("/api/admin/setup")
def setup():
    c = db()
    if c.execute("SELECT 1 FROM admins").fetchone(): return jsonify(error="Setup already completed."), 403
    d = request.get_json(silent=True) or {}
    if len(d.get("password") or "") < 10: return jsonify(error="Password must be at least 10 characters."), 400
    with c: c.execute("INSERT INTO admins(name,email,password_hash,role) VALUES(?,?,?,'superadmin')", (d.get("name") or "Admin", d["email"].lower().strip(), generate_password_hash(d["password"])))
    return jsonify(ok=True)

@app.get("/api/admin/stats")
@admin_only
def stats():
    c = db(); q = lambda s, *a: c.execute(s, a).fetchone()[0]
    day = int(time.time()) - 86400
    return jsonify(users=q("SELECT COUNT(*) FROM users"), admins=q("SELECT COUNT(*) FROM admins"),
        subscriptions=dict(active=q("SELECT COUNT(*) FROM subscriptions WHERE status='active'"), revenue=q("SELECT COALESCE(SUM(amount),0) FROM subscriptions WHERE status='active'"), total=q("SELECT COUNT(*) FROM subscriptions")),
        audit=dict(today=q("SELECT COUNT(*) FROM audit WHERE created_at>?", day), total=q("SELECT COUNT(*) FROM audit"), suspicious=q("SELECT COUNT(*) FROM audit WHERE action='suspicious_activity'"),
                   logins=q("SELECT COUNT(*) FROM audit WHERE action IN('login','admin_login')"), signups=q("SELECT COUNT(*) FROM audit WHERE action='signup'")))

@app.get("/api/admin/users")
@admin_only
def users(): return jsonify(users=[dict(r) for r in db().execute("SELECT id,name,email,provider,created_at FROM users ORDER BY id DESC")])

@app.get("/api/admin/subscriptions")
@admin_only
def subs(): return jsonify(subscriptions=[dict(r) for r in db().execute("SELECT id,name,email,plan,amount,status FROM subscriptions ORDER BY id DESC")])

@app.get("/api/admin/audit-logs")
@admin_only
def audit():
    lim = min(int(request.args.get("limit", 200)), 1000); act = request.args.get("action")
    sql, a = "SELECT * FROM audit" + (" WHERE action=?" if act else "") + " ORDER BY id DESC LIMIT ?", ([act] if act else []) + [lim]
    return jsonify(logs=[dict(r) for r in db().execute(sql, a)])

@app.get("/api/admin/admins")
@admin_only
def admins(): return jsonify(admins=[dict(r) for r in db().execute("SELECT id,name,email,role,is_active FROM admins ORDER BY id")])

@app.post("/api/admin/invite")
@admin_only
def invite():
    if current()["role"] != "superadmin": return jsonify(error="Only a superadmin can add admins."), 403
    d = request.get_json(silent=True) or {}
    if len(d.get("password") or "") < 10: return jsonify(error="Password must be at least 10 characters."), 400
    try:
        with db() as c: c.execute("INSERT INTO admins(name,email,password_hash,role) VALUES(?,?,?,?)", (d.get("name"), d["email"].lower().strip(), generate_password_hash(d["password"]), "superadmin" if d.get("role") == "superadmin" else "admin"))
    except sqlite3.IntegrityError: return jsonify(error="That email already has an admin account."), 409
    return jsonify(ok=True)

@app.post("/api/admin/admins/<int:aid>/toggle")
@admin_only
def toggle(aid):
    if current()["role"] != "superadmin": return jsonify(error="Only a superadmin can do that."), 403
    with db() as c: c.execute("UPDATE admins SET is_active=1-is_active WHERE id=? AND role!='superadmin'", (aid,))
    return jsonify(ok=True)


# ---- "Review due today" web push -------------------------------------------------------------
# The Mistake Notebook lives in the browser (localStorage). The browser tells us ONLY its push
# subscription, the time its next review falls due, and how many are due -- never question text.
# A background loop pushes a generic reminder when that time passes (not during 22:00-07:00 local).
try:
    from pywebpush import webpush, WebPushException
    from py_vapid import Vapid
    from cryptography.hazmat.primitives import serialization
except ImportError:  # pip install -r requirements.txt
    webpush = None

def vapid():
    with db() as c:
        r = c.execute("SELECT v FROM kv WHERE k='vapid_pem'").fetchone()
        if r: v = Vapid.from_pem(r["v"].encode())
        else:
            v = Vapid(); v.generate_keys()
            c.execute("INSERT INTO kv(k,v) VALUES('vapid_pem',?)", (v.private_pem().decode(),))
    raw = v.public_key.public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    return v, base64.urlsafe_b64encode(raw).rstrip(b"=").decode()

@app.get("/api/push/key")
def push_key():
    if too_many("push-key", client_ip(request), 60, 3600): return jsonify(error="Too many requests. Please try again later."), 429
    if not webpush: return jsonify(error="Push is not installed on this server."), 503
    return jsonify(key=vapid()[1])

@app.post("/api/push/sync")
def push_sync():
    if too_many("push-sync", client_ip(request), 60, 3600): return jsonify(error="Too many requests. Please try again later."), 429
    d = request.get_json(silent=True) or {}; sub = d.get("subscription") or {}
    if not sub.get("endpoint") or not str(sub["endpoint"]).startswith("https://"): return jsonify(error="Bad subscription."), 400
    due = int(d.get("nextDue") or 0); n = max(0, int(d.get("dueCount") or 0)); tz = max(-840, min(840, int(d.get("tzOffset") or 0)))
    with db() as c:
        c.execute("INSERT INTO push_subs(endpoint,sub,next_due,due_count,tz_offset,created_at) VALUES(?,?,?,?,?,?) "
                  "ON CONFLICT(endpoint) DO UPDATE SET sub=excluded.sub,next_due=excluded.next_due,due_count=excluded.due_count,tz_offset=excluded.tz_offset",
                  (sub["endpoint"], json.dumps(sub), due, n, tz, int(time.time())))
    return jsonify(ok=True)

@app.post("/api/push/unsubscribe")
def push_unsub():
    ep = ((request.get_json(silent=True) or {}).get("endpoint") or "")
    with db() as c: c.execute("DELETE FROM push_subs WHERE endpoint=?", (ep,))
    return jsonify(ok=True)

def push_tick():
    """Send one reminder per due period (and at most one a day while reviews stay unanswered)."""
    if not webpush: return
    now = int(time.time()); v, _ = vapid()
    with db() as c: rows = c.execute("SELECT * FROM push_subs WHERE next_due>0 AND next_due<=? AND due_count>0 AND (last_sent<next_due OR ?-last_sent>86400)", (now * 1000, now)).fetchall()
    for r in rows:
        hour = ((now - r["tz_offset"] * 60) // 3600) % 24   # tz_offset = JS getTimezoneOffset() (minutes, UTC - local)
        if hour >= 22 or hour < 7: continue
        n = r["due_count"]
        body = json.dumps({"title": "Review due today", "body": f"{n} question{'s' if n != 1 else ''} ready in your Mistake Notebook.", "url": "pages/review.html"})
        try:
            webpush(json.loads(r["sub"]), body, vapid_private_key=v, vapid_claims={"sub": os.environ.get("VAPID_SUBJECT", "mailto:admin@curiolab.app")})
            with db() as c: c.execute("UPDATE push_subs SET last_sent=? WHERE endpoint=?", (now, r["endpoint"]))
        except WebPushException as e:
            if getattr(e.response, "status_code", 0) in (404, 410):
                with db() as c: c.execute("DELETE FROM push_subs WHERE endpoint=?", (r["endpoint"],))
            else: logging.warning("push failed: %s", e)
        except Exception as e: logging.warning("push error: %s", e)

def push_loop():
    while True:
        try: push_tick()
        except Exception as e: logging.warning("push loop: %s", e)
        time.sleep(60)


# ---- Contact form (Contact, Careers, Partners and Press pages post here) ----------------------
# Stores name, email, topic and message so the team can reply. The visitor ticks a consent box; the row is deleted
# after MESSAGE_RETENTION_DAYS (default 365) or sooner on request (admin DELETE below / privacy requests).
TOPICS = {"general", "bug", "feedback", "teacher", "partner", "careers", "press", "privacy"}
RETENTION = int(os.environ.get("MESSAGE_RETENTION_DAYS", 365)) * 86400

@app.post("/api/contact")
def contact_post():
    d = request.get_json(silent=True) or {}
    if d.get("website"): return jsonify(ok=True)  # honeypot: bots fill the hidden field, humans never see it
    now = time.time()
    if too_many("contact", client_ip(request), 5, 3600): return jsonify(error="Too many messages from this device. Please try again later."), 429
    name, email, msg = (d.get("name") or "").strip(), (d.get("email") or "").strip(), (d.get("message") or "").strip()
    topic = d.get("topic") if d.get("topic") in TOPICS else "general"
    if not name or len(name) > 120: return jsonify(error="Please enter your name."), 400
    if "@" not in email or "." not in email.split("@")[-1] or len(email) > 200: return jsonify(error="Please enter a valid email address."), 400
    if len(msg) < 5 or len(msg) > 5000: return jsonify(error="Please write a message (up to 5,000 characters)."), 400
    if not d.get("consent"): return jsonify(error="Please tick the box so we can store your message and reply."), 400
    if not d.get("age_ok"): return jsonify(error="Please confirm you are 13 or older, or a parent or guardian writing for a child."), 400
    with db() as c: c.execute("INSERT INTO messages(topic,name,email,message,consent,created_at) VALUES(?,?,?,?,1,?)", (topic, name, email, msg, int(now)))
    return jsonify(ok=True)

@app.get("/api/admin/messages")
@admin_only
def messages_list(): return jsonify(messages=[dict(r) for r in db().execute("SELECT * FROM messages ORDER BY id DESC LIMIT 500")])

@app.post("/api/admin/messages/<int:mid>/handled")
@admin_only
def messages_handled(mid):
    with db() as c: c.execute("UPDATE messages SET handled=1-handled WHERE id=?", (mid,))
    return jsonify(ok=True)

@app.delete("/api/admin/messages/<int:mid>")
@admin_only
def messages_delete(mid):
    with db() as c: c.execute("DELETE FROM messages WHERE id=?", (mid,))
    log("message_deleted", current()["name"], current()["email"], f"id={mid}")
    return jsonify(ok=True)

# ---- Privacy requests (GDPR Art. 15-17, 20): look up / export / erase everything held about one email address ----
# Used from /pages/admin/messages.html after the requester has been verified (reply to their email first).
def _em(d): return ((d or {}).get("email") or "").strip().lower()

@app.get("/api/admin/privacy/lookup")
@admin_only
def privacy_lookup():
    em = (request.args.get("email") or "").strip().lower()
    if "@" not in em: return jsonify(error="Enter a valid email address."), 400
    q = lambda sql: [dict(r) for r in db().execute(sql, (em,))]
    out = dict(email=em, exported_at=int(time.time()),
               users=q("SELECT id,name,email,provider,created_at FROM users WHERE lower(email)=?"),
               subscriptions=q("SELECT id,plan,amount,status FROM subscriptions WHERE lower(email)=?"),
               messages=q("SELECT id,topic,name,email,message,created_at,handled FROM messages WHERE lower(email)=?"),
               audit=q("SELECT action,detail,created_at FROM audit WHERE lower(user_email)=? ORDER BY id DESC LIMIT 500"),
               child_accounts=coppa.lookup_by_email(db(), em))
    log("privacy_lookup", current()["name"], current()["email"], "ref=" + hashlib.sha256(em.encode()).hexdigest()[:10])
    return jsonify(out)

@app.post("/api/admin/privacy/erase")
@admin_only
def privacy_erase():
    em = _em(request.get_json(silent=True))
    if "@" not in em: return jsonify(error="Enter a valid email address."), 400
    if db().execute("SELECT 1 FROM admins WHERE lower(email)=?", (em,)).fetchone():
        return jsonify(error="That address belongs to an admin account. Remove it from the Admins page."), 400
    with db() as c:
        n = dict(
            messages=c.execute("DELETE FROM messages WHERE lower(email)=?", (em,)).rowcount,
            subscriptions=c.execute("DELETE FROM subscriptions WHERE lower(email)=?", (em,)).rowcount,
            users=c.execute("DELETE FROM users WHERE lower(email)=?", (em,)).rowcount,
            audit_anonymised=c.execute("UPDATE audit SET user_email='[erased]', user_name='[erased]' WHERE lower(user_email)=?", (em,)).rowcount,
            **coppa.erase_by_email(c, em))
    log("privacy_erase", current()["name"], current()["email"], "ref=%s %s" % (hashlib.sha256(em.encode()).hexdigest()[:10], n))
    return jsonify(ok=True, deleted=n)

def purge_old_messages():
    with db() as c: c.execute("DELETE FROM messages WHERE created_at<?", (int(time.time()) - RETENTION,))

PUB = os.path.normpath(os.path.join(ROOT, "..", "public"))
@app.get("/", defaults={"p": "index.html"})
@app.get("/<path:p>")
def static_files(p): return send_from_directory(PUB, p)

coppa.register(app)
coach.register(app)
certificates.register(app, admin_only, log, current)
monitoring.register(app, admin_only, PUB)
community.register(app, admin_only, log)
discuss.register(app, admin_only, log)
moderation.register(app, admin_only, log)
rooms.register(app, admin_only, log)
init(); purge_old_messages()
backup.start()  # daily verified backup; BACKUP_EVERY_HOURS=0 turns it off (use cron + `python backup.py` with several workers)
if os.environ.get("PUSH_WORKER", "1") == "1": threading.Thread(target=push_loop, daemon=True).start()  # with gunicorn use ONE worker (or PUSH_WORKER=0 + a cron calling push_tick)
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
