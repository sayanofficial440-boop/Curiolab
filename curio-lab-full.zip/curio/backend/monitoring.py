"""First-party error monitoring: browser error reports, admin listing, friendly error pages, optional Sentry.

Browser reports are collected by public/js/monitor.js. A report holds only: the message, a short stack, the page PATH
(no query string or hash), a timestamp and a count. No cookies, no IP address, no user agent, no account details.
Identical errors are folded into one row with a counter, and the table is capped so it cannot grow without limit.
"""
import os, time, re, hashlib, logging
from flask import request, jsonify, send_from_directory, Response
from werkzeug.exceptions import HTTPException

from dbutil import db, too_many, client_ip

log = logging.getLogger("curiolab.monitoring")
MAX_ROWS = int(os.environ.get("CLIENT_ERROR_MAX_ROWS", "2000"))
KEEP_DAYS = int(os.environ.get("CLIENT_ERROR_KEEP_DAYS", "30"))


def init(c):
    c.execute("""CREATE TABLE IF NOT EXISTS client_errors(
        id INTEGER PRIMARY KEY, fp TEXT UNIQUE, message TEXT, stack TEXT, page TEXT, source TEXT,
        count INTEGER DEFAULT 1, first_seen INTEGER, last_seen INTEGER)""")


def init_sentry():
    dsn = os.environ.get("SENTRY_DSN")
    if not dsn:
        return False
    try:
        import sentry_sdk
    except ImportError:
        log.warning("SENTRY_DSN is set but sentry-sdk is not installed (pip install 'sentry-sdk[flask]')")
        return False
    sentry_sdk.init(dsn=dsn, send_default_pii=False, traces_sample_rate=float(os.environ.get("SENTRY_TRACES", "0")),
                    environment=os.environ.get("SENTRY_ENV", "production"))
    return True


def _clip(v, n):
    return (v if isinstance(v, str) else "")[:n]


def _clean_path(v):
    p = _clip(v, 300).split("?")[0].split("#")[0]
    return re.sub(r"https?://[^/]+", "", p) or "/"


def register(app, admin_only, pub_dir):
    @app.post("/api/client-error")
    def client_error():
        if too_many("client-error", client_ip(request), 30, 3600):
            return jsonify(ok=True), 202  # silently drop; a noisy page must not turn into a flood
        d = request.get_json(silent=True) or {}
        msg = _clip(d.get("message"), 300).strip()
        if not msg:
            return jsonify(ok=True), 202
        stack, page, src = _clip(d.get("stack"), 1500), _clean_path(d.get("page")), _clean_path(d.get("source"))
        fp = hashlib.sha256(f"{msg}|{src}|{d.get('line')}|{page}".encode()).hexdigest()[:24]
        now = int(time.time())
        with db() as c:
            if c.execute("UPDATE client_errors SET count=count+1,last_seen=? WHERE fp=?", (now, fp)).rowcount == 0:
                c.execute("INSERT INTO client_errors(fp,message,stack,page,source,first_seen,last_seen) VALUES(?,?,?,?,?,?,?)",
                          (fp, msg, stack, page, src, now, now))
                c.execute("DELETE FROM client_errors WHERE last_seen<?", (now - KEEP_DAYS * 86400,))
                c.execute("DELETE FROM client_errors WHERE id IN (SELECT id FROM client_errors ORDER BY last_seen DESC LIMIT -1 OFFSET ?)", (MAX_ROWS,))
        log.warning("browser error on %s: %s", page, msg)
        return jsonify(ok=True), 202

    @app.get("/api/admin/errors")
    @admin_only
    def errors_list():
        rows = db().execute("SELECT message,stack,page,source,count,first_seen,last_seen FROM client_errors ORDER BY last_seen DESC LIMIT 200")
        return jsonify(errors=[dict(r) for r in rows])

    def page(name, status):
        r = send_from_directory(pub_dir, name)
        r.status_code = status
        r.headers["Cache-Control"] = "no-store"
        r.headers["X-Robots-Tag"] = "noindex"
        return r

    @app.errorhandler(404)
    def not_found(e):
        if request.path.startswith("/api/"):
            return jsonify(error="Not found."), 404
        return page("404.html", 404)

    @app.errorhandler(Exception)
    def boom(e):
        if isinstance(e, HTTPException):
            if e.code and e.code < 500:
                if request.path.startswith("/api/"):
                    return jsonify(error=e.description or e.name), e.code
                return e
        else:
            app.logger.exception("unhandled error on %s", request.path)
            try:
                import sentry_sdk; sentry_sdk.capture_exception(e)  # no-op unless init_sentry() ran
            except ImportError:
                pass
        if request.path.startswith("/api/"):
            return jsonify(error="Something went wrong on our side. Please try again."), 500
        try:
            return page("500.html", 500)
        except Exception:
            return Response("Something went wrong. Please try again in a moment.", 500, mimetype="text/plain")
