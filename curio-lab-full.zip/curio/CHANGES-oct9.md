# Added: study rooms and report/moderation tools
- Rooms tab (Community): live study rooms with a server-synced Pomodoro timer, presets (25/5, 50/10, 15/3), invite code or group-linked, presence, preset "working on" list, 5 emoji cheers, optional sound, tab title countdown. Host: start/pause/resume/skip/stop, settings, lock, remove, new code, close.
- Report dialog (js/report-dialog.js) replaces the browser prompt() for profiles, lesson posts, study groups and rooms: 7 categories + optional note, keyboard/focus-trap accessible.
- Notices: learners see moderator messages (warnings, hidden/restored/removed content, outcome of their reports) in a banner on the Community page; `/me` carries `notices` and `muted_until`.
- Admin > Community: unified moderation queue, warn / mute / unmute / history, live room list with close/reopen/delete. Older report tables kept under "All individual reports".
- Backend: backend/rooms.py, backend/moderation.py; small hooks in discuss.py, community.py, app.py. DB: new tables cm_rooms, cm_room_members, cm_room_bans, cm_room_reacts, cm_mod_actions, cm_notices; new columns `category`, `outcome` on both report tables (added automatically on start).
- Also: privacy page, changelog (Phase 27), Hindi/Bengali labels (need review), sw.js cache curio-v9.
- Tests: backend/tests/check_rooms_moderation.py (123 checks); check_community, check_discuss, check_hardening, check_certificates_coppa still pass.
- Not browser-tested here: the new front-end JS passed syntax checks only. Click through Rooms and the report dialog once on a real device before shipping.
- Mute also covers editing display name and bio (avatar and visibility stay allowed).
